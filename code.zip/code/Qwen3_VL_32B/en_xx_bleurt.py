#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import argparse

# =====================================================
# 0. 命令行参数：必须在导入 bleurt / tensorflow 前设置 GPU
# =====================================================

VG_LANGUAGES = {"hi", "ha", "bn", "ma"}
MULTI30K_LANGUAGES = {"hi", "lv", "tr"}
ALL_LANGUAGES = VG_LANGUAGES | MULTI30K_LANGUAGES

DATA_DIR_NAME = {
    "vg": "VG",
    "multi30k": "Multi30k",
}


def parse_args():
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--data",
        type=str,
        required=True,
        choices=["vg", "multi30k"],
        help="Dataset name: vg or multi30k.",
    )

    parser.add_argument(
        "--lang",
        type=str,
        required=True,
        choices=sorted(ALL_LANGUAGES),
        help="Target language code. VG: bn, ha, hi, ma. Multi30K: hi, lv, tr.",
    )

    parser.add_argument(
        "--gpu",
        type=str,
        required=True,
        help="Physical GPU id, for example: 0, 1, 5, 6, 7.",
    )

    return parser.parse_args()


ARGS = parse_args()

DATASET = ARGS.data.strip().lower()
LANGUAGE = ARGS.lang.strip().lower()
GPU = str(ARGS.gpu).strip()

if DATASET == "vg" and LANGUAGE not in VG_LANGUAGES:
    raise ValueError(
        f"--data vg only supports languages: {sorted(VG_LANGUAGES)}, "
        f"but got --lang {LANGUAGE}"
    )

if DATASET == "multi30k" and LANGUAGE not in MULTI30K_LANGUAGES:
    raise ValueError(
        f"--data multi30k only supports languages: {sorted(MULTI30K_LANGUAGES)}, "
        f"but got --lang {LANGUAGE}"
    )

DATA_OUTPUT_NAME = DATA_DIR_NAME[DATASET]

os.environ["CUDA_VISIBLE_DEVICES"] = GPU
os.environ["TOKENIZERS_PARALLELISM"] = "false"

# TensorFlow / BLEURT 显存更稳一点
os.environ["TF_FORCE_GPU_ALLOW_GROWTH"] = "true"

import json
from statistics import mean
from typing import List, Dict, Any, Tuple

from bleurt import score as bleurt_score


# =====================================================
# 1. 路径配置
# =====================================================

ROOT_BASE = "/home/chenyi/offline_blaser_qe/out/Qwen3_VL_32B"

BLEURT_CHECKPOINT = "/mnt/raid/gzy/bleurt_model/BLEURT-20"

# 每批打分数量，显存不足时可以调小
BATCH_SIZE = 32

REFERENCE_FIELD = "reference_translation"

# En -> xx 图文直接翻译字段
CANDIDATE_FIELD_PRIMARY = f"direct_translation_{LANGUAGE}"
CANDIDATE_FIELD_FALLBACK = f"initial_translation_{LANGUAGE}"

# 兼容旧字段：有些生成程序会把目标语言译文同时写入 direct_translation_en / initial_translation_en
LEGACY_CANDIDATE_FIELD_PRIMARY = "direct_translation_en"
LEGACY_CANDIDATE_FIELD_FALLBACK = "initial_translation_en"


def build_paths() -> Tuple[str, str, str]:
    root_dir = os.path.join(
        ROOT_BASE,
        DATA_OUTPUT_NAME,
        LANGUAGE,
    )

    input_jsonl = os.path.join(
        root_dir,
        f"en_{LANGUAGE}_image_text_direct_translation.jsonl",
    )

    output_jsonl = os.path.join(
        root_dir,
        f"en_{LANGUAGE}_image_text_direct_translation_bleurt.jsonl",
    )

    return root_dir, input_jsonl, output_jsonl


ROOT_DIR, INPUT_JSONL, OUTPUT_JSONL = build_paths()


# =====================================================
# 2. 基础工具
# =====================================================

def clean_text(x: Any) -> str:
    if x is None:
        return ""
    return str(x).strip()


def first_non_empty(row: Dict[str, Any], fields: List[str]) -> Tuple[str, str]:
    for field in fields:
        value = clean_text(row.get(field, ""))
        if value:
            return value, field
    return "", ""


def read_jsonl(path: str) -> List[Dict[str, Any]]:
    if not os.path.exists(path):
        raise FileNotFoundError(f"找不到输入文件: {path}")

    rows = []

    with open(path, "r", encoding="utf-8") as f:
        for line_no, line in enumerate(f, 1):
            line = line.strip()

            if not line:
                continue

            try:
                row = json.loads(line)
            except Exception as e:
                raise ValueError(f"第 {line_no} 行不是合法 JSON: {e}")

            if row.get("record_type") == "summary":
                continue

            if str(row.get("id", "")).strip() in {"AVERAGE_SCORE", "__average__"}:
                continue

            rows.append(row)

    return rows


def write_jsonl(path: str, rows: List[Dict[str, Any]]) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)

    with open(path, "w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


def get_row_id(row: Dict[str, Any], fallback_idx: int) -> str:
    for key in ["id", "image_id", "qid", "question_id"]:
        value = clean_text(row.get(key, ""))
        if value:
            return value
    return str(fallback_idx)


# =====================================================
# 3. BLEURT 打分
# =====================================================

def compute_bleurt_scores(
    scorer,
    references: List[str],
    candidates: List[str],
    batch_size: int = 32,
) -> List[float]:
    all_scores = []
    total = len(references)

    for start in range(0, total, batch_size):
        end = min(start + batch_size, total)

        refs_batch = references[start:end]
        cands_batch = candidates[start:end]

        scores = scorer.score(
            references=refs_batch,
            candidates=cands_batch,
        )

        all_scores.extend(scores)

        print(f"[INFO] BLEURT scored {end}/{total}", flush=True)

    return all_scores


# =====================================================
# 4. 主流程
# =====================================================

def main():
    os.makedirs(ROOT_DIR, exist_ok=True)

    print("========== Runtime Config ==========")
    print(f"[INFO] TASK_DIRECTION: English_to_{LANGUAGE}")
    print(f"[INFO] ROOT_BASE: {ROOT_BASE}")
    print(f"[INFO] DATASET: {DATASET}")
    print(f"[INFO] DATA_OUTPUT_NAME: {DATA_OUTPUT_NAME}")
    print(f"[INFO] LANGUAGE: {LANGUAGE}")
    print(f"[INFO] GPU: {GPU}")
    print(f"[INFO] CUDA_VISIBLE_DEVICES: {os.environ.get('CUDA_VISIBLE_DEVICES')}")
    print(f"[INFO] INPUT_JSONL: {INPUT_JSONL}")
    print(f"[INFO] OUTPUT_JSONL: {OUTPUT_JSONL}")
    print(f"[INFO] REFERENCE_FIELD: {REFERENCE_FIELD}")
    print(f"[INFO] CANDIDATE_FIELD_PRIMARY: {CANDIDATE_FIELD_PRIMARY}")
    print(f"[INFO] CANDIDATE_FIELD_FALLBACK: {CANDIDATE_FIELD_FALLBACK}")
    print(f"[INFO] LEGACY_CANDIDATE_FIELD_PRIMARY: {LEGACY_CANDIDATE_FIELD_PRIMARY}")
    print(f"[INFO] LEGACY_CANDIDATE_FIELD_FALLBACK: {LEGACY_CANDIDATE_FIELD_FALLBACK}")
    print(f"[INFO] BLEURT_CHECKPOINT: {BLEURT_CHECKPOINT}")
    print(f"[INFO] BATCH_SIZE: {BATCH_SIZE}")
    print("====================================")

    rows = read_jsonl(INPUT_JSONL)

    print(f"[INFO] 读取样本数: {len(rows)}")

    if not rows:
        raise ValueError("输入文件为空，无法打分。")

    references = []
    candidates = []
    valid_rows = []
    skipped_rows = []

    candidate_fields = [
        CANDIDATE_FIELD_PRIMARY,
        CANDIDATE_FIELD_FALLBACK,
        LEGACY_CANDIDATE_FIELD_PRIMARY,
        LEGACY_CANDIDATE_FIELD_FALLBACK,
    ]

    for idx, row in enumerate(rows, start=1):
        row_id = get_row_id(row, fallback_idx=idx)

        ref = clean_text(row.get(REFERENCE_FIELD, ""))

        hyp, hyp_field_used = first_non_empty(
            row,
            candidate_fields,
        )

        if not ref or not hyp:
            skipped_rows.append({
                "id": row_id,
                "reason": "empty_reference_or_candidate",
                "reference_translation": ref,
                "candidate_translation": hyp,
                "reference_field": REFERENCE_FIELD,
                "candidate_field_used": hyp_field_used,
            })
            continue

        references.append(ref)
        candidates.append(hyp)
        valid_rows.append((row, hyp, hyp_field_used, row_id))

    print(f"[INFO] 有效打分样本数: {len(valid_rows)}")
    print(f"[INFO] 跳过样本数: {len(skipped_rows)}")

    if not valid_rows:
        raise ValueError(
            f"没有有效样本：{REFERENCE_FIELD} 或 "
            f"{candidate_fields} 全为空。"
        )

    print(f"[INFO] 正在加载 BLEURT 模型: {BLEURT_CHECKPOINT}")

    if not os.path.exists(BLEURT_CHECKPOINT):
        raise FileNotFoundError(f"找不到 BLEURT 模型路径: {BLEURT_CHECKPOINT}")

    scorer = bleurt_score.BleurtScorer(BLEURT_CHECKPOINT)

    print("[INFO] BLEURT 模型加载完成。")
    print("[INFO] 开始 BLEURT 打分...")

    scores_raw = compute_bleurt_scores(
        scorer=scorer,
        references=references,
        candidates=candidates,
        batch_size=BATCH_SIZE,
    )

    scored_rows = []

    for (row, hyp, hyp_field_used, row_id), score in zip(valid_rows, scores_raw):
        out = {
            "id": row_id,
            "data": DATASET,
            "data_output_name": DATA_OUTPUT_NAME,
            "translation_direction": f"English_to_{LANGUAGE}",
            "language": LANGUAGE,

            "source_text": clean_text(row.get("source_text", "")),
            "reference_translation": clean_text(row.get(REFERENCE_FIELD, "")),

            "candidate_field_used": hyp_field_used,
            "candidate_translation": clean_text(hyp),

            CANDIDATE_FIELD_PRIMARY: clean_text(row.get(CANDIDATE_FIELD_PRIMARY, "")),
            CANDIDATE_FIELD_FALLBACK: clean_text(row.get(CANDIDATE_FIELD_FALLBACK, "")),
            LEGACY_CANDIDATE_FIELD_PRIMARY: clean_text(row.get(LEGACY_CANDIDATE_FIELD_PRIMARY, "")),
            LEGACY_CANDIDATE_FIELD_FALLBACK: clean_text(row.get(LEGACY_CANDIDATE_FIELD_FALLBACK, "")),

            "bleurt_raw": round(float(score), 6),
            "bleurt_100": round(float(score) * 100, 2),
        }

        scored_rows.append(out)

    avg_raw = mean([float(x) for x in scores_raw])
    avg_100 = avg_raw * 100

    summary_row = {
        "record_type": "summary",
        "id": "__average__",

        "data": DATASET,
        "data_output_name": DATA_OUTPUT_NAME,
        "translation_direction": f"English_to_{LANGUAGE}",
        "language": LANGUAGE,

        "input_jsonl": INPUT_JSONL,
        "output_jsonl": OUTPUT_JSONL,

        "reference_field": REFERENCE_FIELD,
        "candidate_field_primary": CANDIDATE_FIELD_PRIMARY,
        "candidate_field_fallback": CANDIDATE_FIELD_FALLBACK,
        "legacy_candidate_field_primary": LEGACY_CANDIDATE_FIELD_PRIMARY,
        "legacy_candidate_field_fallback": LEGACY_CANDIDATE_FIELD_FALLBACK,

        "total_rows": len(rows),
        "valid_scored_rows": len(valid_rows),
        "skipped_rows": len(skipped_rows),

        "average_bleurt_raw": round(float(avg_raw), 6),
        "average_bleurt_100": round(float(avg_100), 2),
    }

    scored_rows.append(summary_row)

    write_jsonl(OUTPUT_JSONL, scored_rows)

    print("\n[DONE] BLEURT 打分完成。")
    print(f"[RESULT] translation_direction = English_to_{LANGUAGE}")
    print(f"[RESULT] data = {DATASET}")
    print(f"[RESULT] data_output_name = {DATA_OUTPUT_NAME}")
    print(f"[RESULT] language = {LANGUAGE}")
    print(f"[RESULT] total rows = {len(rows)}")
    print(f"[RESULT] valid scored rows = {len(valid_rows)}")
    print(f"[RESULT] skipped rows = {len(skipped_rows)}")
    print(f"[RESULT] average BLEURT raw = {avg_raw:.6f}")
    print(f"[RESULT] average BLEURT x100 = {avg_100:.2f}")
    print(f"[SAVE] JSONL: {OUTPUT_JSONL}")

    if skipped_rows:
        print("[WARN] 存在跳过样本，原因多为 reference_translation 或候选译文为空。")


if __name__ == "__main__":
    main()