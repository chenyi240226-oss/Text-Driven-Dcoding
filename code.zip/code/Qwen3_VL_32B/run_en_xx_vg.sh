#!/bin/bash
set -e


source /home/chenyi/venvs/qwen3_vl_env/bin/activate
cd /home/chenyi/offline_blaser_qe/code/Qwen3_VL_32B


python text_only_and_image_prior.py --data vg --lang hi --gpu 7
python text_only_and_image_prior.py --data vg --lang ha --gpu 7
python text_only_and_image_prior.py --data vg --lang bn --gpu 7
python text_only_and_image_prior.py --data vg --lang ma --gpu 7


# for alpha in 0.1 0.3 0.5 0.7 0.9
# do
#     echo "Running alpha: $lalpha"
#     python en_xx_contract_decoding.py --data multi30k --lang lv --gpu 1 --alpha $alpha
#     python en_xx_contract_decoding.py --data multi30k --lang tr --gpu 1 --alpha $alpha
#     python en_xx_contract_decoding.py --data multi30k --lang hi --gpu 1 --alpha $alpha
   
#     echo "Finished language: $alpha"
# done

# for alpha in  0.05  
# do
#     echo "Running alpha: $lalpha"
#     # python en_xx_contract_decoding.py --data vg --lang bn --gpu 1 --alpha $alpha
#     # python en_xx_contract_decoding.py --data vg --lang ha --gpu 1 --alpha $alpha
#     python en_xx_contract_decoding.py --data vg --lang hi --gpu 1 --alpha $alpha
#     # python en_xx_contract_decoding.py --data vg --lang ma --gpu 1 --alpha $alpha
#     echo "Finished language: $alpha"
# done
echo "All  finished."