#!/bin/bash
set -e


source /home/chenyi/venvs/qwen3_vl_env/bin/activate
cd /home/chenyi/offline_blaser_qe/code/Qwen3_VL_32B




# python en_xx_direct_both.py --data vg --lang ha --gpu 3 
# python en_xx_direct_both.py --data vg --lang hi --gpu 3 
# python en_xx_direct_both.py --data vg --lang ma --gpu 3 
# python en_xx_direct_both.py --data vg --lang bn --gpu 3 


# python en_xx_direct_both.py --data multi30k --lang lv --gpu 3 
# python en_xx_direct_both.py --data multi30k --lang tr --gpu 3 
python en_xx_direct_both.py --data multi30k --lang hi --gpu 3



echo "All  finished."