#!/bin/bash
set -e


source /home/chenyi/venvs/qwen3_vl_env/bin/activate
cd /home/chenyi/offline_blaser_qe/code/Qwen3_VL_32B


for alpha in  0.3
do
    echo "Running alpha: $lalpha"
    python en_xx_contract_decoding.py --data multi30k --lang lv --gpu 5 --alpha $alpha
    python en_xx_contract_decoding.py --data multi30k --lang tr --gpu 5 --alpha $alpha
    python en_xx_contract_decoding.py --data multi30k --lang hi --gpu 5 --alpha $alpha
   
    echo "Finished language: $alpha"
done

for alpha in 0.3 
do
    echo "Running alpha: $lalpha"
    python en_xx_contract_decoding.py --data vg --lang bn --gpu 5 --alpha $alpha
    python en_xx_contract_decoding.py --data vg --lang ha --gpu 5 --alpha $alpha
    python en_xx_contract_decoding.py --data vg --lang hi --gpu 5 --alpha $alpha
    python en_xx_contract_decoding.py --data vg --lang ma --gpu 5 --alpha $alpha
    echo "Finished language: $alpha"
done
echo "All  finished."