#!/bin/bash
set -e

source /home/guozhengyi/anaconda3/envs/evaluate/bin/activate
cd /home/chenyi/offline_blaser_qe/code/Qwen3_VL_8B

python score_text_only_image_prior.py --model qwen3_vl_32b --data vg --lang ha --gpu 5
python score_text_only_image_prior.py --model qwen3_vl_32b --data vg --lang bn --gpu 5
python score_text_only_image_prior.py --model qwen3_vl_32b --data vg --lang hi --gpu 5
python score_text_only_image_prior.py --model qwen3_vl_32b --data vg --lang ma --gpu 5


python score_text_only_image_prior.py --model qwen3_vl_32b --data multi30k --lang hi --gpu 5
python score_text_only_image_prior.py --model qwen3_vl_32b --data multi30k --lang lv --gpu 5
python score_text_only_image_prior.py --model qwen3_vl_32b --data multi30k --lang tr --gpu 5


echo "All  finished."





# python eval_en_xx_direct.py --data vg --lang ha --gpu 2 
# python eval_en_xx_direct.py --data vg --lang hi --gpu 2 
# python eval_en_xx_direct.py --data vg --lang ma --gpu 2 
# python eval_en_xx_direct.py --data vg --lang bn --gpu 2 

# python eval_en_xx_direct.py --data multi30k --lang lv --gpu 2 
# python eval_en_xx_direct.py --data multi30k --lang tr --gpu 2 
# python eval_en_xx_direct.py --data multi30k --lang hi --gpu 2 



# for alpha in 0.25 0.3
# do
#     echo "Running alpha: $lalpha"
    
#     python eval_en_xx_best.py --data vg --lang hi --gpu 1 --alpha $alpha
#     python eval_en_xx_best.py --data vg --lang ha --gpu 1 --alpha $alpha
   
#     python eval_en_xx_best.py --data vg --lang ma --gpu 1 --alpha $alpha
#     python eval_en_xx_best.py --data vg --lang bn --gpu 1 --alpha $alpha
#     echo "Finished language: $alpha"
# done

# for alpha in 0.25 0.3
# do
#     echo "Running alpha: $lalpha"
#     python eval_en_xx_best.py --data multi30k --lang lv --gpu 1 --alpha $alpha
#     python eval_en_xx_best.py --data multi30k --lang tr --gpu 1 --alpha $alpha
#     python eval_en_xx_best.py --data multi30k --lang hi --gpu 1 --alpha $alpha
   
#     echo "Finished language: $alpha"
# done

echo "All  finished."