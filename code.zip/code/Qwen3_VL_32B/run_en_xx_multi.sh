#!/bin/bash
set -e


source /home/chenyi/venvs/qwen3_vl_env/bin/activate
cd /home/chenyi/offline_blaser_qe/code/Qwen3_VL_32B


python text_only_and_image_prior.py --data multi30k --lang hi --gpu 6
python text_only_and_image_prior.py --data multi30k --lang lv --gpu 6
python text_only_and_image_prior.py --data multi30k --lang tr --gpu 6


# for alpha in 0.1 
# do
#     echo "Running alpha: $lalpha"
#     # python en_xx_contract_decoding.py --data multi30k --lang lv --gpu 7 --alpha $alpha
#     # python en_xx_contract_decoding.py --data multi30k --lang tr --gpu 7 --alpha $alpha
#     python en_xx_contract_decoding.py --data multi30k --lang hi --gpu 4 --alpha $alpha
   
#     echo "Finished language: $alpha"
# done

# for alpha in 0.01 0.03 0.05 0.07 0.09
# do
#     echo "Running alpha: $lalpha"
#     python en_xx_contract_decoding.py --data vg --lang bn --gpu 1 --alpha $alpha
#     python en_xx_contract_decoding.py --data vg --lang ha --gpu 1 --alpha $alpha
#     python en_xx_contract_decoding.py --data vg --lang hi --gpu 1 --alpha $alpha
#     python en_xx_contract_decoding.py --data vg --lang ma --gpu 1 --alpha $alpha
#     echo "Finished language: $alpha"
# done
echo "All  finished."