import os
os.environ["CUDA_VISIBLE_DEVICES"] = "1"
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"

import re
import json
import time
from typing import Dict, List, Optional, Tuple

from PIL import Image

import torch
from transformers import AutoProcessor, Qwen2VLForConditionalGeneration

torch.set_grad_enabled(False)

# =========================
# PATH
# =========================
MODEL_PATH = "/mnt/raid/hss/model/Qwen2-VL-7B-Instruct"
INPUT_JSONL = "/home/chenyi/offline_blaser_qe/out/VG/ha/ha_detect_span.jsonl"
OUTPUT_JSONL = "/home/chenyi/offline_blaser_qe/out/VG/ha/ha_candidates_from_span.jsonl"

MAX_ROWS = None

# =========================
# LOAD MODEL
# =========================
print("Loading model...")
processor = AutoProcessor.from_pretrained(MODEL_PATH, trust_remote_code=True)
model = Qwen2VLForConditionalGeneration.from_pretrained(
    MODEL_PATH,
    torch_dtype=torch.bfloat16,
    device_map="auto",
    trust_remote_code=True
).eval()
tokenizer = processor.tokenizer

# =========================
# UTIL
# =========================
def format_time(sec: float) -> str:
    sec = int(sec)
    return f"{sec//3600:02d}:{(sec%3600)//60:02d}:{sec%60:02d}"

def load_image(path: str) -> Optional[Image.Image]:
    if not path or not os.path.isfile(path):
        return None
    try:
        return Image.open(path).convert("RGB")
    except Exception:
        return None

def clean_text(s: str) -> str:
    if s is None:
        return ""
    s = str(s).strip()
    s = re.sub(r"\s+", " ", s)
    return s

def simple_post_clean(text: str) -> str:
    text = clean_text(text)
    return text.strip(' "\'')

def normalize_token(text: str) -> str:
    text = text.lower().strip()
    text = re.sub(r"[^a-z0-9\- ]", "", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()

def tokenize_words(text: str) -> List[str]:
    return re.findall(r"[A-Za-z0-9\-]+", clean_text(text).lower())

def deduplicate_keep_order(items: List[str]) -> List[str]:
    out = []
    seen = set()
    for x in items:
        x = simple_post_clean(x)
        if not x:
            continue
        k = x.lower()
        if k in seen:
            continue
        seen.add(k)
        out.append(x)
    return out

def titlecase_first(text: str) -> str:
    text = simple_post_clean(text)
    if not text:
        return text
    return text[0].upper() + text[1:]

def normalize_sentence(text: str) -> str:
    text = clean_text(text)
    if not text:
        return ""
    text = titlecase_first(text)
    return text.rstrip(".") + "."

def contains_whole_phrase(text: str, phrase: str) -> bool:
    text_n = normalize_token(text)
    phrase_n = normalize_token(phrase)
    if not text_n or not phrase_n:
        return False
    return re.search(rf"\b{re.escape(phrase_n)}\b", text_n) is not None

def content_overlap_ratio(a: str, b: str) -> float:
    wa = set(tokenize_words(a))
    wb = set(tokenize_words(b))
    if not wa or not wb:
        return 0.0
    inter = len(wa & wb)
    return inter / max(1, len(wa | wb))

# =========================
# BASIC FILTERS
# =========================
BAD_FRAGMENT_PATTERNS = [
    r"^there are in\b",
    r"^a between\b",
    r"^a wearing\b",
    r"^the someone\b",
    r"^there white\b",
    r"^a woman wearing a\.?$",
    r"^a man is\.?$",
    r"^(is|are|was|were|be|been|being)\b",
    r"^(on|in|at|by|with|from|to|between)\b",
    r"^(a|an|the)\s+(on|in|at|by|with|from|to|between)\b",
]

CONTENT_STOPWORDS = {
    "a", "an", "the", "is", "are", "was", "were", "be", "been", "being",
    "to", "of", "in", "on", "at", "by", "with", "from", "for", "into",
    "onto", "over", "under", "there", "here", "this", "that", "these",
    "those", "and", "or", "but", "as", "it", "its", "their", "his", "her",
    "has", "have", "had", "very", "just", "also", "still"
}

SUBJECT_HINTS = {
    "man", "woman", "person", "people", "girl", "boy", "child", "children",
    "dog", "cat", "bird", "zebra", "horse", "giraffe", "bear", "elephant",
    "airplane", "plane", "train", "bus", "car", "bench", "sign", "tower",
    "building", "window", "clock", "table", "plate", "donut", "doughnut",
    "helmet", "motorcycle", "kite", "frisbee", "controller", "monitor",
    "cone", "light"
}

def sanitize_candidate_surface(text: str) -> str:
    text = clean_text(text)
    if not text:
        return ""

    toks = text.split()
    if toks:
        out = [toks[0]]
        for tok in toks[1:]:
            if normalize_token(tok) == normalize_token(out[-1]):
                continue
            out.append(tok)
        text = " ".join(out)

    text = re.sub(r"\s+", " ", text).strip()
    text = re.sub(r"\s+([,.;:!?])", r"\1", text)
    return normalize_sentence(text)

def extract_content_words(text: str) -> set:
    out = set()
    for w in tokenize_words(text):
        nw = normalize_token(w)
        if not nw or nw in CONTENT_STOPWORDS or len(nw) <= 1:
            continue
        out.add(nw)
    return out

def is_fragment_candidate(text: str) -> bool:
    text = clean_text(text)
    if not text:
        return True

    low = text.lower().strip()
    words = tokenize_words(text)

    if not words:
        return True

    if any(re.match(p, low) for p in BAD_FRAGMENT_PATTERNS):
        return True

    if low.endswith((" a", " an", " the", " of", " in", " on", " to", " with", " by", " from", " between")):
        return True

    if len(words) == 1:
        return True

    if len(words) == 2 and words[0] in {"a", "an", "the"}:
        return True

    if len(words) <= 3 and len(extract_content_words(text)) <= 1:
        return True

    return False

def has_bad_repetition(text: str) -> bool:
    t = normalize_token(text)
    bad_patterns = [
        "a a ", "the the ", "an an ", "of of ", "to to ",
        "is is ", "are are ", "in the in the", "on the on the"
    ]
    return any(p in t for p in bad_patterns)

def has_unsupported_new_content(
    candidate: str,
    initial_translation: str,
    local_evidence: Optional[Dict] = None
) -> bool:
    candidate = clean_text(candidate)
    initial_translation = clean_text(initial_translation)

    if not candidate:
        return False

    cand_words = extract_content_words(candidate)
    init_words = extract_content_words(initial_translation)

    evidence_words = set()
    if isinstance(local_evidence, dict):
        evidence_words |= extract_content_words(clean_text(local_evidence.get("visual_evidence", "")))
        evidence_words |= extract_content_words(clean_text(local_evidence.get("corrected_part", "")))
        evidence_words |= extract_content_words(clean_text(local_evidence.get("target_span", "")))

    new_words = cand_words - init_words - evidence_words
    dropped_words = init_words - cand_words

    if len(new_words) >= 2:
        return True

    if len(new_words) >= 1 and len(dropped_words) >= 1 and content_overlap_ratio(candidate, initial_translation) < 0.60:
        return True

    return False

# =========================
# COMPLETE-SENTENCE DETECTION
# =========================
def looks_like_complete_sentence_candidate(text: str) -> bool:
    text = clean_text(text)
    if not text:
        return False

    words = tokenize_words(text)
    if len(words) < 3:
        return False

    low = text.lower()

    if text.endswith("."):
        return True

    if re.match(r"^(there|this|that|these|those|it|people|someone|somebody)\b", low):
        return True

    if re.match(r"^(a|an|the)\s+\w+", low) and len(words) >= 4:
        return True

    return False

# =========================
# LLM VALIDATOR
# =========================
def run_text_json(prompt: str, max_new_tokens: int = 180) -> str:
    messages = [{"role": "user", "content": [{"type": "text", "text": prompt}]}]
    text = processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    inputs = processor(text=[text], return_tensors="pt")
    inputs = {k: v.to(model.device) for k, v in inputs.items()}

    with torch.no_grad():
        out = model.generate(
            **inputs,
            do_sample=False,
            max_new_tokens=max_new_tokens,
            repetition_penalty=1.02,
            pad_token_id=tokenizer.eos_token_id,
        )

    gen = out[:, inputs["input_ids"].shape[1]:]
    return processor.batch_decode(gen, skip_special_tokens=True)[0]

def extract_first_json(raw: str) -> Dict:
    raw = clean_text(raw)
    candidates = re.findall(r"\{.*\}", raw, flags=re.DOTALL)
    for c in candidates:
        try:
            return json.loads(c)
        except Exception:
            continue
    return {}

def llm_validate_fluency(candidate: str) -> Tuple[bool, str]:
    candidate = clean_text(candidate)
    if not candidate:
        return False, "empty"

    if is_fragment_candidate(candidate):
        return False, "rule_fragment"
    if has_bad_repetition(candidate):
        return False, "rule_repetition"

    prompt = f"""
You are an English sentence validator.

Task:
Judge whether the sentence is a complete, fluent, grammatical English sentence.

Rules:
- Reject fragments, broken phrases, duplicated starts, missing subject, missing predicate, or clearly malformed output.
- Accept short noun phrases only if they are natural image-caption style expressions.
- Return JSON only.

Return JSON ONLY:
{{
  "valid": true,
  "reason": "..."
}}

Sentence:
{candidate}
""".strip()

    try:
        raw = run_text_json(prompt, max_new_tokens=80)
        obj = extract_first_json(raw)
        if isinstance(obj, dict) and "valid" in obj:
            return bool(obj.get("valid", False)), clean_text(obj.get("reason", ""))
    except Exception:
        pass

    return False, "validator_parse_failed"

# =========================
# REPAIR
# =========================
def infer_subject_from_visual_evidence(
    initial_translation: str,
    local_evidence: Optional[Dict]
) -> str:
    candidates = []

    if isinstance(local_evidence, dict):
        ve = clean_text(local_evidence.get("visual_evidence", ""))
        candidates.extend(tokenize_words(ve))

    candidates.extend(tokenize_words(initial_translation))

    for w in candidates:
        nw = normalize_token(w)
        if nw in SUBJECT_HINTS:
            if nw == "people":
                return "People"
            return titlecase_first(nw)

    return "It"

def replace_span_once(text: str, target_span: str, replacement: str) -> str:
    text = clean_text(text)
    target_span = clean_text(target_span)
    replacement = clean_text(replacement)

    if not text or not target_span:
        return text

    pattern = re.compile(re.escape(target_span), flags=re.IGNORECASE)
    new_text, n = pattern.subn(replacement, text, count=1)
    if n == 0:
        return text

    new_text = re.sub(r"\s+", " ", new_text).strip()
    new_text = re.sub(r"\s+([,.;:!?])", r"\1", new_text)
    return normalize_sentence(new_text)

def repair_by_direct_replacement_or_keep(
    initial_translation: str,
    target_span: str,
    corrected_part: str,
    local_evidence: Optional[Dict] = None
) -> str:
    initial_translation = normalize_sentence(initial_translation)
    target_span = clean_text(target_span)
    corrected_part = clean_text(corrected_part)

    if not initial_translation:
        return ""

    if not target_span:
        return initial_translation

    if not corrected_part:
        return initial_translation

    if looks_like_complete_sentence_candidate(corrected_part):
        return sanitize_candidate_surface(corrected_part)

    replaced = replace_span_once(initial_translation, target_span, corrected_part)
    replaced = sanitize_candidate_surface(replaced)

    if replaced and not is_fragment_candidate(replaced):
        return replaced

    subject = infer_subject_from_visual_evidence(initial_translation, local_evidence)
    low = clean_text(replaced).lower()

    if re.match(r"^(is|are|was|were|on|in|at|with|from|to|between)\b", low):
        return sanitize_candidate_surface(f"{subject} {replaced}")

    if re.match(r"^(a|an|the)\s+(wearing|standing|sitting|lying|jumping|climbing|holding|reading)\b", low):
        return sanitize_candidate_surface(f"{subject} {replaced.split(None, 1)[1]}") if len(replaced.split()) > 1 else initial_translation

    return initial_translation

# =========================
# HALLUCINATION MODES
# =========================
def get_hallucination_mode(hallucination_analysis: Dict) -> str:
    primary_type = clean_text(hallucination_analysis.get("primary_type", ""))
    target_span = clean_text(hallucination_analysis.get("target_hallucination_span", ""))

    if primary_type == "faithful" or not target_span:
        return "no_hallucination"

    if primary_type == "object_head_shift":
        return "general_correct"

    if primary_type == "extra_content":
        return "delete_only"
    if primary_type in {"attribute_color", "attribute_number", "semantic_refinement"}:
        return "replace_or_correct"
    return "general_correct"

# =========================
# PROMPTS
# =========================
def build_candidate_prompt(source_text: str, initial_translation: str, hallucination_analysis: Dict) -> str:
    primary_type = clean_text(hallucination_analysis.get("primary_type", ""))
    target_span = clean_text(hallucination_analysis.get("target_hallucination_span", ""))

    return f"""
You are a multimodal translation correction system.

Task:
Correct the suspicious part conservatively.

Rules:
- You may output either a corrected local phrase or a complete corrected sentence.
- If a complete corrected sentence is safer and more grammatical, prefer the complete corrected sentence.
- Do not add unrelated scene details.
- Keep the rest of the translation unchanged as much as possible.

Return JSON ONLY:
{{
  "corrected_part_1": "...",
  "corrected_part_2": "...",
  "corrected_part_3": "...",
  "local_evidence": {{
    "target_span": "...",
    "corrected_part": "...",
    "visual_evidence": "..."
  }}
}}

Source sentence:
{source_text}

Current translation:
{initial_translation}

Suspicious type:
{primary_type}

Suspicious span:
{target_span}
""".strip()

# =========================
# MODEL CALL
# =========================
def run_multimodal_json(prompt: str, image: Optional[Image.Image], max_new_tokens: int = 220) -> str:
    content = []
    if image is not None:
        content.append({"type": "image", "image": image})
    content.append({"type": "text", "text": prompt})

    messages = [{"role": "user", "content": content}]
    text = processor.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True
    )

    if image is not None:
        inputs = processor(text=[text], images=[image], return_tensors="pt")
    else:
        inputs = processor(text=[text], return_tensors="pt")

    inputs = {k: v.to(model.device) for k, v in inputs.items()}

    with torch.no_grad():
        out = model.generate(
            **inputs,
            do_sample=False,
            max_new_tokens=max_new_tokens,
            repetition_penalty=1.02,
            pad_token_id=tokenizer.eos_token_id,
        )

    gen = out[:, inputs["input_ids"].shape[1]:]
    raw = processor.batch_decode(gen, skip_special_tokens=True)[0]
    return raw

def extract_json_block(raw: str) -> Dict:
    raw = str(raw).strip()
    candidates = re.findall(r"\{.*\}", raw, flags=re.DOTALL)
    for c in candidates:
        try:
            obj = json.loads(c)
            if all(k in obj for k in ["corrected_part_1", "corrected_part_2", "corrected_part_3"]):
                return obj
        except Exception:
            pass
    return {}

# =========================
# CANDIDATE BUILD / VALIDATE
# =========================
def build_raw_candidates_from_model_output(
    initial_translation: str,
    target_span: str,
    parsed: Dict
) -> List[str]:
    parts = [
        simple_post_clean(parsed.get("corrected_part_1", "")),
        simple_post_clean(parsed.get("corrected_part_2", "")),
        simple_post_clean(parsed.get("corrected_part_3", "")),
    ]

    out = []
    for p in parts:
        if not p:
            continue

        if looks_like_complete_sentence_candidate(p):
            out.append(sanitize_candidate_surface(p))
        else:
            out.append(sanitize_candidate_surface(replace_span_once(initial_translation, target_span, p)))

    return deduplicate_keep_order(out)

def validate_and_finalize_candidates(
    candidates: List[str],
    initial_translation: str,
    target_span: str,
    corrected_part: str,
    local_evidence: Optional[Dict] = None
) -> List[str]:
    out = []

    for cand in candidates:
        cand = sanitize_candidate_surface(cand)
        if not cand:
            cand = normalize_sentence(initial_translation)

        rule_ok = (
            not has_bad_repetition(cand)
            and not is_fragment_candidate(cand)
            and not has_unsupported_new_content(cand, initial_translation, local_evidence)
        )

        if not rule_ok:
            cand = repair_by_direct_replacement_or_keep(
                initial_translation=initial_translation,
                target_span=target_span,
                corrected_part=corrected_part,
                local_evidence=local_evidence
            )
            cand = sanitize_candidate_surface(cand)

        valid, _ = llm_validate_fluency(cand)
        if not valid:
            cand = repair_by_direct_replacement_or_keep(
                initial_translation=initial_translation,
                target_span=target_span,
                corrected_part=corrected_part,
                local_evidence=local_evidence
            )
            cand = sanitize_candidate_surface(cand)

            valid2, _ = llm_validate_fluency(cand)
            if not valid2:
                cand = normalize_sentence(initial_translation)

        out.append(cand)

    out = deduplicate_keep_order(out)
    if not out:
        out = [normalize_sentence(initial_translation)]

    while len(out) < 3:
        out.append(out[-1])

    out = lightly_make_distinct(out)
    return out[:3]

def parse_or_fallback(
    raw: str,
    initial_translation: str,
    hallucination_analysis: Dict
) -> Dict:
    mode = get_hallucination_mode(hallucination_analysis)

    if mode == "no_hallucination":
        base = normalize_sentence(initial_translation)
        return {
            "candidate_1": base,
            "candidate_2": base,
            "candidate_3": base,
            "local_evidence": {
                "target_span": "",
                "corrected_part": "",
                "visual_evidence": ""
            }
        }

    obj = extract_json_block(raw)
    if not obj:
        obj = {
            "corrected_part_1": "",
            "corrected_part_2": "",
            "corrected_part_3": "",
            "local_evidence": {
                "target_span": clean_text(hallucination_analysis.get("target_hallucination_span", "")),
                "corrected_part": "",
                "visual_evidence": ""
            }
        }

    local_evidence = obj.get("local_evidence", {})
    if not isinstance(local_evidence, dict):
        local_evidence = {}

    target_span = clean_text(local_evidence.get("target_span", "")) or clean_text(hallucination_analysis.get("target_hallucination_span", ""))
    corrected_part = clean_text(local_evidence.get("corrected_part", ""))

    raw_candidates = build_raw_candidates_from_model_output(
        initial_translation=initial_translation,
        target_span=target_span,
        parsed=obj
    )

    if not raw_candidates:
        raw_candidates = [normalize_sentence(initial_translation)]

    final_candidates = validate_and_finalize_candidates(
        candidates=raw_candidates,
        initial_translation=initial_translation,
        target_span=target_span,
        corrected_part=corrected_part,
        local_evidence=local_evidence
    )

    return {
        "candidate_1": final_candidates[0],
        "candidate_2": final_candidates[1],
        "candidate_3": final_candidates[2],
        "local_evidence": {
            "target_span": target_span,
            "corrected_part": corrected_part,
            "visual_evidence": clean_text(local_evidence.get("visual_evidence", "")),
        }
    }

# =========================
# JSONL
# =========================
def init_jsonl():
    os.makedirs(os.path.dirname(OUTPUT_JSONL), exist_ok=True)
    with open(OUTPUT_JSONL, "w", encoding="utf-8"):
        pass

def append_jsonl(record: Dict):
    with open(OUTPUT_JSONL, "a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")

# =========================
# MAIN
# =========================
def main():
    rows = []
    with open(INPUT_JSONL, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            rows.append(json.loads(line))

    if MAX_ROWS:
        rows = rows[:MAX_ROWS]

    init_jsonl()

    times = []
    total = len(rows)

    for i, row in enumerate(rows, 1):
        t0 = time.time()

        sid = clean_text(row.get("id", ""))
        image_path = clean_text(row.get("image_path", ""))
        source_text = clean_text(row.get("source_text", ""))
        initial_translation = clean_text(row.get("initial_translation", ""))

        hallucination_analysis = {
            "primary_type": clean_text(row.get("primary_hallucination_type", "")),
            "target_hallucination_span": clean_text(row.get("target_hallucination_span", "")),
        }

        mode = get_hallucination_mode(hallucination_analysis)

        try:
            if mode == "no_hallucination":
                base = normalize_sentence(initial_translation)
                parsed = {
                    "candidate_1": base,
                    "candidate_2": base,
                    "candidate_3": base,
                    "local_evidence": {
                        "target_span": "",
                        "corrected_part": "",
                        "visual_evidence": ""
                    }
                }
                raw = ""
            else:
                image = load_image(image_path)
                prompt = build_candidate_prompt(
                    source_text=source_text,
                    initial_translation=initial_translation,
                    hallucination_analysis=hallucination_analysis
                )
                raw = run_multimodal_json(prompt, image, max_new_tokens=220)
                parsed = parse_or_fallback(
                    raw=raw,
                    initial_translation=initial_translation,
                    hallucination_analysis=hallucination_analysis
                )

                del image
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()

            append_jsonl({
                "id": sid,
                "image_path": image_path,
                "source_text": source_text,
                "initial_translation": initial_translation,
                "target_hallucination_span": clean_text(hallucination_analysis.get("target_hallucination_span", "")),
                "primary_hallucination_type": clean_text(hallucination_analysis.get("primary_type", "")),
                "hallucination_mode": mode,
                "candidate_1": parsed["candidate_1"],
                "candidate_2": parsed["candidate_2"],
                "candidate_3": parsed["candidate_3"],
                "local_evidence": parsed["local_evidence"],
                "raw_model_output": raw
            })

        except Exception as e:
            print(f"ERROR: {sid} | {e}")
            fallback = normalize_sentence(initial_translation)
            append_jsonl({
                "id": sid,
                "image_path": image_path,
                "source_text": source_text,
                "initial_translation": initial_translation,
                "target_hallucination_span": clean_text(hallucination_analysis.get("target_hallucination_span", "")),
                "primary_hallucination_type": clean_text(hallucination_analysis.get("primary_type", "")),
                "hallucination_mode": mode,
                "candidate_1": fallback,
                "candidate_2": fallback,
                "candidate_3": fallback,
                "local_evidence": {
                    "target_span": clean_text(hallucination_analysis.get("target_hallucination_span", "")),
                    "corrected_part": "",
                    "visual_evidence": ""
                },
                "raw_model_output": f"ERROR: {repr(e)}"
            })

        dt = time.time() - t0
        times.append(dt)
        avg = sum(times) / len(times)
        eta = (total - i) * avg
        print(f"[{i}/{total}] {sid} | mode={mode} | {dt:.2f}s | ETA {format_time(eta)}")

    print("DONE")

if __name__ == "__main__":
    main()