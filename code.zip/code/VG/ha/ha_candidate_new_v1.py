import os
os.environ["CUDA_VISIBLE_DEVICES"] = "2"
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"

import re
import json
import time
from typing import Dict, List, Optional

from PIL import Image

import torch
from transformers import AutoProcessor, Qwen2VLForConditionalGeneration

torch.set_grad_enabled(False)

# =========================
# PATH
# =========================
MODEL_PATH = "/mnt/raid/hss/model/Qwen2-VL-7B-Instruct"
INPUT_JSONL = "/home/chenyi/offline_blaser_qe/out/VG/ha/ha_detect_span.jsonl"
OUTPUT_JSONL = "/home/chenyi/offline_blaser_qe/out/VG/ha/ha_candidates_from_span.jsonl"

MAX_ROWS = None

# =========================
# LOAD MODEL
# =========================
print("Loading model...")
processor = AutoProcessor.from_pretrained(MODEL_PATH, trust_remote_code=True)
model = Qwen2VLForConditionalGeneration.from_pretrained(
    MODEL_PATH,
    torch_dtype=torch.bfloat16,
    device_map="auto",
    trust_remote_code=True
).eval()
tokenizer = processor.tokenizer

# =========================
# UTIL
# =========================
def format_time(sec: float) -> str:
    sec = int(sec)
    return f"{sec//3600:02d}:{(sec%3600)//60:02d}:{sec%60:02d}"

def load_image(path: str) -> Optional[Image.Image]:
    if not path or not os.path.isfile(path):
        return None
    try:
        return Image.open(path).convert("RGB")
    except Exception:
        return None

def clean_text(s: str) -> str:
    if s is None:
        return ""
    s = str(s).strip()
    s = re.sub(r"\s+", " ", s)
    return s

def simple_post_clean(text: str) -> str:
    text = clean_text(text)
    return text.strip(' "\'')

def normalize_token(text: str) -> str:
    text = text.lower().strip()
    text = re.sub(r"[^a-z0-9\- ]", "", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()

def tokenize_words(text: str) -> List[str]:
    return re.findall(r"[A-Za-z0-9\-]+", clean_text(text).lower())

def deduplicate_keep_order(items: List[str]) -> List[str]:
    out = []
    seen = set()
    for x in items:
        x = simple_post_clean(x)
        if not x:
            continue
        k = x.lower()
        if k in seen:
            continue
        seen.add(k)
        out.append(x)
    return out

def lightly_make_distinct(cands: List[str]) -> List[str]:
    cands = [simple_post_clean(x) for x in cands]
    while len(cands) < 3:
        cands.append(cands[-1] if cands else "")

    c1, c2, c3 = cands[:3]

    if c1.lower() == c2.lower() == c3.lower():
        if c2.endswith("."):
            c2 = c2[:-1]
        else:
            c2 = c2 + "."
        if c3.endswith("."):
            c3 = c3[:-1]
        else:
            c3 = c3 + "."
            if c3 == c2:
                c3 = c3 + " "

    if c1.lower() == c2.lower():
        c2 = c2[:-1] if c2.endswith(".") else c2 + "."

    if c2.lower() == c3.lower():
        c3 = c3[:-1] if c3.endswith(".") else c3 + "."

    if c1.lower() == c3.lower():
        c3 = c3[:-1] if c3.endswith(".") else c3 + "."

    return [c1, c2, c3]

def titlecase_first(text: str) -> str:
    text = simple_post_clean(text)
    if not text:
        return text
    return text[0].upper() + text[1:]

def strip_terminal_punct(text: str) -> str:
    return re.sub(r"[ \t\r\n]+", " ", text).strip().strip(" ,.;:!?")

def same_except_case_punct(a: str, b: str) -> bool:
    na = normalize_token(a)
    nb = normalize_token(b)
    return na == nb

def normalize_sentence(text: str) -> str:
    text = clean_text(text)
    if not text:
        return ""
    text = titlecase_first(text)
    return text.rstrip(".") + "."

def contains_whole_phrase(text: str, phrase: str) -> bool:
    text_n = normalize_token(text)
    phrase_n = normalize_token(phrase)
    if not text_n or not phrase_n:
        return False
    return re.search(rf"\b{re.escape(phrase_n)}\b", text_n) is not None

def content_overlap_ratio(a: str, b: str) -> float:
    wa = set(tokenize_words(a))
    wb = set(tokenize_words(b))
    if not wa or not wb:
        return 0.0
    inter = len(wa & wb)
    return inter / max(1, len(wa | wb))

# =========================
# REPETITION FILTER
# =========================
def collapse_adjacent_duplicate_words(text: str) -> str:
    toks = clean_text(text).split()
    if not toks:
        return ""
    out = [toks[0]]
    for tok in toks[1:]:
        prev_n = normalize_token(out[-1])
        cur_n = normalize_token(tok)
        if prev_n and cur_n and prev_n == cur_n:
            continue
        out.append(tok)
    return " ".join(out)

def collapse_repeated_ngrams(text: str, min_n: int = 2, max_n: int = 6) -> str:
    toks = clean_text(text).split()
    if len(toks) < min_n * 2:
        return clean_text(text)

    changed = True
    while changed:
        changed = False
        toks_n = [normalize_token(t) for t in toks]

        for n in range(max_n, min_n - 1, -1):
            i = 0
            rebuilt = []
            local_changed = False

            while i < len(toks):
                if i + 2 * n <= len(toks):
                    g1 = toks_n[i:i+n]
                    g2 = toks_n[i+n:i+2*n]
                    if g1 == g2 and any(x not in {"a", "an", "the", "of", "in", "on", "to", "is", "are"} for x in g1):
                        rebuilt.extend(toks[i:i+n])
                        i += 2 * n
                        local_changed = True
                        continue
                rebuilt.append(toks[i])
                i += 1

            if local_changed:
                toks = rebuilt
                changed = True
                break

    return " ".join(toks)

def has_repeated_ngram(text: str, min_n: int = 2, max_n: int = 6) -> bool:
    toks = tokenize_words(text)
    if len(toks) < min_n * 2:
        return False

    for n in range(max_n, min_n - 1, -1):
        seen = {}
        for i in range(len(toks) - n + 1):
            gram = tuple(toks[i:i+n])
            if all(x in {"a", "an", "the", "of", "in", "on", "to", "is", "are"} for x in gram):
                continue
            if gram in seen:
                return True
            seen[gram] = 1
    return False

def has_mid_sentence_restart(text: str) -> bool:
    t = clean_text(text)
    if not t:
        return False

    patterns = [
        r"\b[Aa]\s+[A-Z][a-z]+\b",
        r"\b[Tt]he\s+[A-Z][a-z]+\b",
        r"\b[Aa]n\s+[A-Z][a-z]+\b",
    ]
    for p in patterns:
        if len(re.findall(p, t)) >= 2:
            return True
    return False

def has_bad_repetition(text: str) -> bool:
    t = normalize_token(text)
    bad_patterns = [
        "a a ",
        "the the ",
        "an an ",
        "of of ",
        "to to ",
        "is is ",
        "are are ",
        "in the in the",
        "on the on the",
        "with a with a",
    ]
    if any(p in t for p in bad_patterns):
        return True

    if has_repeated_ngram(text, min_n=2, max_n=6):
        return True

    if has_mid_sentence_restart(text):
        return True

    return False

def sanitize_candidate_surface(text: str) -> str:
    text = clean_text(text)
    if not text:
        return ""

    text = collapse_adjacent_duplicate_words(text)
    text = collapse_repeated_ngrams(text, min_n=2, max_n=6)
    text = re.sub(r"\s+", " ", text).strip()
    text = re.sub(r"\s+([,.;:!?])", r"\1", text)

    return normalize_sentence(text)

# =========================
# NEW: FRAGMENT / UNSUPPORTED CONTENT FILTER
# =========================
CONTENT_STOPWORDS = {
    "a", "an", "the",
    "is", "are", "was", "were", "be", "being", "been",
    "am", "do", "does", "did",
    "to", "of", "in", "on", "at", "by", "with", "from", "for",
    "into", "onto", "over", "under", "above", "below", "outside", "inside",
    "there", "here", "this", "that", "these", "those",
    "and", "or", "but", "as", "it", "its", "their", "his", "her",
    "has", "have", "had",
    "very", "just", "also", "still",
}

SUSPICIOUS_NEW_WORDS = {
    "kumquat", "sunglasses", "crosswalk", "ocean", "sea",
    "shavings", "skier", "snowboarder", "toddler", "lady",
    "soldiers", "military", "guy", "woman", "man", "girl", "boy",
    "long-haired", "longhaired", "decorated",
}

def extract_content_words(text: str) -> set:
    out = set()
    for w in tokenize_words(text):
        nw = normalize_token(w)
        if not nw:
            continue
        if nw in CONTENT_STOPWORDS:
            continue
        if len(nw) <= 1:
            continue
        out.add(nw)
    return out

def is_fragment_candidate(text: str) -> bool:
    text = clean_text(text)
    if not text:
        return True

    low = text.lower().strip()
    words = tokenize_words(text)
    if not words:
        return True

    # 明显残句开头
    if re.match(r"^(a|an|the)\s+(on|in|at|by|with|from|of|to|into|onto|outside|inside|over|under)\b", low):
        return True

    if re.match(r"^(a|an|the)\s+(is|are|was|were|be|been|being)\b", low):
        return True

    if re.match(r"^(is|are|was|were|be|been|being)\b", low):
        return True

    if re.match(r"^(on|in|at|by|with|from|to|into|onto|outside|inside)\b", low):
        return True

    # A standing outside..., The running...
    if re.match(r"^(a|an|the)\s+\w+ing(\s+(on|in|at|by|with|from|to|outside|inside|over|under)\b|$)", low):
        return True

    # 太短且没有骨架
    if len(words) == 1:
        return True

    if len(words) == 2 and words[0] in {"a", "an", "the"}:
        return True

    # 只有冠词+形容词+句号，也视作残片
    if len(words) <= 3:
        content = extract_content_words(text)
        if len(content) <= 1:
            return True

    return False

def has_unsupported_new_content(
    candidate: str,
    initial_translation: str,
    local_evidence: Optional[Dict] = None
) -> bool:
    candidate = clean_text(candidate)
    initial_translation = clean_text(initial_translation)

    if not candidate:
        return False

    cand_words = extract_content_words(candidate)
    init_words = extract_content_words(initial_translation)

    evidence_words = set()
    if isinstance(local_evidence, dict):
        evidence_words |= extract_content_words(clean_text(local_evidence.get("visual_evidence", "")))
        evidence_words |= extract_content_words(clean_text(local_evidence.get("corrected_part", "")))
        evidence_words |= extract_content_words(clean_text(local_evidence.get("target_span", "")))

    new_words = cand_words - init_words - evidence_words
    dropped_words = init_words - cand_words

    # 明显可疑的新词直接拦
    if new_words & SUSPICIOUS_NEW_WORDS:
        return True

    # 既引入新内容，又丢掉原核心内容，且和原句重叠不高
    if len(new_words) >= 1 and len(dropped_words) >= 1 and content_overlap_ratio(candidate, initial_translation) < 0.60:
        return True

    # 引入两个以上未经支持的新核心词
    if len(new_words) >= 2:
        return True

    return False

def filter_repetition_candidates(
    cands: List[str],
    fallback: str,
    local_evidence: Optional[Dict] = None
) -> List[str]:
    kept = []
    for c in cands:
        c = sanitize_candidate_surface(c)
        if not c:
            continue
        if has_bad_repetition(c):
            continue
        if is_fragment_candidate(c):
            continue
        if has_unsupported_new_content(c, fallback, local_evidence):
            continue
        kept.append(c)

    kept = deduplicate_keep_order(kept)
    if not kept:
        fb = sanitize_candidate_surface(fallback)
        kept = [fb] if fb else []

    while len(kept) < 3 and kept:
        kept.append(kept[-1])

    return kept[:3]

def looks_like_full_sentence_part(part: str) -> bool:
    part_n = normalize_token(part)
    if not part_n:
        return False
    if len(tokenize_words(part_n)) >= 4:
        return True
    return False

def phrase_is_supported_by_initial(initial_translation: str, phrase: str) -> bool:
    return contains_whole_phrase(initial_translation, phrase)

def local_evidence_supports_original(
    initial_translation: str,
    hallucination_analysis: Dict,
    local_evidence: Dict
) -> bool:
    if not isinstance(local_evidence, dict):
        return False

    target_span = clean_text(hallucination_analysis.get("target_hallucination_span", ""))
    evidence_span = clean_text(local_evidence.get("target_span", ""))
    corrected_part = clean_text(local_evidence.get("corrected_part", ""))
    visual_evidence = clean_text(local_evidence.get("visual_evidence", ""))

    if corrected_part and phrase_is_supported_by_initial(initial_translation, corrected_part):
        return True

    if evidence_span and phrase_is_supported_by_initial(initial_translation, evidence_span):
        return True

    if visual_evidence and content_overlap_ratio(initial_translation, visual_evidence) >= 0.6:
        return True

    if target_span and visual_evidence and contains_whole_phrase(visual_evidence, target_span):
        return True

    return False

# =========================
# HALLUCINATION MODES
# =========================
def get_hallucination_mode(hallucination_analysis: Dict) -> str:
    types = hallucination_analysis.get("hallucination_types", []) or []
    primary_type = clean_text(hallucination_analysis.get("primary_type", ""))
    target_span = clean_text(hallucination_analysis.get("target_hallucination_span", ""))

    if primary_type == "faithful" or not target_span:
        return "no_hallucination"

    if not types and primary_type:
        if primary_type == "extra_content":
            return "delete_only"
        if primary_type in {"attribute_color", "attribute_number", "semantic_refinement"}:
            return "replace_or_correct"
        if primary_type == "unsupported_span":
            return "general_correct"

    type_set = set(types)
    if type_set == {"extra_content"}:
        return "delete_only"
    if "extra_content" in type_set and len(type_set) >= 2:
        return "mixed"
    if (
        "attribute_color" in type_set
        or "attribute_number" in type_set
        or "semantic_refinement" in type_set
    ):
        return "replace_or_correct"
    return "general_correct"

# =========================
# PROMPT BUILDING
# =========================
def build_hallucination_focus_text(hallucination_analysis: Dict) -> str:
    primary_type = clean_text(hallucination_analysis.get("primary_type", ""))
    target_hallucination_span = clean_text(hallucination_analysis.get("target_hallucination_span", ""))

    lines = []
    lines.append("Detected suspicious translation parts:")
    lines.append(f"- primary_type: {json.dumps(primary_type, ensure_ascii=False)}")
    lines.append(f"- target_hallucination_span: {json.dumps(target_hallucination_span, ensure_ascii=False)}")
    lines.append(f"- hallucinated_words: {json.dumps(hallucination_analysis.get('hallucinated_words', []) or [], ensure_ascii=False)}")
    lines.append(f"- hallucinated_phrases: {json.dumps(hallucination_analysis.get('hallucinated_phrases', []) or [], ensure_ascii=False)}")
    lines.append(f"- hallucination_types: {json.dumps(hallucination_analysis.get('hallucination_types', []) or [], ensure_ascii=False)}")
    lines.append(f"- attribute_color_words: {json.dumps(hallucination_analysis.get('attribute_color_words', []) or [], ensure_ascii=False)}")
    lines.append(f"- attribute_number_words: {json.dumps(hallucination_analysis.get('attribute_number_words', []) or [], ensure_ascii=False)}")
    lines.append(f"- refinement_words: {json.dumps(hallucination_analysis.get('refinement_words', []) or [], ensure_ascii=False)}")
    lines.append(f"- extra_content_words: {json.dumps(hallucination_analysis.get('extra_content_words', []) or [], ensure_ascii=False)}")
    return "\n".join(lines)

def build_local_grounding_guidance(
    initial_translation: str,
    hallucination_analysis: Dict
) -> str:
    target_hallucination_span = clean_text(hallucination_analysis.get("target_hallucination_span", ""))

    return f"""
Local grounding requirement:
- First find the suspicious span inside the current translation:
  "{target_hallucination_span}"
- Use the suspicious span and its immediate textual context to identify the corresponding local object, attribute, action, or phrase in the image.
- Focus ONLY on that corresponding local object or local region.
- Do NOT generalize to the whole image.
- Do NOT rewrite unrelated parts of the sentence.
- Extract only the minimal local visual evidence needed to repair the suspicious span.
- Keep every other non-hallucinated part of the current translation unchanged whenever possible.
- If the suspicious span is a color, number, or local attribute, inspect only the color/number/attribute of that local object.
- If the suspicious span is an unsupported phrase, remove or minimally replace only that phrase.
""".strip()

def build_part_output_constraints() -> str:
    return """
Output constraints:
- Do NOT output full rewritten sentences.
- Output only corrected local parts.
- Produce exactly 3 corrected local parts:
  corrected_part_1, corrected_part_2, corrected_part_3
- Each corrected local part should replace only the hallucinated span or its immediate phrase.
- Keep the correction minimal.
- Do NOT introduce unrelated scene details.
- Do NOT paraphrase parts of the sentence outside the hallucinated local region.
- The 3 corrected local parts should differ slightly in wording when possible, but all must stay local and conservative.
""".strip()

def build_no_hallucination_prompt(
    source_text: str,
    initial_translation: str
) -> str:
    return f"""
You are a multimodal translation verification system.

Task:
The current translation is already faithful.
Do NOT rewrite it.

Return JSON ONLY:
{{
  "corrected_part_1": "",
  "corrected_part_2": "",
  "corrected_part_3": "",
  "local_evidence": {{
    "target_span": "",
    "corrected_part": "",
    "visual_evidence": ""
  }}
}}
""".strip()

def build_delete_only_prompt(
    source_text: str,
    initial_translation: str,
    hallucination_analysis: Dict
) -> str:
    focus_text = build_hallucination_focus_text(hallucination_analysis)
    local_grounding = build_local_grounding_guidance(initial_translation, hallucination_analysis)
    output_constraints = build_part_output_constraints()

    return f"""
You are a multimodal translation correction system.

Task:
The suspicious span is unsupported extra content.
Delete only the unsupported local span.

{local_grounding}

{output_constraints}

Important rules:
- corrected_part_1/2/3 should be the local replacement text only.
- If the best correction is deletion, corrected_part can be an empty string.
- Do NOT output a full sentence.
- Do NOT add any new scene wording.

Return JSON ONLY:
{{
  "corrected_part_1": "...",
  "corrected_part_2": "...",
  "corrected_part_3": "...",
  "local_evidence": {{
    "target_span": "...",
    "corrected_part": "...",
    "visual_evidence": "..."
  }}
}}

Source sentence:
{source_text}

Current translation:
{initial_translation}

{focus_text}
""".strip()

def build_replace_or_correct_prompt(
    source_text: str,
    initial_translation: str,
    hallucination_analysis: Dict
) -> str:
    focus_text = build_hallucination_focus_text(hallucination_analysis)
    local_grounding = build_local_grounding_guidance(initial_translation, hallucination_analysis)
    output_constraints = build_part_output_constraints()

    return f"""
You are a multimodal translation correction system.

Task:
The current translation contains a localized hallucination.
Use the suspicious span and its surrounding context to locate the corresponding local object or local region in the image.
Then output only corrected local parts, not full sentences.

{local_grounding}

{output_constraints}

Important rules:
- corrected_part_1/2/3 must be local replacement phrases only.
- They should replace only the hallucinated span or its immediate local phrase.
- Do NOT output full rewritten sentences.
- Do NOT rewrite the rest of the sentence.
- For color or number errors, replace only the wrong local attribute with the visually grounded one.
- For semantic refinement errors, use a less specific local term if needed.
- The corrected local part must not preserve the original hallucinated word when a corrected alternative is available.

Return JSON ONLY:
{{
  "corrected_part_1": "...",
  "corrected_part_2": "...",
  "corrected_part_3": "...",
  "local_evidence": {{
    "target_span": "...",
    "corrected_part": "...",
    "visual_evidence": "..."
  }}
}}

Source sentence:
{source_text}

Current translation:
{initial_translation}

{focus_text}
""".strip()

def build_mixed_prompt(
    source_text: str,
    initial_translation: str,
    hallucination_analysis: Dict
) -> str:
    focus_text = build_hallucination_focus_text(hallucination_analysis)
    local_grounding = build_local_grounding_guidance(initial_translation, hallucination_analysis)
    output_constraints = build_part_output_constraints()

    return f"""
You are a multimodal translation correction system.

Task:
The current translation contains:
1. a wrong local detail that needs correction, and
2. unsupported extra local content that should be deleted.

Use the suspicious span and its surrounding context to identify the corresponding local object or local region in the image.
Then output only corrected local parts.

{local_grounding}

{output_constraints}

Important rules:
- corrected_part_1/2/3 must be local replacement text only.
- Do NOT output full sentences.
- Correct only the wrong local detail and/or delete only unsupported local content.
- Keep the rest of the sentence unchanged outside this local region.

Return JSON ONLY:
{{
  "corrected_part_1": "...",
  "corrected_part_2": "...",
  "corrected_part_3": "...",
  "local_evidence": {{
    "target_span": "...",
    "corrected_part": "...",
    "visual_evidence": "..."
  }}
}}

Source sentence:
{source_text}

Current translation:
{initial_translation}

{focus_text}
""".strip()

def build_general_correct_prompt(
    source_text: str,
    initial_translation: str,
    hallucination_analysis: Dict
) -> str:
    focus_text = build_hallucination_focus_text(hallucination_analysis)
    local_grounding = build_local_grounding_guidance(initial_translation, hallucination_analysis)
    output_constraints = build_part_output_constraints()

    return f"""
You are a multimodal translation correction system.

Task:
The current translation contains a suspicious unsupported local span.
Use the suspicious span and its immediate textual context to locate the corresponding local object or local region in the image.
Correct only that local span and output only corrected local parts.

{local_grounding}

{output_constraints}

Important rules:
- corrected_part_1/2/3 must be local replacement phrases only.
- Do NOT output full rewritten sentences.
- Keep the rest of the current translation unchanged.
- Do NOT add new global scene information.
- The corrected local part must not preserve the original suspicious span when a corrected alternative is available.

Return JSON ONLY:
{{
  "corrected_part_1": "...",
  "corrected_part_2": "...",
  "corrected_part_3": "...",
  "local_evidence": {{
    "target_span": "...",
    "corrected_part": "...",
    "visual_evidence": "..."
  }}
}}

Source sentence:
{source_text}

Current translation:
{initial_translation}

{focus_text}
""".strip()

def build_candidate_prompt(
    source_text: str,
    initial_translation: str,
    hallucination_analysis: Dict
) -> str:
    mode = get_hallucination_mode(hallucination_analysis)
    if mode == "no_hallucination":
        return build_no_hallucination_prompt(source_text, initial_translation)
    if mode == "delete_only":
        return build_delete_only_prompt(source_text, initial_translation, hallucination_analysis)
    if mode == "replace_or_correct":
        return build_replace_or_correct_prompt(source_text, initial_translation, hallucination_analysis)
    if mode == "mixed":
        return build_mixed_prompt(source_text, initial_translation, hallucination_analysis)
    return build_general_correct_prompt(source_text, initial_translation, hallucination_analysis)

# =========================
# MODEL CALL
# =========================
def run_multimodal_json(prompt: str, image: Optional[Image.Image], max_new_tokens: int = 220) -> str:
    content = []
    if image is not None:
        content.append({"type": "image", "image": image})
    content.append({"type": "text", "text": prompt})

    messages = [{"role": "user", "content": content}]
    text = processor.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True
    )

    if image is not None:
        inputs = processor(text=[text], images=[image], return_tensors="pt")
    else:
        inputs = processor(text=[text], return_tensors="pt")

    inputs = {k: v.to(model.device) for k, v in inputs.items()}

    with torch.no_grad():
        out = model.generate(
            **inputs,
            do_sample=False,
            max_new_tokens=max_new_tokens,
            repetition_penalty=1.02,
            pad_token_id=tokenizer.eos_token_id,
        )

    gen = out[:, inputs["input_ids"].shape[1]:]
    raw = processor.batch_decode(gen, skip_special_tokens=True)[0]
    return raw

def extract_json_block(raw: str) -> Dict:
    raw = str(raw).strip()
    candidates = re.findall(r"\{.*\}", raw, flags=re.DOTALL)
    for c in candidates:
        try:
            obj = json.loads(c)
            if all(k in obj for k in ["corrected_part_1", "corrected_part_2", "corrected_part_3"]):
                return obj
        except Exception:
            pass
    return {}

# =========================
# PART-TO-SENTENCE REWRITE
# =========================
def replace_span_once(text: str, target_span: str, replacement: str) -> str:
    text = clean_text(text)
    target_span = clean_text(target_span)
    replacement = clean_text(replacement)

    if not text or not target_span:
        return text

    if replacement == "":
        pattern = re.compile(re.escape(target_span), flags=re.IGNORECASE)
        new_text, n = pattern.subn("", text, count=1)
        if n == 0:
            return text
        new_text = re.sub(r"\s+", " ", new_text).strip()
        new_text = re.sub(r"\s+([,.;:!?])", r"\1", new_text)
        new_text = re.sub(r"\(\s*\)", "", new_text)
        return normalize_sentence(new_text) if new_text else ""
    else:
        pattern = re.compile(re.escape(target_span), flags=re.IGNORECASE)
        new_text, n = pattern.subn(replacement, text, count=1)
        if n == 0:
            return text
        new_text = re.sub(r"\s+", " ", new_text).strip()
        new_text = re.sub(r"\s+([,.;:!?])", r"\1", new_text)
        return normalize_sentence(new_text)

def local_phrase_from_translation(
    initial_translation: str,
    target_span: str,
    window_tokens: int = 2
) -> str:
    text = clean_text(initial_translation)
    span = clean_text(target_span)
    if not text or not span:
        return span

    m = re.search(re.escape(span), text, flags=re.IGNORECASE)
    if not m:
        return span

    left = text[:m.start()]
    right = text[m.end():]

    left_tokens = re.findall(r"\S+", left)
    right_tokens = re.findall(r"\S+", right)

    left_part = " ".join(left_tokens[-window_tokens:]) if left_tokens else ""
    right_part = " ".join(right_tokens[:window_tokens]) if right_tokens else ""

    phrase = " ".join(x for x in [left_part, span, right_part] if x).strip()
    return strip_terminal_punct(phrase)

def apply_local_replacement(
    initial_translation: str,
    target_span: str,
    corrected_part: str
) -> str:
    initial_translation = clean_text(initial_translation)
    target_span = clean_text(target_span)
    corrected_part = clean_text(corrected_part)

    if not initial_translation:
        return ""
    if not target_span:
        return normalize_sentence(initial_translation)

    direct = replace_span_once(initial_translation, target_span, corrected_part)
    if not same_except_case_punct(direct, initial_translation) or corrected_part == "":
        return direct if direct else initial_translation

    local_phrase = local_phrase_from_translation(initial_translation, target_span, window_tokens=2)
    if local_phrase and local_phrase.lower() != target_span.lower():
        phrase_replaced = replace_span_once(initial_translation, local_phrase, corrected_part)
        if not same_except_case_punct(phrase_replaced, initial_translation):
            return phrase_replaced

    return normalize_sentence(initial_translation)

# =========================
# GENERIC POST-PROCESSING
# =========================
def maybe_naturalize_corrected_part(
    corrected_part: str,
    hallucination_analysis: Dict,
    local_evidence: Dict
) -> str:
    text = simple_post_clean(corrected_part)
    if not text:
        return text

    primary_type = clean_text(hallucination_analysis.get("primary_type", ""))
    if primary_type in {"attribute_color", "attribute_number"}:
        corrected_norm = clean_text(local_evidence.get("corrected_part", text)).lower() or text.lower()
        if corrected_norm and "color" not in corrected_norm and "shade" not in corrected_norm and "hue" not in corrected_norm:
            return corrected_norm
    return text

def candidate_contains_target(candidate: str, target_span: str) -> bool:
    c_norm = normalize_token(candidate)
    t_norm = normalize_token(target_span)
    if not t_norm:
        return False
    return re.search(rf"\b{re.escape(t_norm)}\b", c_norm) is not None

def hard_filter_unrepaired_candidates(
    candidates: List[str],
    hallucination_analysis: Dict
) -> List[str]:
    primary_type = clean_text(hallucination_analysis.get("primary_type", ""))
    target_span = clean_text(hallucination_analysis.get("target_hallucination_span", ""))

    if primary_type not in {"attribute_color", "attribute_number", "semantic_refinement", "unsupported_span"} and \
       "extra_content" not in set(hallucination_analysis.get("hallucination_types", []) or []):
        return candidates

    if not target_span:
        return candidates

    repaired = []
    for c in candidates:
        if not candidate_contains_target(c, target_span):
            repaired.append(c)

    if repaired:
        return repaired
    return candidates

def fill_candidates_from_good_only(good_candidates: List[str]) -> List[str]:
    good_candidates = deduplicate_keep_order(good_candidates)
    if not good_candidates:
        return []

    while len(good_candidates) < 3:
        good_candidates.append(good_candidates[-1])

    return good_candidates[:3]

def fill_candidates_generic(
    cands: List[str],
    initial_translation: str,
    mode: str
) -> List[str]:
    cands = deduplicate_keep_order(cands)

    if not cands:
        if mode == "no_hallucination":
            cands = [simple_post_clean(initial_translation)]
        else:
            fill = simple_post_clean(initial_translation)
            cands = [fill]

    while len(cands) < 3:
        fill = simple_post_clean(initial_translation)
        cands.append(fill if fill else cands[-1])

    return cands[:3]

def enforce_no_hallucination_policy(initial_translation: str) -> Dict:
    base = normalize_sentence(initial_translation) if initial_translation else ""
    return {
        "candidate_1": base,
        "candidate_2": base,
        "candidate_3": base,
        "local_evidence": {
            "target_span": "",
            "corrected_part": "",
            "visual_evidence": ""
        }
    }

def is_bad_delete_candidate(
    cand: str,
    initial_translation: str,
    target_span: str,
    corrected_part: str,
    visual_evidence: str
) -> bool:
    cand = sanitize_candidate_surface(cand)
    if not cand:
        return False

    if has_bad_repetition(cand):
        return True

    if is_fragment_candidate(cand):
        return True

    if has_unsupported_new_content(
        candidate=cand,
        initial_translation=initial_translation,
        local_evidence={
            "target_span": target_span,
            "corrected_part": corrected_part,
            "visual_evidence": visual_evidence,
        }
    ):
        return True

    init_words = set(tokenize_words(initial_translation))
    cand_words = set(tokenize_words(cand))
    new_words = cand_words - init_words

    forbidden_new_words = {
        "horse", "field", "road", "grass", "sky", "background",
        "train", "car", "dog", "cat", "tree", "street", "mountain"
    }
    if new_words & forbidden_new_words:
        return True

    if corrected_part and visual_evidence:
        if contains_whole_phrase(visual_evidence, corrected_part) and not contains_whole_phrase(cand, corrected_part):
            return True

    if target_span and corrected_part:
        if contains_whole_phrase(initial_translation, corrected_part) and not contains_whole_phrase(cand, corrected_part):
            return True

    if content_overlap_ratio(cand, initial_translation) < 0.45:
        return True

    return False

def should_revert_delete_only_to_original(
    initial_translation: str,
    hallucination_analysis: Dict,
    local_evidence: Dict
) -> bool:
    return local_evidence_supports_original(
        initial_translation=initial_translation,
        hallucination_analysis=hallucination_analysis,
        local_evidence=local_evidence
    )

def enforce_delete_only_policy(
    initial_translation: str,
    parsed: Dict,
    hallucination_analysis: Dict
) -> Dict:
    local_evidence = parsed.get("local_evidence", {})
    if not isinstance(local_evidence, dict):
        local_evidence = {}

    target_span = clean_text(local_evidence.get("target_span", "")) or clean_text(hallucination_analysis.get("target_hallucination_span", ""))
    corrected_part_evidence = clean_text(local_evidence.get("corrected_part", ""))
    visual_evidence = clean_text(local_evidence.get("visual_evidence", ""))

    if should_revert_delete_only_to_original(
        initial_translation=initial_translation,
        hallucination_analysis=hallucination_analysis,
        local_evidence=local_evidence
    ):
        base = normalize_sentence(initial_translation)
        return {
            "candidate_1": base,
            "candidate_2": base,
            "candidate_3": base,
            "local_evidence": {
                "target_span": target_span,
                "corrected_part": corrected_part_evidence,
                "visual_evidence": visual_evidence,
            }
        }

    part1 = simple_post_clean(parsed.get("corrected_part_1", ""))
    part2 = simple_post_clean(parsed.get("corrected_part_2", ""))
    part3 = simple_post_clean(parsed.get("corrected_part_3", ""))

    raw_parts = [part1, part2, part3]
    safe_parts = []
    for p in raw_parts:
        if not p:
            safe_parts.append("")
            continue
        if looks_like_full_sentence_part(p) and not contains_whole_phrase(initial_translation, p):
            safe_parts.append("")
        else:
            safe_parts.append(p)

    sent_cands = [
        apply_local_replacement(initial_translation, target_span, safe_parts[0]),
        apply_local_replacement(initial_translation, target_span, safe_parts[1]),
        apply_local_replacement(initial_translation, target_span, safe_parts[2]),
    ]
    sent_cands = [sanitize_candidate_surface(x) for x in sent_cands]
    sent_cands = deduplicate_keep_order(sent_cands)

    cleaned = []
    for c in sent_cands:
        if is_bad_delete_candidate(
            cand=c,
            initial_translation=initial_translation,
            target_span=target_span,
            corrected_part=corrected_part_evidence,
            visual_evidence=visual_evidence
        ):
            continue
        cleaned.append(c)

    cleaned = filter_repetition_candidates(cleaned, initial_translation, local_evidence)

    if not cleaned:
        base = normalize_sentence(initial_translation)
        cleaned = [base]

    cleaned = fill_candidates_generic(cleaned, initial_translation, "delete_only")
    cleaned = lightly_make_distinct(cleaned)
    cleaned = filter_repetition_candidates(cleaned, initial_translation, local_evidence)

    return {
        "candidate_1": cleaned[0],
        "candidate_2": cleaned[1],
        "candidate_3": cleaned[2],
        "local_evidence": {
            "target_span": target_span,
            "corrected_part": corrected_part_evidence,
            "visual_evidence": visual_evidence,
        }
    }

def enforce_general_policy(
    initial_translation: str,
    parsed: Dict,
    hallucination_analysis: Dict,
    mode: str
) -> Dict:
    local_evidence = parsed.get("local_evidence", {})
    if not isinstance(local_evidence, dict):
        local_evidence = {}

    target_span = clean_text(local_evidence.get("target_span", "")) or clean_text(hallucination_analysis.get("target_hallucination_span", ""))

    part1 = maybe_naturalize_corrected_part(parsed.get("corrected_part_1", ""), hallucination_analysis, local_evidence)
    part2 = maybe_naturalize_corrected_part(parsed.get("corrected_part_2", ""), hallucination_analysis, local_evidence)
    part3 = maybe_naturalize_corrected_part(parsed.get("corrected_part_3", ""), hallucination_analysis, local_evidence)

    # general 路径也拒绝明显整句 part
    parts = [part1, part2, part3]
    safe_parts = []
    for p in parts:
        if not p:
            safe_parts.append("")
            continue
        if looks_like_full_sentence_part(p) and not contains_whole_phrase(initial_translation, p):
            safe_parts.append("")
        else:
            safe_parts.append(p)

    raw_cands = [
        apply_local_replacement(initial_translation, target_span, safe_parts[0]),
        apply_local_replacement(initial_translation, target_span, safe_parts[1]),
        apply_local_replacement(initial_translation, target_span, safe_parts[2]),
    ]
    raw_cands = [sanitize_candidate_surface(x) for x in raw_cands]
    raw_cands = deduplicate_keep_order(raw_cands)

    filtered = hard_filter_unrepaired_candidates(raw_cands, hallucination_analysis)
    filtered = [
        c for c in filtered
        if not has_bad_repetition(c)
        and not is_fragment_candidate(c)
        and not has_unsupported_new_content(c, initial_translation, local_evidence)
    ]

    if filtered and len(filtered) < 3 and filtered != raw_cands:
        cands = fill_candidates_from_good_only(filtered)
    else:
        cands = fill_candidates_generic(filtered, initial_translation, mode)

    cands = lightly_make_distinct(cands)
    cands = filter_repetition_candidates(cands, initial_translation, local_evidence)

    return {
        "candidate_1": cands[0],
        "candidate_2": cands[1],
        "candidate_3": cands[2],
        "local_evidence": {
            "target_span": target_span,
            "corrected_part": clean_text(local_evidence.get("corrected_part", "")),
            "visual_evidence": clean_text(local_evidence.get("visual_evidence", "")),
        }
    }

def parse_or_fallback(
    raw: str,
    initial_translation: str,
    hallucination_analysis: Dict
) -> Dict:
    mode = get_hallucination_mode(hallucination_analysis)

    if mode == "no_hallucination":
        return enforce_no_hallucination_policy(initial_translation)

    obj = extract_json_block(raw)
    if not obj:
        obj = {
            "corrected_part_1": "",
            "corrected_part_2": "",
            "corrected_part_3": "",
            "local_evidence": {
                "target_span": clean_text(hallucination_analysis.get("target_hallucination_span", "")),
                "corrected_part": "",
                "visual_evidence": ""
            }
        }

    if mode == "delete_only":
        return enforce_delete_only_policy(
            initial_translation=initial_translation,
            parsed=obj,
            hallucination_analysis=hallucination_analysis
        )

    return enforce_general_policy(
        initial_translation=initial_translation,
        parsed=obj,
        hallucination_analysis=hallucination_analysis,
        mode=mode
    )

# =========================
# JSONL
# =========================
def init_jsonl():
    os.makedirs(os.path.dirname(OUTPUT_JSONL), exist_ok=True)
    with open(OUTPUT_JSONL, "w", encoding="utf-8"):
        pass

def append_jsonl(record: Dict):
    with open(OUTPUT_JSONL, "a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")

# =========================
# MAIN
# =========================
def main():
    rows = []
    with open(INPUT_JSONL, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            rows.append(json.loads(line))

    if MAX_ROWS:
        rows = rows[:MAX_ROWS]

    init_jsonl()

    times = []
    total = len(rows)

    for i, row in enumerate(rows, 1):
        t0 = time.time()

        sid = clean_text(row.get("id", ""))
        image_path = clean_text(row.get("image_path", ""))
        source_text = clean_text(row.get("source_text", ""))
        initial_translation = clean_text(row.get("initial_translation", ""))

        hallucination_analysis = {
            "primary_type": clean_text(row.get("primary_hallucination_type", "")),
            "target_hallucination_span": clean_text(row.get("target_hallucination_span", "")),
            "hallucination_types": []
        }

        mode = get_hallucination_mode(hallucination_analysis)

        try:
            if mode == "no_hallucination":
                parsed = enforce_no_hallucination_policy(initial_translation)
                raw = ""
            else:
                image = load_image(image_path)
                prompt = build_candidate_prompt(
                    source_text=source_text,
                    initial_translation=initial_translation,
                    hallucination_analysis=hallucination_analysis
                )
                raw = run_multimodal_json(prompt, image, max_new_tokens=220)
                parsed = parse_or_fallback(
                    raw=raw,
                    initial_translation=initial_translation,
                    hallucination_analysis=hallucination_analysis
                )

                del image
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()

            append_jsonl({
                "id": sid,
                "image_path": image_path,
                "source_text": source_text,
                "initial_translation": initial_translation,
                "target_hallucination_span": clean_text(hallucination_analysis.get("target_hallucination_span", "")),
                "primary_hallucination_type": clean_text(hallucination_analysis.get("primary_type", "")),
                "hallucination_mode": mode,
                "candidate_1": parsed["candidate_1"],
                "candidate_2": parsed["candidate_2"],
                "candidate_3": parsed["candidate_3"],
                "local_evidence": parsed["local_evidence"],
                "raw_model_output": raw
            })

        except Exception as e:
            print(f"ERROR: {sid} | {e}")
            fallback = enforce_no_hallucination_policy(initial_translation) if mode == "no_hallucination" else {
                "candidate_1": normalize_sentence(initial_translation),
                "candidate_2": normalize_sentence(initial_translation),
                "candidate_3": normalize_sentence(initial_translation),
                "local_evidence": {
                    "target_span": clean_text(hallucination_analysis.get("target_hallucination_span", "")),
                    "corrected_part": "",
                    "visual_evidence": ""
                }
            }
            append_jsonl({
                "id": sid,
                "image_path": image_path,
                "source_text": source_text,
                "initial_translation": initial_translation,
                "target_hallucination_span": clean_text(hallucination_analysis.get("target_hallucination_span", "")),
                "primary_hallucination_type": clean_text(hallucination_analysis.get("primary_type", "")),
                "hallucination_mode": mode,
                "candidate_1": fallback["candidate_1"],
                "candidate_2": fallback["candidate_2"],
                "candidate_3": fallback["candidate_3"],
                "local_evidence": fallback["local_evidence"],
                "raw_model_output": f"ERROR: {repr(e)}"
            })

        dt = time.time() - t0
        times.append(dt)
        avg = sum(times) / len(times)
        eta = (total - i) * avg
        print(f"[{i}/{total}] {sid} | mode={mode} | {dt:.2f}s | ETA {format_time(eta)}")

    print("DONE")

if __name__ == "__main__":
    main()