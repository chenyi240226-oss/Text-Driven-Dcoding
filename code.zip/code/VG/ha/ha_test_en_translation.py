import os
os.environ["CUDA_VISIBLE_DEVICES"] = "7"
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"

import re
import csv
import json
import time
from typing import Any, Dict, List, Optional

import torch
from PIL import Image
from transformers import Qwen2VLForConditionalGeneration, AutoProcessor

# =========================
# 路径配置
# =========================
INPUT_JSONL = "/home/chenyi/offline_blaser_qe/dataSet/VG/ha/ha_vg_test.jsonl"
OUTPUT_CSV = "/home/chenyi/offline_blaser_qe/out/VG/ha/ha_test_translation.csv"

QWEN_PATH = "/mnt/raid/hss/model/Qwen2-VL-7B-Instruct"

# 图片目录
IMAGE_DIR = "/home/chenyi/offline_blaser_qe/dataSet/VG/images"

# =========================
# 参数
# =========================
DTYPE = torch.bfloat16 if torch.cuda.is_available() else torch.float32
MAX_SAMPLES = None
FLUSH_EVERY = 20
RETRY_TIMES = 2
FALLBACK_RETRY_TIMES = 2


def format_time(seconds: float) -> str:
    seconds = max(0, int(seconds))
    h = seconds // 3600
    m = (seconds % 3600) // 60
    s = seconds % 60
    return f"{h:02d}:{m:02d}:{s:02d}"


def load_jsonl(path: str) -> List[Dict[str, Any]]:
    data = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            data.append(json.loads(line))
            if MAX_SAMPLES is not None and len(data) >= MAX_SAMPLES:
                break
    return data


def find_image(image_id: Any) -> Optional[str]:
    image_id = str(image_id)

    for ext in [".jpg", ".jpeg", ".png", ".JPG", ".JPEG", ".PNG"]:
        p = os.path.join(IMAGE_DIR, f"{image_id}{ext}")
        if os.path.isfile(p):
            return p

    for fname in os.listdir(IMAGE_DIR):
        stem, ext = os.path.splitext(fname)
        if stem == image_id and ext.lower() in [".jpg", ".jpeg", ".png"]:
            return os.path.join(IMAGE_DIR, fname)

    return None


def cleanup_cuda():
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        torch.cuda.ipc_collect()


def strip_outer_quotes(s: str) -> str:
    s = s.strip()
    pairs = [
        ('"', '"'),
        ("'", "'"),
        ("“", "”"),
        ("‘", "’"),
    ]
    changed = True
    while changed and len(s) >= 2:
        changed = False
        for lq, rq in pairs:
            if s.startswith(lq) and s.endswith(rq):
                s = s[1:-1].strip()
                changed = True
    return s


def looks_like_bad_meta_response(s: str) -> bool:
    s_low = s.lower().strip()

    bad_prefixes = [
        "i'm sorry",
        "i am sorry",
        "sorry,",
        "sorry but",
        "i cannot",
        "i can't",
        "i do not",
        "i don't",
        "cannot assist",
        "can't assist",
        "what is this",
        "this is in hausa",
        "the sentence you provided is in hausa",
        "the source sentence does not translate",
        "does not translate into english",
        "cannot translate",
        "translation:",
        "the translation is:",
        "the source sentence translates to",
    ]
    if any(s_low.startswith(x) for x in bad_prefixes):
        return True

    bad_substrings = [
        "i'm sorry, but",
        "i cannot assist with that",
        "doesn't translate into english",
        "does not translate into english",
        "the sentence you provided is in hausa",
        "language spoken in nigeria",
        "return only the translation",
        "the translation is:",
        "the source sentence translates to",
        "what is this?",
    ]
    if any(x in s_low for x in bad_substrings):
        return True

    return False


def is_valid_english_translation(s: str) -> bool:
    if not s:
        return False

    s = s.strip()
    if not s:
        return False

    # 不要问句/元输出/明显拒答
    if "?" in s:
        return False
    if looks_like_bad_meta_response(s):
        return False

    # 过长重复垃圾输出直接判无效
    if len(s) > 400:
        return False

    # “The translation is: ...” 类重复嵌套仍未清掉则无效
    low = s.lower()
    if low.count("the translation is") >= 1:
        return False

    # 至少应包含英文字母
    if not re.search(r"[A-Za-z]", s):
        return False

    return True


def clean_translation_output(text: str) -> str:
    if not text:
        return ""

    s = text.strip()
    s = re.sub(r"\s+", " ", s).strip()

    # 多轮清洗，去掉重复的元前缀
    for _ in range(10):
        old = s

        patterns = [
            r'^\s*the\s+translation\s+(?:is)?\s*[:：]\s*',
            r'^\s*translation\s*[:：]\s*',
            r'^\s*the\s+source\s+sentence\s+translates?\s+(?:to|into\s+english(?:\s+as)?)\s*[:：]?\s*',
            r'^\s*this\s+translates?\s+(?:to|as)\s*[:：]?\s*',
            r'^\s*english\s+translation\s*[:：]\s*',
        ]
        for p in patterns:
            s = re.sub(p, '', s, flags=re.IGNORECASE).strip()

        s = strip_outer_quotes(s)

        if s == old:
            break

    # 只取第一行
    s = s.split("\n")[0].strip()
    s = strip_outer_quotes(s)
    s = re.sub(r"\s+", " ", s).strip()

    # 若仍然包含嵌套的 The translation is:，继续从最后一个冒号后截取
    # 例如：
    # The translation is: "The translation is: "The translation is: black clothed man"
    if re.search(r'the\s+translation\s+is\s*[:：]', s, flags=re.IGNORECASE):
        parts = re.split(r'the\s+translation\s+is\s*[:：]\s*', s, flags=re.IGNORECASE)
        candidate = parts[-1].strip()
        candidate = strip_outer_quotes(candidate)
        if candidate:
            s = candidate

    # 截掉常见解释性后缀
    s = re.split(
        r'\s+(?:because|which means|meaning|that is|it means)\s+',
        s,
        maxsplit=1,
        flags=re.IGNORECASE
    )[0].strip()

    # 清掉包裹性标点
    s = s.strip(" \t\r\n\"'“”‘’`")
    s = re.sub(r"\s+", " ", s).strip()

    # 明显坏输出直接置空
    if looks_like_bad_meta_response(s):
        return ""

    if not is_valid_english_translation(s):
        return ""

    return s


def load_model():
    print("[Info] Loading model ...")
    model = Qwen2VLForConditionalGeneration.from_pretrained(
        QWEN_PATH,
        torch_dtype=DTYPE,
        device_map="auto",
        trust_remote_code=True
    )
    processor = AutoProcessor.from_pretrained(
        QWEN_PATH,
        trust_remote_code=True
    )
    print("[Info] Model loaded.")
    return model, processor


def generate_and_clean(model, processor, messages, image: Optional[Image.Image], retry_times: int) -> str:
    text = processor.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True
    )

    if image is not None:
        inputs = processor(
            text=[text],
            images=[image],
            padding=True,
            return_tensors="pt"
        )
    else:
        inputs = processor(
            text=[text],
            padding=True,
            return_tensors="pt"
        )

    inputs = {
        k: v.to(model.device) if hasattr(v, "to") else v
        for k, v in inputs.items()
    }

    for _ in range(retry_times + 1):
        with torch.no_grad():
            out = model.generate(
                **inputs,
                max_new_tokens=64,
                do_sample=False,
                use_cache=True
            )

        out = out[:, inputs["input_ids"].shape[1]:]
        result = processor.batch_decode(
            out,
            skip_special_tokens=True,
            clean_up_tokenization_spaces=True
        )[0].strip()

        result = clean_translation_output(result)
        if result:
            return result

    return ""


def translate_with_image(model, processor, image: Image.Image, src: str) -> str:
    prompt = f"""
Translate the source sentence into English taking consideration of the image.

Return only the translation.
Do not output any explanation.
Do not output phrases like:
- The translation is:
- The source sentence translates to
- The source sentence does not translate into English
Return only the final English translation text itself.

Source:
{src}
""".strip()

    messages = [{
        "role": "user",
        "content": [
            {"type": "image"},
            {"type": "text", "text": prompt}
        ]
    }]

    return generate_and_clean(
        model=model,
        processor=processor,
        messages=messages,
        image=image,
        retry_times=RETRY_TIMES
    )


def translate_text_only(model, processor, src: str) -> str:
    prompt = f"""
Translate the source sentence into English.

Return only the translation.
Do not output any explanation.
Do not output phrases like:
- The translation is:
- The source sentence translates to
- The source sentence does not translate into English
Return only the final English translation text itself.

Source:
{src}
""".strip()

    messages = [{
        "role": "user",
        "content": [
            {"type": "text", "text": prompt}
        ]
    }]

    return generate_and_clean(
        model=model,
        processor=processor,
        messages=messages,
        image=None,
        retry_times=FALLBACK_RETRY_TIMES
    )


def translate(model, processor, image: Optional[Image.Image], src: str) -> str:
    translation = ""

    if image is not None:
        translation = translate_with_image(model, processor, image, src)

    if not translation:
        translation = translate_text_only(model, processor, src)

    # 最终再做一次兜底清洗
    translation = clean_translation_output(translation)
    return translation


def main():
    data = load_jsonl(INPUT_JSONL)
    total = len(data)

    print(f"[Info] Total samples: {total}")
    print(f"[Info] CUDA available: {torch.cuda.is_available()}")
    if torch.cuda.is_available():
        print(f"[Info] Visible GPU count: {torch.cuda.device_count()}")
        print(f"[Info] Current device: {torch.cuda.current_device()}")

    model, processor = load_model()

    os.makedirs(os.path.dirname(OUTPUT_CSV), exist_ok=True)

    start_time = time.time()
    buffer = []
    saved = 0

    with open(OUTPUT_CSV, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "image_id",
                "source_text",
                "initial_translation_en"
            ],
            extrasaction="ignore"
        )
        writer.writeheader()

        for i, item in enumerate(data, 1):
            iter_start = time.time()

            image_id = str(item.get("image_id", "")).strip()
            source_text = str(item.get("tgt", "")).strip()

            if not source_text:
                elapsed = time.time() - start_time
                avg = elapsed / i
                eta = avg * (total - i)
                print(f"[{i}/{total}] skipped_empty_src | elapsed={format_time(elapsed)} | ETA={format_time(eta)}")
                continue

            img_path = find_image(image_id)

            try:
                image = None
                if img_path is not None:
                    image = Image.open(img_path).convert("RGB")

                translation = translate(model, processor, image, source_text)

                # 只写这三个字段，且译文必须是清洗后的纯文本
                row = {
                    "image_id": image_id,
                    "source_text": source_text,
                    "initial_translation_en": translation
                }

                buffer.append(row)
                saved += 1

            except Exception as e:
                print(f"[Error] image_id={image_id} | {repr(e)}")

            finally:
                cleanup_cuda()

            if len(buffer) >= FLUSH_EVERY:
                writer.writerows(buffer)
                f.flush()
                buffer = []

            iter_time = time.time() - iter_start
            elapsed = time.time() - start_time
            avg = elapsed / i
            eta = avg * (total - i)

            print(
                f"[{i}/{total}] "
                f"image_id={image_id} | "
                f"iter={iter_time:.2f}s | "
                f"avg={avg:.2f}s | "
                f"elapsed={format_time(elapsed)} | "
                f"ETA={format_time(eta)} | "
                f"saved={saved}"
            )

        if buffer:
            writer.writerows(buffer)
            f.flush()

    total_time = time.time() - start_time
    print("\n==============================")
    print(f"TOTAL TIME: {format_time(total_time)}")
    print(f"SAVED TO: {OUTPUT_CSV}")
    print("==============================")


if __name__ == "__main__":
    main()