#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import json
import logging
import warnings
import re
from typing import List, Tuple, Dict, Any

import pandas as pd
import torch
import sacrebleu

# ====== 环境 & 日志降噪 ======
os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"
os.environ["TOKENIZERS_PARALLELISM"] = "false"

warnings.filterwarnings("ignore", category=UserWarning)

logging.getLogger("pytorch_lightning").setLevel(logging.ERROR)
logging.getLogger("lightning.pytorch").setLevel(logging.ERROR)
logging.getLogger("lightning").setLevel(logging.ERROR)

# ====== COMET / XCOMET ======
try:
    from comet.models.regression.regression_metric import RegressionMetric
except Exception:
    RegressionMetric = None

try:
    from comet.models.multitask.xcomet_metric import XCOMETMetric
except Exception:
    XCOMETMetric = None


# =====================================================
# 1. 路径配置
# =====================================================
INPUT_TRANSLATION_JSONL = "/home/chenyi/offline_blaser_qe/out/VG/ha/ha_test_translation.jsonl"
INPUT_REFERENCE_JSONL   = "/home/chenyi/offline_blaser_qe/dataSet/VG/ha/ha_vg_test.jsonl"
OUTPUT_DIR              = "/home/chenyi/offline_blaser_qe/out/VG/ha"

# ===== COMET / XCOMET 模型路径 =====
COMET_MODEL_DIR = "/mnt/raid/gzy/comet_model/wmt22-comet-da"
COMET_MODEL_CKPT = os.path.join(COMET_MODEL_DIR, "checkpoints", "model.ckpt")
COMET_ENCODER_DIR = os.path.join(COMET_MODEL_DIR, "xlm-roberta-large")

XCOMET_MODEL_DIR = "/mnt/raid/gzy/comet_model/XCOMET-XL"
XCOMET_MODEL_CKPT = os.path.join(XCOMET_MODEL_DIR, "checkpoints", "model.ckpt")
XCOMET_ENCODER_DIR = os.path.join(XCOMET_MODEL_DIR, "xlm-roberta-xl")

COMET_BATCH_SIZE = 16
USE_GPU = True

# 输出文件
OUTPUT_JSONL = os.path.join(OUTPUT_DIR, "ha_test_translation_scored_with_ref.jsonl")
OUTPUT_CSV   = os.path.join(OUTPUT_DIR, "ha_test_translation_scored_with_ref.csv")


# =====================================================
# 2. 工具函数
# =====================================================
def get_gpus_flag() -> int:
    if USE_GPU and torch.cuda.is_available():
        return 1
    return 0


def read_jsonl(path: str) -> List[dict]:
    rows = []
    with open(path, "r", encoding="utf-8") as f:
        for line_idx, line in enumerate(f, start=1):
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except Exception as e:
                print(f"[WARN] 文件 {path} 第 {line_idx} 行 JSON 解析失败，已跳过: {e}")
    return rows


def write_jsonl(path: str, rows: List[dict]) -> None:
    with open(path, "w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


def normalize_text(x: Any) -> str:
    if x is None:
        return ""
    return str(x).strip()


def normalize_for_compare(x: Any) -> str:
    s = normalize_text(x).lower()
    s = re.sub(r"\s+", " ", s)
    s = s.strip()
    return s


def is_empty_or_same_as_source(source_text: str, hyp: str) -> bool:
    """
    规则：
    1. 初始翻译为空 -> 记 0 分
    2. 初始翻译与原语句相同/基本相同 -> 视为还是原语言，记 0 分
    """
    hyp_norm = normalize_for_compare(hyp)
    src_norm = normalize_for_compare(source_text)

    if hyp_norm == "":
        return True

    if src_norm != "" and hyp_norm == src_norm:
        return True

    return False


def safe_sentence_bleu(hyp: str, ref: str) -> float:
    if hyp == "":
        return 0.0
    return round(sacrebleu.sentence_bleu(hyp, [ref]).score, 2)


def safe_sentence_chrf(hyp: str, ref: str) -> float:
    if hyp == "":
        return 0.0
    return round(sacrebleu.sentence_chrf(hyp, [ref]).score, 2)


def compute_bleu_chrf_with_zero_mask(
    hyps: List[str],
    refs: List[str],
    zero_mask: List[int]
) -> Tuple[List[float], List[float], float, float]:
    """
    对于 zero_mask=1 的样本，BLEU/chrF++ 直接记 0，并参与最终平均分。
    """
    bleu_seg = []
    chrf_seg = []

    for hyp, ref, zero_flag in zip(hyps, refs, zero_mask):
        if zero_flag == 1:
            bleu_seg.append(0.0)
            chrf_seg.append(0.0)
        else:
            bleu_seg.append(safe_sentence_bleu(hyp, ref))
            chrf_seg.append(safe_sentence_chrf(hyp, ref))

    bleu_sys = round(sum(bleu_seg) / len(bleu_seg), 2) if bleu_seg else 0.0
    chrf_sys = round(sum(chrf_seg) / len(chrf_seg), 2) if chrf_seg else 0.0

    print(f"[RESULT] BLEU   = {bleu_sys:.2f}")
    print(f"[RESULT] chrF++ = {chrf_sys:.2f}")

    return bleu_seg, chrf_seg, bleu_sys, chrf_sys


def compute_comet(
    comet_model,
    srcs: List[str],
    hyps: List[str],
    refs: List[str]
) -> Tuple[List[float], float]:
    samples = [{"src": s, "mt": h, "ref": r} for s, h, r in zip(srcs, hyps, refs)]

    gpus = get_gpus_flag()
    result = comet_model.predict(
        samples,
        batch_size=COMET_BATCH_SIZE,
        gpus=gpus,
        progress_bar=False
    )

    if isinstance(result, dict):
        sys_score = result.get("system_score", float("nan"))
        scores = result.get("scores", [float("nan")] * len(srcs))
    else:
        scores, sys_score = result

    scores_100 = [round(float(s) * 100, 2) if s == s else 0.0 for s in scores]

    if isinstance(sys_score, str):
        try:
            sys_score_float = round(float(sys_score) * 100, 2)
        except ValueError:
            print(f"[RESULT] COMET system score = {sys_score}")
            return scores_100, 0.0
    else:
        sys_score_float = round(float(sys_score) * 100, 2)

    print(f"[RESULT] COMET (wmt22-comet-da) system score = {sys_score_float:.2f}")
    return scores_100, sys_score_float


def compute_xcomet(
    xcomet_model,
    srcs: List[str],
    hyps: List[str]
) -> Tuple[List[float], float]:
    samples = [{"src": s, "mt": h} for s, h in zip(srcs, hyps)]

    gpus = get_gpus_flag()
    result = xcomet_model.predict(
        samples,
        batch_size=COMET_BATCH_SIZE,
        gpus=gpus,
        progress_bar=False
    )

    if isinstance(result, dict):
        sys_score = result.get("system_score", float("nan"))
        scores = result.get("scores", [float("nan")] * len(srcs))
    else:
        scores, sys_score = result

    scores_100 = [round(float(s) * 100, 2) if s == s else 0.0 for s in scores]

    if isinstance(sys_score, str):
        try:
            sys_score_float = round(float(sys_score) * 100, 2)
        except ValueError:
            print(f"[RESULT] XCOMET-XL system score = {sys_score}")
            return scores_100, 0.0
    else:
        sys_score_float = round(float(sys_score) * 100, 2)

    print(f"[RESULT] XCOMET-XL system score = {sys_score_float:.2f}")
    return scores_100, sys_score_float


# =====================================================
# 3. 数据对齐
# =====================================================
def build_reference_map(ref_rows: List[dict]) -> Dict[str, str]:
    """
    从参考文件中建立 image_id -> src_en 的映射
    """
    ref_map = {}
    for row in ref_rows:
        image_id = row.get("image_id", row.get("id", None))
        src_en = normalize_text(row.get("src_en", ""))

        if image_id is None:
            continue

        image_id_key = str(image_id)
        ref_map[image_id_key] = src_en

    return ref_map


def align_rows(
    trans_rows: List[dict],
    ref_map: Dict[str, str]
) -> List[dict]:
    """
    按 image_id 对齐:
    translation jsonl: image_id, source_text, initial_translation_en
    reference   jsonl: image_id, src_en
    """
    aligned = []
    miss_ref = 0

    for row in trans_rows:
        image_id = row.get("image_id", row.get("id", None))
        if image_id is None:
            continue

        image_id_key = str(image_id)

        source_text = normalize_text(row.get("source_text", ""))
        hyp = normalize_text(row.get("initial_translation_en", ""))

        if image_id_key not in ref_map:
            miss_ref += 1
            continue

        ref = normalize_text(ref_map[image_id_key])

        aligned.append({
            "image_id": image_id,
            "source_text": source_text,
            "initial_translation_en": hyp,
            "reference_en": ref
        })

    print(f"[INFO] 成功对齐条数: {len(aligned)}")
    print(f"[INFO] 缺少参考译文而跳过的条数: {miss_ref}")
    return aligned


# =====================================================
# 4. 主函数
# =====================================================
def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    if not os.path.exists(INPUT_TRANSLATION_JSONL):
        raise FileNotFoundError(f"待评分文件不存在: {INPUT_TRANSLATION_JSONL}")
    if not os.path.exists(INPUT_REFERENCE_JSONL):
        raise FileNotFoundError(f"参考文件不存在: {INPUT_REFERENCE_JSONL}")

    print(f"[INFO] 读取待评分文件: {INPUT_TRANSLATION_JSONL}")
    trans_rows = read_jsonl(INPUT_TRANSLATION_JSONL)
    print(f"[INFO] 待读取条数: {len(trans_rows)}")

    print(f"[INFO] 读取参考文件: {INPUT_REFERENCE_JSONL}")
    ref_rows = read_jsonl(INPUT_REFERENCE_JSONL)
    print(f"[INFO] 参考文件条数: {len(ref_rows)}")

    ref_map = build_reference_map(ref_rows)
    aligned_rows = align_rows(trans_rows, ref_map)

    if len(aligned_rows) == 0:
        raise RuntimeError("没有成功对齐的数据，无法打分。请检查 image_id 和 src_en 字段。")

    # -----------------------------------------------------
    # 初始化样本状态：
    # 1. 空翻译 -> 0分
    # 2. 与原语句相同/基本相同 -> 视为原语言未翻译，0分
    # -----------------------------------------------------
    for row in aligned_rows:
        source_text = row["source_text"]
        hyp = row["initial_translation_en"]

        row["is_empty_or_source_language"] = 1 if is_empty_or_same_as_source(source_text, hyp) else 0
        row["BLEU"] = 0.0
        row["Chrf++"] = 0.0
        row["COMET"] = 0.0
        row["XCOMET-XL"] = 0.0

    valid_rows = [row for row in aligned_rows if row["is_empty_or_source_language"] == 0]
    invalid_count = len(aligned_rows) - len(valid_rows)

    print(f"[INFO] 空翻译或原语言未翻译条数: {invalid_count}")
    print(f"[INFO] 有效英文翻译条数: {len(valid_rows)}")

    # -----------------------------------------------------
    # BLEU / chrF++：全部样本都参与
    # invalid 样本直接记 0
    # -----------------------------------------------------
    all_hyp_list = [row["initial_translation_en"] for row in aligned_rows]
    all_ref_list = [row["reference_en"] for row in aligned_rows]
    zero_mask = [row["is_empty_or_source_language"] for row in aligned_rows]

    print("[INFO] 评估 BLEU / chrF++ ...")
    bleu_seg, chrf_seg, bleu_sys, chrf_sys = compute_bleu_chrf_with_zero_mask(
        all_hyp_list, all_ref_list, zero_mask
    )

    for i, row in enumerate(aligned_rows):
        row["BLEU"] = bleu_seg[i]
        row["Chrf++"] = chrf_seg[i]

    # -----------------------------------------------------
    # COMET / XCOMET：只对有效样本调用模型
    # invalid 样本保持 0 分
    # 最终系统分：所有样本逐句平均
    # -----------------------------------------------------
    comet_sys = 0.0
    xcomet_sys = 0.0

    if len(valid_rows) > 0:
        src_list_valid = [row["source_text"] for row in valid_rows]
        hyp_list_valid = [row["initial_translation_en"] for row in valid_rows]
        ref_list_valid = [row["reference_en"] for row in valid_rows]

        # -------------------------------------------------
        # 加载 COMET
        # -------------------------------------------------
        print("[INFO] 正在加载 COMET 模型 (wmt22-comet-da)...")
        if RegressionMetric is None:
            raise RuntimeError("找不到 RegressionMetric，请检查 comet 安装版本。")

        comet_model = RegressionMetric.load_from_checkpoint(
            COMET_MODEL_CKPT,
            pretrained_model=COMET_ENCODER_DIR,
            load_pretrained_weights=False,
            strict=False
        )
        if get_gpus_flag() > 0:
            comet_model = comet_model.cuda()
        comet_model.eval()

        # -------------------------------------------------
        # 加载 XCOMET
        # -------------------------------------------------
        print("[INFO] 正在加载 XCOMET 模型 (XCOMET-XL)...")
        if XCOMETMetric is None:
            raise RuntimeError("找不到 XCOMETMetric，请确认 unbabel-comet 版本 >= 2.2.0。")

        xcomet_model = XCOMETMetric.load_from_checkpoint(
            XCOMET_MODEL_CKPT,
            pretrained_model=XCOMET_ENCODER_DIR,
            load_pretrained_weights=False,
            strict=False
        )
        if get_gpus_flag() > 0:
            xcomet_model = xcomet_model.cuda()
        xcomet_model.eval()

        print("[INFO] 模型加载完成，开始评估 COMET / XCOMET。")

        # -------------------------------------------------
        # COMET
        # -------------------------------------------------
        print("[INFO] 评估 COMET ...")
        comet_seg_valid, _ = compute_comet(
            comet_model, src_list_valid, hyp_list_valid, ref_list_valid
        )

        # -------------------------------------------------
        # XCOMET
        # -------------------------------------------------
        print("[INFO] 评估 XCOMET-XL ...")
        xcomet_seg_valid, _ = compute_xcomet(
            xcomet_model, src_list_valid, hyp_list_valid
        )

        # 写回有效样本分数
        for row, c_score, x_score in zip(valid_rows, comet_seg_valid, xcomet_seg_valid):
            row["COMET"] = c_score
            row["XCOMET-XL"] = x_score

        # 最终平均：包含 0 分样本
        comet_sys = round(sum(row["COMET"] for row in aligned_rows) / len(aligned_rows), 2)
        xcomet_sys = round(sum(row["XCOMET-XL"] for row in aligned_rows) / len(aligned_rows), 2)

    else:
        print("[INFO] 所有初始翻译都为空或仍是原语言，COMET / XCOMET-XL 全部记为 0。")
        comet_sys = 0.0
        xcomet_sys = 0.0

    print(f"[RESULT] COMET (含空译文/原语言未译记0后的最终平均) = {comet_sys:.2f}")
    print(f"[RESULT] XCOMET-XL (含空译文/原语言未译记0后的最终平均) = {xcomet_sys:.2f}")

    # -----------------------------------------------------
    # 整理输出
    # -----------------------------------------------------
    output_rows = []
    for row in aligned_rows:
        out = {
            "image_id": row["image_id"],
            "source_text": row["source_text"],
            "initial_translation_en": row["initial_translation_en"],
            "reference_en": row["reference_en"],
            "is_empty_or_source_language": row["is_empty_or_source_language"],
            "BLEU": row["BLEU"],
            "Chrf++": row["Chrf++"],
            "COMET": row["COMET"],
            "XCOMET-XL": row["XCOMET-XL"]
        }
        output_rows.append(out)

    # 保存 jsonl
    write_jsonl(OUTPUT_JSONL, output_rows)
    print(f"[INFO] JSONL 结果已保存到: {OUTPUT_JSONL}")

    # 保存 csv，并追加平均分
    df = pd.DataFrame(output_rows)

    avg_row = {
        "image_id": "AVERAGE SCORE",
        "source_text": "---",
        "initial_translation_en": "---",
        "reference_en": "---",
        "is_empty_or_source_language": "---",
        "BLEU": bleu_sys,
        "Chrf++": chrf_sys,
        "COMET": comet_sys,
        "XCOMET-XL": xcomet_sys
    }
    df = pd.concat([df, pd.DataFrame([avg_row])], ignore_index=True)

    df.to_csv(OUTPUT_CSV, index=False, encoding="utf-8-sig")
    print(f"[INFO] CSV 结果已保存到: {OUTPUT_CSV}")
    print("[DONE] 全部评估完成。")


if __name__ == "__main__":
    main()