import os
os.environ["CUDA_VISIBLE_DEVICES"] = "1"
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"

import json
import re
from typing import List, Dict, Optional, Tuple

import torch
import sentencepiece as spm

# =========================
# SONAR / BLASER
# =========================
from sonar.models.sonar_text.model import SequenceBatch
from sonar.models.sonar_text import SonarTextEncoderConfig, create_sonar_text_encoder_model
from sonar.models.blaser.builder import create_blaser_model, _arch_blaser_basic_qe
from sonar.models.blaser.loader import convert_blaser_checkpoint

torch.set_grad_enabled(False)

# =========================================================
# 固定路径配置
# =========================================================
INPUT_JSONL = "/home/chenyi/offline_blaser_qe/out/VG/bn/bn_3_candidates_from_span_v8.jsonl"
REFERENCE_JSONL = "/home/chenyi/offline_blaser_qe/dataSet/VG/bn/bn_vg_test.jsonl"

OUTPUT_DIR = "/home/chenyi/offline_blaser_qe/out/VG/bn"

# 第一份输出：主输出，改成 JSONL
OUTPUT_JSONL = os.path.join(OUTPUT_DIR, "bn_candidates_blaser_repair_noparam_selected.jsonl")

# 第二份输出：reference + best，改成 JSONL
OUTPUT_REF_BEST_JSONL = os.path.join(OUTPUT_DIR, "bn_source_reference_best.jsonl")

CHECKPOINTS_DIR = "/home/chenyi/offline_blaser_qe/checkpoints"
SYSLIBS_DIR = "/home/chenyi/offline_blaser_qe/syslibs"

SONAR_MODEL = os.path.join(CHECKPOINTS_DIR, "sonar_text_encoder.pt")
SPM_MODEL = os.path.join(CHECKPOINTS_DIR, "sentencepiece.source.256000.model")
BLASER_QE_CKPT = os.path.join(CHECKPOINTS_DIR, "blaser_2_0_qe_model.pt")

DEVICE = "cuda"
MAX_LEN = 256
BATCH_ROWS = 64

# 孟加拉语 -> 英语
SRC_LANG = "ben_Beng"
TGT_LANG = "eng_Latn"

# 如果 source_text 为空，可回退到 source_text_en（此时用 eng_Latn 编码）
FALLBACK_TO_SOURCE_TEXT_EN = True

ROUND_DIGITS = 4

# =========================================================
# 文本工具
# =========================================================
COLOR_CANONICAL_MAP = {
    "red": "red", "reddish": "red", "crimson": "red", "scarlet": "red",
    "maroon": "red", "burgundy": "red", "ruby": "red", "wine": "red",
    "rose": "red", "pink": "red", "magenta": "red", "fuchsia": "red",

    "orange": "orange", "orangish": "orange", "coral": "orange", "peach": "orange",
    "apricot": "orange", "amber": "orange", "tangerine": "orange", "salmon": "orange",
    "copper": "orange", "bronze": "orange", "rust": "orange",

    "yellow": "yellow", "gold": "yellow", "golden": "yellow", "beige": "yellow",
    "khaki": "yellow", "cream": "yellow", "ivory": "yellow", "mustard": "yellow",
    "lemon": "yellow", "tan": "yellow",

    "green": "green", "greenish": "green", "lime": "green", "olive": "green",
    "emerald": "green", "mint": "green", "teal": "green", "turquoise": "green",
    "chartreuse": "green",

    "blue": "blue", "bluish": "blue", "navy": "blue", "azure": "blue",
    "cyan": "blue", "aqua": "blue", "indigo": "blue", "skyblue": "blue",
    "royalblue": "blue",

    "purple": "purple", "violet": "purple", "lavender": "purple",
    "lilac": "purple", "plum": "purple",

    "brown": "brown", "brownish": "brown", "chocolate": "brown", "coffee": "brown",
    "mocha": "brown", "camel": "brown", "sandy": "brown", "sand": "brown",
    "taupe": "brown", "wood": "brown", "wooden": "brown",

    "gray": "gray", "grey": "gray", "grayish": "gray", "greyish": "gray",
    "silver": "gray", "charcoal": "gray", "slate": "gray", "ash": "gray",

    "black": "black", "blackish": "black", "ebony": "black",
    "white": "white", "whitish": "white", "pale": "white",
}

NUMBER_WORDS = {
    "zero", "one", "two", "three", "four", "five",
    "six", "seven", "eight", "nine", "ten",
    "eleven", "twelve"
}

DIGIT_TO_WORD = {
    "0": "zero", "1": "one", "2": "two", "3": "three",
    "4": "four", "5": "five", "6": "six", "7": "seven",
    "8": "eight", "9": "nine", "10": "ten", "11": "eleven",
    "12": "twelve",
}

PERSON_SPECIFIC = {
    "man", "woman", "boy", "girl", "guy", "lady",
    "gentleman", "male", "female", "child", "kid", "children"
}


def clean_text(x) -> str:
    if x is None:
        return ""
    return str(x).strip()


def safe_json_loads(x: str):
    x = clean_text(x)
    if not x:
        return {}
    try:
        return json.loads(x)
    except Exception:
        return {}


def normalize_basic_token(w: str) -> str:
    w = w.lower().strip()
    w = w.replace("’", "'").replace("“", '"').replace("”", '"')
    w = re.sub(r"[^a-z0-9\-]", "", w)
    return w


def strip_color_suffixes(w: str) -> str:
    suffixes = [
        "-colored", "colored",
        "-colour", "colour",
        "-hued", "hued",
        "-tinted", "tinted",
        "-toned", "toned",
        "-ish", "ish",
    ]
    for s in suffixes:
        if w.endswith(s) and len(w) > len(s):
            return w[:-len(s)]
    return w


def canonicalize_color_token(w: str) -> str:
    w = normalize_basic_token(w)
    if not w:
        return ""

    if w in COLOR_CANONICAL_MAP:
        return COLOR_CANONICAL_MAP[w]

    w2 = strip_color_suffixes(w)
    if w2 in COLOR_CANONICAL_MAP:
        return COLOR_CANONICAL_MAP[w2]

    if "-" in w:
        parts = [p for p in w.split("-") if p]
        filtered = [strip_color_suffixes(p) for p in parts]
        recognized = [COLOR_CANONICAL_MAP[p] for p in filtered if p in COLOR_CANONICAL_MAP]
        if recognized:
            return recognized[-1]

    limited_prefixes = [
        "red", "blue", "green", "yellow", "orange",
        "purple", "brown", "gray", "grey", "black", "white"
    ]
    for p in limited_prefixes:
        if w.startswith(p):
            return COLOR_CANONICAL_MAP[p]
    return ""


def extract_color_set(text: str) -> List[str]:
    colors = set()
    for w in re.findall(r"[A-Za-z0-9\-]+", text.lower()):
        c = canonicalize_color_token(w)
        if c:
            colors.add(c)
    return sorted(list(colors))


def canonicalize_number_token(w: str) -> str:
    w = normalize_basic_token(w)
    if w in DIGIT_TO_WORD:
        return DIGIT_TO_WORD[w]
    if w in NUMBER_WORDS:
        return w
    return ""


def extract_number_set(text: str) -> List[str]:
    nums = set()
    for w in re.findall(r"[A-Za-z0-9\-]+", text.lower()):
        n = canonicalize_number_token(w)
        if n:
            nums.add(n)
    return sorted(list(nums))


def extract_word_set(text: str) -> set:
    ws = set()
    for w in re.findall(r"[A-Za-z0-9\-]+", text.lower()):
        nw = normalize_basic_token(w)
        if nw:
            ws.add(nw)
    return ws


def format_score(x: float) -> float:
    return round(float(x), ROUND_DIGITS)


def write_jsonl_record(fp, obj: Dict):
    fp.write(json.dumps(obj, ensure_ascii=False) + "\n")


# =========================================================
# JSONL
# =========================================================
def read_jsonl_records(path: str) -> List[Dict]:
    if not os.path.isfile(path):
        raise FileNotFoundError(f"JSONL not found: {path}")
    data = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            data.append(json.loads(line))
    return data


def build_reference_map(records: List[Dict]) -> Tuple[Dict[str, str], Dict[str, str]]:
    image_id_to_src_en = {}
    source_text_to_src_en = {}

    for r in records:
        image_id = clean_text(r.get("image_id", ""))
        source_text = clean_text(r.get("tgt", ""))
        src_en = clean_text(r.get("src_en", ""))

        if image_id and src_en and image_id not in image_id_to_src_en:
            image_id_to_src_en[image_id] = src_en

        if source_text and src_en and source_text not in source_text_to_src_en:
            source_text_to_src_en[source_text] = src_en

    return image_id_to_src_en, source_text_to_src_en


def get_reference_translation(
    row: Dict,
    image_id_to_src_en: Dict[str, str],
    source_text_to_src_en: Dict[str, str]
) -> str:
    image_id = clean_text(row.get("id", row.get("image_id", "")))
    source_text = clean_text(row.get("source_text", ""))

    if image_id and image_id in image_id_to_src_en:
        return image_id_to_src_en[image_id]

    if source_text and source_text in source_text_to_src_en:
        return source_text_to_src_en[source_text]

    return ""


# =========================================================
# sentencepiece encode
# =========================================================
def sp_encode_batch(
    sp: spm.SentencePieceProcessor,
    texts: List[str],
    lang: str,
    max_len: int = 512,
    pad_id: int = 0
):
    tagged = [f"__{lang}__ {str(t).strip()}" for t in texts]

    ids = [sp.encode(t, out_type=int)[:max_len] for t in tagged]
    lens = [len(x) for x in ids]
    maxl = max(lens) if lens else 0

    x = torch.full((len(ids), maxl), pad_id, dtype=torch.long)
    for i, row in enumerate(ids):
        if row:
            x[i, :len(row)] = torch.tensor(row, dtype=torch.long)

    attn = (x != pad_id)
    return x, attn


def build_vocab_info_from_spm(spm_path: str, vocab_size_override: Optional[int] = None):
    from fairseq2.data.vocabulary_info import VocabularyInfo

    sp = spm.SentencePieceProcessor(model_file=spm_path)
    unk = sp.unk_id()
    bos = sp.bos_id()
    eos = sp.eos_id()
    pad = sp.pad_id() if hasattr(sp, "pad_id") else -1
    if pad is None or pad < 0:
        pad = 0

    size = vocab_size_override if vocab_size_override is not None else sp.get_piece_size()

    return VocabularyInfo(
        size=int(size),
        unk_idx=int(unk),
        bos_idx=int(bos),
        eos_idx=int(eos),
        pad_idx=int(pad),
    )


# =========================================================
# SONAR Text Encoder: offline load from state_dict
# =========================================================
def load_sonar_text_encoder_offline(
    encoder_ckpt: str,
    spm_path: str,
    device: torch.device,
    max_seq_len: int = 512
):
    if not os.path.isfile(encoder_ckpt):
        raise FileNotFoundError(f"SONAR text encoder checkpoint not found: {encoder_ckpt}")
    if not os.path.isfile(spm_path):
        raise FileNotFoundError(f"SentencePiece model not found: {spm_path}")

    ckpt = torch.load(encoder_ckpt, map_location="cpu")
    if not isinstance(ckpt, dict) or "model" not in ckpt:
        raise RuntimeError(
            f"Unexpected encoder checkpoint format: type={type(ckpt)} "
            f"keys={list(ckpt.keys()) if isinstance(ckpt, dict) else None}"
        )

    state_dict = ckpt["model"]
    if not isinstance(state_dict, dict):
        raise RuntimeError(
            f"Expected ckpt['model'] to be a state_dict dict/OrderedDict, got {type(state_dict)}"
        )

    emb_w = state_dict["encoder_frontend.embed.weight"]
    vocab_size = emb_w.shape[0]
    model_dim = emb_w.shape[1]

    ffn_w = state_dict["encoder.layers.0.ffn.inner_proj.weight"]
    ffn_inner_dim = ffn_w.shape[0]

    max_layer = -1
    for k in state_dict.keys():
        if k.startswith("encoder.layers."):
            parts = k.split(".")
            if len(parts) > 2 and parts[2].isdigit():
                max_layer = max(max_layer, int(parts[2]))
    num_encoder_layers = max_layer + 1

    vocab_info = build_vocab_info_from_spm(spm_path, vocab_size_override=int(vocab_size))
    num_heads = 16

    cfg = SonarTextEncoderConfig(
        model_dim=int(model_dim),
        max_seq_len=int(max_seq_len),
        vocab_info=vocab_info,
        num_encoder_layers=int(num_encoder_layers),
        num_decoder_layers=0,
        num_encoder_attn_heads=int(num_heads),
        num_decoder_attn_heads=0,
        ffn_inner_dim=int(ffn_inner_dim),
        pooling="mean",
    )

    encoder = create_sonar_text_encoder_model(cfg, device=device).eval()

    missing, unexpected = encoder.load_state_dict(state_dict, strict=False)
    if missing or unexpected:
        print(
            f"[warn] SONAR encoder load_state_dict(strict=False): "
            f"missing={len(missing)} unexpected={len(unexpected)}"
        )

    sp = spm.SentencePieceProcessor(model_file=spm_path)
    return encoder, sp


@torch.no_grad()
def sonar_encode(
    encoder,
    sp: spm.SentencePieceProcessor,
    texts: List[str],
    lang: str,
    device: torch.device,
    max_len: int = 512
) -> torch.Tensor:
    toks, attn = sp_encode_batch(
        sp,
        texts,
        lang=lang,
        max_len=max_len,
        pad_id=0
    )
    toks = toks.to(device)
    attn = attn.to(device)

    padding_mask = None
    try:
        from fairseq2.nn.padding import PaddingMask
        pad = ~attn
        if hasattr(PaddingMask, "from_bool_tensor"):
            padding_mask = PaddingMask.from_bool_tensor(pad)
        elif hasattr(PaddingMask, "from_bool"):
            padding_mask = PaddingMask.from_bool(pad)
        else:
            padding_mask = PaddingMask(pad)
    except Exception:
        padding_mask = None

    batch = SequenceBatch(seqs=toks, padding_mask=padding_mask)
    out = encoder(batch)

    if hasattr(out, "sentence_embeddings"):
        emb = out.sentence_embeddings
    elif isinstance(out, dict) and "sentence_embeddings" in out:
        emb = out["sentence_embeddings"]
    elif isinstance(out, (list, tuple)):
        emb = out[0]
    elif isinstance(out, torch.Tensor):
        emb = out
    else:
        raise RuntimeError(f"Unsupported SONAR encoder output type: {type(out)}")

    if emb.dim() != 2:
        raise RuntimeError(f"Unexpected embedding shape: {tuple(emb.shape)}")

    return emb


# =========================================================
# BLASER-QE offline load + scoring
# =========================================================
def load_blaser_qe_offline(blaser_ckpt: str, device: torch.device):
    if not os.path.isfile(blaser_ckpt):
        raise FileNotFoundError(f"BLASER-QE checkpoint not found: {blaser_ckpt}")

    cfg = _arch_blaser_basic_qe()
    model = create_blaser_model(cfg, device=device).eval()

    raw = torch.load(blaser_ckpt, map_location="cpu")

    candidate = raw
    if isinstance(candidate, dict) and "model" in candidate and isinstance(candidate["model"], dict):
        candidate = candidate["model"]
    elif isinstance(candidate, dict) and "state_dict" in candidate and isinstance(candidate["state_dict"], dict):
        candidate = candidate["state_dict"]

    try:
        state = convert_blaser_checkpoint(candidate, cfg)
    except Exception as e:
        print(f"[warn] convert_blaser_checkpoint failed, fallback to direct state_dict. err={repr(e)}")
        state = candidate

    if isinstance(state, dict) and "model" in state and isinstance(state["model"], dict):
        state = state["model"]

    missing, unexpected = model.load_state_dict(state, strict=False)
    if missing or unexpected:
        print(
            f"[warn] BLASER load_state_dict(strict=False): "
            f"missing={len(missing)} unexpected={len(unexpected)}"
        )

    return model


@torch.no_grad()
def blaser_qe_scores(blaser_model, src_emb: torch.Tensor, mt_emb: torch.Tensor) -> List[float]:
    try:
        s = blaser_model(src_emb, mt_emb)
    except TypeError:
        s = blaser_model(src=src_emb, mt=mt_emb)

    if s.dim() == 2 and s.size(-1) == 1:
        s = s.squeeze(-1)

    return s.detach().cpu().tolist()


# =========================================================
# Softmax normalization
# =========================================================
def softmax_3(scores: List[float]) -> List[float]:
    t = torch.tensor(scores, dtype=torch.float32)
    probs = torch.softmax(t, dim=0)
    return probs.tolist()


# =========================================================
# Repair bonus
# =========================================================
def build_min_hallucination_analysis(row: Dict) -> Dict:
    htype = clean_text(row.get("primary_hallucination_type", ""))
    target_span = clean_text(row.get("target_hallucination_span", ""))

    out = {
        "hallucination_types": [htype] if htype else [],
        "hallucinated_words": [],
        "extra_content_words": [],
        "refinement_words": [],
        "attribute_color_words": [],
        "attribute_number_words": [],
    }

    if target_span:
        span_words = [normalize_basic_token(x) for x in re.findall(r"[A-Za-z0-9\-]+", target_span.lower())]
        span_words = [x for x in span_words if x]

        if htype == "attribute_color":
            out["attribute_color_words"] = span_words
            out["hallucinated_words"] = span_words
        elif htype == "attribute_number":
            out["attribute_number_words"] = span_words
            out["hallucinated_words"] = span_words
        elif htype == "semantic_refinement":
            out["refinement_words"] = span_words
            out["hallucinated_words"] = span_words
        elif htype in {"extra_content", "unsupported_span"}:
            out["extra_content_words"] = span_words
            out["hallucinated_words"] = span_words
        else:
            out["hallucinated_words"] = span_words

    return out


def compute_repair_bonus(
    initial_translation: str,
    candidate: str,
    hallucination_analysis: Dict
) -> float:
    types = hallucination_analysis.get("hallucination_types", []) or []
    hallucinated_words = [normalize_basic_token(x) for x in (hallucination_analysis.get("hallucinated_words", []) or [])]
    extra_content_words = [normalize_basic_token(x) for x in (hallucination_analysis.get("extra_content_words", []) or [])]
    refinement_words = [normalize_basic_token(x) for x in (hallucination_analysis.get("refinement_words", []) or [])]
    attr_color_words = [normalize_basic_token(x) for x in (hallucination_analysis.get("attribute_color_words", []) or [])]
    attr_number_words = [normalize_basic_token(x) for x in (hallucination_analysis.get("attribute_number_words", []) or [])]

    cand_words = extract_word_set(candidate)

    bonus_parts = []

    if "extra_content" in types or "unsupported_span" in types:
        if extra_content_words:
            removed = sum(1 for w in extra_content_words if w not in cand_words)
            bonus_parts.append(removed / max(1, len(extra_content_words)))
        else:
            bonus_parts.append(0.5)

    if "semantic_refinement" in types:
        if refinement_words:
            removed = sum(1 for w in refinement_words if w not in cand_words)
            bonus_parts.append(removed / max(1, len(refinement_words)))
        else:
            specific_now = sum(1 for w in PERSON_SPECIFIC if w in cand_words)
            bonus_parts.append(1.0 if specific_now == 0 else 0.0)

    if "attribute_color" in types:
        cand_colors = set(extract_color_set(candidate))
        bad_colors = set(canonicalize_color_token(w) for w in attr_color_words if canonicalize_color_token(w))
        if bad_colors:
            bonus_parts.append(1.0 if len(cand_colors & bad_colors) == 0 else 0.0)
        else:
            bonus_parts.append(0.5)

    if "attribute_number" in types:
        cand_nums = set(extract_number_set(candidate))
        bad_nums = set(canonicalize_number_token(w) for w in attr_number_words if canonicalize_number_token(w))
        if bad_nums:
            bonus_parts.append(1.0 if len(cand_nums & bad_nums) == 0 else 0.0)
        else:
            bonus_parts.append(0.5)

    if hallucinated_words:
        removed = sum(1 for w in hallucinated_words if w not in cand_words)
        bonus_parts.append(removed / max(1, len(hallucinated_words)))

    if not bonus_parts:
        return 1.0

    return float(sum(bonus_parts) / len(bonus_parts))


# =========================================================
# No-parameter selection rule
# =========================================================
def select_best_index_no_params(
    blaser_prob3: List[float],
    repair3: List[float]
) -> int:
    ranking = sorted(
        range(3),
        key=lambda i: (repair3[i], blaser_prob3[i], -i),
        reverse=True
    )
    return ranking[0]


# =========================================================
# Main
# =========================================================
def main():
    os.environ["LD_LIBRARY_PATH"] = SYSLIBS_DIR + ":" + os.environ.get("LD_LIBRARY_PATH", "")

    device = torch.device(DEVICE if torch.cuda.is_available() else "cpu")
    print("device:", device, "visible_cuda_count:", torch.cuda.device_count())
    print(f"[info] SRC_LANG={SRC_LANG}, TGT_LANG={TGT_LANG}")

    records = read_jsonl_records(INPUT_JSONL)
    total = len(records)
    print(f"[info] loaded candidate rows: {total}")
    if total == 0:
        print("[warn] no rows found.")
        return

    ref_records = read_jsonl_records(REFERENCE_JSONL)
    image_id_to_src_en, source_text_to_src_en = build_reference_map(ref_records)
    print(f"[info] loaded reference rows: {len(ref_records)}")

    print("[info] loading SONAR encoder...")
    sonar_encoder, sp = load_sonar_text_encoder_offline(
        SONAR_MODEL,
        SPM_MODEL,
        device=device,
        max_seq_len=MAX_LEN
    )

    print("[info] loading BLASER-QE...")
    blaser = load_blaser_qe_offline(BLASER_QE_CKPT, device=device)

    os.makedirs(OUTPUT_DIR, exist_ok=True)

    with open(OUTPUT_JSONL, "w", encoding="utf-8") as f_main, \
         open(OUTPUT_REF_BEST_JSONL, "w", encoding="utf-8") as f_ref_best:

        for b0 in range(0, total, BATCH_ROWS):
            b1 = min(b0 + BATCH_ROWS, total)
            batch = records[b0:b1]

            src_texts: List[str] = []
            src_langs: List[str] = []
            cand_texts: List[str] = []
            row_meta: List[Tuple[int, int]] = []

            for row_idx, row in enumerate(batch):
                source_text = clean_text(row.get("source_text", ""))
                source_text_en = clean_text(row.get("source_text_en", ""))

                if source_text:
                    src_for_score = source_text
                    src_lang = SRC_LANG
                elif FALLBACK_TO_SOURCE_TEXT_EN and source_text_en:
                    src_for_score = source_text_en
                    src_lang = TGT_LANG
                else:
                    src_for_score = ""
                    src_lang = SRC_LANG

                cands = [
                    clean_text(row.get("candidate_1", "")),
                    clean_text(row.get("candidate_2", "")),
                    clean_text(row.get("candidate_3", "")),
                ]

                for cand_idx, cand in enumerate(cands):
                    src_texts.append(src_for_score)
                    src_langs.append(src_lang)
                    cand_texts.append(cand)
                    row_meta.append((row_idx, cand_idx))

            src_emb_list = [None] * len(src_texts)
            lang_to_indices: Dict[str, List[int]] = {}
            for i, lg in enumerate(src_langs):
                lang_to_indices.setdefault(lg, []).append(i)

            for lg, idxs in lang_to_indices.items():
                texts_sub = [src_texts[i] for i in idxs]
                emb_sub = sonar_encode(
                    sonar_encoder,
                    sp,
                    texts_sub,
                    lang=lg,
                    device=device,
                    max_len=MAX_LEN
                )
                for j, global_i in enumerate(idxs):
                    src_emb_list[global_i] = emb_sub[j]

            src_emb = torch.stack(src_emb_list, dim=0)

            mt_emb = sonar_encode(
                sonar_encoder,
                sp,
                cand_texts,
                lang=TGT_LANG,
                device=device,
                max_len=MAX_LEN
            )

            raw_scores = blaser_qe_scores(blaser, src_emb, mt_emb)

            row_to_raw_scores: Dict[int, List[float]] = {i: [0.0, 0.0, 0.0] for i in range(len(batch))}
            for score, (row_idx, cand_idx) in zip(raw_scores, row_meta):
                row_to_raw_scores[row_idx][cand_idx] = float(score)

            for row_idx, row in enumerate(batch):
                row_id = clean_text(row.get("id", row.get("image_id", "")))
                image_path = clean_text(row.get("image_path", ""))
                source_text = clean_text(row.get("source_text", ""))
                initial_translation = clean_text(row.get("initial_translation", row.get("initial_translation_en", "")))

                cands = [
                    clean_text(row.get("candidate_1", "")),
                    clean_text(row.get("candidate_2", "")),
                    clean_text(row.get("candidate_3", "")),
                ]

                if "hallucination_analysis" in row:
                    hallucination_analysis = safe_json_loads(row.get("hallucination_analysis", ""))
                else:
                    hallucination_analysis = build_min_hallucination_analysis(row)

                raw3 = row_to_raw_scores[row_idx]
                blaser_prob3 = softmax_3(raw3)

                repair3 = [
                    compute_repair_bonus(initial_translation, cands[0], hallucination_analysis),
                    compute_repair_bonus(initial_translation, cands[1], hallucination_analysis),
                    compute_repair_bonus(initial_translation, cands[2], hallucination_analysis),
                ]

                best_idx = select_best_index_no_params(blaser_prob3, repair3)
                best_translation = cands[best_idx]

                # 第一份输出
                out_main = {
                    "id": row_id,
                    "image_path": image_path,
                    "source_text": source_text,
                    "initial_translation": initial_translation,
                    "target_hallucination_span": clean_text(row.get("target_hallucination_span", "")),
                    "primary_hallucination_type": clean_text(row.get("primary_hallucination_type", "")),
                    "hallucination_mode": clean_text(row.get("hallucination_mode", "")),

                    "candidate_1": cands[0],
                    "blaser_softmax_1": format_score(blaser_prob3[0]),
                    "repair_bonus_1": format_score(repair3[0]),

                    "candidate_2": cands[1],
                    "blaser_softmax_2": format_score(blaser_prob3[1]),
                    "repair_bonus_2": format_score(repair3[1]),

                    "candidate_3": cands[2],
                    "blaser_softmax_3": format_score(blaser_prob3[2]),
                    "repair_bonus_3": format_score(repair3[2]),

                    "selection_rule": "lexicographic(repair_bonus, blaser_softmax)",
                    "best_translation": best_translation,

                    "local_evidence": row.get("local_evidence", {}),
                    "raw_model_output": clean_text(row.get("raw_model_output", "")),
                }
                write_jsonl_record(f_main, out_main)

                # 第二份输出
                reference_translation = get_reference_translation(
                    row=row,
                    image_id_to_src_en=image_id_to_src_en,
                    source_text_to_src_en=source_text_to_src_en
                )

                out_ref_best = {
                    "id": row_id,
                    "source_text": source_text,
                    "reference_translation": reference_translation,
                    "best_translation": best_translation,
                }
                write_jsonl_record(f_ref_best, out_ref_best)

            f_main.flush()
            os.fsync(f_main.fileno())
            f_ref_best.flush()
            os.fsync(f_ref_best.fileno())

            print(f"[info] processed {b1}/{total}")

    print(f"[done] main saved to: {OUTPUT_JSONL}")
    print(f"[done] ref-best saved to: {OUTPUT_REF_BEST_JSONL}")


if __name__ == "__main__":
    main()