import os
os.environ["CUDA_VISIBLE_DEVICES"] = "2"
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"

import re
import json
import time
from typing import List, Tuple, Dict, Set, Optional

from PIL import Image

import torch
import torch.nn.functional as F
from transformers import AutoProcessor, Qwen2VLForConditionalGeneration

torch.set_grad_enabled(False)

# =========================
# PATH
# =========================
MODEL_PATH = "/mnt/raid/hss/model/Qwen2-VL-7B-Instruct"
INPUT_JSONL = "/home/chenyi/offline_blaser_qe/out/VG/bn/bn_test_translation.jsonl"
IMAGE_DIR = "/home/chenyi/offline_blaser_qe/dataSet/VG/images"
OUTPUT_JSONL = "/home/chenyi/offline_blaser_qe/out/VG/bn/bn_detect_span.jsonl"

MAX_ROWS = None

# =========================
# SETTINGS
# =========================
WINDOW_SIZES = [1, 2, 3]
TOP_K_SPANS = 2

STOPWORDS = {
    "the", "a", "an", "in", "on", "at", "of", "to",
    "is", "are", "was", "were", "be", "been", "being",
    "this", "that", "these", "those", "there", "here",
    "it", "its", "their", "his", "her", "my", "your",
    "as", "for", "with", "by", "from", "into", "onto",
    "up", "down", "over", "under", "near", "along",
    "and", "or", "but", "so", "than", "then",
    "do", "does", "did", "done",
    "have", "has", "had",
    "can", "could", "will", "would", "should",
    "may", "might", "must",
    "where", "when", "while",
    "after", "before", "during", "through", "across",
}

# 轻量功能词，不再包含动作词
FUNCTIONAL_EXTRA_WORDS = {
    "very", "just", "quite", "really",
    "some", "many", "few", "several", "kind", "sort",
    "type", "piece", "side", "front", "back",
    "inside", "outside", "nearby", "around",
}

LIGHT_ACTION_WORDS = {
    "standing", "sitting", "lying", "placed"
}

COLOR_CANONICAL_MAP = {
    "red": "red", "reddish": "red", "crimson": "red", "scarlet": "red",
    "maroon": "red", "burgundy": "red", "ruby": "red", "wine": "red",
    "rose": "red", "pink": "red", "magenta": "red", "fuchsia": "red",
    "orange": "orange", "orangish": "orange", "coral": "orange", "peach": "orange",
    "apricot": "orange", "amber": "orange", "tangerine": "orange", "salmon": "orange",
    "copper": "orange", "bronze": "orange", "rust": "orange",
    "yellow": "yellow", "gold": "yellow", "golden": "yellow", "beige": "yellow",
    "khaki": "yellow", "cream": "yellow", "ivory": "yellow", "mustard": "yellow",
    "lemon": "yellow", "tan": "yellow",
    "green": "green", "greenish": "green", "lime": "green", "olive": "green",
    "emerald": "green", "mint": "green", "teal": "green", "turquoise": "green",
    "chartreuse": "green",
    "blue": "blue", "bluish": "blue", "navy": "blue", "azure": "blue",
    "cyan": "blue", "aqua": "blue", "indigo": "blue", "skyblue": "blue",
    "royalblue": "blue",
    "purple": "purple", "violet": "purple", "lavender": "purple",
    "lilac": "purple", "plum": "purple",
    "brown": "brown", "brownish": "brown", "chocolate": "brown", "coffee": "brown",
    "mocha": "brown", "camel": "brown", "sandy": "brown", "sand": "brown",
    "taupe": "brown", "wood": "brown", "wooden": "brown",
    "gray": "gray", "grey": "gray", "grayish": "gray", "greyish": "gray",
    "silver": "gray", "charcoal": "gray", "slate": "gray", "ash": "gray",
    "black": "black", "blackish": "black", "ebony": "black",
    "white": "white", "whitish": "white", "pale": "white",
}

NUMBER_WORDS = {
    "zero", "one", "two", "three", "four", "five",
    "six", "seven", "eight", "nine", "ten",
    "eleven", "twelve"
}

DIGIT_TO_WORD = {
    "0": "zero", "1": "one", "2": "two", "3": "three",
    "4": "four", "5": "five", "6": "six", "7": "seven",
    "8": "eight", "9": "nine", "10": "ten", "11": "eleven",
    "12": "twelve",
}

PERSON_GENERIC = {"person", "people", "human", "individual"}
PERSON_SPECIFIC = {
    "man", "woman", "boy", "girl", "guy", "lady",
    "gentleman", "male", "female", "child", "kid",
    "children"
}

HEAD_BLOCKLIST = STOPWORDS | FUNCTIONAL_EXTRA_WORDS | LIGHT_ACTION_WORDS

# =========================
# LOAD MODEL
# =========================
print("Loading model...")
processor = AutoProcessor.from_pretrained(MODEL_PATH, trust_remote_code=True)
model = Qwen2VLForConditionalGeneration.from_pretrained(
    MODEL_PATH,
    torch_dtype=torch.bfloat16,
    device_map="auto",
    trust_remote_code=True
).eval()
tokenizer = processor.tokenizer

# =========================
# UTIL
# =========================
def safe_mean(x: List[float]) -> float:
    return sum(x) / len(x) if x else 0.0

def format_time(sec: float) -> str:
    sec = int(sec)
    return f"{sec//3600:02d}:{(sec%3600)//60:02d}:{sec%60:02d}"

def clean_text(x) -> str:
    if x is None:
        return ""
    return str(x).strip()

def normalize_spaces(text: str) -> str:
    text = clean_text(text)
    text = re.sub(r"\s+", " ", text).strip()
    text = re.sub(r"\s+([,.;:!?])", r"\1", text)
    return text

def find_image(i: str) -> str:
    for ext in [".jpg", ".jpeg", ".png", ".JPEG", ".JPG", ".PNG"]:
        p = os.path.join(IMAGE_DIR, i + ext)
        if os.path.exists(p):
            return p
    return ""

def load_image(path: str) -> Optional[Image.Image]:
    if not path or not os.path.isfile(path):
        return None
    return Image.open(path).convert("RGB")

def normalize_basic_token(w: str) -> str:
    w = w.lower().strip()
    w = w.replace("’", "'").replace("“", '"').replace("”", '"')
    w = re.sub(r"[^a-z0-9\-]", "", w)
    return w

def strip_color_suffixes(w: str) -> str:
    suffixes = [
        "-colored", "colored",
        "-colour", "colour",
        "-hued", "hued",
        "-tinted", "tinted",
        "-toned", "toned",
        "-ish", "ish",
    ]
    for s in suffixes:
        if w.endswith(s) and len(w) > len(s):
            return w[:-len(s)]
    return w

def extract_words(text: str) -> List[str]:
    raw = re.findall(r"[A-Za-z0-9\-]+", text.lower())
    words = []
    for w in raw:
        nw = normalize_basic_token(w)
        if not nw:
            continue
        if nw in STOPWORDS:
            continue
        if nw in DIGIT_TO_WORD:
            nw = DIGIT_TO_WORD[nw]
        words.append(nw)
    return words

def tokenize_with_positions(text: str) -> List[Dict]:
    tokens = []
    for m in re.finditer(r"[A-Za-z0-9\-]+", text):
        raw = m.group(0)
        norm = normalize_basic_token(raw)
        if not norm:
            continue
        out_norm = DIGIT_TO_WORD.get(norm, norm)
        tokens.append({
            "raw": raw,
            "norm": out_norm,
            "start": m.start(),
            "end": m.end(),
        })
    return tokens

def is_bad_translation(text: str) -> bool:
    if not text:
        return True
    tl = text.lower()
    if "strict rules" in tl:
        return True
    if "return json" in tl:
        return True
    if len(text) > 120:
        return True
    return False

def is_empty_translation(text: str) -> bool:
    return not clean_text(text)

# =========================
# COLOR / NUMBER
# =========================
def canonicalize_color_token(w: str) -> str:
    w = normalize_basic_token(w)
    if not w:
        return ""

    if w in COLOR_CANONICAL_MAP:
        return COLOR_CANONICAL_MAP[w]

    w2 = strip_color_suffixes(w)
    if w2 in COLOR_CANONICAL_MAP:
        return COLOR_CANONICAL_MAP[w2]

    if "-" in w:
        parts = [p for p in w.split("-") if p]
        filtered = [strip_color_suffixes(p) for p in parts]
        recognized = [COLOR_CANONICAL_MAP[p] for p in filtered if p in COLOR_CANONICAL_MAP]
        if recognized:
            return recognized[-1]

    limited_prefixes = [
        "red", "blue", "green", "yellow", "orange",
        "purple", "brown", "gray", "grey", "black", "white"
    ]
    for p in limited_prefixes:
        if w.startswith(p):
            return COLOR_CANONICAL_MAP[p]
    return ""

def canonicalize_number_token(w: str) -> str:
    w = normalize_basic_token(w)
    if w in DIGIT_TO_WORD:
        return DIGIT_TO_WORD[w]
    if w in NUMBER_WORDS:
        return w
    return ""

# =========================
# SOURCE / TEXT-ONLY TRANSLATION
# 只在初始翻译为空时补回初始翻译，不参与 hallucination 定位
# =========================
def translate_source_sentence(src: str) -> str:
    prompt = f"""
You are a translation system.

Task: Translate the source sentence into English.

Rules:
- MUST translate, NOT transliterate
- DO NOT copy source-language tokens
- Preserve attributes exactly, including color, number, object, and action
- Be short, literal, and faithful
- Prefer noun phrases when the source is a noun phrase

Return JSON ONLY:
{{"translation": "..."}}

Source:
{src}
"""
    messages = [{"role": "user", "content": [{"type": "text", "text": prompt}]}]
    text = processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    inputs = processor(text=[text], return_tensors="pt").to(model.device)

    with torch.no_grad():
        out = model.generate(
            **inputs,
            do_sample=False,
            max_new_tokens=50,
            repetition_penalty=1.0,
            pad_token_id=tokenizer.eos_token_id,
        )

    raw = processor.batch_decode(
        out[:, inputs["input_ids"].shape[1]:],
        skip_special_tokens=True
    )[0]

    try:
        match = re.search(r"\{.*\}", raw, re.DOTALL)
        if match:
            parsed = json.loads(match.group(0))
            res = parsed.get("translation", "").strip()
            if not is_bad_translation(res):
                return res
    except Exception:
        pass

    return ""

def get_or_fill_initial_translation(src: str, tgt: str) -> str:
    tgt = clean_text(tgt)
    if tgt:
        return tgt
    filled_tgt = translate_source_sentence(src)
    return clean_text(filled_tgt)

# =========================
# CONDITIONAL LOGPROB
# =========================
def build_messages(prompt_text: str, image: Optional[Image.Image]) -> List[Dict]:
    content = []
    if image is not None:
        content.append({"type": "image", "image": image})
    content.append({"type": "text", "text": prompt_text if prompt_text else ""})
    return [{"role": "user", "content": content}]

def get_conditional_logprob(
    prompt_text: str,
    target_text: str,
    image: Optional[Image.Image]
) -> Tuple[List[float], List[int], List[str]]:
    messages = build_messages(prompt_text, image)
    prompt_rendered = processor.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True
    )
    full_text = prompt_rendered + target_text

    if image is not None:
        enc_prompt = processor(text=[prompt_rendered], images=[image], return_tensors="pt")
        enc_full = processor(text=[full_text], images=[image], return_tensors="pt")
    else:
        enc_prompt = processor(text=[prompt_rendered], return_tensors="pt")
        enc_full = processor(text=[full_text], return_tensors="pt")

    enc_prompt = {k: v.to(model.device) for k, v in enc_prompt.items()}
    enc_full = {k: v.to(model.device) for k, v in enc_full.items()}

    with torch.no_grad():
        logits = model(**enc_full).logits

    ids = enc_full["input_ids"]
    prompt_len = enc_prompt["input_ids"].shape[1]
    log_probs = F.log_softmax(logits, dim=-1)

    scores = []
    token_ids = []
    for pos in range(prompt_len, ids.shape[1]):
        tid = ids[0, pos]
        scores.append(log_probs[0, pos - 1, tid].item())
        token_ids.append(tid.item())

    tokens = tokenizer.convert_ids_to_tokens(token_ids)
    return scores, token_ids, tokens

def token_support_details(src: str, tgt: str, image: Optional[Image.Image]) -> List[Dict]:
    prompt_xi = f"""Translate the source sentence into English using both the source sentence and the image.
Be faithful to the source sentence, and use the image only to resolve ambiguity.
Source: {src}
Translation:"""

    prompt_x = f"""Translate the source sentence into English using only the source sentence.
Do not rely on any image information.
Source: {src}
Translation:"""

    prompt_i = """Generate a concise English description using only the image.
Focus only on visually grounded content.
Description:"""

    prompt_0 = """Continue the English text naturally.
Text:"""

    if is_empty_translation(tgt):
        return []

    if image is not None:
        lp_xi, ids, toks = get_conditional_logprob(prompt_xi, tgt, image)
        lp_x,  _,   _    = get_conditional_logprob(prompt_x,  tgt, None)
        lp_i,  _,   _    = get_conditional_logprob(prompt_i,  tgt, image)
        lp_0,  _,   _    = get_conditional_logprob(prompt_0,  tgt, None)
    else:
        lp_xi, ids, toks = get_conditional_logprob(prompt_x, tgt, None)
        lp_x,  _,   _    = get_conditional_logprob(prompt_x, tgt, None)
        lp_i,  _,   _    = get_conditional_logprob(prompt_0, tgt, None)
        lp_0,  _,   _    = get_conditional_logprob(prompt_0, tgt, None)

    out = []
    for raw_tok, tid, a, b, c, d in zip(toks, ids, lp_xi, lp_x, lp_i, lp_0):
        text_gain = a - c
        image_gain = a - b
        bottleneck_score = min(text_gain, image_gain)
        joint_gain = a - d

        clean_tok = raw_tok.replace("Ġ", "").replace("▁", "").strip()
        norm_tok = normalize_basic_token(clean_tok)

        if not norm_tok:
            continue
        if norm_tok in STOPWORDS:
            continue

        out.append({
            "raw_token": raw_tok,
            "token": clean_tok,
            "token_id": int(tid),
            "logprob_xi": float(a),
            "logprob_x": float(b),
            "logprob_i": float(c),
            "logprob_0": float(d),
            "text_gain": float(text_gain),
            "image_gain": float(image_gain),
            "bottleneck_score": float(bottleneck_score),
            "joint_gain": float(joint_gain),
        })
    return out

def compute_sentence_stats_from_token_scores(token_scores: List[Dict]) -> Dict:
    if not token_scores:
        return {
            "bottleneck_mean": 0.0,
            "joint_mean": 0.0,
        }
    return {
        "bottleneck_mean": safe_mean([x["bottleneck_score"] for x in token_scores]),
        "joint_mean": safe_mean([x["joint_gain"] for x in token_scores]),
    }

# =========================
# WORD MERGE
# =========================
def merge_token_scores_to_words(token_scores: List[Dict]) -> List[Dict]:
    words = []
    cur = None

    for ts in token_scores:
        raw_tok = ts["raw_token"]
        clean_tok = ts["token"]

        if not clean_tok:
            continue

        is_new_word = raw_tok.startswith("Ġ") or raw_tok.startswith("▁")
        is_punct = re.fullmatch(r"[^\w]+", clean_tok) is not None

        if cur is None:
            cur = {"text": clean_tok, "parts": [ts]}
            continue

        if is_punct:
            if cur is not None:
                words.append(cur)
                cur = None
            continue

        if is_new_word:
            words.append(cur)
            cur = {"text": clean_tok, "parts": [ts]}
        else:
            cur["text"] += clean_tok
            cur["parts"].append(ts)

    if cur is not None:
        words.append(cur)

    merged = []
    for w in words:
        text = clean_text(w["text"])
        if not text:
            continue

        norm = normalize_basic_token(text)
        if not norm or norm in STOPWORDS:
            continue

        merged.append({
            "text": text,
            "norm_text": norm,
            "bottleneck_score": safe_mean([p["bottleneck_score"] for p in w["parts"]]),
            "joint_gain": safe_mean([p["joint_gain"] for p in w["parts"]]),
        })

    return merged

def align_surface_words_with_scores(text: str, word_scores: List[Dict]) -> List[Dict]:
    surface = tokenize_with_positions(text)
    if not surface:
        return []

    bottleneck_map = {}
    joint_map = {}
    for w in word_scores:
        k = w["norm_text"]
        if k not in bottleneck_map:
            bottleneck_map[k] = w["bottleneck_score"]
            joint_map[k] = w["joint_gain"]
        else:
            bottleneck_map[k] = min(bottleneck_map[k], w["bottleneck_score"])
            joint_map[k] = min(joint_map[k], w["joint_gain"])

    aligned = []
    cursor = 0
    for sw in surface:
        if sw["norm"] in STOPWORDS:
            continue

        assigned = None
        for j in range(cursor, len(word_scores)):
            if word_scores[j]["norm_text"] == sw["norm"]:
                assigned = word_scores[j]
                cursor = j + 1
                break

        if assigned is None:
            for j in range(len(word_scores)):
                if word_scores[j]["norm_text"] == sw["norm"]:
                    assigned = word_scores[j]
                    break

        aligned.append({
            "text": sw["raw"],
            "norm": sw["norm"],
            "start": sw["start"],
            "end": sw["end"],
            "bottleneck_score": assigned["bottleneck_score"] if assigned else bottleneck_map.get(sw["norm"], 0.0),
            "joint_gain": assigned["joint_gain"] if assigned else joint_map.get(sw["norm"], 0.0),
        })
    return aligned

# =========================
# SPAN UTILS
# =========================
def is_bad_span_text(text: str) -> bool:
    text = text.strip().lower()
    if not text:
        return True
    if len(text) <= 2:
        return True
    if re.fullmatch(r"[^\w]+", text):
        return True
    return False

def span_content_tokens(span_text: str) -> List[str]:
    toks = []
    for w in extract_words(span_text):
        nw = normalize_basic_token(w)
        if not nw:
            continue
        if nw in STOPWORDS:
            continue
        if nw in FUNCTIONAL_EXTRA_WORDS:
            continue
        toks.append(nw)
    return toks

def extract_head_word(span_text: str) -> str:
    toks = span_content_tokens(span_text)
    if not toks:
        return ""

    for w in reversed(toks):
        if w in HEAD_BLOCKLIST:
            continue
        if canonicalize_color_token(w):
            continue
        if canonicalize_number_token(w):
            continue
        return w
    return toks[-1] if toks else ""

def classify_span_type(span_text: str) -> str:
    ws = span_content_tokens(span_text)

    if not ws:
        return "fluency_expansion"

    if all((canonicalize_number_token(w) or "") for w in ws):
        return "attribute_number"

    if all((canonicalize_color_token(w) or "") for w in ws):
        return "attribute_color"

    if any(w in PERSON_SPECIFIC for w in ws):
        return "person_specificity"

    head = extract_head_word(span_text)
    if head:
        return "head_phrase"

    return "content_related"

def enumerate_spans(surface_words: List[Dict], tgt: str) -> List[Dict]:
    spans = []
    n = len(surface_words)

    for win in WINDOW_SIZES:
        for i in range(n - win + 1):
            seg = surface_words[i:i + win]
            if not seg:
                continue

            s = seg[0]["start"]
            e = seg[-1]["end"]
            span_text = tgt[s:e].strip(" ,.;:!?\"'()[]{}")
            if is_bad_span_text(span_text):
                continue

            content = [x for x in seg if x["norm"] not in STOPWORDS]
            if not content:
                continue

            support_mean = safe_mean([x["bottleneck_score"] for x in content])
            joint_mean = safe_mean([x["joint_gain"] for x in content])

            head_word = extract_head_word(span_text)
            head_scores = [x["bottleneck_score"] for x in content if x["norm"] == head_word]
            modifier_scores = [x["bottleneck_score"] for x in content if x["norm"] != head_word]

            spans.append({
                "text": span_text,
                "start_char": s,
                "end_char": e,
                "start_idx": i,
                "end_idx": i + win - 1,
                "span_type": classify_span_type(span_text),
                "support_mean": float(support_mean),
                "joint_mean": float(joint_mean),
                "head_word": head_word,
                "head_score": float(min(head_scores)) if head_scores else float(support_mean),
                "modifier_scores": modifier_scores,
                "len_tokens": len(content),
            })
    return spans

def delete_span_from_text(text: str, start_char: int, end_char: int) -> str:
    left = text[:start_char].rstrip()
    right = text[end_char:].lstrip()

    if left and right:
        out = left + " " + right
    else:
        out = left + right

    out = normalize_spaces(out)
    return out

def enrich_spans_with_delete_gain(
    src: str,
    tgt: str,
    image: Optional[Image.Image],
    spans: List[Dict],
    base_stats: Dict
) -> List[Dict]:
    out = []
    for sp in spans:
        new_tgt = delete_span_from_text(tgt, sp["start_char"], sp["end_char"])
        if new_tgt == tgt:
            delete_gain_b = 0.0
            delete_gain_j = 0.0
        else:
            new_token_scores = token_support_details(src, new_tgt, image)
            new_stats = compute_sentence_stats_from_token_scores(new_token_scores)
            delete_gain_b = new_stats["bottleneck_mean"] - base_stats["bottleneck_mean"]
            delete_gain_j = new_stats["joint_mean"] - base_stats["joint_mean"]

        sp2 = dict(sp)
        sp2["delete_gain_b"] = float(delete_gain_b)
        sp2["delete_gain_j"] = float(delete_gain_j)
        out.append(sp2)
    return out

def rank_spans(spans: List[Dict]) -> List[Dict]:
    return sorted(
        spans,
        key=lambda s: (
            -s["delete_gain_b"],
            -s["delete_gain_j"],
            s["support_mean"],
            s["joint_mean"],
            -s["len_tokens"],
        )
    )

# =========================
# DECISION
# =========================
def is_faithful_case(base_stats: Dict, ranked_spans: List[Dict]) -> bool:
    if not ranked_spans:
        return True

    best = ranked_spans[0]

    if best["delete_gain_b"] > 0:
        return False
    if best["delete_gain_j"] > 0:
        return False

    if best["support_mean"] < base_stats["bottleneck_mean"]:
        return False
    if best["joint_mean"] < base_stats["joint_mean"]:
        return False

    return True

def classify_best_span(best_span: Dict) -> str:
    span_text = best_span["text"]
    toks = span_content_tokens(span_text)

    if not toks:
        return "unsupported_span"

    if all((canonicalize_color_token(w) or "") for w in toks):
        return "attribute_color"

    if all((canonicalize_number_token(w) or "") for w in toks):
        return "attribute_number"

    if any(w in PERSON_SPECIFIC for w in toks):
        return "person_specificity"

    head_word = best_span["head_word"]
    modifier_scores = best_span["modifier_scores"]

    if (
        head_word
        and head_word not in PERSON_GENERIC
        and head_word not in PERSON_SPECIFIC
        and not canonicalize_color_token(head_word)
        and not canonicalize_number_token(head_word)
        and modifier_scores
        and best_span["head_score"] < min(modifier_scores)
    ):
        return "object_head_shift"

    if best_span["delete_gain_b"] > 0 or best_span["delete_gain_j"] > 0:
        return "extra_content"

    return "unsupported_span"

def select_primary_type_and_spans(
    tgt: str,
    ranked_spans: List[Dict],
    base_stats: Dict
) -> Dict:
    if is_empty_translation(tgt):
        return {
            "primary_type": "empty_translation",
            "target_hallucination_span": "",
        }

    if is_faithful_case(base_stats, ranked_spans):
        return {
            "primary_type": "faithful",
            "target_hallucination_span": "",
        }

    if not ranked_spans:
        return {
            "primary_type": "uncertain",
            "target_hallucination_span": "",
        }

    best = ranked_spans[0]
    return {
        "primary_type": classify_best_span(best),
        "target_hallucination_span": best["text"],
    }

# =========================
# JSONL
# =========================
def init_jsonl():
    os.makedirs(os.path.dirname(OUTPUT_JSONL), exist_ok=True)
    with open(OUTPUT_JSONL, "w", encoding="utf-8"):
        pass

def append(record: Dict):
    with open(OUTPUT_JSONL, "a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")

# =========================
# MAIN
# =========================
def main():
    rows = []
    with open(INPUT_JSONL, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            rows.append(json.loads(line))

    if MAX_ROWS:
        rows = rows[:MAX_ROWS]

    init_jsonl()
    times = []
    total = len(rows)

    for i, r in enumerate(rows, 1):
        t0 = time.time()

        sid = str(r["image_id"])
        src = clean_text(r.get("source_text", ""))
        tgt_raw = clean_text(r.get("initial_translation_en", ""))

        try:
            image_path = find_image(sid)
            image = load_image(image_path)

            # 只补空初始翻译，不引入 src_en
            tgt = get_or_fill_initial_translation(src, tgt_raw)

            token_scores = token_support_details(src, tgt, image)
            base_stats = compute_sentence_stats_from_token_scores(token_scores)

            word_scores = merge_token_scores_to_words(token_scores)
            surface_words = align_surface_words_with_scores(tgt, word_scores)
            spans = enumerate_spans(surface_words, tgt)
            spans = enrich_spans_with_delete_gain(
                src=src,
                tgt=tgt,
                image=image,
                spans=spans,
                base_stats=base_stats
            )
            ranked_spans = rank_spans(spans)[:TOP_K_SPANS]

            hallucination_analysis = select_primary_type_and_spans(
                tgt=tgt,
                ranked_spans=ranked_spans,
                base_stats=base_stats
            )

            append({
                "id": sid,
                "image_path": image_path,
                "source_text": src,
                "initial_translation": tgt,
                "primary_hallucination_type": hallucination_analysis["primary_type"],
                "target_hallucination_span": hallucination_analysis["target_hallucination_span"],
            })

            del image
            if torch.cuda.is_available():
                torch.cuda.empty_cache()

        except Exception as e:
            print("ERROR:", sid, e)
            continue

        dt = time.time() - t0
        times.append(dt)
        avg = sum(times) / len(times)
        eta = (total - i) * avg
        print(f"[{i}/{total}] {sid} | {dt:.2f}s | ETA {format_time(eta)}")

    print("DONE")

if __name__ == "__main__":
    main()