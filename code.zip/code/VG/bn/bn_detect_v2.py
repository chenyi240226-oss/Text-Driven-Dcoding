import os
os.environ["CUDA_VISIBLE_DEVICES"] = "2"
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"

import re
import json
import time
from typing import List, Tuple, Dict, Set, Optional

from PIL import Image

import torch
import torch.nn.functional as F
from transformers import AutoProcessor, Qwen2VLForConditionalGeneration

torch.set_grad_enabled(False)

# =========================
# PATH
# =========================
MODEL_PATH = "/mnt/raid/hss/model/Qwen2-VL-7B-Instruct"
INPUT_JSONL = "/home/chenyi/offline_blaser_qe/out/VG/bn/bn_test_translation.jsonl"
IMAGE_DIR = "/home/chenyi/offline_blaser_qe/dataSet/VG/images"
OUTPUT_JSONL = "/home/chenyi/offline_blaser_qe/out/VG/bn/bn_detect_span.jsonl"

MAX_ROWS = 100

# =========================
# SETTINGS
# =========================
WINDOW_SIZES = [1, 2, 3]
TOP_K_SPANS = 2

# 新支持度定义下，阈值贴近 0 重新设定
FAITHFUL_BASE_SCORE_MIN = 0.00
FAITHFUL_LOWEST_SPAN_MIN = -0.05

# 只有 span 分数明显很差时，才判 unsupported_span
UNSUPPORTED_STRONG_SPAN_MAX = -0.12

# extra_content 必须同时满足“词面不对齐 + 支持度低”
EXTRA_CONTENT_WORD_SCORE_MAX = -0.03

STOPWORDS = {
    "the", "a", "an", "in", "on", "at", "of", "to",
    "is", "are", "was", "were", "be", "been", "being",
    "this", "that", "these", "those", "there", "here",
    "it", "its", "their", "his", "her", "my", "your",
    "as", "for", "with", "by", "from", "into", "onto",
    "up", "down", "over", "under", "near", "along",
    "and", "or", "but", "so", "than", "then",
    "do", "does", "did", "done",
    "have", "has", "had",
    "can", "could", "will", "would", "should",
    "may", "might", "must",
    "where", "when", "while",
    "after", "before", "during", "through", "across",
}

FUNCTIONAL_EXTRA_WORDS = {
    "very", "just", "quite", "really",
    "some", "many", "few", "several", "kind", "sort",
    "type", "piece", "side", "front", "back",
    "inside", "outside", "nearby", "around",
    "standing", "sitting", "lying", "placed"
}

COLOR_CANONICAL_MAP = {
    "red": "red", "reddish": "red", "crimson": "red", "scarlet": "red",
    "maroon": "red", "burgundy": "red", "ruby": "red", "wine": "red",
    "rose": "red", "pink": "red", "magenta": "red", "fuchsia": "red",
    "orange": "orange", "orangish": "orange", "coral": "orange", "peach": "orange",
    "apricot": "orange", "amber": "orange", "tangerine": "orange", "salmon": "orange",
    "copper": "orange", "bronze": "orange", "rust": "orange",
    "yellow": "yellow", "gold": "yellow", "golden": "yellow", "beige": "yellow",
    "khaki": "yellow", "cream": "yellow", "ivory": "yellow", "mustard": "yellow",
    "lemon": "yellow", "tan": "yellow",
    "green": "green", "greenish": "green", "lime": "green", "olive": "green",
    "emerald": "green", "mint": "green", "teal": "green", "turquoise": "green",
    "chartreuse": "green",
    "blue": "blue", "bluish": "blue", "navy": "blue", "azure": "blue",
    "cyan": "blue", "aqua": "blue", "indigo": "blue", "skyblue": "blue",
    "royalblue": "blue",
    "purple": "purple", "violet": "purple", "lavender": "purple",
    "lilac": "purple", "plum": "purple",
    "brown": "brown", "brownish": "brown", "chocolate": "brown", "coffee": "brown",
    "mocha": "brown", "camel": "brown", "sandy": "brown", "sand": "brown",
    "taupe": "brown", "wood": "brown", "wooden": "brown",
    "gray": "gray", "grey": "gray", "grayish": "gray", "greyish": "gray",
    "silver": "gray", "charcoal": "gray", "slate": "gray", "ash": "gray",
    "black": "black", "blackish": "black", "ebony": "black",
    "white": "white", "whitish": "white", "pale": "white",
}

NUMBER_WORDS = {
    "zero", "one", "two", "three", "four", "five",
    "six", "seven", "eight", "nine", "ten",
    "eleven", "twelve"
}

DIGIT_TO_WORD = {
    "0": "zero", "1": "one", "2": "two", "3": "three",
    "4": "four", "5": "five", "6": "six", "7": "seven",
    "8": "eight", "9": "nine", "10": "ten", "11": "eleven",
    "12": "twelve",
}

PERSON_GENERIC = {"person", "people", "human", "individual"}
PERSON_SPECIFIC = {
    "man", "woman", "boy", "girl", "guy", "lady",
    "gentleman", "male", "female", "child", "kid",
    "children"
}

# =========================
# LOAD MODEL
# =========================
print("Loading model...")
processor = AutoProcessor.from_pretrained(MODEL_PATH, trust_remote_code=True)
model = Qwen2VLForConditionalGeneration.from_pretrained(
    MODEL_PATH,
    torch_dtype=torch.bfloat16,
    device_map="auto",
    trust_remote_code=True
).eval()
tokenizer = processor.tokenizer

# =========================
# UTIL
# =========================
def safe_mean(x: List[float]) -> float:
    return sum(x) / len(x) if x else 0.0

def format_time(sec: float) -> str:
    sec = int(sec)
    return f"{sec//3600:02d}:{(sec%3600)//60:02d}:{sec%60:02d}"

def clean_text(x) -> str:
    if x is None:
        return ""
    return str(x).strip()

def find_image(i: str) -> str:
    for ext in [".jpg", ".jpeg", ".png", ".JPEG", ".JPG", ".PNG"]:
        p = os.path.join(IMAGE_DIR, i + ext)
        if os.path.exists(p):
            return p
    return ""

def load_image(path: str) -> Optional[Image.Image]:
    if not path or not os.path.isfile(path):
        return None
    return Image.open(path).convert("RGB")

def normalize_basic_token(w: str) -> str:
    w = w.lower().strip()
    w = w.replace("’", "'").replace("“", '"').replace("”", '"')
    w = re.sub(r"[^a-z0-9\-]", "", w)
    return w

def strip_color_suffixes(w: str) -> str:
    suffixes = [
        "-colored", "colored",
        "-colour", "colour",
        "-hued", "hued",
        "-tinted", "tinted",
        "-toned", "toned",
        "-ish", "ish",
    ]
    for s in suffixes:
        if w.endswith(s) and len(w) > len(s):
            return w[:-len(s)]
    return w

def extract_words(text: str) -> List[str]:
    raw = re.findall(r"[A-Za-z0-9\-]+", text.lower())
    words = []
    for w in raw:
        nw = normalize_basic_token(w)
        if not nw:
            continue
        if nw in STOPWORDS:
            continue
        if nw in DIGIT_TO_WORD:
            nw = DIGIT_TO_WORD[nw]
        words.append(nw)
    return words

def tokenize_with_positions(text: str) -> List[Dict]:
    tokens = []
    for m in re.finditer(r"[A-Za-z0-9\-]+", text):
        raw = m.group(0)
        norm = normalize_basic_token(raw)
        if not norm:
            continue
        out_norm = DIGIT_TO_WORD.get(norm, norm)
        tokens.append({
            "raw": raw,
            "norm": out_norm,
            "start": m.start(),
            "end": m.end(),
        })
    return tokens

def is_bad_translation(text: str) -> bool:
    if not text:
        return True
    tl = text.lower()
    if "strict rules" in tl:
        return True
    if "return json" in tl:
        return True
    if len(text) > 120:
        return True
    return False

def is_empty_translation(text: str) -> bool:
    return not clean_text(text)

# =========================
# COLOR / NUMBER
# =========================
def canonicalize_color_token(w: str) -> str:
    w = normalize_basic_token(w)
    if not w:
        return ""

    if w in COLOR_CANONICAL_MAP:
        return COLOR_CANONICAL_MAP[w]

    w2 = strip_color_suffixes(w)
    if w2 in COLOR_CANONICAL_MAP:
        return COLOR_CANONICAL_MAP[w2]

    if "-" in w:
        parts = [p for p in w.split("-") if p]
        filtered = [strip_color_suffixes(p) for p in parts]
        recognized = [COLOR_CANONICAL_MAP[p] for p in filtered if p in COLOR_CANONICAL_MAP]
        if recognized:
            return recognized[-1]

    limited_prefixes = [
        "red", "blue", "green", "yellow", "orange",
        "purple", "brown", "gray", "grey", "black", "white"
    ]
    for p in limited_prefixes:
        if w.startswith(p):
            return COLOR_CANONICAL_MAP[p]
    return ""

def extract_color_set(text: str) -> Set[str]:
    colors = set()
    for w in re.findall(r"[A-Za-z0-9\-]+", text.lower()):
        c = canonicalize_color_token(w)
        if c:
            colors.add(c)
    return colors

def canonicalize_number_token(w: str) -> str:
    w = normalize_basic_token(w)
    if w in DIGIT_TO_WORD:
        return DIGIT_TO_WORD[w]
    if w in NUMBER_WORDS:
        return w
    return ""

def extract_number_set(text: str) -> Set[str]:
    nums = set()
    for w in re.findall(r"[A-Za-z0-9\-]+", text.lower()):
        n = canonicalize_number_token(w)
        if n:
            nums.add(n)
    return nums

def is_functional_or_light_extra_token(w: str) -> bool:
    w = normalize_basic_token(w)
    if not w:
        return True
    if w in STOPWORDS:
        return True
    if w in FUNCTIONAL_EXTRA_WORDS:
        return True
    if canonicalize_color_token(w):
        return True
    if canonicalize_number_token(w):
        return True
    return False

# =========================
# SOURCE / TEXT-ONLY TRANSLATION
# =========================
def translate_source_sentence(src: str) -> str:
    prompt = f"""
You are a translation system.

Task: Translate the source sentence into English.

Rules:
- MUST translate, NOT transliterate
- DO NOT copy source-language tokens
- Preserve attributes exactly, including color, number, object, and action
- Be short, literal, and faithful
- Prefer noun phrases when the source is a noun phrase

Return JSON ONLY:
{{"translation": "..."}}

Source:
{src}
"""
    messages = [{"role": "user", "content": [{"type": "text", "text": prompt}]}]
    text = processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    inputs = processor(text=[text], return_tensors="pt").to(model.device)

    with torch.no_grad():
        out = model.generate(
            **inputs,
            do_sample=False,
            max_new_tokens=50,
            repetition_penalty=1.0,
            pad_token_id=tokenizer.eos_token_id,
        )

    raw = processor.batch_decode(
        out[:, inputs["input_ids"].shape[1]:],
        skip_special_tokens=True
    )[0]

    try:
        match = re.search(r"\{.*\}", raw, re.DOTALL)
        if match:
            parsed = json.loads(match.group(0))
            res = parsed.get("translation", "").strip()
            if not is_bad_translation(res):
                return res
    except Exception:
        pass

    return ""

def get_or_fill_initial_translation(src: str, tgt: str) -> Tuple[str, str]:
    """
    如果初始翻译为空，先调用模型只使用文本进行翻译，作为初始翻译。
    返回：
    - final_tgt: 用于后续 detect 的初始翻译
    - src_en: 用于规则判断的 source-side English
    """
    tgt = clean_text(tgt)

    if tgt:
        # 原本已有初始翻译，则 source_text 仍单独做 text-only 翻译
        src_en = translate_source_sentence(src)
        return tgt, src_en

    # 初始翻译为空时，先做 text-only 翻译补回
    filled_tgt = translate_source_sentence(src)
    filled_tgt = clean_text(filled_tgt)

    # 这里复用同一结果作为 tgt 和 src_en，避免再额外跑一遍
    return filled_tgt, filled_tgt

# =========================
# CONDITIONAL LOGPROB
# =========================
def build_messages(prompt_text: str, image: Optional[Image.Image]) -> List[Dict]:
    content = []
    if image is not None:
        content.append({"type": "image", "image": image})
    content.append({"type": "text", "text": prompt_text if prompt_text else ""})
    return [{"role": "user", "content": content}]

def get_conditional_logprob(
    prompt_text: str,
    target_text: str,
    image: Optional[Image.Image]
) -> Tuple[List[float], List[int], List[str]]:
    messages = build_messages(prompt_text, image)
    prompt_rendered = processor.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True
    )
    full_text = prompt_rendered + target_text

    if image is not None:
        enc_prompt = processor(text=[prompt_rendered], images=[image], return_tensors="pt")
        enc_full = processor(text=[full_text], images=[image], return_tensors="pt")
    else:
        enc_prompt = processor(text=[prompt_rendered], return_tensors="pt")
        enc_full = processor(text=[full_text], return_tensors="pt")

    enc_prompt = {k: v.to(model.device) for k, v in enc_prompt.items()}
    enc_full = {k: v.to(model.device) for k, v in enc_full.items()}

    with torch.no_grad():
        logits = model(**enc_full).logits

    ids = enc_full["input_ids"]
    prompt_len = enc_prompt["input_ids"].shape[1]
    log_probs = F.log_softmax(logits, dim=-1)

    scores = []
    token_ids = []
    for pos in range(prompt_len, ids.shape[1]):
        tid = ids[0, pos]
        scores.append(log_probs[0, pos - 1, tid].item())
        token_ids.append(tid.item())

    tokens = tokenizer.convert_ids_to_tokens(token_ids)
    return scores, token_ids, tokens

def token_support_details(src: str, tgt: str, image: Optional[Image.Image]) -> List[Dict]:
    # 图文联合翻译：要求同时利用源句和图片
    prompt_xi = f"""Translate the source sentence into English using both the source sentence and the image.
Be faithful to the source sentence, and use the image only to resolve ambiguity.
Source: {src}
Translation:"""

    # 纯文本翻译：明确不允许用图片
    prompt_x = f"""Translate the source sentence into English using only the source sentence.
Do not rely on any image information.
Source: {src}
Translation:"""

    # 纯图片条件：只做图片描述
    prompt_i = """Generate a concise English description using only the image.
Focus only on visually grounded content.
Description:"""

    # 空译文直接返回空列表，避免后面被当 faithful
    if is_empty_translation(tgt):
        return []

    if image is not None:
        lp_xi, ids, toks = get_conditional_logprob(prompt_xi, tgt, image)
        lp_x,  _,   _    = get_conditional_logprob(prompt_x,  tgt, None)
        lp_i,  _,   _    = get_conditional_logprob(prompt_i,  tgt, image)
    else:
        # 无图样本：这里不做“图文双支持”，直接退化为文本条件
        lp_xi, ids, toks = get_conditional_logprob(prompt_x, tgt, None)
        lp_x = lp_xi[:]
        lp_i = lp_xi[:]

    out = []
    for raw_tok, tid, a, b, c in zip(toks, ids, lp_xi, lp_x, lp_i):
        text_gain = a - c
        image_gain = a - b
        support_score = min(text_gain, image_gain)

        clean_tok = raw_tok.replace("Ġ", "").replace("▁", "").strip()
        norm_tok = normalize_basic_token(clean_tok)

        if not norm_tok:
            continue
        if norm_tok in STOPWORDS:
            continue

        out.append({
            "raw_token": raw_tok,
            "token": clean_tok,
            "token_id": int(tid),
            "logprob_xi": float(a),
            "logprob_x": float(b),
            "logprob_i": float(c),
            "text_gain": float(text_gain),
            "image_gain": float(image_gain),
            "support_score": float(support_score),
        })
    return out

# =========================
# WORD MERGE + LOWEST-SPAN
# =========================
def merge_token_scores_to_words(token_scores: List[Dict]) -> List[Dict]:
    """
    修复原先直接 cur['text'] += tok 导致的 boxsmalloranges 问题。
    这里按 tokenizer 的新词边界（Ġ / ▁）合并。
    """
    words = []
    cur = None

    for ts in token_scores:
        raw_tok = ts["raw_token"]
        clean_tok = ts["token"]

        if not clean_tok:
            continue

        is_new_word = raw_tok.startswith("Ġ") or raw_tok.startswith("▁")
        is_punct = re.fullmatch(r"[^\w]+", clean_tok) is not None

        if cur is None:
            cur = {"text": clean_tok, "parts": [ts]}
            continue

        if is_punct:
            if cur is not None:
                words.append(cur)
                cur = None
            continue

        if is_new_word:
            words.append(cur)
            cur = {"text": clean_tok, "parts": [ts]}
        else:
            cur["text"] += clean_tok
            cur["parts"].append(ts)

    if cur is not None:
        words.append(cur)

    merged = []
    for w in words:
        text = clean_text(w["text"])
        if not text:
            continue

        norm = normalize_basic_token(text)
        if not norm or norm in STOPWORDS:
            continue

        gains = [p["support_score"] for p in w["parts"]]
        merged.append({
            "text": text,
            "norm_text": norm,
            "mean_support_score": float(sum(gains) / len(gains)),
        })

    return merged

def is_bad_span_text(text: str) -> bool:
    text = text.strip().lower()
    if not text:
        return True
    if len(text) <= 2:
        return True
    if re.fullmatch(r"[^\w]+", text):
        return True
    return False

def classify_span_type(span_text: str) -> str:
    ws = [normalize_basic_token(x) for x in re.findall(r"[A-Za-z0-9\-]+", span_text.lower())]
    ws = [w for w in ws if w]

    if not ws:
        return "other"

    content_words = [w for w in ws if w not in STOPWORDS and w not in FUNCTIONAL_EXTRA_WORDS]

    if len(content_words) == 0:
        return "fluency_expansion"

    if all((canonicalize_number_token(w) or "") for w in content_words):
        return "attribute_related"

    if all((canonicalize_color_token(w) or "") for w in content_words):
        return "attribute_related"

    return "content_related"

def find_lowest_support_spans(word_scores: List[Dict]) -> List[Dict]:
    spans = []
    n = len(word_scores)

    for win in WINDOW_SIZES:
        for i in range(n - win + 1):
            seg = word_scores[i:i + win]
            span_text = " ".join(x["text"] for x in seg).strip()
            if is_bad_span_text(span_text):
                continue

            mean_support = safe_mean([x["mean_support_score"] for x in seg])
            spans.append({
                "text": span_text,
                "start": i,
                "end": i + win - 1,
                "span_score": float(mean_support),
                "span_type": classify_span_type(span_text),
            })

    spans.sort(key=lambda x: x["span_score"])
    return spans[:TOP_K_SPANS]

def build_word_support_map(word_scores: List[Dict]) -> Dict[str, float]:
    """
    同一个词如果出现多次，取最低支持度，偏保守。
    """
    out = {}
    for w in word_scores:
        k = w["norm_text"]
        v = w["mean_support_score"]
        if k not in out:
            out[k] = v
        else:
            out[k] = min(out[k], v)
    return out

# =========================
# RULE-BASED DECISION
# =========================
def get_color_hallucinated_words(src_en: str, tgt: str) -> List[str]:
    src_colors = extract_color_set(src_en)
    out = []
    for w in extract_words(tgt):
        c = canonicalize_color_token(w)
        if c and src_colors and c not in src_colors:
            out.append(w)
    return sorted(list(set(out)))

def get_number_hallucinated_words(src_en: str, tgt: str) -> List[str]:
    src_nums = extract_number_set(src_en)
    out = []
    for w in extract_words(tgt):
        n = canonicalize_number_token(w)
        if n and src_nums and n not in src_nums:
            out.append(w)
    return sorted(list(set(out)))

def get_refinement_hallucinated_words(src_en: str, tgt: str) -> List[str]:
    src_words = set(extract_words(src_en))
    tgt_words = set(extract_words(tgt))

    src_has_generic = len(src_words & PERSON_GENERIC) > 0
    src_has_specific = len(src_words & PERSON_SPECIFIC) > 0
    tgt_specific = sorted(list(tgt_words & PERSON_SPECIFIC))

    if src_has_generic and (not src_has_specific) and tgt_specific:
        return tgt_specific
    return []

def get_extra_content_words(
    src_en: str,
    tgt: str,
    refinement_words: List[str],
    word_scores: List[Dict]
) -> List[str]:
    src_words = set(extract_words(src_en))
    tgt_words = set(extract_words(tgt))
    refinement_set = set(refinement_words)
    support_map = build_word_support_map(word_scores)

    extras = []
    for w in sorted(tgt_words - src_words):
        if is_functional_or_light_extra_token(w):
            continue
        if w in refinement_set:
            continue
        if support_map.get(w, 1.0) > EXTRA_CONTENT_WORD_SCORE_MAX:
            continue
        extras.append(w)
    return extras

def words_to_merged_phrases(tgt: str, hallucinated_words: List[str]) -> List[str]:
    if not hallucinated_words:
        return []

    tokens = tokenize_with_positions(tgt)
    hw = set(normalize_basic_token(w) for w in hallucinated_words)

    selected = []
    for idx, tk in enumerate(tokens):
        if tk["norm"] in hw:
            selected.append(idx)

    if not selected:
        return []

    groups = []
    cur = [selected[0]]
    for idx in selected[1:]:
        if idx == cur[-1] + 1:
            cur.append(idx)
        else:
            groups.append(cur)
            cur = [idx]
    groups.append(cur)

    phrases = []
    for g in groups:
        s = tokens[g[0]]["start"]
        e = tokens[g[-1]]["end"]
        phrase = tgt[s:e].strip(" ,.;:!?\"'()[]{}")
        if phrase:
            phrases.append(phrase)

    out = []
    seen = set()
    for p in phrases:
        k = p.lower()
        if k not in seen:
            seen.add(k)
            out.append(p)
    return out[:TOP_K_SPANS]

def choose_target_hallucination_span(
    hallucinated_phrases: List[str],
    hallucinated_words: List[str],
    lowest_spans: List[Dict]
) -> str:
    if hallucinated_phrases:
        return hallucinated_phrases[0]
    if hallucinated_words:
        return " ".join(hallucinated_words)
    if lowest_spans:
        return lowest_spans[0]["text"]
    return ""

def is_faithful_case(
    base_support_score: float,
    lowest_spans: List[Dict],
    color_words: List[str],
    number_words: List[str],
    refinement_words: List[str],
    extra_words: List[str],
) -> bool:
    if color_words or number_words or refinement_words or extra_words:
        return False

    lowest_span_score = lowest_spans[0]["span_score"] if lowest_spans else 0.0
    if base_support_score >= FAITHFUL_BASE_SCORE_MIN and lowest_span_score >= FAITHFUL_LOWEST_SPAN_MIN:
        return True

    return False

def select_primary_type_and_spans(
    src_en: str,
    tgt: str,
    word_scores: List[Dict],
    lowest_spans: List[Dict],
    base_support_score: float
) -> Dict:
    # 空译文：只有 text-only fallback 仍失败时才会到这里
    if is_empty_translation(tgt):
        return {
            "primary_type": "empty_translation",
            "target_hallucination_span": "",
        }

    src_en = clean_text(src_en)

    if src_en:
        color_words = get_color_hallucinated_words(src_en, tgt)
        number_words = get_number_hallucinated_words(src_en, tgt)
        refinement_words = get_refinement_hallucinated_words(src_en, tgt)
        extra_words = get_extra_content_words(
            src_en=src_en,
            tgt=tgt,
            refinement_words=refinement_words,
            word_scores=word_scores
        )
    else:
        color_words = []
        number_words = []
        refinement_words = []
        extra_words = []

    if is_faithful_case(
        base_support_score=base_support_score,
        lowest_spans=lowest_spans,
        color_words=color_words,
        number_words=number_words,
        refinement_words=refinement_words,
        extra_words=extra_words,
    ):
        return {
            "primary_type": "faithful",
            "target_hallucination_span": "",
        }

    if color_words:
        phrases = words_to_merged_phrases(tgt, color_words) or color_words[:TOP_K_SPANS]
        return {
            "primary_type": "attribute_color",
            "target_hallucination_span": choose_target_hallucination_span(phrases, color_words, lowest_spans),
        }

    if number_words:
        phrases = words_to_merged_phrases(tgt, number_words) or number_words[:TOP_K_SPANS]
        return {
            "primary_type": "attribute_number",
            "target_hallucination_span": choose_target_hallucination_span(phrases, number_words, lowest_spans),
        }

    if refinement_words:
        phrases = words_to_merged_phrases(tgt, refinement_words) or refinement_words[:TOP_K_SPANS]
        return {
            "primary_type": "semantic_refinement",
            "target_hallucination_span": choose_target_hallucination_span(phrases, refinement_words, lowest_spans),
        }

    if extra_words:
        phrases = words_to_merged_phrases(tgt, extra_words) or extra_words[:TOP_K_SPANS]
        return {
            "primary_type": "extra_content",
            "target_hallucination_span": choose_target_hallucination_span(phrases, extra_words, lowest_spans),
        }

    if lowest_spans:
        span = lowest_spans[0]
        if span["span_score"] <= UNSUPPORTED_STRONG_SPAN_MAX:
            return {
                "primary_type": "unsupported_span",
                "target_hallucination_span": span["text"],
            }

    return {
        "primary_type": "uncertain",
        "target_hallucination_span": "",
    }

# =========================
# JSONL
# =========================
def init_jsonl():
    os.makedirs(os.path.dirname(OUTPUT_JSONL), exist_ok=True)
    with open(OUTPUT_JSONL, "w", encoding="utf-8"):
        pass

def append(record: Dict):
    with open(OUTPUT_JSONL, "a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")

# =========================
# MAIN
# =========================
def main():
    rows = []
    with open(INPUT_JSONL, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            rows.append(json.loads(line))

    if MAX_ROWS:
        rows = rows[:MAX_ROWS]

    init_jsonl()
    times = []
    total = len(rows)

    for i, r in enumerate(rows, 1):
        t0 = time.time()

        sid = str(r["image_id"])
        src = clean_text(r.get("source_text", ""))
        tgt_raw = clean_text(r.get("initial_translation_en", ""))

        try:
            image_path = find_image(sid)
            image = load_image(image_path)

            # 新增逻辑：若初始翻译为空，先 text-only 补翻译，再 detect
            tgt, src_en = get_or_fill_initial_translation(src, tgt_raw)

            token_scores = token_support_details(src, tgt, image)
            word_scores = merge_token_scores_to_words(token_scores)
            base_support_score = safe_mean([x["support_score"] for x in token_scores])
            lowest_spans = find_lowest_support_spans(word_scores)

            hallucination_analysis = select_primary_type_and_spans(
                src_en=src_en,
                tgt=tgt,
                word_scores=word_scores,
                lowest_spans=lowest_spans,
                base_support_score=base_support_score
            )

            append({
                "id": sid,
                "image_path": image_path,
                "source_text": src,
                "initial_translation": tgt,
                "primary_hallucination_type": hallucination_analysis["primary_type"],
                "target_hallucination_span": hallucination_analysis["target_hallucination_span"],
            })

            del image
            if torch.cuda.is_available():
                torch.cuda.empty_cache()

        except Exception as e:
            print("ERROR:", sid, e)
            continue

        dt = time.time() - t0
        times.append(dt)
        avg = sum(times) / len(times)
        eta = (total - i) * avg
        print(f"[{i}/{total}] {sid} | {dt:.2f}s | ETA {format_time(eta)}")

    print("DONE")

if __name__ == "__main__":
    main()