import os
os.environ["CUDA_VISIBLE_DEVICES"] = "6"
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"

import csv
import json
import time
from typing import Any, Dict, List, Optional

import torch
from PIL import Image
from transformers import Qwen2VLForConditionalGeneration, AutoProcessor

# =========================
# 路径配置
# =========================
INPUT_JSONL = "/home/chenyi/offline_blaser_qe/dataSet/VG/hi/hi_vg_test.jsonl"
OUTPUT_CSV = "/home/chenyi/offline_blaser_qe/out/VG/hi/hi_test_translation.csv"

QWEN_PATH = "/mnt/raid/hss/model/Qwen2-VL-7B-Instruct"

# 修正图片目录
IMAGE_DIR = "/home/chenyi/offline_blaser_qe/dataSet/VG/images"

# =========================
# 参数
# =========================
DTYPE = torch.bfloat16 if torch.cuda.is_available() else torch.float32
MAX_SAMPLES = None      # 测试时可改成 10
FLUSH_EVERY = 20


def format_time(seconds: float) -> str:
    seconds = max(0, int(seconds))
    h = seconds // 3600
    m = (seconds % 3600) // 60
    s = seconds % 60
    return f"{h:02d}:{m:02d}:{s:02d}"


def load_jsonl(path: str) -> List[Dict[str, Any]]:
    data = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            data.append(json.loads(line))
            if MAX_SAMPLES is not None and len(data) >= MAX_SAMPLES:
                break
    return data


def find_image(image_id: Any) -> Optional[str]:
    image_id = str(image_id)

    # 先按精确文件名查找
    for ext in [".jpg", ".jpeg", ".png", ".JPG", ".JPEG", ".PNG"]:
        p = os.path.join(IMAGE_DIR, f"{image_id}{ext}")
        if os.path.isfile(p):
            return p

    # 再按 stem 模糊匹配
    for fname in os.listdir(IMAGE_DIR):
        stem, ext = os.path.splitext(fname)
        if stem == image_id and ext.lower() in [".jpg", ".jpeg", ".png"]:
            return os.path.join(IMAGE_DIR, fname)

    return None


def cleanup_cuda():
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        torch.cuda.ipc_collect()


def load_model():
    print("[Info] Loading model on GPU 7 ...")
    model = Qwen2VLForConditionalGeneration.from_pretrained(
        QWEN_PATH,
        torch_dtype=DTYPE,
        device_map="auto",
        trust_remote_code=True
    )
    processor = AutoProcessor.from_pretrained(
        QWEN_PATH,
        trust_remote_code=True
    )
    print("[Info] Model loaded.")
    return model, processor


def translate(model, processor, image: Image.Image, src: str) -> str:
    prompt = f"""
Translate the source sentence into English taking consideration of the image.

Return only the translation.
No explanation.
No prefix.
No extra text.

Source:
{src}
""".strip()

    messages = [{
        "role": "user",
        "content": [
            {"type": "image"},
            {"type": "text", "text": prompt}
        ]
    }]

    text = processor.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True
    )

    inputs = processor(
        text=[text],
        images=[image],
        padding=True,
        return_tensors="pt"
    )
    inputs = {
        k: v.to(model.device) if hasattr(v, "to") else v
        for k, v in inputs.items()
    }

    with torch.no_grad():
        out = model.generate(
            **inputs,
            max_new_tokens=64,
            do_sample=False,
            use_cache=True
        )

    out = out[:, inputs["input_ids"].shape[1]:]
    result = processor.batch_decode(
        out,
        skip_special_tokens=True,
        clean_up_tokenization_spaces=True
    )[0].strip()

    return result


def main():
    data = load_jsonl(INPUT_JSONL)
    total = len(data)

    print(f"[Info] Total samples: {total}")
    print(f"[Info] CUDA available: {torch.cuda.is_available()}")
    if torch.cuda.is_available():
        print(f"[Info] Visible GPU count: {torch.cuda.device_count()}")
        print(f"[Info] Current device: {torch.cuda.current_device()}")

    model, processor = load_model()

    os.makedirs(os.path.dirname(OUTPUT_CSV), exist_ok=True)

    start_time = time.time()
    buffer = []
    saved = 0

    with open(OUTPUT_CSV, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=[
            "image_id",
            "source_text",
            "initial_translation_en"
        ])
        writer.writeheader()

        for i, item in enumerate(data, 1):
            iter_start = time.time()

            image_id = item.get("image_id", "")
            source_text = str(item.get("tgt", "")).strip()

            if not source_text:
                elapsed = time.time() - start_time
                avg = elapsed / i
                eta = avg * (total - i)
                print(f"[{i}/{total}] skipped_empty_src | elapsed={format_time(elapsed)} | ETA={format_time(eta)}")
                continue

            img_path = find_image(image_id)
            if img_path is None:
                elapsed = time.time() - start_time
                avg = elapsed / i
                eta = avg * (total - i)
                print(f"[{i}/{total}] image_not_found image_id={image_id} | elapsed={format_time(elapsed)} | ETA={format_time(eta)}")
                continue

            try:
                image = Image.open(img_path).convert("RGB")
                translation = translate(model, processor, image, source_text)

                buffer.append({
                    "image_id": image_id,
                    "source_text": source_text,
                    "initial_translation_en": translation
                })
                saved += 1

            except Exception as e:
                print(f"[Error] image_id={image_id} | {repr(e)}")

            finally:
                cleanup_cuda()

            if len(buffer) >= FLUSH_EVERY:
                writer.writerows(buffer)
                f.flush()
                buffer = []

            iter_time = time.time() - iter_start
            elapsed = time.time() - start_time
            avg = elapsed / i
            eta = avg * (total - i)

            print(
                f"[{i}/{total}] "
                f"image_id={image_id} | "
                f"iter={iter_time:.2f}s | "
                f"avg={avg:.2f}s | "
                f"elapsed={format_time(elapsed)} | "
                f"ETA={format_time(eta)} | "
                f"saved={saved}"
            )

        if buffer:
            writer.writerows(buffer)
            f.flush()

    total_time = time.time() - start_time
    print("\n==============================")
    print(f"TOTAL TIME: {format_time(total_time)}")
    print(f"SAVED TO: {OUTPUT_CSV}")
    print("==============================")


if __name__ == "__main__":
    main()