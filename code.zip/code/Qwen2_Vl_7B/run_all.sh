#!/bin/bash
set -e


source /home/chenyi/venvs/qwen3_vl_env/bin/activate
cd /home/chenyi/offline_blaser_qe/code/Qwen2_Vl_7B

python text_only_and_image_prior.py --data vg --lang hi --gpu 5
python text_only_and_image_prior.py --data vg --lang ha --gpu 5
python text_only_and_image_prior.py --data vg --lang bn --gpu 5
python text_only_and_image_prior.py --data vg --lang ma --gpu 5

python text_only_and_image_prior.py --data multi30k --lang hi --gpu 5
python text_only_and_image_prior.py --data multi30k --lang lv --gpu 5
python text_only_and_image_prior.py --data multi30k --lang tr --gpu 5


# for alpha in 0.01 0.03 0.05 0.07 0.09
# do
#     echo "Running alpha: $lalpha"
#     python contract_decoding.py --data vg --lang bn --gpu 5 --alpha $alpha
#     python contract_decoding.py --data vg --lang ha --gpu 5 --alpha $alpha
#     python contract_decoding.py --data vg --lang hi --gpu 5 --alpha $alpha
#     python contract_decoding.py --data vg --lang ma --gpu 5 --alpha $alpha
#     echo "Finished language: $alpha"
# done

# for alpha in 0.01 0.03 0.05 0.07 0.09
# do
#     echo "Running alpha: $lalpha"
#     python contract_decoding.py --data multi30k --lang lv --gpu 5 --alpha $alpha
#     python contract_decoding.py --data multi30k --lang tr --gpu 5 --alpha $alpha
#     python contract_decoding.py --data multi30k --lang hi --gpu 5 --alpha $alpha
   
#     echo "Finished language: $alpha"
# done

echo "All  finished."