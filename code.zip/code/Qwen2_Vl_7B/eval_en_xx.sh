#!/bin/bash
set -e

source /home/guozhengyi/anaconda3/envs/evaluate/bin/activate
cd /home/chenyi/offline_blaser_qe/code/Qwen2_Vl_7B

# python eval_en_xx_direct.py --data vg --lang ha --gpu 0 
# python eval_en_xx_direct.py --data vg --lang hi --gpu 0 
# python eval_en_xx_direct.py --data vg --lang ma --gpu 0 
# python eval_en_xx_direct.py --data vg --lang bn --gpu 0 

# python eval_en_xx_direct.py --data multi30k --lang lv --gpu 6 
# python eval_en_xx_direct.py --data multi30k --lang tr --gpu 6 
# python eval_en_xx_direct.py --data multi30k --lang hi --gpu 6 

for alpha in 0.35 0.4 
do
    echo "Running alpha: $lalpha"
    
    python eval_en_xx_best.py --data vg --lang ha --gpu 5 --alpha $alpha
    python eval_en_xx_best.py --data vg --lang hi --gpu 5 --alpha $alpha
    python eval_en_xx_best.py --data vg --lang ma --gpu 5 --alpha $alpha
    python eval_en_xx_best.py --data vg --lang bn --gpu 5 --alpha $alpha
    echo "Finished language: $alpha"
done

for alpha in 0.35 0.4
do
    echo "Running alpha: $lalpha"
    python eval_en_xx_best.py --data multi30k --lang lv --gpu 5 --alpha $alpha
    python eval_en_xx_best.py --data multi30k --lang tr --gpu 5 --alpha $alpha
    python eval_en_xx_best.py --data multi30k --lang hi --gpu 5 --alpha $alpha
   
    echo "Finished language: $alpha"
done

echo "All  finished."