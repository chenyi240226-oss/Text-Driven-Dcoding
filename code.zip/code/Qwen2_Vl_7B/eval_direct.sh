#!/bin/bash
set -e


source /home/guozhengyi/anaconda3/envs/evaluate/bin/activate
cd /home/chenyi/offline_blaser_qe/code/Qwen2_Vl_7B




python eval_direct.py --data vg --lang ha --gpu 3 --alpha 0
# python eval_direct.py --data vg --lang hi --gpu 4 --alpha 0
# python eval_direct.py --data vg --lang ma --gpu 4 --alpha 0
# python eval_direct.py --data vg --lang bn --gpu 4 --alpha 0


# python eval_direct.py --data multi30k --lang lv --gpu 4 --alpha 0
# python eval_direct.py --data multi30k --lang tr --gpu 4 --alpha 0
# python eval_direct.py --data multi30k --lang hi --gpu 4 --alpha 0



echo "All  finished."