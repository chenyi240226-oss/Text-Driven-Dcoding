#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import argparse

# =========================================================
# Arguments: must be parsed before importing torch
# =========================================================
ALLOWED_LANGUAGES = {"hi", "ma", "ha", "bn"}


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--lang",
        type=str,
        required=True,
        choices=sorted(ALLOWED_LANGUAGES),
        help="Language code. Allowed values: hi, ma, ha, bn."
    )
    parser.add_argument(
        "--gpu",
        type=str,
        required=True,
        help="Physical GPU id, for example: 0, 1, 5, 6, 7."
    )
    return parser.parse_args()


ARGS = parse_args()
LANGUAGE = ARGS.lang
GPU = ARGS.gpu

os.environ["CUDA_VISIBLE_DEVICES"] = str(GPU)
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"

import re
import json
import time
import difflib
from typing import Any, Dict, List, Optional, Tuple

from PIL import Image
import torch

# =========================================================
# Torch compatibility patch
# =========================================================
if not hasattr(torch, "compiler"):
    class _DummyCompiler:
        @staticmethod
        def is_compiling():
            return False
    torch.compiler = _DummyCompiler()
elif not hasattr(torch.compiler, "is_compiling"):
    torch.compiler.is_compiling = lambda: False

from transformers import AutoProcessor, Qwen2VLForConditionalGeneration

torch.set_grad_enabled(False)

# =========================================================
# Paths
# =========================================================
QWEN_PATH = "/mnt/raid/hss/model/Qwen2-VL-7B-Instruct"

OUTPUT_ROOT = "/home/chenyi/offline_blaser_qe/out/Qwen2_VL_7B/VG"

INPUT_JSONL = os.path.join(
    OUTPUT_ROOT,
    LANGUAGE,
    f"{LANGUAGE}_detect_span.jsonl"
)

REFERENCE_JSONL = os.path.join(
    OUTPUT_ROOT,
    LANGUAGE,
    f"{LANGUAGE}_test_translation.jsonl"
)

OUTPUT_JSONL = os.path.join(
    OUTPUT_ROOT,
    LANGUAGE,
    f"{LANGUAGE}_3_candidates_from_span.jsonl"
)

MAX_ROWS = None

DTYPE = torch.bfloat16 if torch.cuda.is_available() else torch.float32

MAX_NEW_TOKENS_CANDIDATE = 380

ALLOWED_EDIT_TYPES = {"keep", "paraphrase", "visual_refill"}

CANDIDATE_FORMULA_VERSION = "candidate_phrase_level_source_faithful_no_llm_verifier_v7_delete_as_paraphrase"

FUNCTION_WORDS = {
    "a", "an", "the",
    "of", "in", "on", "at", "by", "with", "from", "to", "for",
    "into", "onto", "over", "under", "between", "around", "through",
    "during", "while", "near", "inside", "outside", "along", "across",
    "behind", "beside", "toward", "towards", "against", "about",
    "before", "after", "front", "back", "next",
    "is", "are", "was", "were", "am", "be", "been", "being",
    "and", "or", "but", "who", "which", "that",
    "this", "these", "those",
    "his", "her", "their", "theirs", "its", "our", "ours", "your", "yours", "my", "mine",
    "he", "him", "she", "it", "they", "them", "we", "us", "you", "i", "me",
    "himself", "herself", "itself", "themselves", "ourselves", "yourself", "yourselves", "myself",
    "as", "if", "than", "then",
    "there", "here",
    "not", "no",
    "do", "does", "did", "done",
    "have", "has", "had",
    "will", "would", "can", "could", "should", "may", "might", "must",
    "still", "very", "just", "also",
}

RELATION_WORDS = {
    "in", "on", "at", "by", "with", "from", "to", "for",
    "into", "onto", "over", "under", "between", "around", "through",
    "during", "while", "near", "inside", "outside", "along", "across",
    "behind", "beside", "toward", "towards", "against", "before", "after",
    "front", "back", "next"
}

DETERMINERS = {
    "a", "an", "the", "this", "that", "these", "those",
    "his", "her", "their", "its", "our", "your", "my"
}

AUX_WORDS = {
    "is", "are", "was", "were", "am", "be", "been", "being",
    "has", "have", "had", "do", "does", "did",
    "will", "would", "can", "could", "should", "may", "might", "must"
}

REFLEXIVE_PRONOUNS = {
    "myself", "yourself", "yourselves", "himself", "herself",
    "itself", "ourselves", "themselves"
}

PRONOUN_GROUPS = {
    "male": {"he", "him", "his", "himself"},
    "female": {"she", "her", "hers", "herself"},
    "neutral": {"it", "its", "itself"},
    "plural": {"they", "them", "their", "theirs", "themselves"},
    "first": {"i", "me", "my", "mine", "myself", "we", "us", "our", "ours", "ourselves"},
    "second": {"you", "your", "yours", "yourself", "yourselves"},
}

IDENTITY_NOUN_TERMS = {
    "man", "men", "woman", "women",
    "boy", "boys", "girl", "girls",
    "male", "female", "gentleman", "lady",
    "mother", "father", "mom", "dad",
    "son", "daughter", "child", "children", "baby", "babies",
}

PRONOUN_OR_IDENTITY_TERMS = set().union(*PRONOUN_GROUPS.values()) | IDENTITY_NOUN_TERMS

VOWEL_INITIAL = set("aeiou")


# =========================================================
# Load model
# =========================================================
print("Loading model...")
print(f"[INFO] LANGUAGE: {LANGUAGE}")
print(f"[INFO] GPU: {GPU}")
print(f"[INFO] CUDA_VISIBLE_DEVICES: {os.environ.get('CUDA_VISIBLE_DEVICES')}")
print(f"[INFO] QWEN_PATH: {QWEN_PATH}")
print(f"[INFO] INPUT_JSONL: {INPUT_JSONL}")
print(f"[INFO] REFERENCE_JSONL(output field only): {REFERENCE_JSONL}")
print(f"[INFO] OUTPUT_JSONL: {OUTPUT_JSONL}")

processor = AutoProcessor.from_pretrained(
    QWEN_PATH,
    trust_remote_code=True
)

model = Qwen2VLForConditionalGeneration.from_pretrained(
    QWEN_PATH,
    torch_dtype=DTYPE,
    device_map="auto",
    trust_remote_code=True,
).eval()

tokenizer = processor.tokenizer
print("Model loaded.")


# =========================================================
# Basic utils
# =========================================================
def clean_text(x: Any) -> str:
    if x is None:
        return ""
    return re.sub(r"\s+", " ", str(x).strip())


def norm(x: Any) -> str:
    x = clean_text(x).lower()
    x = x.replace("’", "'").replace("“", '"').replace("”", '"')
    x = re.sub(r"[^a-z0-9_\-\s]", " ", x)
    return re.sub(r"\s+", " ", x).strip()


def norm_sent(x: Any) -> str:
    x = clean_text(x)
    x = re.sub(r"\s+([,.;:!?])", r"\1", x)
    x = x.strip().strip('"').strip("'").strip()
    return x.rstrip(".,;:!?")


def same(a: Any, b: Any) -> bool:
    return norm(a) == norm(b)


def safe_json(obj: Any) -> str:
    try:
        return json.dumps(obj, ensure_ascii=False)
    except Exception:
        return "[]"


def cleanup_cuda():
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        torch.cuda.ipc_collect()


def load_image(path: str) -> Optional[Image.Image]:
    path = clean_text(path)
    if not path or not os.path.isfile(path):
        return None
    try:
        return Image.open(path).convert("RGB")
    except Exception:
        return None


def format_time(sec: float) -> str:
    sec = int(sec)
    return f"{sec // 3600:02d}:{(sec % 3600) // 60:02d}:{sec % 60:02d}"


def tokenize_words(x: Any) -> List[str]:
    return re.findall(r"[A-Za-z0-9_\-]+", norm(x))


def content_tokens(x: Any) -> List[str]:
    return [t for t in tokenize_words(x) if t and t not in FUNCTION_WORDS]


def relation_tokens(x: Any) -> List[str]:
    return [t for t in tokenize_words(x) if t in RELATION_WORDS]


def pronoun_tokens(x: Any) -> List[str]:
    toks = tokenize_words(x)
    pronouns = set().union(*PRONOUN_GROUPS.values())
    return [t for t in toks if t in pronouns]


def ratio_score(flags: List[bool]) -> float:
    if not flags:
        return 0.0
    return sum(1 for x in flags if bool(x)) / float(len(flags))


def first_nonempty(row: Dict, keys: List[str]) -> str:
    for k in keys:
        v = clean_text(row.get(k, ""))
        if v:
            return v
    return ""


def dict_first_nonempty(d: Dict, keys: List[str]) -> str:
    for k in keys:
        v = clean_text(d.get(k, ""))
        if v:
            return v
    return ""


# =========================================================
# Reference translation adapter
# 说明：
# 参考译文只用于最终输出字段 reference_translation。
# 不参与候选生成、不参与过滤、不参与统计、不参与日志判断。
# =========================================================
def row_id_keys(row: Dict) -> List[str]:
    keys = []

    for k in ["id", "image_id"]:
        v = clean_text(row.get(k, ""))
        if v:
            keys.append(f"id::{v}")

    image_path = clean_text(row.get("image_path", row.get("image", "")))
    if image_path:
        base = os.path.basename(image_path)
        stem = os.path.splitext(base)[0]
        if stem:
            keys.append(f"id::{stem}")

    source_text = clean_text(row.get("source_text", ""))
    if source_text:
        keys.append(f"src::{norm(source_text)}")

    target = clean_text(row.get("target", ""))
    if target:
        keys.append(f"src::{norm(target)}")

    return keys


def read_jsonl_records(path: str) -> List[Dict]:
    rows = []

    if not os.path.isfile(path):
        return rows

    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))

    return rows


def build_reference_map(reference_jsonl: str) -> Dict[str, str]:
    ref_map: Dict[str, str] = {}

    if not reference_jsonl or not os.path.isfile(reference_jsonl):
        print(f"[WARN] REFERENCE_JSONL not found. reference_translation output field may be empty: {reference_jsonl}")
        return ref_map

    rows = read_jsonl_records(reference_jsonl)

    for row in rows:
        ref = first_nonempty(
            row,
            [
                "reference_translation",
                "src_en",
                "source_text_en",
                "reference",
                "source",
            ],
        )

        if not ref:
            continue

        for k in row_id_keys(row):
            if k not in ref_map:
                ref_map[k] = ref

    print(f"[INFO] Loaded reference map for output field only: {len(ref_map)} keys from {reference_jsonl}")
    return ref_map


def get_reference_translation_for_output_only(row: Dict, ref_map: Dict[str, str]) -> str:
    ref = first_nonempty(
        row,
        [
            "reference_translation",
            "src_en",
            "source_text_en",
            "reference",
            "source",
        ],
    )

    if ref:
        return ref

    for k in row_id_keys(row):
        if k in ref_map and clean_text(ref_map[k]):
            return clean_text(ref_map[k])

    return ""


# =========================================================
# Qwen generation / JSON parsing
# =========================================================
def run_qwen_json(
    system_prompt: str,
    user_prompt: str,
    image: Optional[Image.Image],
    max_new_tokens: int,
) -> str:
    prompt_text = f"{system_prompt}\n\n{user_prompt}".strip()

    messages = [
        {
            "role": "user",
            "content": (
                ([{"type": "image"}] if image is not None else [])
                + [{"type": "text", "text": prompt_text}]
            ),
        },
    ]

    text = processor.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True,
    )

    if image is not None:
        inputs = processor(
            text=[text],
            images=[image],
            return_tensors="pt"
        )
    else:
        inputs = processor(
            text=[text],
            return_tensors="pt"
        )

    inputs = {
        k: v.to(model.device) if isinstance(v, torch.Tensor) else v
        for k, v in inputs.items()
    }

    with torch.no_grad():
        out = model.generate(
            **inputs,
            do_sample=False,
            max_new_tokens=max_new_tokens,
            repetition_penalty=1.02,
            pad_token_id=tokenizer.eos_token_id,
            eos_token_id=tokenizer.eos_token_id,
            use_cache=True,
        )

    gen = out[:, inputs["input_ids"].shape[1]:]
    return processor.batch_decode(gen, skip_special_tokens=True)[0]


def extract_json(raw: str) -> Dict:
    raw = clean_text(raw)

    if not raw:
        return {}

    raw = raw.strip()
    raw = re.sub(r"^```(?:json)?", "", raw, flags=re.I).strip()
    raw = re.sub(r"```$", "", raw).strip()

    try:
        obj = json.loads(raw)
        if isinstance(obj, dict):
            return obj
    except Exception:
        pass

    start = raw.find("{")
    end = raw.rfind("}")

    if start >= 0 and end > start:
        s = raw[start:end + 1]
        try:
            obj = json.loads(s)
            if isinstance(obj, dict):
                return obj
        except Exception:
            pass

    candidates = re.findall(
        r"\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}",
        raw,
        flags=re.S,
    )

    for c in candidates:
        try:
            obj = json.loads(c)
            if isinstance(obj, dict):
                return obj
        except Exception:
            continue

    return {}


# =========================================================
# Detect output adapter
# =========================================================
def normalize_edit_type(x: Any) -> str:
    et = clean_text(x).lower()

    # 核心修改：
    # 原程序是 delete -> keep，会导致 delete span 被 collect_non_keep() 过滤掉。
    # 现在改成 delete -> paraphrase，让 delete span 进入候选生成阶段，
    # 由模型进行 source-faithful phrase-level paraphrase repair，而不是直接删除。
    if et == "delete":
        return "paraphrase"

    if et in ALLOWED_EDIT_TYPES:
        return et

    return ""


def overlap(a: str, b: str) -> bool:
    a, b = norm(a), norm(b)
    if not a or not b:
        return False
    return a == b or a in b or b in a


def get_et_from_list(items: Any, span: str) -> str:
    if not isinstance(items, list):
        return ""

    ns = norm(span)

    for it in items:
        if isinstance(it, dict) and norm(it.get("span", "")) == ns:
            return normalize_edit_type(it.get("edit_type", ""))

    return ""


def get_span_item(row: Dict, span: str) -> Dict:
    ns = norm(span)
    spans = row.get("suspicious_spans", [])

    if not isinstance(spans, list):
        return {}

    for it in spans:
        if isinstance(it, dict) and norm(it.get("span", "")) == ns:
            out = dict(it)
            out["edit_type"] = normalize_edit_type(out.get("edit_type", ""))
            return out

    return {}


def get_et(row: Dict, span: str) -> str:
    for key in [
        "action_primary_edit_types",
        "primary_edit_types",
        "action_primary_edit_types_detect",
        "primary_edit_types_detect",
    ]:
        et = get_et_from_list(row.get(key, []), span)
        if et:
            return et

    spans = row.get("suspicious_spans", [])
    if isinstance(spans, list):
        for it in spans:
            if isinstance(it, dict) and norm(it.get("span", "")) == norm(span):
                et = normalize_edit_type(it.get("edit_type", ""))
                if et:
                    return et

    pairs = [
        ("action_primary_suspicious_span", "action_primary_edit_type"),
        ("action_primary_low_suspicious_span", "action_primary_low_edit_type"),
        ("primary_suspicious_span", "primary_edit_type"),
        ("primary_low_suspicious_span", "primary_low_edit_type"),
        ("score_primary_suspicious_span", "score_primary_edit_type"),
        ("score_primary_low_suspicious_span", "score_primary_low_edit_type"),
        ("action_primary_suspicious_span_detect", "action_primary_edit_type_detect"),
        ("action_primary_low_suspicious_span_detect", "action_primary_low_edit_type_detect"),
        ("primary_suspicious_span_detect", "primary_edit_type_detect"),
        ("primary_low_suspicious_span_detect", "primary_low_edit_type_detect"),
        ("score_primary_suspicious_span_detect", "score_primary_edit_type_detect"),
        ("score_primary_low_suspicious_span_detect", "score_primary_low_edit_type_detect"),
    ]

    for sk, ek in pairs:
        if norm(row.get(sk, "")) == norm(span):
            et = normalize_edit_type(row.get(ek, ""))
            if et:
                return et

    return ""


def add_operand(
    out: List[Dict],
    row: Dict,
    span: Any,
    et: Any = "",
    source: str = "",
):
    sp = clean_text(span)
    if not sp:
        return

    e = normalize_edit_type(et) if et else get_et(row, sp)
    if not e:
        e = "keep"

    for old in out:
        if overlap(old.get("span", ""), sp):
            if len(sp) > len(clean_text(old.get("span", ""))):
                old["span"] = sp
                old["edit_type"] = e
                old["span_item"] = get_span_item(row, sp)
                old["source"] = source
            elif old.get("edit_type") == "keep" and e != "keep":
                old["edit_type"] = e
            return

    out.append({
        "span": sp,
        "edit_type": e,
        "span_item": get_span_item(row, sp),
        "source": source,
        "order": len(out),
    })


def collect_non_keep(row: Dict) -> List[Dict]:
    out: List[Dict] = []

    for key in [
        "action_primary_edit_types",
        "action_primary_edit_types_detect",
        "primary_edit_types",
        "primary_edit_types_detect",
    ]:
        v = row.get(key, [])
        if isinstance(v, list):
            for it in v:
                if isinstance(it, dict):
                    add_operand(
                        out,
                        row,
                        it.get("span", ""),
                        it.get("edit_type", ""),
                        key,
                    )

    for sk, ek in [
        ("action_primary_suspicious_span", "action_primary_edit_type"),
        ("action_primary_low_suspicious_span", "action_primary_low_edit_type"),
        ("primary_suspicious_span", "primary_edit_type"),
        ("primary_low_suspicious_span", "primary_low_edit_type"),
        ("score_primary_suspicious_span", "score_primary_edit_type"),
        ("score_primary_low_suspicious_span", "score_primary_low_edit_type"),
        ("action_primary_suspicious_span_detect", "action_primary_edit_type_detect"),
        ("action_primary_low_suspicious_span_detect", "action_primary_low_edit_type_detect"),
        ("primary_suspicious_span_detect", "primary_edit_type_detect"),
        ("primary_low_suspicious_span_detect", "primary_low_edit_type_detect"),
        ("score_primary_suspicious_span_detect", "score_primary_edit_type_detect"),
        ("score_primary_low_suspicious_span_detect", "score_primary_low_edit_type_detect"),
    ]:
        add_operand(out, row, row.get(sk, ""), row.get(ek, ""), sk)

    spans = row.get("suspicious_spans", [])
    if isinstance(spans, list):
        for it in spans:
            if isinstance(it, dict):
                add_operand(
                    out,
                    row,
                    it.get("span", ""),
                    it.get("edit_type", ""),
                    "suspicious_spans",
                )

    return [
        x for x in out
        if normalize_edit_type(x.get("edit_type", "")) in {"paraphrase", "visual_refill"}
    ]


def compact_operands(ops: List[Dict]) -> List[Dict]:
    arr = []

    for x in ops:
        item = x.get("span_item", {}) if isinstance(x.get("span_item", {}), dict) else {}
        arr.append({
            "span": clean_text(x.get("span", "")),
            "edit_type": normalize_edit_type(x.get("edit_type", "")),
            "edit_reason": clean_text(item.get("edit_reason", "")),
        })

    return arr


def has_visual_refill(ops: List[Dict]) -> bool:
    return any(normalize_edit_type(x.get("edit_type", "")) == "visual_refill" for x in ops)


# =========================================================
# String diff for edited_spans
# =========================================================
def diff_edits(old: str, new: str) -> List[Dict]:
    old, new = norm_sent(old), norm_sent(new)

    if same(old, new):
        return []

    old_toks = re.findall(r"\S+", old)
    new_toks = re.findall(r"\S+", new)

    old_norm = [norm(x) for x in old_toks]
    new_norm = [norm(x) for x in new_toks]

    edits = []

    for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(
        a=old_norm,
        b=new_norm,
    ).get_opcodes():
        if tag == "equal":
            continue

        frm = " ".join(old_toks[i1:i2]).strip()
        to = " ".join(new_toks[j1:j2]).strip()

        if frm or to:
            edits.append({"from": frm, "to": to})

    out = []
    seen = set()

    for ed in edits:
        if same(ed.get("from", ""), ed.get("to", "")):
            continue

        k = (norm(ed.get("from", "")), norm(ed.get("to", "")))
        if k not in seen:
            seen.add(k)
            out.append(ed)

    return out


def model_repairs_to_edits(obj: Dict, initial: str, candidate: str) -> List[Dict]:
    if not isinstance(obj, dict):
        return []

    repairs = obj.get("local_repairs", [])
    if not isinstance(repairs, list):
        return []

    out = []
    seen = set()

    for r in repairs:
        if not isinstance(r, dict):
            continue

        frm = dict_first_nonempty(
            r,
            [
                "old_phrase",
                "from",
                "local_phrase",
                "span",
                "original",
                "source_phrase",
            ],
        )
        to = dict_first_nonempty(
            r,
            [
                "new_phrase",
                "to",
                "replacement",
                "corrected_phrase",
                "target_phrase",
            ],
        )

        frm = norm_sent(frm)
        to = norm_sent(to)

        if not frm or not to:
            continue

        if same(frm, to):
            continue

        if norm(frm) not in norm(initial):
            continue

        k = (norm(frm), norm(to))
        if k in seen:
            continue

        seen.add(k)
        out.append({"from": frm, "to": to})

    return out


def make_candidate_edits(initial: str, candidate: str, obj: Optional[Dict] = None) -> List[Dict]:
    phrase_edits = model_repairs_to_edits(obj or {}, initial, candidate)

    if phrase_edits:
        return phrase_edits

    return diff_edits(initial, candidate)


# =========================================================
# Deterministic candidate checks
# =========================================================
def changed_token_sets(edited_spans: List[Dict]) -> Tuple[set, set]:
    from_tokens = set()
    to_tokens = set()

    if not isinstance(edited_spans, list):
        return from_tokens, to_tokens

    for ed in edited_spans:
        if not isinstance(ed, dict):
            continue

        from_tokens.update(content_tokens(ed.get("from", "")))
        to_tokens.update(content_tokens(ed.get("to", "")))

    return from_tokens, to_tokens


def pronoun_groups(tokens: List[str]) -> set:
    groups = set()

    st = set(tokens)
    for group_name, group_terms in PRONOUN_GROUPS.items():
        if st & group_terms:
            groups.add(group_name)

    return groups


def only_reflexive_pronoun_difference(from_tokens: List[str], to_tokens: List[str]) -> bool:
    all_pronouns = set().union(*PRONOUN_GROUPS.values())

    f_pron = set([x for x in from_tokens if x in all_pronouns])
    t_pron = set([x for x in to_tokens if x in all_pronouns])

    diff = f_pron.symmetric_difference(t_pron)

    if not diff:
        return True

    return diff.issubset(REFLEXIVE_PRONOUNS)


def deterministic_pronoun_or_identity_shift(edited_spans: List[Dict]) -> bool:
    if not isinstance(edited_spans, list):
        return False

    for ed in edited_spans:
        if not isinstance(ed, dict):
            continue

        ft_all = tokenize_words(ed.get("from", ""))
        tt_all = tokenize_words(ed.get("to", ""))

        f_id = set(ft_all) & IDENTITY_NOUN_TERMS
        t_id = set(tt_all) & IDENTITY_NOUN_TERMS

        if f_id != t_id and (f_id or t_id):
            return True

        f_pron = pronoun_groups(ft_all)
        t_pron = pronoun_groups(tt_all)

        if f_pron and t_pron and f_pron != t_pron:
            if not only_reflexive_pronoun_difference(ft_all, tt_all):
                return True

        if bool(f_pron) != bool(t_pron):
            if not only_reflexive_pronoun_difference(ft_all, tt_all):
                return True

    return False


def has_empty_to_content_deletion(edited_spans: List[Dict]) -> bool:
    for ed in edited_spans:
        frm = clean_text(ed.get("from", ""))
        to = clean_text(ed.get("to", ""))

        if frm and not to and len(content_tokens(frm)) > 0:
            return True

    return False


def is_phrase_compression_edit(from_content: List[str], to_content: List[str], frm: str, to: str) -> bool:
    if len(from_content) < 2:
        return False

    if len(to_content) != 1:
        return False

    frm_tokens = tokenize_words(frm)
    to_tokens = tokenize_words(to)

    if set(frm_tokens) & IDENTITY_NOUN_TERMS:
        return False

    if set(to_tokens) & IDENTITY_NOUN_TERMS:
        return False

    if relation_tokens(frm) or relation_tokens(to):
        return False

    return True


def edit_content_stats(edited_spans: List[Dict]) -> Dict:
    edit_count = 0
    from_content_total = 0
    to_content_total = 0
    shared_content_total = 0
    one_content_token_replacement_count = 0
    empty_from_count = 0
    empty_to_count = 0
    changed_content_from_total = 0
    changed_content_to_total = 0
    non_empty_removed_content_total = 0
    non_empty_uncompensated_removed_content_total = 0
    relation_change_count = 0
    unsafe_relation_rewrite_count = 0
    relation_repair_core_preserved_count = 0
    core_content_replacement_count = 0
    phrase_compression_repair_count = 0

    for ed in edited_spans if isinstance(edited_spans, list) else []:
        frm = clean_text(ed.get("from", ""))
        to = clean_text(ed.get("to", ""))

        if same(frm, to):
            continue

        ft = content_tokens(frm)
        tt = content_tokens(to)
        fs = set(ft)
        ts = set(tt)

        fr = set(relation_tokens(frm))
        tr = set(relation_tokens(to))

        removed = [x for x in ft if x not in ts]
        added = [x for x in tt if x not in fs]

        shared_content = fs & ts
        relation_changed = fr != tr

        phrase_compression = is_phrase_compression_edit(ft, tt, frm, to)

        edit_count += 1
        from_content_total += len(ft)
        to_content_total += len(tt)
        shared_content_total += len(shared_content)

        changed_content_from_total += len(removed)
        changed_content_to_total += len(added)

        if phrase_compression:
            phrase_compression_repair_count += 1

        if frm and to:
            non_empty_removed_content_total += len(removed)
            if removed and not added:
                non_empty_uncompensated_removed_content_total += len(removed)

            if ft and tt and not shared_content and not phrase_compression:
                core_content_replacement_count += 1

        if relation_changed:
            relation_change_count += 1

            if len(ft) > 0 and len(tt) > 0 and len(shared_content) > 0:
                relation_repair_core_preserved_count += 1
            elif len(ft) == 0 or len(tt) == 0:
                relation_repair_core_preserved_count += 1
            else:
                unsafe_relation_rewrite_count += 1

        if not frm and to:
            empty_from_count += 1
        if frm and not to:
            empty_to_count += 1

        if len(ft) == 1 and len(tt) == 1 and ft[0] != tt[0]:
            one_content_token_replacement_count += 1

    return {
        "edit_count": edit_count,
        "from_content_total": from_content_total,
        "to_content_total": to_content_total,
        "shared_content_total": shared_content_total,
        "one_content_token_replacement_count": one_content_token_replacement_count,
        "empty_from_count": empty_from_count,
        "empty_to_count": empty_to_count,
        "changed_content_from_total": changed_content_from_total,
        "changed_content_to_total": changed_content_to_total,
        "non_empty_removed_content_total": non_empty_removed_content_total,
        "non_empty_uncompensated_removed_content_total": non_empty_uncompensated_removed_content_total,
        "relation_change_count": relation_change_count,
        "relation_repair_core_preserved_count": relation_repair_core_preserved_count,
        "unsafe_relation_rewrite_count": unsafe_relation_rewrite_count,
        "core_content_replacement_count": core_content_replacement_count,
        "phrase_compression_repair_count": phrase_compression_repair_count,
    }


def is_single_word_replacement(edited_spans: List[Dict]) -> bool:
    stats = edit_content_stats(edited_spans)

    return (
        stats["edit_count"] == 1
        and stats["one_content_token_replacement_count"] == 1
    )


def is_local_content_substitution(edited_spans: List[Dict]) -> bool:
    stats = edit_content_stats(edited_spans)

    if stats["edit_count"] != 1:
        return False

    if stats["shared_content_total"] <= 0:
        return False

    if stats["changed_content_from_total"] == 1 and stats["changed_content_to_total"] == 1:
        return True

    return False


def has_non_empty_content_deletion(edited_spans: List[Dict]) -> bool:
    stats = edit_content_stats(edited_spans)

    return stats["non_empty_uncompensated_removed_content_total"] > 0


def has_core_content_replacement(edited_spans: List[Dict]) -> bool:
    stats = edit_content_stats(edited_spans)
    return stats["core_content_replacement_count"] > 0


def has_unsafe_relation_rewrite(edited_spans: List[Dict]) -> bool:
    stats = edit_content_stats(edited_spans)
    return stats["unsafe_relation_rewrite_count"] > 0


def is_relation_repair(edited_spans: List[Dict]) -> bool:
    stats = edit_content_stats(edited_spans)

    if stats["relation_change_count"] <= 0:
        return False

    if stats["unsafe_relation_rewrite_count"] > 0:
        return False

    if stats["core_content_replacement_count"] > 0:
        return False

    if stats["non_empty_uncompensated_removed_content_total"] > 0:
        return False

    return True


def is_surface_rewrite(edited_spans: List[Dict]) -> bool:
    stats = edit_content_stats(edited_spans)

    if stats["edit_count"] == 0:
        return False

    if is_relation_repair(edited_spans):
        return False

    if stats["core_content_replacement_count"] > 0:
        return False

    if stats["shared_content_total"] <= 0:
        return False

    smaller_side = max(1, min(stats["from_content_total"], stats["to_content_total"]))
    overlap_ratio = stats["shared_content_total"] / smaller_side

    return overlap_ratio >= 0.5


def has_bad_repetition(text: str) -> bool:
    toks = tokenize_words(text)
    for i in range(1, len(toks)):
        if toks[i] == toks[i - 1]:
            return True
    return False


def has_repeated_ngram(text: str, min_n: int = 2, max_n: int = 5) -> bool:
    toks = tokenize_words(text)
    if len(toks) < min_n * 2:
        return False

    for n in range(min_n, max_n + 1):
        if len(toks) < 2 * n:
            continue
        for i in range(0, len(toks) - 2 * n + 1):
            if toks[i:i + n] == toks[i + n:i + 2 * n]:
                return True
    return False


def has_unbalanced_punctuation(text: str) -> bool:
    s = clean_text(text)
    for l, r in [("(", ")"), ("[", "]")]:
        if s.count(l) != s.count(r):
            return True
    if s.count('"') % 2 != 0:
        return True
    return False


def has_bad_article_sequence(text: str) -> bool:
    toks = tokenize_words(text)

    for i in range(len(toks) - 1):
        cur = toks[i]
        nxt = toks[i + 1]

        if cur == "a" and nxt and nxt[0] in VOWEL_INITIAL:
            return True

        if cur == "an" and nxt and nxt[0] not in VOWEL_INITIAL:
            return True

    return False


def looks_like_fragment(text: str) -> bool:
    toks = tokenize_words(text)

    if len(toks) < 3:
        return True

    low = norm(text)

    if re.match(r"^(is|are|was|were|am|be|been|being)\b", low):
        return True

    if re.match(r"^(in|on|at|by|with|from|to|of|for|between|around|through|during|while)\b", low):
        return True

    last = toks[-1] if toks else ""

    if last in {
        "and", "or", "but", "while", "who", "which", "that",
        "of", "to", "from", "with", "in", "on", "at", "by", "for"
    }:
        return True

    return False


def edited_spans_have_real_change(edited_spans: List[Dict]) -> bool:
    for ed in edited_spans:
        frm = clean_text(ed.get("from", ""))
        to = clean_text(ed.get("to", ""))

        if frm or to:
            if not same(frm, to):
                return True

    return False


def target_span_touched(ops: List[Dict], edited_spans: List[Dict]) -> Tuple[bool, float, List[str], List[str]]:
    target_spans = [clean_text(x.get("span", "")) for x in ops if clean_text(x.get("span", ""))]
    changed_from = [clean_text(x.get("from", "")) for x in edited_spans if isinstance(x, dict)]

    if not target_spans:
        return False, 0.0, target_spans, changed_from

    touched = 0
    joined_from = " ".join(changed_from)
    joined_to = " ".join([clean_text(x.get("to", "")) for x in edited_spans if isinstance(x, dict)])

    for sp in target_spans:
        if overlap(sp, joined_from) or overlap(sp, joined_to):
            touched += 1

    ratio = touched / max(1, len(target_spans))

    return touched > 0, ratio, target_spans, changed_from


def local_hard_filter_candidate(
    initial: str,
    candidate: str,
    edited_spans: List[Dict],
) -> Tuple[bool, str]:
    candidate = clean_text(candidate)
    initial = clean_text(initial)

    if not candidate:
        return False, "empty_candidate"

    if same(candidate, initial):
        return False, "same_as_initial"

    if not edited_spans_have_real_change(edited_spans):
        return False, "no_real_edited_span"

    if has_bad_article_sequence(candidate):
        return False, "bad_article_sequence"

    if has_bad_repetition(candidate):
        return False, "bad_repetition"

    if has_repeated_ngram(candidate):
        return False, "repeated_ngram"

    if has_unbalanced_punctuation(candidate):
        return False, "unbalanced_punctuation"

    if looks_like_fragment(candidate):
        return False, "fragment_or_truncated_sentence"

    return True, "hard_filter_passed"


def make_static_verification(reason: str, tier: str = "unchanged_candidate") -> Dict:
    edit_stats = {
        "edit_count": 0,
        "from_content_total": 0,
        "to_content_total": 0,
        "shared_content_total": 0,
        "one_content_token_replacement_count": 0,
        "empty_from_count": 0,
        "empty_to_count": 0,
        "changed_content_from_total": 0,
        "changed_content_to_total": 0,
        "non_empty_removed_content_total": 0,
        "non_empty_uncompensated_removed_content_total": 0,
        "relation_change_count": 0,
        "relation_repair_core_preserved_count": 0,
        "unsafe_relation_rewrite_count": 0,
        "core_content_replacement_count": 0,
        "phrase_compression_repair_count": 0,
    }

    verifier = {
        "verifier_type": "deterministic_no_llm",
        "verifier_parse_ok": True,
        "source_support_checked_by_llm": False,
        "source_semantic_better_judged_by_llm": False,

        "target_spans": [],
        "changed_from_spans": [],
        "target_span_touched": False,
        "target_span_coverage_ratio": 0.0,

        "deterministic_allow_candidate": False,
        "deterministic_score": 0.0,
        "deterministic_risk_ratio": 0.0,
        "deterministic_risk_items": [],

        "content_deletion": False,
        "empty_to_content_deletion": False,
        "non_empty_content_deletion": False,
        "relation_repair": False,
        "unsafe_relation_rewrite": False,
        "core_content_replacement": False,
        "phrase_compression_repair": False,
        "pronoun_or_identity_shift": False,
        "single_word_replacement": False,
        "surface_rewrite": False,
        "local_content_substitution": False,
        "non_local_edit": False,
        "length_delta_risk": False,
        "edit_stats": edit_stats,

        "initial_phrase_problem": "not_judged_by_llm",
        "candidate_repair_type": "not_judged_by_llm",

        "replacement_supported_by_source": False,
        "candidate_fixes_initial_problem": False,
        "adds_unsupported_information": False,
        "removes_source_information": False,
        "changes_core_meaning": False,
        "local_edit_only": True,
        "grammar_ok": True,

        "style_or_synonym_only": False,
        "exact_hindi_word_meaning_uncertain": False,
        "candidate_is_more_specific_than_source": False,
        "candidate_introduces_unrequested_rewrite": False,

        "safety_ok": False,
        "useful_repair_ok": False,
        "verified_better_than_initial": False,
        "soft_source_supported": False,
        "eligible_for_selection": False,
        "selection_tier": tier,

        "evidence": "",
        "reason_tag": reason,
    }

    reward_details = {
        "reward_formula_version": CANDIDATE_FORMULA_VERSION,
        "reward_gate_pass": False,
        "reward_gate_failed_reasons": [reason],
        "repair_reward_raw": 0.0,
        "repair_reward_components": [],
        "risk_penalty": 0.0,
        "risk_penalty_reasons": [],
        "risk_level": "none",
        "verifier_reward_score": 0.0,
        "reward_tier": tier,
        "needs_pairwise_check": False,
        "edit_stats": edit_stats,
    }

    return {
        "hard_filter_ok": False,
        "hard_filter_reason": reason,

        "deterministic_allow_candidate": False,
        "deterministic_score": 0.0,
        "deterministic_risk_ratio": 0.0,
        "deterministic_risk_items": [],

        "verified_better_than_initial": False,
        "soft_source_supported": False,
        "eligible_for_selection": False,
        "selection_tier": tier,

        "verifier": verifier,

        "reward_gate_pass": False,
        "reward_gate_failed_reasons": [reason],
        "repair_reward_raw": 0.0,
        "risk_penalty": 0.0,
        "verifier_reward_score": 0.0,
        "reward_tier": tier,
        "reward_risk_level": "none",
        "reward_components": [],
        "risk_penalty_reasons": [],
        "needs_pairwise_check": False,
        "reward_details": reward_details,
    }


def deterministic_evaluate_candidate(
    source_text: str,
    initial: str,
    candidate: str,
    ops: List[Dict],
    edited_spans: List[Dict],
) -> Dict:
    hard_ok, hard_reason = local_hard_filter_candidate(
        initial=initial,
        candidate=candidate,
        edited_spans=edited_spans,
    )

    touched, coverage_ratio, target_spans, changed_from = target_span_touched(
        ops=ops,
        edited_spans=edited_spans,
    )

    stats = edit_content_stats(edited_spans)

    empty_to_content_deletion = has_empty_to_content_deletion(edited_spans)
    non_empty_content_deletion = has_non_empty_content_deletion(edited_spans)
    content_deletion = empty_to_content_deletion or non_empty_content_deletion

    relation_repair = is_relation_repair(edited_spans)
    unsafe_relation_rewrite = has_unsafe_relation_rewrite(edited_spans)
    core_content_replacement = has_core_content_replacement(edited_spans)
    phrase_compression_repair = stats.get("phrase_compression_repair_count", 0) > 0

    pronoun_identity_shift = deterministic_pronoun_or_identity_shift(edited_spans)
    single_word_replacement = is_single_word_replacement(edited_spans)
    surface_rewrite = is_surface_rewrite(edited_spans)
    local_content_substitution = is_local_content_substitution(edited_spans)

    edit_count = stats["edit_count"]
    from_content_total = stats["from_content_total"]

    non_local_edit = False

    if edit_count > max(1, len(ops) + 1):
        non_local_edit = True

    if from_content_total > max(4, len(ops) * 3):
        non_local_edit = True

    length_delta_risk = abs(len(tokenize_words(candidate)) - len(tokenize_words(initial))) > max(2, len(ops) + 1)

    risk_items = [
        {"name": "target_span_not_touched", "triggered": not touched},
        {"name": "content_deletion", "triggered": content_deletion},
        {"name": "empty_to_content_deletion", "triggered": empty_to_content_deletion},
        {"name": "non_empty_content_deletion", "triggered": non_empty_content_deletion},
        {"name": "pronoun_or_identity_shift", "triggered": pronoun_identity_shift},
        {"name": "non_local_edit", "triggered": non_local_edit},
        {"name": "single_word_replacement_high_risk", "triggered": single_word_replacement},
        {"name": "surface_rewrite_high_risk", "triggered": surface_rewrite},
        {"name": "local_content_substitution_high_risk", "triggered": local_content_substitution},
        {"name": "core_content_replacement_high_risk", "triggered": core_content_replacement},
        {"name": "relation_repair", "triggered": relation_repair},
        {"name": "unsafe_relation_rewrite", "triggered": unsafe_relation_rewrite},
        {"name": "phrase_compression_repair", "triggered": phrase_compression_repair},
        {"name": "length_delta_risk", "triggered": length_delta_risk},
    ]

    risk_flags_for_score = [
        not touched,
        content_deletion,
        pronoun_identity_shift,
        non_local_edit,
        single_word_replacement,
        surface_rewrite,
        local_content_substitution,
        core_content_replacement,
        unsafe_relation_rewrite,
        length_delta_risk,
    ]

    risk_ratio = ratio_score(risk_flags_for_score)

    deterministic_allow = (
        hard_ok
        and touched
        and not content_deletion
        and not pronoun_identity_shift
        and not non_local_edit
        and not unsafe_relation_rewrite
        and not core_content_replacement
    )

    deterministic_score = coverage_ratio * (1.0 - risk_ratio)
    deterministic_score = max(0.0, min(1.0, deterministic_score))

    verifier = {
        "verifier_type": "deterministic_no_llm",
        "verifier_parse_ok": True,
        "source_support_checked_by_llm": False,
        "source_semantic_better_judged_by_llm": False,

        "target_spans": target_spans,
        "changed_from_spans": changed_from,
        "target_span_touched": touched,
        "target_span_coverage_ratio": round(coverage_ratio, 4),

        "deterministic_allow_candidate": deterministic_allow,
        "deterministic_score": round(deterministic_score, 4),
        "deterministic_risk_ratio": round(risk_ratio, 4),
        "deterministic_risk_items": risk_items,

        "content_deletion": content_deletion,
        "empty_to_content_deletion": empty_to_content_deletion,
        "non_empty_content_deletion": non_empty_content_deletion,
        "relation_repair": relation_repair,
        "unsafe_relation_rewrite": unsafe_relation_rewrite,
        "core_content_replacement": core_content_replacement,
        "phrase_compression_repair": phrase_compression_repair,
        "pronoun_or_identity_shift": pronoun_identity_shift,
        "single_word_replacement": single_word_replacement,
        "surface_rewrite": surface_rewrite,
        "local_content_substitution": local_content_substitution,
        "non_local_edit": non_local_edit,
        "length_delta_risk": length_delta_risk,
        "edit_stats": stats,

        "initial_phrase_problem": "not_judged_by_llm",
        "candidate_repair_type": (
            "phrase_compression_repair" if phrase_compression_repair
            else "relation_repair" if relation_repair
            else "core_content_replacement" if core_content_replacement
            else "unsafe_relation_rewrite" if unsafe_relation_rewrite
            else "not_judged_by_llm"
        ),

        "replacement_supported_by_source": deterministic_allow,
        "candidate_fixes_initial_problem": (
            touched
            and not content_deletion
            and not unsafe_relation_rewrite
            and not core_content_replacement
        ),

        "adds_unsupported_information": unsafe_relation_rewrite or core_content_replacement,
        "removes_source_information": content_deletion,
        "changes_core_meaning": pronoun_identity_shift or unsafe_relation_rewrite or core_content_replacement,
        "local_edit_only": not non_local_edit,
        "grammar_ok": hard_ok,

        "style_or_synonym_only": local_content_substitution or surface_rewrite,
        "exact_hindi_word_meaning_uncertain": core_content_replacement,
        "candidate_is_more_specific_than_source": core_content_replacement,
        "candidate_introduces_unrequested_rewrite": non_local_edit or unsafe_relation_rewrite or core_content_replacement,

        "safety_ok": deterministic_allow,
        "useful_repair_ok": False,
        "verified_better_than_initial": False,
        "soft_source_supported": False,
        "eligible_for_selection": False,
        "selection_tier": "deterministic_safe_candidate" if deterministic_allow else "rejected",

        "evidence": "",
        "reason_tag": "deterministic_safe_candidate" if deterministic_allow else "deterministic_rejected",
    }

    reward_details = {
        "reward_formula_version": CANDIDATE_FORMULA_VERSION,
        "reward_gate_pass": False,
        "reward_gate_failed_reasons": ["llm_verifier_removed"],
        "repair_reward_raw": 0.0,
        "repair_reward_components": [],
        "risk_penalty": round(risk_ratio, 4),
        "risk_penalty_reasons": risk_items,
        "risk_level": (
            "none" if risk_ratio == 0
            else "low" if risk_ratio < 1 / 3
            else "medium" if risk_ratio < 2 / 3
            else "high"
        ),
        "verifier_reward_score": 0.0,
        "reward_tier": "deterministic_no_reward",
        "needs_pairwise_check": (
            single_word_replacement
            or surface_rewrite
            or local_content_substitution
            or core_content_replacement
            or relation_repair
            or unsafe_relation_rewrite
            or risk_ratio > 0
        ),
        "edit_stats": stats,
    }

    return {
        "hard_filter_ok": hard_ok,
        "hard_filter_reason": hard_reason,

        "deterministic_allow_candidate": deterministic_allow,
        "deterministic_score": round(deterministic_score, 4),
        "deterministic_risk_ratio": round(risk_ratio, 4),
        "deterministic_risk_items": risk_items,

        "verified_better_than_initial": False,
        "soft_source_supported": False,
        "eligible_for_selection": False,
        "selection_tier": "deterministic_safe_candidate" if deterministic_allow else "rejected",

        "verifier": verifier,

        "reward_gate_pass": False,
        "reward_gate_failed_reasons": ["llm_verifier_removed"],
        "repair_reward_raw": 0.0,
        "risk_penalty": round(risk_ratio, 4),
        "verifier_reward_score": 0.0,
        "reward_tier": "deterministic_no_reward",
        "reward_risk_level": reward_details["risk_level"],
        "reward_components": [],
        "risk_penalty_reasons": risk_items,
        "needs_pairwise_check": reward_details["needs_pairwise_check"],
        "reward_details": reward_details,
    }


# =========================================================
# Candidate generation prompts
# =========================================================
def system_candidate_prompt() -> str:
    return """
You are a professional translation candidate generator.

Your task is to generate one conservative English candidate by locally repairing suspicious spans in the current English translation.

You are only a candidate generator, not a judge.

Strict rules:
1. The source sentence is the primary constraint.
2. The image is only secondary evidence for visual_refill spans.
3. Preserve all source-supported objects, actions, attributes, numbers, identities, and relations.
4. Do not add source-unsupported information.
5. Do not delete source information.
6. Keep every unrelated part of the current English translation unchanged.
7. Repair only the target suspicious span or its smallest grammatical local phrase.
8. If the current translation is already faithful for the listed span, return the original translation unchanged.
9. Do not produce style-only, synonym-only, or more formal alternatives.
10. Do not replace an object/category word with a broader or different object/category word.
11. Do not change an action verb or relation unless the source clearly requires that local correction.
12. Do not replace only one content word inside an otherwise unchanged phrase.
13. If a repair is necessary, rewrite the complete local phrase that contains the suspicious span, including necessary function words, pronouns, prepositions, or objects.
14. If the only possible change is a synonym, broader word, or uncertain source reading, return the original translation unchanged.
15. If the repair changes a relation or preposition, preserve all content words in that local phrase unless the source clearly does not support them.
16. Do not weaken a source-supported phrase by deleting modifiers, attributes, objects, or relation arguments.
17. Do not replace the core object/action with a different core object/action unless the source clearly requires it.
18. Candidate must be a complete grammatical English sentence.
19. Return JSON only. Do not output chain-of-thought.

Return exactly:
{
  "candidate": "...",
  "local_repairs": [
    {
      "span": "...",
      "old_phrase": "...",
      "new_phrase": "...",
      "repair_intent": "source_aligned_phrase_repair|relation_repair|grammar_role_repair|phrase_compression_repair|no_change"
    }
  ]
}

Requirements for local_repairs:
- old_phrase must be an exact phrase copied from the current English translation.
- new_phrase must be the replacement phrase inside the candidate.
- If no change is made, use an empty local_repairs list.
""".strip()


def user_candidate_prompt(
    source_text: str,
    initial: str,
    ops: List[Dict],
    role: str,
    avoid: str = "",
) -> str:
    avoid_part = ""
    if clean_text(avoid):
        avoid_part = f"""
Avoid returning this previous candidate exactly:
{avoid}
""".strip()

    return f"""
Candidate role:
{role}

Source sentence:
{source_text}

Current English translation:
{initial}

Target suspicious spans to repair:
{safe_json(compact_operands(ops))}

{avoid_part}

Instructions:
- Only repair the listed suspicious spans.
- Prefer complete local phrase repair, not isolated word replacement.
- The repaired phrase must include the suspicious span and its smallest grammatical context.
- Do not replace a concrete word with a broader, different, or more formal word.
- Do not change an action verb unless the source clearly requires it.
- Do not change an object noun unless the source clearly requires it.
- Do not delete source-supported content words inside a phrase.
- If repairing a relation or preposition, preserve all source-supported content words in that phrase.
- Do not introduce a new concrete object/category that is not explicitly required by the source.
- Do not produce style-only or synonym-only alternatives.
- If there is no clear source-faithfulness repair, return the current English translation unchanged.
- Candidate must be a complete fluent English sentence.
- Keep unrelated text unchanged.
- Return JSON only.
""".strip()


def gen_candidate_once(
    source_text: str,
    initial: str,
    image_path: str,
    ops: List[Dict],
    role: str,
    avoid: str = "",
) -> Tuple[str, Dict, str]:
    image = load_image(image_path) if has_visual_refill(ops) else None

    try:
        raw = run_qwen_json(
            system_candidate_prompt(),
            user_candidate_prompt(source_text, initial, ops, role, avoid),
            image,
            MAX_NEW_TOKENS_CANDIDATE,
        )

        obj = extract_json(raw)
        cand = norm_sent(obj.get("candidate", "")) if isinstance(obj, dict) else ""
        return cand, obj if isinstance(obj, dict) else {}, raw

    finally:
        if image is not None:
            image.close()
        cleanup_cuda()


# =========================================================
# Candidate item helpers
# =========================================================
def unchanged(initial: str, reason: str) -> Dict:
    return {
        "candidate": norm_sent(initial),
        "edit_label": "unchanged",
        "edited_spans": [],
        "reason": reason,
    }


def changed_item(initial: str, cand: str, reason: str, edited_spans: Optional[List[Dict]] = None) -> Dict:
    edits = edited_spans if edited_spans is not None else diff_edits(initial, cand)

    return {
        "candidate": norm_sent(cand),
        "edit_label": "wording_only" if edits else "unchanged",
        "edited_spans": edits,
        "reason": reason,
    }


def candidate_generation_risk_reason(initial: str, candidate: str, edits: List[Dict]) -> str:
    if has_bad_article_sequence(candidate):
        return "blocked_bad_article_sequence"

    if is_single_word_replacement(edits):
        return "blocked_single_word_replacement_no_phrase_repair"

    if is_local_content_substitution(edits):
        return "blocked_local_content_substitution_no_clear_phrase_repair"

    if has_non_empty_content_deletion(edits):
        return "blocked_non_empty_content_deletion_no_clear_phrase_repair"

    if has_core_content_replacement(edits):
        return "blocked_core_content_replacement_no_clear_source_support"

    if has_unsafe_relation_rewrite(edits):
        return "blocked_unsafe_relation_rewrite_no_core_preservation"

    return ""


def build_candidate(
    source_text: str,
    initial: str,
    image_path: str,
    ops: List[Dict],
    role: str,
    avoid: str = "",
) -> Dict:
    base = norm_sent(initial)

    if not ops:
        return unchanged(base, "no_non_keep_span")

    cand, obj, raw = gen_candidate_once(
        source_text,
        base,
        image_path,
        ops,
        role,
        avoid,
    )

    if not cand:
        return unchanged(base, "generation_failed_empty")

    if same(cand, base):
        return unchanged(base, "model_returned_unchanged")

    if avoid and same(cand, avoid):
        cand2, obj2, raw2 = gen_candidate_once(
            source_text,
            base,
            image_path,
            ops,
            role + "_alternative_source_faithful_phrase_level",
            avoid,
        )

        if cand2 and not same(cand2, base) and not same(cand2, avoid):
            cand, obj = cand2, obj2
        else:
            return unchanged(base, "duplicated_previous_or_unchanged")

    edits = make_candidate_edits(base, cand, obj)

    if not edits:
        return unchanged(base, "diff_no_actual_change")

    risk_reason = candidate_generation_risk_reason(base, cand, edits)

    if risk_reason:
        cand2, obj2, raw2 = gen_candidate_once(
            source_text=source_text,
            initial=base,
            image_path=image_path,
            ops=ops,
            role=role + "_strict_retry_preserve_core_content_phrase",
            avoid=cand,
        )

        if cand2 and not same(cand2, base) and not same(cand2, cand):
            edits2 = make_candidate_edits(base, cand2, obj2)
            risk_reason2 = candidate_generation_risk_reason(base, cand2, edits2)

            if edits2 and not risk_reason2:
                cand, obj, edits = cand2, obj2, edits2
            else:
                return unchanged(base, risk_reason)
        else:
            return unchanged(base, risk_reason)

    reason = (
        clean_text(obj.get("reason", "source-faithful phrase-level local candidate"))
        if isinstance(obj, dict)
        else "source-faithful phrase-level local candidate"
    )

    return changed_item(base, cand, reason, edited_spans=edits)


def dedup(c1: Dict, c2: Dict, c3: Dict, initial: str) -> Tuple[Dict, Dict, Dict]:
    base = norm_sent(initial)
    seen = set()
    out = []

    for idx, item in enumerate([c1, c2, c3], 1):
        cand = norm_sent(item.get("candidate", ""))

        if not cand:
            item = unchanged(base, f"empty_candidate_{idx}_fallback")
            cand = base

        nc = norm(cand)

        if nc in seen and nc != norm(base):
            item = unchanged(base, f"candidate_{idx}_duplicated_previous_candidate")
            nc = norm(base)

        seen.add(nc)
        out.append(item)

    return out[0], out[1], out[2]


def add_verification_fields(
    rec: Dict,
    idx: int,
    verify_result: Dict,
):
    prefix = f"candidate_{idx}"

    rec[f"{prefix}_hard_filter_ok"] = verify_result.get("hard_filter_ok", False)
    rec[f"{prefix}_hard_filter_reason"] = verify_result.get("hard_filter_reason", "")

    rec[f"{prefix}_deterministic_allow_candidate"] = verify_result.get(
        "deterministic_allow_candidate",
        False,
    )
    rec[f"{prefix}_deterministic_score"] = verify_result.get(
        "deterministic_score",
        0.0,
    )
    rec[f"{prefix}_deterministic_risk_ratio"] = verify_result.get(
        "deterministic_risk_ratio",
        0.0,
    )
    rec[f"{prefix}_deterministic_risk_items"] = verify_result.get(
        "deterministic_risk_items",
        [],
    )

    rec[f"{prefix}_verified_better_than_initial"] = verify_result.get(
        "verified_better_than_initial",
        False,
    )
    rec[f"{prefix}_soft_source_supported"] = verify_result.get(
        "soft_source_supported",
        False,
    )
    rec[f"{prefix}_eligible_for_selection"] = verify_result.get(
        "eligible_for_selection",
        False,
    )
    rec[f"{prefix}_selection_tier"] = verify_result.get(
        "selection_tier",
        "rejected",
    )
    rec[f"{prefix}_verifier"] = verify_result.get("verifier", {})

    rec[f"{prefix}_reward_gate_pass"] = verify_result.get(
        "reward_gate_pass",
        False,
    )
    rec[f"{prefix}_reward_gate_failed_reasons"] = verify_result.get(
        "reward_gate_failed_reasons",
        [],
    )
    rec[f"{prefix}_repair_reward_raw"] = verify_result.get(
        "repair_reward_raw",
        0.0,
    )
    rec[f"{prefix}_risk_penalty"] = verify_result.get(
        "risk_penalty",
        0.0,
    )
    rec[f"{prefix}_verifier_reward_score"] = verify_result.get(
        "verifier_reward_score",
        0.0,
    )
    rec[f"{prefix}_reward_tier"] = verify_result.get(
        "reward_tier",
        "rejected",
    )
    rec[f"{prefix}_reward_risk_level"] = verify_result.get(
        "reward_risk_level",
        "none",
    )
    rec[f"{prefix}_reward_components"] = verify_result.get(
        "reward_components",
        [],
    )
    rec[f"{prefix}_risk_penalty_reasons"] = verify_result.get(
        "risk_penalty_reasons",
        [],
    )
    rec[f"{prefix}_needs_pairwise_check"] = verify_result.get(
        "needs_pairwise_check",
        False,
    )
    rec[f"{prefix}_reward_details"] = verify_result.get(
        "reward_details",
        {},
    )


def add_error_verification_fields(
    rec: Dict,
    idx: int,
    hard_reason: str = "error_fallback",
):
    verify_result = make_static_verification(
        reason=hard_reason,
        tier="error_fallback",
    )

    add_verification_fields(rec, idx, verify_result)


def write_record(path: str, rec: Dict):
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")


# =========================================================
# Main
# =========================================================
def main():
    rows = []

    with open(INPUT_JSONL, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))

    total_all = len(rows)

    if MAX_ROWS is not None:
        rows = rows[:MAX_ROWS]

    # 参考译文映射只用于最终输出字段，不参与任何中间过程。
    ref_map_for_output_only = build_reference_map(REFERENCE_JSONL)

    os.makedirs(os.path.dirname(OUTPUT_JSONL), exist_ok=True)

    with open(OUTPUT_JSONL, "w", encoding="utf-8"):
        pass

    print(f"[INFO] Total loaded rows: {total_all}")
    print(f"[INFO] Actual run rows: {len(rows)}")
    print(f"[INFO] REFERENCE_JSONL only used for output field: {REFERENCE_JSONL}")
    print("[INFO] candidate_1 = first non-keep span source-faithful phrase repair")
    print("[INFO] candidate_2 = joint source-faithful phrase repair")
    print("[INFO] candidate_3 = initial translation fallback")
    print("[INFO] LLM verifier removed")
    print("[INFO] LLM guard removed")
    print("[INFO] Model only generates candidates")
    print("[INFO] Source-faithful phrase-level repair mode enabled")
    print("[INFO] delete edit_type is converted to paraphrase in detect adapter")
    print("[INFO] Local content substitution retry/block enabled")
    print("[INFO] Core content replacement retry/block enabled")
    print("[INFO] Non-empty content deletion retry/block enabled")
    print("[INFO] Relation repair detection with core preservation enabled")
    print("[INFO] Reflexive pronoun allowance enabled")
    print("[INFO] Bad article sequence hard filter enabled")
    print("[INFO] Deterministic candidate filtering enabled")
    print("[INFO] Stats fix enabled:")
    print("       unchanged candidates are not counted as rejected/risk")
    print("       candidate_3 is marked as initial_fallback")
    print("       risk stats are counted only for changed candidates")

    stats = {
        "total": 0,
        "candidate_slots_total": 0,

        "changed_candidate_rows": 0,
        "candidate_changed_total": 0,
        "unchanged_candidate_total": 0,
        "initial_fallback_candidates": 0,

        "deterministic_allowed_candidates": 0,
        "deterministic_rejected_candidates": 0,
        "changed_allowed_candidate_count": 0,
        "changed_rejected_candidate_count": 0,

        "target_span_not_touched_candidates": 0,
        "content_deletion_candidates": 0,
        "empty_to_content_deletion_candidates": 0,
        "non_empty_content_deletion_candidates": 0,
        "pronoun_identity_shift_candidates": 0,
        "non_local_edit_candidates": 0,
        "single_word_replacement_candidates": 0,
        "surface_rewrite_candidates": 0,
        "local_content_substitution_candidates": 0,
        "core_content_replacement_candidates": 0,
        "relation_repair_candidates": 0,
        "unsafe_relation_rewrite_candidates": 0,
        "phrase_compression_repair_candidates": 0,
        "length_delta_risk_candidates": 0,
    }

    times = []

    for i, row in enumerate(rows, 1):
        t0 = time.time()

        sid = clean_text(row.get("id", row.get("image_id", "")))
        image_path = clean_text(row.get("image_path", ""))
        source_text = clean_text(row.get("source_text", ""))
        initial = clean_text(row.get("initial_translation", row.get("initial_translation_en", "")))
        base = norm_sent(initial)

        stats["total"] += 1

        try:
            ops = collect_non_keep(row)

            if not ops:
                c1 = unchanged(base, "no_non_keep_span")
                c2 = unchanged(base, "no_non_keep_span")
            else:
                c1 = build_candidate(
                    source_text=source_text,
                    initial=base,
                    image_path=image_path,
                    ops=ops[:1],
                    role="candidate_1_single_span_source_faithful_phrase_repair",
                )

                c2 = build_candidate(
                    source_text=source_text,
                    initial=base,
                    image_path=image_path,
                    ops=ops,
                    role="candidate_2_joint_source_faithful_phrase_repair",
                    avoid=c1.get("candidate", ""),
                )

            c3 = unchanged(base, "safe unchanged fallback")

            c1, c2, c3 = dedup(c1, c2, c3, base)

            candidate_items = [c1, c2, c3]
            candidate_ops = [ops[:1], ops, []]

            verify_results = []

            for cand_idx, (cand_item, cand_ops) in enumerate(zip(candidate_items, candidate_ops), start=1):
                stats["candidate_slots_total"] += 1

                cand_text = cand_item.get("candidate", base)
                is_changed = not same(cand_text, base)

                if cand_idx == 3:
                    stats["initial_fallback_candidates"] += 1
                    stats["unchanged_candidate_total"] += 1

                    verify_results.append(
                        make_static_verification(
                            reason="initial_fallback",
                            tier="initial_fallback",
                        )
                    )
                    continue

                if not is_changed:
                    stats["unchanged_candidate_total"] += 1

                    verify_results.append(
                        make_static_verification(
                            reason=cand_item.get("reason", "unchanged_candidate"),
                            tier="unchanged_candidate",
                        )
                    )
                    continue

                stats["candidate_changed_total"] += 1

                verify_result = deterministic_evaluate_candidate(
                    source_text=source_text,
                    initial=base,
                    candidate=cand_text,
                    ops=cand_ops,
                    edited_spans=cand_item.get("edited_spans", []),
                )

                verify_results.append(verify_result)

                if verify_result.get("deterministic_allow_candidate", False):
                    stats["deterministic_allowed_candidates"] += 1
                    stats["changed_allowed_candidate_count"] += 1
                else:
                    stats["deterministic_rejected_candidates"] += 1
                    stats["changed_rejected_candidate_count"] += 1

                for item in verify_result.get("deterministic_risk_items", []):
                    if not isinstance(item, dict):
                        continue

                    if not item.get("triggered", False):
                        continue

                    name = clean_text(item.get("name", ""))

                    if name == "target_span_not_touched":
                        stats["target_span_not_touched_candidates"] += 1
                    elif name == "content_deletion":
                        stats["content_deletion_candidates"] += 1
                    elif name == "empty_to_content_deletion":
                        stats["empty_to_content_deletion_candidates"] += 1
                    elif name == "non_empty_content_deletion":
                        stats["non_empty_content_deletion_candidates"] += 1
                    elif name == "pronoun_or_identity_shift":
                        stats["pronoun_identity_shift_candidates"] += 1
                    elif name == "non_local_edit":
                        stats["non_local_edit_candidates"] += 1
                    elif name == "single_word_replacement_high_risk":
                        stats["single_word_replacement_candidates"] += 1
                    elif name == "surface_rewrite_high_risk":
                        stats["surface_rewrite_candidates"] += 1
                    elif name == "local_content_substitution_high_risk":
                        stats["local_content_substitution_candidates"] += 1
                    elif name == "core_content_replacement_high_risk":
                        stats["core_content_replacement_candidates"] += 1
                    elif name == "relation_repair":
                        stats["relation_repair_candidates"] += 1
                    elif name == "unsafe_relation_rewrite":
                        stats["unsafe_relation_rewrite_candidates"] += 1
                    elif name == "phrase_compression_repair":
                        stats["phrase_compression_repair_candidates"] += 1
                    elif name == "length_delta_risk":
                        stats["length_delta_risk_candidates"] += 1

            changed_count = sum(
                not same(x.get("candidate", ""), base)
                for x in candidate_items
            )

            if changed_count > 0:
                stats["changed_candidate_rows"] += 1

            v1, v2, v3 = verify_results

            allowed_count = sum(
                bool(v.get("deterministic_allow_candidate", False))
                for v in verify_results
            )

            # 参考译文只在这里取出，用于最终输出字段。
            reference_translation_for_output = get_reference_translation_for_output_only(
                row,
                ref_map_for_output_only
            )

            rec = {
                "id": sid,
                "image_path": image_path,
                "source_text": source_text,
                "reference_translation": reference_translation_for_output,
                "initial_translation": initial,

                "candidate_1": c1.get("candidate", base),
                "candidate_2": c2.get("candidate", base),
                "candidate_3": c3.get("candidate", base),

                "edit_label_1": c1.get("edit_label", "unchanged"),
                "edit_label_2": c2.get("edit_label", "unchanged"),
                "edit_label_3": c3.get("edit_label", "unchanged"),

                "edited_spans_1": c1.get("edited_spans", []),
                "edited_spans_2": c2.get("edited_spans", []),
                "edited_spans_3": c3.get("edited_spans", []),

                "candidate_formula_version": CANDIDATE_FORMULA_VERSION,
                "llm_verifier_removed": True,
                "llm_guard_removed": True,
                "source_faithful_phrase_level_repair_mode": True,
                "delete_converted_to_paraphrase": True,
                "single_word_replacement_retry_block": True,
                "local_content_substitution_retry_block": True,
                "core_content_replacement_retry_block": True,
                "non_empty_content_deletion_retry_block": True,
                "relation_repair_detection": True,
                "relation_repair_core_preservation": True,
                "unsafe_relation_rewrite_filter": True,
                "reflexive_pronoun_allowance": True,
                "bad_article_sequence_filter": True,
                "stats_fix_unchanged_not_counted_as_rejected": True,
                "reference_translation_used_only_as_output_field": True,
            }

            add_verification_fields(rec, 1, v1)
            add_verification_fields(rec, 2, v2)
            add_verification_fields(rec, 3, v3)

            write_record(OUTPUT_JSONL, rec)

            dt = time.time() - t0
            times.append(dt)
            avg = sum(times) / len(times)
            eta = avg * (len(rows) - i)

            print(
                f"[{i}/{len(rows)}] id={sid} | {dt:.2f}s | "
                f"avg={avg:.2f}s | ETA={format_time(eta)} | "
                f"non_keep={len(ops)} | changed={changed_count} | "
                f"det_allowed={allowed_count}"
            )

        except Exception as e:
            reference_translation_for_output = get_reference_translation_for_output_only(
                row,
                ref_map_for_output_only
            )

            rec = {
                "id": sid,
                "image_path": image_path,
                "source_text": source_text,
                "reference_translation": reference_translation_for_output,
                "initial_translation": initial,

                "candidate_1": base,
                "candidate_2": base,
                "candidate_3": base,

                "edit_label_1": "unchanged",
                "edit_label_2": "unchanged",
                "edit_label_3": "unchanged",

                "edited_spans_1": [],
                "edited_spans_2": [],
                "edited_spans_3": [],

                "candidate_formula_version": CANDIDATE_FORMULA_VERSION,
                "llm_verifier_removed": True,
                "llm_guard_removed": True,
                "source_faithful_phrase_level_repair_mode": True,
                "delete_converted_to_paraphrase": True,
                "single_word_replacement_retry_block": True,
                "local_content_substitution_retry_block": True,
                "core_content_replacement_retry_block": True,
                "non_empty_content_deletion_retry_block": True,
                "relation_repair_detection": True,
                "relation_repair_core_preservation": True,
                "unsafe_relation_rewrite_filter": True,
                "reflexive_pronoun_allowance": True,
                "bad_article_sequence_filter": True,
                "stats_fix_unchanged_not_counted_as_rejected": True,
                "reference_translation_used_only_as_output_field": True,

                "error": repr(e),
            }

            add_error_verification_fields(rec, 1, "error_fallback")
            add_error_verification_fields(rec, 2, "error_fallback")
            add_error_verification_fields(rec, 3, "initial_fallback")

            write_record(OUTPUT_JSONL, rec)
            print(f"[WARN] id={sid} failed: {repr(e)}")
            cleanup_cuda()

    print(f"[DONE] Saved to: {OUTPUT_JSONL}")
    print("[stats]", stats)


if __name__ == "__main__":
    main()