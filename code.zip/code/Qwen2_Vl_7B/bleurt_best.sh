#!/bin/bash
set -e

source /home/guozhengyi/anaconda3/envs/bleurt/bin/activate
cd /home/chenyi/offline_blaser_qe/code/Qwen2_Vl_7B



python bleurt_direct_text.py --data vg --lang bn --gpu 4 
python bleurt_direct_text.py --data vg --lang ha --gpu 4 
python bleurt_direct_text.py --data vg --lang hi --gpu 4 
python bleurt_direct_text.py --data vg --lang ma --gpu 4 
    


python bleurt_direct_text.py --data multi30k --lang lv --gpu 4 
python bleurt_direct_text.py --data multi30k --lang tr --gpu 4 
python bleurt_direct_text.py --data multi30k --lang hi --gpu 4 

echo "All  finished."