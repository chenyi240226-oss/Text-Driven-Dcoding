#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
text_only_and_image_prior_qwen2vl_en2xx.py

目标：
1. 使用 Qwen2-VL-7B-Instruct 模型。
2. 支持 VG / Multi30K 两套数据。
3. 翻译方向：
   English -> 指定语言

4. 由命令行输入：
   --data vg 或 --data multi30k
   --lang
   --gpu

5. 仅生成两个文件：
   A. Text-only condition:
      English source visible, no image

   B. Image-prior only condition:
      与 TD2 中完全相同的 image-prior condition：
      source hidden, image visible
      即：build_initial_style_user_text("[SOURCE SENTENCE HIDDEN]")

6. 不使用额外解码方式：
   - 不使用 contrastive decoding
   - 不手动 logits 解码
   - 不设置 do_sample
   - 不设置 beam search
   - 不设置 top_p / top_k / temperature
   - 不设置 repetition_penalty
   - 只调用模型原生 model.generate()

7. 两个输出文件均只保留后续评分需要的字段：
   id
   source_text
   reference_translation
   initial_translation

输出路径：
   /home/chenyi/offline_blaser_qe/out/Qwen2_VL_7B/{DATA}/{lang}/en_{lang}_text_only_translation.jsonl

   /home/chenyi/offline_blaser_qe/out/Qwen2_VL_7B/{DATA}/{lang}/en_{lang}_image_prior_only_translation.jsonl

VG 输入：
   /home/chenyi/offline_blaser_qe/dataSet/VG/{lang}/{lang}_vg_test.jsonl

VG 字段：
   src_en -> 待翻译源句，参与生成
   tgt    -> 参考译文，只写入 reference_translation，不参与生成
   image_id -> 用于在 /home/chenyi/offline_blaser_qe/dataSet/VG/images 下找图片

Multi30K 输入：
   /mnt/raid/cycy/data/txt_multi30k/en_{lang}_test.jsonl

Multi30K 字段：
   source -> 待翻译源句，参与生成
   target -> 参考译文，只写入 reference_translation，不参与生成
   image / image_path / image_id -> 图片路径解析
"""

import os
import argparse

# =====================================================
# 0. 命令行参数：必须在 import torch 前解析并设置 GPU
# =====================================================

VG_LANGUAGES = {"hi", "ha", "bn", "ma"}
MULTI30K_LANGUAGES = {"hi", "lv", "tr"}
ALL_LANGUAGES = VG_LANGUAGES | MULTI30K_LANGUAGES

TARGET_LANGUAGE_NAME_MAP = {
    "hi": "Hindi",
    "ha": "Hausa",
    "bn": "Bengali",
    "ma": "Malayalam",
    "lv": "Latvian",
    "tr": "Turkish",
}

DATA_DIR_NAME = {
    "vg": "VG",
    "multi30k": "Multi30k",
}


def parse_args():
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--data",
        type=str,
        required=True,
        choices=["vg", "multi30k"],
        help="Dataset name: vg or multi30k.",
    )

    parser.add_argument(
        "--lang",
        type=str,
        required=True,
        choices=sorted(ALL_LANGUAGES),
        help="Language code. VG: bn, ha, hi, ma. Multi30K: hi, lv, tr.",
    )

    parser.add_argument(
        "--gpu",
        type=str,
        required=True,
        help="Physical GPU id, for example: 0, 1, 2, 5, 6, 7.",
    )

    parser.add_argument(
        "--max_new_tokens",
        type=int,
        default=64,
        help="Maximum generated target-language tokens.",
    )

    parser.add_argument(
        "--max_samples",
        type=int,
        default=None,
        help="None means full dataset. Example: --max_samples 100.",
    )

    return parser.parse_args()


ARGS = parse_args()

DATASET = ARGS.data.strip().lower()
LANGUAGE = ARGS.lang.strip().lower()
GPU = str(ARGS.gpu).strip()
MAX_NEW_TOKENS = int(ARGS.max_new_tokens)
MAX_SAMPLES = ARGS.max_samples

if DATASET == "vg" and LANGUAGE not in VG_LANGUAGES:
    raise ValueError(
        f"--data vg only supports languages: {sorted(VG_LANGUAGES)}, "
        f"but got --lang {LANGUAGE}"
    )

if DATASET == "multi30k" and LANGUAGE not in MULTI30K_LANGUAGES:
    raise ValueError(
        f"--data multi30k only supports languages: {sorted(MULTI30K_LANGUAGES)}, "
        f"but got --lang {LANGUAGE}"
    )

DATA_OUTPUT_NAME = DATA_DIR_NAME[DATASET]
SOURCE_LANG_NAME = "English"
TARGET_LANG_NAME = TARGET_LANGUAGE_NAME_MAP[LANGUAGE]

# ====== 环境变量必须在 import torch 前设置 ======
os.environ["CUDA_VISIBLE_DEVICES"] = GPU
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"

os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"
os.environ["TOKENIZERS_PARALLELISM"] = "false"

os.environ["HF_HOME"] = "/home/chenyi/model_cache/huggingface"
os.environ["TRANSFORMERS_CACHE"] = "/home/chenyi/model_cache/huggingface/hub"

SYSLIBS_DIR = "/home/chenyi/offline_blaser_qe/syslibs"
os.environ["LD_LIBRARY_PATH"] = SYSLIBS_DIR + ":" + os.environ.get("LD_LIBRARY_PATH", "")

import re
import json
import time
import warnings
from typing import Dict, Any, List, Optional, Tuple

from PIL import Image

import torch
from transformers import AutoProcessor

try:
    from transformers import Qwen2VLForConditionalGeneration
except Exception:
    Qwen2VLForConditionalGeneration = None


# =====================================================
# Torch compatibility patch
# =====================================================

if not hasattr(torch, "compiler"):
    class _DummyCompiler:
        @staticmethod
        def is_compiling():
            return False

    torch.compiler = _DummyCompiler()
else:
    if not hasattr(torch.compiler, "is_compiling"):
        torch.compiler.is_compiling = lambda: False


warnings.filterwarnings("ignore", category=UserWarning)
torch.set_grad_enabled(False)


# =====================================================
# 1. 固定配置
# =====================================================

MODEL_PATH = "/mnt/raid/hss/model/Qwen2-VL-7B-Instruct"

VG_INPUT_ROOT = "/home/chenyi/offline_blaser_qe/dataSet/VG"
VG_IMAGE_DIR = "/home/chenyi/offline_blaser_qe/dataSet/VG/images"

MULTI30K_INPUT_ROOT = "/mnt/raid/cycy/data/txt_multi30k"
MULTI30K_IMAGE_DIR = "/mnt/raid/wjx/vision-rag-mt/images_multi30k"

OUTPUT_ROOT_BASE = "/home/chenyi/offline_blaser_qe/out/Qwen2_VL_7B"

DTYPE_NAME = "bfloat16"
SEED = 42

# =====================================================
# 字段配置：English -> target language
# =====================================================

IMAGE_ID_FIELD = "image_id"

# VG:
# src_en -> 待翻译源句
# tgt    -> 参考译文
VG_SOURCE_FIELD = "src_en"
VG_REFERENCE_FIELD = "tgt"

# Multi30K:
# source -> 待翻译源句
# target -> 参考译文
MULTI30K_SOURCE_FIELDS = ["source", "reference_translation"]
MULTI30K_REFERENCE_FIELDS = ["target", "source_text"]

STANDARD_SOURCE_FIELD = "source_text"
STANDARD_REFERENCE_FIELD = "reference_translation"
HYPOTHESIS_FIELD = "initial_translation"


# =====================================================
# 2. Prompt：与 TD2 条件保持一致
# =====================================================

SYSTEM_PROMPT_TEMPLATE = (
    "/no_think\n"
    "You are a professional translator.\n"
    "Your job is to translate the given {source_lang_name} source sentence into {target_lang_name}.\n"
    "STRICT RULES:\n"
    "1) Faithful: Do NOT add, remove, or change objects, attributes, actions, or relations.\n"
    "2) Use the image only when it helps resolve ambiguity.\n"
    "3) Do not turn the task into image captioning.\n"
    "4) Output ONLY the translation in {target_lang_name}. No explanations.\n"
    "5) NEVER output any <think>...</think> content.\n"
)


def build_initial_style_system_prompt() -> str:
    return SYSTEM_PROMPT_TEMPLATE.format(
        source_lang_name=SOURCE_LANG_NAME,
        target_lang_name=TARGET_LANG_NAME,
    )


def build_initial_style_user_text(src: str) -> str:
    return (
        f"{SOURCE_LANG_NAME} SOURCE:\n"
        f"{src}\n\n"
        f"Translate into {TARGET_LANG_NAME}."
    )


def build_messages_initial_style_text_only(src: str):
    system_prompt = build_initial_style_system_prompt()
    user_text = build_initial_style_user_text(src)

    messages = [
        {
            "role": "system",
            "content": system_prompt,
        },
        {
            "role": "user",
            "content": [
                {"type": "text", "text": user_text},
            ],
        },
    ]

    return messages


def build_messages_initial_style_image_only(image: Image.Image):
    """
    TD2 中完全相同的 image-prior condition：

    - system_prompt 与 full / text-only 完全一致；
    - user_text 仍然是翻译任务格式；
    - 只把真实 source 替换为 [SOURCE SENTENCE HIDDEN]；
    - image 可见。
    """

    system_prompt = build_initial_style_system_prompt()
    user_text = build_initial_style_user_text("[SOURCE SENTENCE HIDDEN]")

    messages = [
        {
            "role": "system",
            "content": system_prompt,
        },
        {
            "role": "user",
            "content": [
                {"type": "image"},
                {"type": "text", "text": user_text},
            ],
        },
    ]

    return messages


# =====================================================
# 3. 路径与基础工具
# =====================================================

def get_input_jsonl(data: str, lang: str) -> str:
    if data == "vg":
        return os.path.join(
            VG_INPUT_ROOT,
            lang,
            f"{lang}_vg_test.jsonl",
        )

    if data == "multi30k":
        return os.path.join(
            MULTI30K_INPUT_ROOT,
            f"en_{lang}_test.jsonl",
        )

    raise ValueError(f"Unsupported data: {data}")


def get_output_paths(data: str, lang: str) -> Tuple[str, str]:
    output_dir = os.path.join(
        OUTPUT_ROOT_BASE,
        DATA_DIR_NAME[data],
        lang,
    )

    text_only_output = os.path.join(
        output_dir,
        f"en_{lang}_text_only_translation.jsonl",
    )

    image_prior_output = os.path.join(
        output_dir,
        f"en_{lang}_image_prior_only_translation.jsonl",
    )

    return text_only_output, image_prior_output


def get_image_dir() -> str:
    if DATASET == "vg":
        return VG_IMAGE_DIR

    if DATASET == "multi30k":
        return MULTI30K_IMAGE_DIR

    raise ValueError(f"Unsupported DATASET: {DATASET}")


def get_torch_dtype(name: str):
    if not torch.cuda.is_available():
        return torch.float32

    if name == "float16":
        return torch.float16

    if name == "bfloat16":
        return torch.bfloat16

    return torch.float32


def ensure_dir(path: str):
    d = os.path.dirname(os.path.abspath(path))
    if d:
        os.makedirs(d, exist_ok=True)


def init_jsonl(path: str):
    ensure_dir(path)
    with open(path, "w", encoding="utf-8"):
        pass


def append_jsonl(path: str, row: Dict[str, Any]):
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(row, ensure_ascii=False) + "\n")


def read_jsonl(
    path: str,
    max_samples: Optional[int] = None,
) -> List[Dict[str, Any]]:
    rows = []

    with open(path, "r", encoding="utf-8") as f:
        for line_idx, line in enumerate(f, start=1):
            line = line.strip()

            if not line:
                continue

            try:
                rows.append(json.loads(line))
            except Exception as e:
                print(f"[WARN] JSON parse failed at line {line_idx}: {e}", flush=True)
                continue

            if max_samples is not None and len(rows) >= max_samples:
                break

    return rows


def normalize_text(x: Any) -> str:
    if x is None:
        return ""
    return str(x).strip()


def first_non_empty_with_field(
    row: Dict[str, Any],
    fields: List[str],
) -> Tuple[str, str]:
    for field in fields:
        value = normalize_text(row.get(field, ""))
        if value:
            return value, field

    return "", ""


def get_row_id(row: Dict[str, Any], fallback_idx: int) -> str:
    if DATASET == "vg":
        if IMAGE_ID_FIELD in row and row[IMAGE_ID_FIELD] is not None:
            return str(row[IMAGE_ID_FIELD])

        for k in ["id", "qid", "question_id", "sample_index"]:
            if k in row and row[k] is not None:
                return str(row[k])

        return str(fallback_idx)

    if DATASET == "multi30k":
        for k in ["id", "image_id", "qid", "question_id"]:
            if k in row and row[k] is not None:
                return str(row[k])

        image_path = normalize_text(row.get("image", row.get("image_path", "")))
        if image_path:
            base = os.path.basename(image_path)
            stem = os.path.splitext(base)[0]
            if stem:
                return stem

        return str(fallback_idx)

    return str(fallback_idx)


def format_seconds(sec: float) -> str:
    sec = max(0, int(sec))
    h = sec // 3600
    m = (sec % 3600) // 60
    s = sec % 60
    return f"{h:02d}:{m:02d}:{s:02d}"


def cleanup_cuda():
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        try:
            torch.cuda.ipc_collect()
        except Exception:
            pass


# =====================================================
# 4. 输出清洗
# =====================================================

def strip_think_blocks(text: str) -> str:
    if not text:
        return text

    text = re.sub(
        r"<think>.*?</think>",
        "",
        text,
        flags=re.DOTALL | re.IGNORECASE,
    )

    text = re.sub(
        r"</?think>",
        "",
        text,
        flags=re.IGNORECASE,
    )

    return text.strip()


def clean_generation_text(text: str) -> str:
    text = str(text).strip()

    text = re.sub(
        r"^\s*(translation\s*[:：-]\s*)",
        "",
        text,
        flags=re.I,
    )

    text = re.sub(r"\s+", " ", text).strip()

    return text


def clean_translation_output(text: str) -> str:
    text = str(text).strip()
    text = strip_think_blocks(text)
    text = clean_generation_text(text)

    bad_prefixes = [
        "Translation:",
        "The translation is:",
        "Output:",
        "Answer:",
        "Final translation:",
        "Final answer:",
    ]

    for p in bad_prefixes:
        if text.lower().startswith(p.lower()):
            text = text[len(p):].strip()

    lines = [x.strip() for x in text.splitlines() if x.strip()]
    if lines:
        text = lines[0]

    text = text.strip().strip('"').strip("'").strip()
    text = re.sub(r"\s+", " ", text).strip()

    return text


def is_effectively_empty_output(text: str) -> bool:
    if text is None:
        return True

    text = str(text).strip()

    if not text:
        return True

    if re.fullmatch(r"[\s\.\,\!\?\:\;\"\'\-\(\)\[\]\{\}]+", text):
        return True

    lower = text.lower()

    bad_patterns = [
        "i can't",
        "i cannot",
        "cannot determine",
        "cannot translate",
        "unable to",
        "no translation",
        "no output",
        "sorry",
    ]

    if any(p in lower for p in bad_patterns):
        return True

    return False


def clean_or_empty(text: str) -> str:
    text = clean_translation_output(text)

    if is_effectively_empty_output(text):
        return ""

    return text


# =====================================================
# 5. 数据字段与图片路径解析
# =====================================================

def get_source_and_reference(row: Dict[str, Any]) -> Tuple[str, str]:
    if DATASET == "vg":
        source_text = normalize_text(row.get(VG_SOURCE_FIELD, ""))
        reference_translation = normalize_text(row.get(VG_REFERENCE_FIELD, ""))
        return source_text, reference_translation

    if DATASET == "multi30k":
        source_text, _ = first_non_empty_with_field(
            row,
            MULTI30K_SOURCE_FIELDS,
        )

        reference_translation, _ = first_non_empty_with_field(
            row,
            MULTI30K_REFERENCE_FIELDS,
        )

        return source_text, reference_translation

    raise ValueError(f"Unsupported DATASET: {DATASET}")


def resolve_image_path(row: Dict[str, Any]) -> Optional[str]:
    if DATASET == "vg":
        image_id = row.get(IMAGE_ID_FIELD, None)

        if image_id is None:
            return None

        image_id = str(image_id).strip()

        if not image_id:
            return None

        if os.path.isfile(image_id):
            return image_id

        for ext in [".jpg", ".jpeg", ".png", ".webp", ".JPG", ".JPEG", ".PNG"]:
            p = os.path.join(VG_IMAGE_DIR, image_id + ext)
            if os.path.isfile(p):
                return p

        return None

    if DATASET == "multi30k":
        candidate_paths = []

        for key in ["image", "image_path", "img_path"]:
            p = normalize_text(row.get(key, ""))

            if not p:
                continue

            candidate_paths.append(p)
            candidate_paths.append(os.path.join(MULTI30K_IMAGE_DIR, p))
            candidate_paths.append(os.path.join(MULTI30K_IMAGE_DIR, os.path.basename(p)))

        for p in candidate_paths:
            if p and os.path.isfile(p):
                return p

        image_id = row.get("image_id", row.get("id", None))

        if image_id is None:
            return None

        image_id = str(image_id).strip()

        if not image_id:
            return None

        direct_path = os.path.join(MULTI30K_IMAGE_DIR, image_id)
        if os.path.isfile(direct_path):
            return direct_path

        for ext in [".jpg", ".jpeg", ".png", ".webp", ".JPG", ".JPEG", ".PNG"]:
            p = os.path.join(MULTI30K_IMAGE_DIR, image_id + ext)
            if os.path.isfile(p):
                return p

        return None

    raise ValueError(f"Unsupported DATASET: {DATASET}")


def load_rgb_image(path: str) -> Image.Image:
    return Image.open(path).convert("RGB")


# =====================================================
# 6. Qwen2-VL 输入与原生 generate
# =====================================================

def get_model_device(model) -> torch.device:
    try:
        return model.device
    except Exception:
        return next(model.parameters()).device


def move_inputs_to_model_device_no_dtype_cast(
    inputs: Dict[str, Any],
    model,
) -> Dict[str, Any]:
    device = get_model_device(model)

    moved = {}

    for k, v in inputs.items():
        if hasattr(v, "to"):
            moved[k] = v.to(device)
        else:
            moved[k] = v

    return moved


def generate_with_original_model_decoding(
    model,
    processor,
    messages,
    image: Optional[Image.Image],
    max_new_tokens: int,
) -> str:
    """
    只调用模型原生 model.generate()。

    不传入：
    - do_sample
    - num_beams
    - top_p
    - top_k
    - temperature
    - repetition_penalty
    - logits_processor
    - 自定义 logits
    - 手动 argmax

    max_new_tokens 只是长度上限，不改变解码策略。
    """

    text = processor.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True,
    )

    if image is not None:
        inputs = processor(
            text=[text],
            images=[image],
            padding=True,
            return_tensors="pt",
        )
    else:
        inputs = processor(
            text=[text],
            padding=True,
            return_tensors="pt",
        )

    prepared_inputs = move_inputs_to_model_device_no_dtype_cast(
        inputs=inputs,
        model=model,
    )

    with torch.inference_mode():
        out = model.generate(
            **prepared_inputs,
            max_new_tokens=max_new_tokens,
        )

    prompt_len = prepared_inputs["input_ids"].shape[1]
    gen_ids = out[:, prompt_len:]

    result = processor.batch_decode(
        gen_ids,
        skip_special_tokens=True,
        clean_up_tokenization_spaces=True,
    )[0]

    result = clean_or_empty(result)

    return result


def generate_text_only_translation(
    model,
    processor,
    source_text: str,
    max_new_tokens: int,
) -> str:
    messages = build_messages_initial_style_text_only(source_text)

    return generate_with_original_model_decoding(
        model=model,
        processor=processor,
        messages=messages,
        image=None,
        max_new_tokens=max_new_tokens,
    )


def generate_image_prior_only_translation(
    model,
    processor,
    image: Image.Image,
    max_new_tokens: int,
) -> str:
    """
    这里使用 TD2 中完全相同的 image-prior condition。
    """

    messages = build_messages_initial_style_image_only(image)

    return generate_with_original_model_decoding(
        model=model,
        processor=processor,
        messages=messages,
        image=image,
        max_new_tokens=max_new_tokens,
    )


# =====================================================
# 7. 输出记录
# =====================================================

def build_score_record(
    row_id: str,
    source_text: str,
    reference_translation: str,
    translation: str,
) -> Dict[str, Any]:
    return {
        "id": row_id,
        STANDARD_SOURCE_FIELD: source_text,
        STANDARD_REFERENCE_FIELD: reference_translation,
        HYPOTHESIS_FIELD: translation,
    }


# =====================================================
# 8. 模型加载：Qwen2-VL-7B
# =====================================================

def load_model_and_processor(dtype: torch.dtype):
    if Qwen2VLForConditionalGeneration is None:
        raise ImportError(
            "当前 transformers 环境无法导入 Qwen2VLForConditionalGeneration。"
            "请确认该环境支持 Qwen2-VL。"
        )

    print("[INFO] Loading Qwen2-VL model ...", flush=True)
    print(f"[INFO] MODEL_PATH: {MODEL_PATH}", flush=True)
    print(f"[INFO] CUDA_VISIBLE_DEVICES: {os.environ.get('CUDA_VISIBLE_DEVICES')}", flush=True)
    print(f"[INFO] torch.cuda.is_available(): {torch.cuda.is_available()}", flush=True)

    if torch.cuda.is_available():
        print(f"[INFO] Visible GPU count: {torch.cuda.device_count()}", flush=True)
        print(f"[INFO] Current device: {torch.cuda.current_device()}", flush=True)

    model = Qwen2VLForConditionalGeneration.from_pretrained(
        MODEL_PATH,
        torch_dtype=dtype,
        device_map="auto",
        trust_remote_code=True,
        local_files_only=True,
    )

    processor = AutoProcessor.from_pretrained(
        MODEL_PATH,
        trust_remote_code=True,
        local_files_only=True,
    )

    model.eval()

    print("[INFO] Model loaded.", flush=True)

    return model, processor


# =====================================================
# 9. 主程序
# =====================================================

def main():
    torch.manual_seed(SEED)

    input_jsonl = get_input_jsonl(DATASET, LANGUAGE)
    text_only_output, image_prior_output = get_output_paths(DATASET, LANGUAGE)

    if not os.path.exists(input_jsonl):
        raise FileNotFoundError(f"输入文件不存在: {input_jsonl}")

    rows = read_jsonl(
        path=input_jsonl,
        max_samples=MAX_SAMPLES,
    )

    total = len(rows)

    dtype = get_torch_dtype(DTYPE_NAME)

    print("========== Runtime Config ==========")
    print(f"[INFO] DATASET: {DATASET}")
    print(f"[INFO] DATA_OUTPUT_NAME: {DATA_OUTPUT_NAME}")
    print(f"[INFO] LANGUAGE: {LANGUAGE}")
    print(f"[INFO] SOURCE_LANG_NAME: {SOURCE_LANG_NAME}")
    print(f"[INFO] TARGET_LANG_NAME: {TARGET_LANG_NAME}")
    print(f"[INFO] TRANSLATION_DIRECTION: English -> {TARGET_LANG_NAME}")
    print(f"[INFO] GPU: {GPU}")
    print(f"[INFO] MAX_SAMPLES: {MAX_SAMPLES}")
    print(f"[INFO] MAX_NEW_TOKENS: {MAX_NEW_TOKENS}")
    print(f"[INFO] dtype: {DTYPE_NAME}")
    print(f"[INFO] MODEL_PATH: {MODEL_PATH}")
    print(f"[INFO] INPUT_JSONL: {input_jsonl}")
    print(f"[INFO] IMAGE_DIR: {get_image_dir()}")
    print(f"[INFO] TEXT_ONLY_OUTPUT: {text_only_output}")
    print(f"[INFO] IMAGE_PRIOR_ONLY_OUTPUT: {image_prior_output}")
    print(f"[INFO] OUTPUT_FIELDS: id, source_text, reference_translation, initial_translation")
    print("[INFO] Text-only condition: English source visible, no image")
    print("[INFO] Image-prior condition: source hidden, image visible, same as TD2")
    print("[INFO] Decoding: original model.generate() only")
    print("====================================", flush=True)

    if DATASET == "vg":
        print(f"[INFO] VG_INPUT_ROOT: {VG_INPUT_ROOT}", flush=True)
        print(f"[INFO] IMAGE_ID_FIELD: {IMAGE_ID_FIELD}", flush=True)
        print(f"[INFO] VG_SOURCE_FIELD: {VG_SOURCE_FIELD}", flush=True)
        print(f"[INFO] VG_REFERENCE_FIELD: {VG_REFERENCE_FIELD}", flush=True)
        print("[INFO] src_en participates in generation: True", flush=True)
        print("[INFO] tgt participates in generation: False", flush=True)
        print("[INFO] tgt only saved as reference_translation: True", flush=True)

    if DATASET == "multi30k":
        print(f"[INFO] MULTI30K_INPUT_ROOT: {MULTI30K_INPUT_ROOT}", flush=True)
        print(f"[INFO] MULTI30K_SOURCE_FIELDS: {MULTI30K_SOURCE_FIELDS}", flush=True)
        print(f"[INFO] MULTI30K_REFERENCE_FIELDS: {MULTI30K_REFERENCE_FIELDS}", flush=True)
        print("[INFO] source/reference_translation participates in generation: True", flush=True)
        print("[INFO] target/source_text participates in generation: False", flush=True)
        print("[INFO] target saved as reference_translation: True", flush=True)

    model, processor = load_model_and_processor(dtype=dtype)

    init_jsonl(text_only_output)
    init_jsonl(image_prior_output)

    stats = {
        "dataset": DATASET,
        "language": LANGUAGE,
        "translation_direction": f"English_to_{LANGUAGE}",
        "total": total,

        "text_only_saved": 0,
        "image_prior_saved": 0,

        "text_only_empty": 0,
        "image_prior_empty": 0,

        "text_only_error": 0,
        "image_prior_error": 0,

        "missing_source": 0,
        "missing_reference": 0,
        "missing_image": 0,
    }

    start_time = time.time()

    for idx, row in enumerate(rows, start=1):
        iter_start = time.time()
        row_id = get_row_id(row, fallback_idx=idx)

        source_text, reference_translation = get_source_and_reference(row)

        if not source_text:
            stats["missing_source"] += 1

        if not reference_translation:
            stats["missing_reference"] += 1

        # ===============================
        # 1) Text-only condition
        # ===============================
        text_only_translation = ""

        if source_text:
            try:
                text_only_translation = generate_text_only_translation(
                    model=model,
                    processor=processor,
                    source_text=source_text,
                    max_new_tokens=MAX_NEW_TOKENS,
                )
            except Exception as e:
                stats["text_only_error"] += 1
                text_only_translation = ""
                print(f"[WARN] text-only failed | id={row_id} | {repr(e)}", flush=True)

        if not text_only_translation:
            stats["text_only_empty"] += 1

        text_only_record = build_score_record(
            row_id=row_id,
            source_text=source_text,
            reference_translation=reference_translation,
            translation=text_only_translation,
        )

        append_jsonl(text_only_output, text_only_record)
        stats["text_only_saved"] += 1

        # ===============================
        # 2) Image-prior only condition
        #    same as TD2 image condition
        # ===============================
        image_prior_translation = ""

        image_path = resolve_image_path(row)

        if not image_path:
            stats["missing_image"] += 1
        else:
            image = None

            try:
                image = load_rgb_image(image_path)

                image_prior_translation = generate_image_prior_only_translation(
                    model=model,
                    processor=processor,
                    image=image,
                    max_new_tokens=MAX_NEW_TOKENS,
                )

            except Exception as e:
                stats["image_prior_error"] += 1
                image_prior_translation = ""
                print(f"[WARN] image-prior failed | id={row_id} | {repr(e)}", flush=True)

            finally:
                if image is not None:
                    try:
                        image.close()
                    except Exception:
                        pass

        if not image_prior_translation:
            stats["image_prior_empty"] += 1

        image_prior_record = build_score_record(
            row_id=row_id,
            source_text=source_text,
            reference_translation=reference_translation,
            translation=image_prior_translation,
        )

        append_jsonl(image_prior_output, image_prior_record)
        stats["image_prior_saved"] += 1

        cleanup_cuda()

        elapsed = time.time() - start_time
        avg = elapsed / max(1, idx)
        eta = avg * max(0, total - idx)

        finish_time = time.strftime(
            "%Y-%m-%d %H:%M:%S",
            time.localtime(time.time() + eta),
        )

        iter_time = time.time() - iter_start

        print(
            f"[{idx}/{total}] data={DATASET} | lang={LANGUAGE} | id={row_id} | "
            f"iter={iter_time:.2f}s | ETA={format_seconds(eta)} | finish={finish_time} | "
            f"text_empty={stats['text_only_empty']} | "
            f"image_prior_empty={stats['image_prior_empty']} | "
            f"text={text_only_translation[:60]} | "
            f"image_prior={image_prior_translation[:60]}",
            flush=True,
        )

    print("[done] " + json.dumps(stats, ensure_ascii=False), flush=True)
    print(f"[INFO] text-only output saved to: {text_only_output}", flush=True)
    print(f"[INFO] image-prior-only output saved to: {image_prior_output}", flush=True)


if __name__ == "__main__":
    main()