


#!/bin/bash
set -e


source /home/chenyi/venvs/blaser_qe_env/bin/activate
cd /home/chenyi/offline_blaser_qe/code/Qwen2_Vl_7B


# for alpha in 0.01 0.03 0.05 0.07 0.09
# do
#     echo "Running alpha: $lalpha"
#     python en_xx_contract_decoding.py --data multi30k --lang lv --gpu 1 --alpha $alpha
#     python en_xx_contract_decoding.py --data multi30k --lang tr --gpu 1 --alpha $alpha
#     python en_xx_contract_decoding.py --data multi30k --lang hi --gpu 1 --alpha $alpha
   
#     echo "Finished language: $alpha"
# done

for alpha in 0.1
do
    echo "Running alpha: $lalpha"
    python en_xx_contract_decoding.py --data vg --lang bn --gpu 3 --alpha $alpha
    python en_xx_contract_decoding.py --data vg --lang ha --gpu 3 --alpha $alpha
    python en_xx_contract_decoding.py --data vg --lang hi --gpu 3 --alpha $alpha
    python en_xx_contract_decoding.py --data vg --lang ma --gpu 3 --alpha $alpha
    echo "Finished language: $alpha"
done
echo "All  finished."