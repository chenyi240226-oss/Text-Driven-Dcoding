#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
text_main_contrastive_translate_qwen2vl_fixed.py

命令行只输入：
    --lang hi/lv/tr
    --gpu 0/1/2...

其他路径和参数全部写定在程序里。

核心分布：
    logits_text  = logit(y | source, y<t)
    logits_full  = logit(y | source, image, y<t)
    logits_image = logit(y | image, y<t)
    logits_prior = logit(y | y<t)

    new_logits = logits_text + 2 * logits_full - logits_image - logits_prior

适配 Multi30K:
    输入:
        /mnt/raid/cycy/data/txt_multi30k/en_{lang}_test.jsonl

    字段:
        target -> 待翻译源句
        source -> 英文参考译文
        image  -> 图片路径

    输出:
        /home/chenyi/offline_blaser_qe/out/Qwen2_VL_7B/Multi30k/{lang}/{lang}_text_main_contrast_translation.jsonl

运行示例:
    CUDA_VISIBLE_DEVICES=0 python text_main_contrastive_translate_qwen2vl_fixed.py --lang hi --gpu 0

或者:
    python text_main_contrastive_translate_qwen2vl_fixed.py --lang hi --gpu 0
"""

import os
import re
import json
import time
import argparse
from typing import Dict, Any, List, Optional

import numpy as np
from PIL import Image

import torch
import torch.nn.functional as F
from transformers import AutoProcessor

try:
    from transformers import Qwen2VLForConditionalGeneration
except Exception:
    Qwen2VLForConditionalGeneration = None


# =========================
# 写定配置
# =========================

MODEL_PATH = "/mnt/raid/hss/model/Qwen2-VL-7B-Instruct"

INPUT_ROOT = "/mnt/raid/cycy/data/txt_multi30k"
OUTPUT_ROOT = "/home/chenyi/offline_blaser_qe/out/Qwen2_VL_7B/Multi30k"

ALLOWED_LANGS = {"hi", "lv", "tr"}

SOURCE_FIELD = "target"
REFERENCE_FIELD = "source"
IMAGE_FIELD = "image"

OUTPUT_FIELD = "text_main_contrast_translation_en"

DTYPE_NAME = "bfloat16"

LAMBDA_IMAGE = 1.0
LAMBDA_PRIOR = 1.0

HEAD_BETA = 0.0

MAX_NEW_TOKENS = 64
DECODING = "greedy"

TEMPERATURE = 1.0
TOP_P = 1.0
TOP_K = 0

SEED = 42

MAX_SAMPLES = 100
SKIP_EXISTING = False


# =========================
# 参数
# =========================

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--lang", type=str, required=True, choices=sorted(ALLOWED_LANGS))
    parser.add_argument("--gpu", type=str, required=True)
    return parser.parse_args()


def get_paths(lang: str):
    input_jsonl = os.path.join(INPUT_ROOT, f"en_{lang}_test.jsonl")
    output_dir = os.path.join(OUTPUT_ROOT, lang)
    output_jsonl = os.path.join(output_dir, f"{lang}_text_main_contrast_translation.jsonl")
    return input_jsonl, output_jsonl


def get_torch_dtype(name: str):
    if name == "float16":
        return torch.float16
    if name == "bfloat16":
        return torch.bfloat16
    return torch.float32


# =========================
# 文件工具
# =========================

def ensure_dir(path: str):
    d = os.path.dirname(os.path.abspath(path))
    if d:
        os.makedirs(d, exist_ok=True)


def read_jsonl(path: str, max_samples: int = 0) -> List[Dict[str, Any]]:
    rows = []

    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue

            rows.append(json.loads(line))

            if max_samples > 0 and len(rows) >= max_samples:
                break

    return rows


def append_jsonl(path: str, row: Dict[str, Any]):
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(row, ensure_ascii=False) + "\n")


def get_row_id(row: Dict[str, Any], fallback_idx: int = -1) -> str:
    for k in ["id", "image_id", "qid", "question_id"]:
        if k in row and row[k] is not None:
            return str(row[k])

    if fallback_idx >= 0:
        return str(fallback_idx)

    return ""


def load_existing_ids(path: str) -> set:
    ids = set()

    if not os.path.exists(path):
        return ids

    with open(path, "r", encoding="utf-8") as f:
        for i, line in enumerate(f):
            try:
                row = json.loads(line)
                rid = get_row_id(row, fallback_idx=i)
                if rid:
                    ids.add(rid)
            except Exception:
                continue

    return ids


def format_seconds(sec: float) -> str:
    sec = max(0, int(sec))
    h = sec // 3600
    m = (sec % 3600) // 60
    s = sec % 60
    return f"{h:02d}:{m:02d}:{s:02d}"


# =========================
# 图片路径
# =========================

def resolve_image_path(row: Dict[str, Any]) -> Optional[str]:
    candidates = []

    if row.get(IMAGE_FIELD):
        candidates.append(str(row[IMAGE_FIELD]))

    for k in ["image_path", "image", "path", "img_path", "file_name", "filename"]:
        if row.get(k):
            p = str(row[k])
            if p not in candidates:
                candidates.append(p)

    for p in candidates:
        if os.path.isabs(p) and os.path.exists(p):
            return p

    for p in candidates:
        if os.path.exists(p):
            return p

    return None


def load_rgb_image(path: str) -> Image.Image:
    return Image.open(path).convert("RGB")


# =========================
# Prompt
# =========================

def build_system_prompt() -> str:
    return (
        "You are a professional translator. "
        "Your job is to translate the given source sentence into English. "
        "STRICT RULES: "
        "1. Be faithful. Do NOT add, remove, or change objects, attributes, actions, or relations. "
        "2. Use the image only when it helps resolve ambiguity. "
        "3. Do not turn the task into image captioning. "
        "4. Output ONLY the English translation. No explanations. "
        "5. Do NOT output any thinking process or <think>...</think> content."
    )


def build_user_prompt(source_text: str, source_visible: bool) -> str:
    if source_visible:
        src = source_text
    else:
        src = "[SOURCE SENTENCE HIDDEN]"

    return (
        "Translate the following source sentence into English.\n"
        f"Source sentence: {src}\n"
        "Output only the English translation."
    )


def build_messages(
    source_text: str,
    use_image: bool,
    source_visible: bool,
):
    system_prompt = build_system_prompt()

    user_prompt = build_user_prompt(
        source_text=source_text,
        source_visible=source_visible,
    )

    user_content = []

    if use_image:
        user_content.append({"type": "image"})

    user_content.append({"type": "text", "text": user_prompt})

    messages = [
        {
            "role": "system",
            "content": system_prompt,
        },
        {
            "role": "user",
            "content": user_content,
        },
    ]

    return messages


# =========================
# Qwen2-VL 输入构造
# =========================

def move_inputs_to_device(
    inputs: Dict[str, Any],
    device: torch.device,
    dtype: torch.dtype,
) -> Dict[str, Any]:
    moved = {}

    for k, v in inputs.items():
        if torch.is_tensor(v):
            if torch.is_floating_point(v):
                moved[k] = v.to(device=device, dtype=dtype)
            else:
                moved[k] = v.to(device=device)
        else:
            moved[k] = v

    return moved


def prepare_condition_inputs(
    processor,
    image: Optional[Image.Image],
    source_text: str,
    use_image: bool,
    source_visible: bool,
    device: torch.device,
    dtype: torch.dtype,
) -> Dict[str, torch.Tensor]:
    messages = build_messages(
        source_text=source_text,
        use_image=use_image,
        source_visible=source_visible,
    )

    text = processor.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True,
    )

    if use_image:
        if image is None:
            raise ValueError("use_image=True but image is None")

        inputs = processor(
            text=[text],
            images=[image],
            padding=True,
            return_tensors="pt",
        )
    else:
        inputs = processor(
            text=[text],
            padding=True,
            return_tensors="pt",
        )

    return move_inputs_to_device(
        inputs=inputs,
        device=device,
        dtype=dtype,
    )


def prepare_all_condition_inputs(
    processor,
    image: Image.Image,
    source_text: str,
    device: torch.device,
    dtype: torch.dtype,
) -> Dict[str, Dict[str, torch.Tensor]]:
    condition_inputs = {
        "text_only": prepare_condition_inputs(
            processor=processor,
            image=None,
            source_text=source_text,
            use_image=False,
            source_visible=True,
            device=device,
            dtype=dtype,
        ),
        "full": prepare_condition_inputs(
            processor=processor,
            image=image,
            source_text=source_text,
            use_image=True,
            source_visible=True,
            device=device,
            dtype=dtype,
        ),
        "image_only": prepare_condition_inputs(
            processor=processor,
            image=image,
            source_text=source_text,
            use_image=True,
            source_visible=False,
            device=device,
            dtype=dtype,
        ),
        "prior_only": prepare_condition_inputs(
            processor=processor,
            image=None,
            source_text=source_text,
            use_image=False,
            source_visible=False,
            device=device,
            dtype=dtype,
        ),
    }

    return condition_inputs


# =========================
# 解码工具
# =========================

def get_eos_token_ids(processor, model) -> set:
    eos_ids = set()

    tokenizer = getattr(processor, "tokenizer", None)

    if tokenizer is not None:
        if tokenizer.eos_token_id is not None:
            eos_ids.add(int(tokenizer.eos_token_id))

        for tok in ["<|im_end|>", "<|endoftext|>"]:
            try:
                tid = tokenizer.convert_tokens_to_ids(tok)
                if isinstance(tid, int) and tid >= 0:
                    eos_ids.add(tid)
            except Exception:
                pass

    gen_cfg = getattr(model, "generation_config", None)

    if gen_cfg is not None:
        eid = getattr(gen_cfg, "eos_token_id", None)

        if isinstance(eid, int):
            eos_ids.add(eid)
        elif isinstance(eid, (list, tuple)):
            for x in eid:
                if x is not None:
                    eos_ids.add(int(x))

    return eos_ids


def get_pad_token_id(processor) -> Optional[int]:
    tokenizer = getattr(processor, "tokenizer", None)

    if tokenizer is None:
        return None

    if tokenizer.pad_token_id is not None:
        return int(tokenizer.pad_token_id)

    return None


def append_generated_to_inputs(
    base_inputs: Dict[str, torch.Tensor],
    generated_ids: List[int],
) -> Dict[str, Any]:
    input_ids = base_inputs["input_ids"]

    if len(generated_ids) > 0:
        gen = torch.tensor(
            [generated_ids],
            dtype=input_ids.dtype,
            device=input_ids.device,
        )
        full_input_ids = torch.cat([input_ids, gen], dim=1)
    else:
        full_input_ids = input_ids

    if "attention_mask" in base_inputs:
        base_mask = base_inputs["attention_mask"]

        if len(generated_ids) > 0:
            gen_mask = torch.ones(
                (base_mask.shape[0], len(generated_ids)),
                dtype=base_mask.dtype,
                device=base_mask.device,
            )
            attention_mask = torch.cat([base_mask, gen_mask], dim=1)
        else:
            attention_mask = base_mask
    else:
        attention_mask = torch.ones_like(full_input_ids)

    merged = {}

    for k, v in base_inputs.items():
        if k in ["input_ids", "attention_mask"]:
            continue
        merged[k] = v

    merged["input_ids"] = full_input_ids
    merged["attention_mask"] = attention_mask

    return merged


def forward_last_logits(
    model,
    base_inputs: Dict[str, torch.Tensor],
    generated_ids: List[int],
) -> torch.Tensor:
    inputs = append_generated_to_inputs(
        base_inputs=base_inputs,
        generated_ids=generated_ids,
    )

    with torch.inference_mode():
        outputs = model(
            **inputs,
            use_cache=False,
        )

    return outputs.logits[:, -1, :].float()


def build_text_main_contrast_logits(
    logits_text: torch.Tensor,
    logits_full: torch.Tensor,
    logits_image: torch.Tensor,
    logits_prior: torch.Tensor,
) -> torch.Tensor:
    new_logits = logits_text.clone()
    new_logits = new_logits + LAMBDA_IMAGE * (logits_full - logits_image)
    new_logits = new_logits + LAMBDA_PRIOR * (logits_full - logits_prior)
    return new_logits


def apply_head_constraint(
    new_logits: torch.Tensor,
    anchor_logits: torch.Tensor,
) -> torch.Tensor:
    if HEAD_BETA <= 0:
        return new_logits

    anchor_probs = F.softmax(anchor_logits, dim=-1)
    max_prob = anchor_probs.max(dim=-1, keepdim=True).values
    keep_mask = anchor_probs >= HEAD_BETA * max_prob

    constrained = new_logits.masked_fill(~keep_mask, float("-inf"))

    if torch.isinf(constrained).all():
        return new_logits

    return constrained


def top_k_top_p_filtering(
    logits_1d: torch.Tensor,
    top_k: int = 0,
    top_p: float = 1.0,
    filter_value: float = float("-inf"),
) -> torch.Tensor:
    logits = logits_1d.clone()

    if top_k is not None and top_k > 0:
        top_k = min(top_k, logits.size(-1))
        threshold = torch.topk(logits, top_k).values[-1]
        logits[logits < threshold] = filter_value

    if top_p is not None and 0.0 < top_p < 1.0:
        sorted_logits, sorted_indices = torch.sort(logits, descending=True)
        sorted_probs = F.softmax(sorted_logits, dim=-1)
        cumulative_probs = torch.cumsum(sorted_probs, dim=-1)

        remove = cumulative_probs > top_p
        remove[1:] = remove[:-1].clone()
        remove[0] = False

        remove_indices = sorted_indices[remove]
        logits[remove_indices] = filter_value

    return logits


def select_next_token(logits: torch.Tensor) -> int:
    logits_1d = logits[0].clone()

    if DECODING == "greedy":
        return int(torch.argmax(logits_1d).item())

    temperature = TEMPERATURE

    if temperature is None or temperature <= 0:
        temperature = 1.0

    logits_1d = logits_1d / temperature

    logits_1d = top_k_top_p_filtering(
        logits_1d,
        top_k=TOP_K,
        top_p=TOP_P,
    )

    probs = F.softmax(logits_1d, dim=-1)

    if (not torch.isfinite(probs).all()) or probs.sum().item() <= 0:
        return int(torch.argmax(logits[0]).item())

    return int(torch.multinomial(probs, num_samples=1).item())


def decode_ids(processor, token_ids: List[int]) -> str:
    if len(token_ids) == 0:
        return ""

    tokenizer = getattr(processor, "tokenizer", None)

    if tokenizer is not None:
        text = tokenizer.decode(
            token_ids,
            skip_special_tokens=True,
            clean_up_tokenization_spaces=False,
        )
    else:
        text = processor.decode(
            token_ids,
            skip_special_tokens=True,
            clean_up_tokenization_spaces=False,
        )

    return clean_translation_output(text)


def clean_translation_output(text: str) -> str:
    text = text.strip()

    bad_prefixes = [
        "Translation:",
        "English translation:",
        "The English translation is:",
        "Output:",
        "Answer:",
    ]

    for p in bad_prefixes:
        if text.lower().startswith(p.lower()):
            text = text[len(p):].strip()

    text = text.strip().strip('"').strip("'").strip()
    text = re.sub(r"\s+", " ", text).strip()

    return text


# =========================
# Text-main contrastive decoding
# =========================

def text_main_contrast_decode_one(
    model,
    processor,
    image: Image.Image,
    source_text: str,
    device: torch.device,
    dtype: torch.dtype,
) -> str:
    condition_inputs = prepare_all_condition_inputs(
        processor=processor,
        image=image,
        source_text=source_text,
        device=device,
        dtype=dtype,
    )

    eos_token_ids = get_eos_token_ids(processor, model)
    pad_token_id = get_pad_token_id(processor)

    generated_ids: List[int] = []

    for _ in range(MAX_NEW_TOKENS):
        logits_text = forward_last_logits(
            model=model,
            base_inputs=condition_inputs["text_only"],
            generated_ids=generated_ids,
        )

        logits_full = forward_last_logits(
            model=model,
            base_inputs=condition_inputs["full"],
            generated_ids=generated_ids,
        )

        logits_image = forward_last_logits(
            model=model,
            base_inputs=condition_inputs["image_only"],
            generated_ids=generated_ids,
        )

        logits_prior = forward_last_logits(
            model=model,
            base_inputs=condition_inputs["prior_only"],
            generated_ids=generated_ids,
        )

        new_logits = build_text_main_contrast_logits(
            logits_text=logits_text,
            logits_full=logits_full,
            logits_image=logits_image,
            logits_prior=logits_prior,
        )

        new_logits = apply_head_constraint(
            new_logits=new_logits,
            anchor_logits=logits_text,
        )

        if pad_token_id is not None and pad_token_id not in eos_token_ids:
            if 0 <= pad_token_id < new_logits.shape[-1]:
                new_logits[:, pad_token_id] = float("-inf")

        next_token_id = select_next_token(new_logits)

        if next_token_id in eos_token_ids:
            break

        generated_ids.append(next_token_id)

    return decode_ids(processor, generated_ids)


# =========================
# 模型加载
# =========================

def load_model_and_processor(
    model_path: str,
    dtype: torch.dtype,
    device: torch.device,
):
    if Qwen2VLForConditionalGeneration is None:
        raise ImportError(
            "当前 transformers 环境无法导入 Qwen2VLForConditionalGeneration。"
            "请确认该环境支持 Qwen2-VL。"
        )

    processor = AutoProcessor.from_pretrained(
        model_path,
        trust_remote_code=True,
        local_files_only=True,
    )

    model = Qwen2VLForConditionalGeneration.from_pretrained(
        model_path,
        torch_dtype=dtype,
        trust_remote_code=True,
        local_files_only=True,
    )

    model.to(device)
    model.eval()

    return model, processor


# =========================
# 主程序
# =========================

def main():
    args = parse_args()

    os.environ["CUDA_VISIBLE_DEVICES"] = str(args.gpu)

    torch.manual_seed(SEED)
    np.random.seed(SEED)

    input_jsonl, output_jsonl = get_paths(args.lang)

    ensure_dir(output_jsonl)

    dtype = get_torch_dtype(DTYPE_NAME)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    print(f"[load] model_path={MODEL_PATH}")
    print(f"[load] device={device}, dtype={DTYPE_NAME}")
    print(f"[args] lang={args.lang}, gpu={args.gpu}")

    model, processor = load_model_and_processor(
        model_path=MODEL_PATH,
        dtype=dtype,
        device=device,
    )

    rows = read_jsonl(
        path=input_jsonl,
        max_samples=MAX_SAMPLES,
    )

    existing_ids = load_existing_ids(output_jsonl) if SKIP_EXISTING else set()

    total = len(rows)
    start_time = time.time()

    config = {
        "formula": "new_logits = logits_text + 2*logits_full - logits_image - logits_prior",
        "model_path": MODEL_PATH,
        "input_jsonl": input_jsonl,
        "output_jsonl": output_jsonl,
        "source_field": SOURCE_FIELD,
        "reference_field": REFERENCE_FIELD,
        "image_field": IMAGE_FIELD,
        "output_field": OUTPUT_FIELD,
        "lambda_image": LAMBDA_IMAGE,
        "lambda_prior": LAMBDA_PRIOR,
        "head_beta": HEAD_BETA,
        "decoding": DECODING,
        "temperature": TEMPERATURE,
        "top_p": TOP_P,
        "top_k": TOP_K,
        "max_new_tokens": MAX_NEW_TOKENS,
        "dtype": DTYPE_NAME,
        "seed": SEED,
    }

    stats = {
        "total": total,
        "saved": 0,
        "skipped_existing": 0,
        "error": 0,
        "image_missing": 0,
        "empty_source": 0,
    }

    print(f"[data] input={input_jsonl}")
    print(f"[data] output={output_jsonl}")
    print(f"[data] total={total}")
    print("[config] " + json.dumps(config, ensure_ascii=False))

    for idx, row in enumerate(rows, start=1):
        rid = get_row_id(row, fallback_idx=idx)

        if SKIP_EXISTING and rid and rid in existing_ids:
            stats["skipped_existing"] += 1
            continue

        iter_start = time.time()
        out = dict(row)

        try:
            source_text = str(row.get(SOURCE_FIELD, "")).strip()

            if not source_text:
                stats["empty_source"] += 1
                raise ValueError(f"missing or empty source field: {SOURCE_FIELD}")

            image_path = resolve_image_path(row)

            if not image_path:
                stats["image_missing"] += 1
                raise FileNotFoundError(f"cannot resolve image path for id={rid}")

            image = load_rgb_image(image_path)

            translation = text_main_contrast_decode_one(
                model=model,
                processor=processor,
                image=image,
                source_text=source_text,
                device=device,
                dtype=dtype,
            )

            out[OUTPUT_FIELD] = translation
            out["text_main_contrast_image_path"] = image_path

            if REFERENCE_FIELD in row:
                out["reference_translation"] = row.get(REFERENCE_FIELD, "")

            out["text_main_contrast_config"] = config

        except Exception as e:
            stats["error"] += 1
            out[OUTPUT_FIELD] = ""
            out["text_main_contrast_error"] = repr(e)
            out["text_main_contrast_config"] = config

        append_jsonl(output_jsonl, out)
        stats["saved"] += 1

        elapsed = time.time() - start_time
        avg = elapsed / max(1, idx)
        eta = avg * max(0, total - idx)
        finish_time = time.strftime(
            "%Y-%m-%d %H:%M:%S",
            time.localtime(time.time() + eta),
        )
        iter_time = time.time() - iter_start

        print(
            f"[{idx}/{total}] id={rid} | iter={iter_time:.2f}s | "
            f"ETA={format_seconds(eta)} | finish={finish_time} | "
            f"saved={stats['saved']} | error={stats['error']}",
            flush=True,
        )

    print("[done] " + json.dumps(stats, ensure_ascii=False))


if __name__ == "__main__":
    main()