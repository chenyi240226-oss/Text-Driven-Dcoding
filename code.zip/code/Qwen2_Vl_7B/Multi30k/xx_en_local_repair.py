#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
text_only_detect_local_repair_qwen2vl.py

目标：
    text-only 生成主翻译；
    contrast logits 只用于检测可疑 token/span；
    局部生成修复候选；
    不再用新分布控制整句每个 token 的生成。

命令行只输入：
    --lang hi/lv/tr
    --gpu 0/1/2/...

输入：
    /mnt/raid/cycy/data/txt_multi30k/en_{lang}_test.jsonl

字段：
    target -> 待翻译源句
    source -> 英文参考译文
    image  -> 图片路径

输出：
    /home/chenyi/offline_blaser_qe/out/Qwen2_VL_7B/Multi30k/{lang}/{lang}_text_only_contrast_local_candidates.jsonl

输出字段：
    text_only_translation_en
    suspicious_spans
    candidate_1
    candidate_2
    candidate_3

其中：
    candidate_1: 针对 primary suspicious span 的局部修复
    candidate_2: 针对所有 suspicious spans 的联合局部修复
    candidate_3: 永远保留 text-only 主翻译
"""

import os
import argparse

# =====================================================
# 0. 命令行参数：必须在 import torch 前解析并设置 GPU
# =====================================================

ALLOWED_LANGUAGES = {"hi", "lv", "tr"}


def parse_args():
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--lang",
        type=str,
        required=True,
        choices=sorted(ALLOWED_LANGUAGES),
        help="Language code. Allowed values: hi, lv, tr.",
    )

    parser.add_argument(
        "--gpu",
        type=str,
        required=True,
        help="Physical GPU id, for example: 0, 1, 2, 5, 6, 7.",
    )

    return parser.parse_args()


ARGS = parse_args()
LANGUAGE = ARGS.lang
GPU = ARGS.gpu

os.environ["CUDA_VISIBLE_DEVICES"] = str(GPU)
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"

os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"
os.environ["TOKENIZERS_PARALLELISM"] = "false"

os.environ["HF_HOME"] = "/home/chenyi/model_cache/huggingface"
os.environ["TRANSFORMERS_CACHE"] = "/home/chenyi/model_cache/huggingface/hub"

SYSLIBS_DIR = "/home/chenyi/offline_blaser_qe/syslibs"
os.environ["LD_LIBRARY_PATH"] = SYSLIBS_DIR + ":" + os.environ.get("LD_LIBRARY_PATH", "")


import re
import json
import time
import math
import warnings
from typing import Dict, Any, List, Optional, Tuple

import numpy as np
from PIL import Image

import torch
import torch.nn.functional as F
from transformers import AutoProcessor

try:
    from transformers import Qwen2VLForConditionalGeneration
except Exception:
    Qwen2VLForConditionalGeneration = None


warnings.filterwarnings("ignore", category=UserWarning)


# =====================================================
# 1. 写定配置
# =====================================================

MODEL_PATH = "/mnt/raid/hss/model/Qwen2-VL-7B-Instruct"

INPUT_ROOT = "/mnt/raid/cycy/data/txt_multi30k"
OUTPUT_ROOT = "/home/chenyi/offline_blaser_qe/out/Qwen2_VL_7B/Multi30k"

SOURCE_FIELD = "target"
REFERENCE_FIELD = "source"
IMAGE_FIELD = "image"

OUTPUT_JSONL_NAME = f"{LANGUAGE}_text_only_contrast_local_candidates.jsonl"

OUTPUT_FIELD_TEXT_ONLY = "text_only_translation_en"

DTYPE_NAME = "bfloat16"

MAX_NEW_TOKENS_TRANSLATE = 64
MAX_NEW_TOKENS_REPAIR = 64

SEED = 42

# 是否如果输入中已有 initial_translation_en 就直接用它作为 text-only 主翻译。
# 如果输入是原始 Multi30K，一般没有这个字段，会自动调用模型生成。
USE_EXISTING_INITIAL_IF_PRESENT = True

# 局部修复时最多送入多少个 suspicious spans。
# 这是为了避免一次修复过多片段导致模型重写整句。
MAX_REPAIR_SPANS = 3


# =====================================================
# 2. 路径与基础工具
# =====================================================

def get_paths(lang: str) -> Tuple[str, str]:
    input_jsonl = os.path.join(INPUT_ROOT, f"en_{lang}_test.jsonl")
    output_dir = os.path.join(OUTPUT_ROOT, lang)
    output_jsonl = os.path.join(output_dir, OUTPUT_JSONL_NAME)
    return input_jsonl, output_jsonl


def get_torch_dtype(name: str):
    if name == "float16":
        return torch.float16
    if name == "bfloat16":
        return torch.bfloat16
    return torch.float32


def ensure_dir(path: str):
    d = os.path.dirname(os.path.abspath(path))
    if d:
        os.makedirs(d, exist_ok=True)


def read_jsonl(path: str) -> List[Dict[str, Any]]:
    rows = []
    with open(path, "r", encoding="utf-8") as f:
        for line_idx, line in enumerate(f, start=1):
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except Exception as e:
                print(f"[WARN] JSON parse failed at line {line_idx}: {e}", flush=True)
    return rows


def append_jsonl(path: str, row: Dict[str, Any]):
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(row, ensure_ascii=False) + "\n")


def normalize_text(x: Any) -> str:
    if x is None:
        return ""
    return str(x).strip()


def clean_translation_output(text: str) -> str:
    text = normalize_text(text)

    bad_prefixes = [
        "Translation:",
        "English translation:",
        "The English translation is:",
        "Output:",
        "Answer:",
        "Revised translation:",
        "Candidate:",
    ]

    for p in bad_prefixes:
        if text.lower().startswith(p.lower()):
            text = text[len(p):].strip()

    text = text.strip().strip('"').strip("'").strip()
    text = re.sub(r"\s+", " ", text).strip()

    return text


def get_row_id(row: Dict[str, Any], fallback_idx: int) -> str:
    for k in ["id", "image_id", "qid", "question_id"]:
        if k in row and row[k] is not None:
            return str(row[k])
    return str(fallback_idx)


def format_seconds(sec: float) -> str:
    sec = max(0, int(sec))
    h = sec // 3600
    m = (sec % 3600) // 60
    s = sec % 60
    return f"{h:02d}:{m:02d}:{s:02d}"


def is_mostly_english_output(text: str) -> bool:
    """
    防止局部修复候选出现中英混杂、印地语残留等情况。
    允许普通英文、数字、标点、空格。
    如果出现 CJK / Devanagari / Arabic 等非拉丁主体文字，则认为无效。
    """
    if not text:
        return False

    bad_script_pattern = re.compile(
        r"[\u4e00-\u9fff\u3400-\u4dbf"      # CJK
        r"\u3040-\u30ff"                    # Japanese
        r"\uac00-\ud7af"                    # Korean
        r"\u0900-\u097f"                    # Devanagari
        r"\u0980-\u09ff"                    # Bengali
        r"\u0d00-\u0d7f"                    # Malayalam
        r"\u0600-\u06ff]"                   # Arabic
    )

    return bad_script_pattern.search(text) is None


# =====================================================
# 3. 图片路径
# =====================================================

def resolve_image_path(row: Dict[str, Any]) -> Optional[str]:
    candidates = []

    if row.get(IMAGE_FIELD):
        candidates.append(str(row[IMAGE_FIELD]))

    for k in ["image_path", "image", "path", "img_path", "file_name", "filename"]:
        if row.get(k):
            p = str(row[k])
            if p not in candidates:
                candidates.append(p)

    for p in candidates:
        if os.path.isabs(p) and os.path.exists(p):
            return p

    for p in candidates:
        if os.path.exists(p):
            return p

    return None


def load_rgb_image(path: str) -> Image.Image:
    return Image.open(path).convert("RGB")


# =====================================================
# 4. Prompt 构造
# =====================================================

def build_translate_system_prompt() -> str:
    return (
        "You are a professional translator. "
        "Your job is to translate the given source sentence into English. "
        "STRICT RULES: "
        "1. Be faithful to the source sentence. "
        "2. Do NOT add, remove, or change objects, attributes, actions, or relations. "
        "3. Output ONLY the English translation. "
        "4. No explanations. "
        "5. Do NOT output any thinking process or <think>...</think> content."
    )


def build_multimodal_repair_system_prompt() -> str:
    return (
        "You are a professional translation reviser. "
        "Your job is to minimally repair an English translation. "
        "STRICT RULES: "
        "1. The source sentence is the primary evidence. "
        "2. Use the image only to resolve ambiguity. "
        "3. Do NOT turn the translation into an image caption. "
        "4. Only edit the suspicious span if it is wrong or unsupported. "
        "5. Keep all correct parts unchanged. "
        "6. Output ONLY the final English translation. "
        "7. No explanations. "
        "8. Do NOT output any thinking process or <think>...</think> content."
    )


def build_translate_user_prompt(source_text: str) -> str:
    return (
        "Translate the following source sentence into English.\n"
        f"Source sentence: {source_text}\n"
        "Output only the English translation."
    )


def build_condition_user_prompt(source_text: str, source_visible: bool) -> str:
    if source_visible:
        src = source_text
    else:
        src = "[SOURCE SENTENCE HIDDEN]"

    return (
        "Translate the following source sentence into English.\n"
        f"Source sentence: {src}\n"
        "Output only the English translation."
    )


def build_repair_user_prompt(
    source_text: str,
    initial_translation: str,
    suspicious_spans: List[Dict[str, Any]],
) -> str:
    span_texts = []
    for sp in suspicious_spans:
        span = normalize_text(sp.get("span", ""))
        if span:
            span_texts.append(span)

    if not span_texts:
        span_part = "(none)"
    else:
        span_part = "; ".join(span_texts)

    return (
        "Repair the translation only if the suspicious span is wrong or unsupported.\n"
        "Keep the revision local and minimal.\n\n"
        f"Source sentence:\n{source_text}\n\n"
        f"Initial English translation:\n{initial_translation}\n\n"
        f"Suspicious span(s):\n{span_part}\n\n"
        "Output only the final English translation."
    )


def build_messages_for_translation(source_text: str):
    return [
        {
            "role": "system",
            "content": build_translate_system_prompt(),
        },
        {
            "role": "user",
            "content": [
                {
                    "type": "text",
                    "text": build_translate_user_prompt(source_text),
                }
            ],
        },
    ]


def build_messages_for_condition(
    source_text: str,
    use_image: bool,
    source_visible: bool,
):
    user_content = []

    if use_image:
        user_content.append({"type": "image"})

    user_content.append(
        {
            "type": "text",
            "text": build_condition_user_prompt(
                source_text=source_text,
                source_visible=source_visible,
            ),
        }
    )

    return [
        {
            "role": "system",
            "content": build_translate_system_prompt(),
        },
        {
            "role": "user",
            "content": user_content,
        },
    ]


def build_messages_for_repair(
    source_text: str,
    initial_translation: str,
    suspicious_spans: List[Dict[str, Any]],
):
    return [
        {
            "role": "system",
            "content": build_multimodal_repair_system_prompt(),
        },
        {
            "role": "user",
            "content": [
                {"type": "image"},
                {
                    "type": "text",
                    "text": build_repair_user_prompt(
                        source_text=source_text,
                        initial_translation=initial_translation,
                        suspicious_spans=suspicious_spans,
                    ),
                },
            ],
        },
    ]


# =====================================================
# 5. Qwen2-VL 输入构造
# =====================================================

def move_inputs_to_device(
    inputs: Dict[str, Any],
    device: torch.device,
    dtype: torch.dtype,
) -> Dict[str, Any]:
    moved = {}

    for k, v in inputs.items():
        if torch.is_tensor(v):
            if torch.is_floating_point(v):
                moved[k] = v.to(device=device, dtype=dtype)
            else:
                moved[k] = v.to(device=device)
        else:
            moved[k] = v

    return moved


def prepare_inputs_from_messages(
    processor,
    messages,
    device: torch.device,
    dtype: torch.dtype,
    image: Optional[Image.Image] = None,
) -> Dict[str, Any]:
    text = processor.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True,
    )

    if image is not None:
        inputs = processor(
            text=[text],
            images=[image],
            padding=True,
            return_tensors="pt",
        )
    else:
        inputs = processor(
            text=[text],
            padding=True,
            return_tensors="pt",
        )

    return move_inputs_to_device(inputs, device=device, dtype=dtype)


def prepare_condition_inputs(
    processor,
    image: Optional[Image.Image],
    source_text: str,
    use_image: bool,
    source_visible: bool,
    device: torch.device,
    dtype: torch.dtype,
) -> Dict[str, Any]:
    messages = build_messages_for_condition(
        source_text=source_text,
        use_image=use_image,
        source_visible=source_visible,
    )

    actual_image = image if use_image else None

    return prepare_inputs_from_messages(
        processor=processor,
        messages=messages,
        image=actual_image,
        device=device,
        dtype=dtype,
    )


def prepare_four_condition_inputs(
    processor,
    image: Image.Image,
    source_text: str,
    device: torch.device,
    dtype: torch.dtype,
) -> Dict[str, Dict[str, Any]]:
    """
    text_only:
        source visible, no image

    full:
        source visible + image

    image_only:
        source hidden + image

    prior_only:
        source hidden, no image
    """
    return {
        "text_only": prepare_condition_inputs(
            processor=processor,
            image=None,
            source_text=source_text,
            use_image=False,
            source_visible=True,
            device=device,
            dtype=dtype,
        ),
        "full": prepare_condition_inputs(
            processor=processor,
            image=image,
            source_text=source_text,
            use_image=True,
            source_visible=True,
            device=device,
            dtype=dtype,
        ),
        "image_only": prepare_condition_inputs(
            processor=processor,
            image=image,
            source_text=source_text,
            use_image=True,
            source_visible=False,
            device=device,
            dtype=dtype,
        ),
        "prior_only": prepare_condition_inputs(
            processor=processor,
            image=None,
            source_text=source_text,
            use_image=False,
            source_visible=False,
            device=device,
            dtype=dtype,
        ),
    }


# =====================================================
# 6. 模型生成
# =====================================================

def get_tokenizer(processor):
    tokenizer = getattr(processor, "tokenizer", None)
    if tokenizer is None:
        raise RuntimeError("processor.tokenizer is None")
    return tokenizer


def get_pad_eos_ids(processor, model) -> Tuple[Optional[int], List[int]]:
    tokenizer = get_tokenizer(processor)

    pad_token_id = tokenizer.pad_token_id
    eos_ids = []

    if tokenizer.eos_token_id is not None:
        eos_ids.append(int(tokenizer.eos_token_id))

    for tok in ["<|im_end|>", "<|endoftext|>"]:
        try:
            tid = tokenizer.convert_tokens_to_ids(tok)
            if isinstance(tid, int) and tid >= 0:
                eos_ids.append(tid)
        except Exception:
            pass

    gen_cfg = getattr(model, "generation_config", None)
    if gen_cfg is not None:
        eid = getattr(gen_cfg, "eos_token_id", None)
        if isinstance(eid, int):
            eos_ids.append(eid)
        elif isinstance(eid, (list, tuple)):
            for x in eid:
                if x is not None:
                    eos_ids.append(int(x))

    eos_ids = sorted(set(eos_ids))

    return pad_token_id, eos_ids


def generate_from_inputs(
    model,
    processor,
    inputs: Dict[str, Any],
    max_new_tokens: int,
) -> str:
    pad_token_id, eos_ids = get_pad_eos_ids(processor, model)

    gen_kwargs = {
        "max_new_tokens": max_new_tokens,
        "do_sample": False,
        "use_cache": True,
    }

    if pad_token_id is not None:
        gen_kwargs["pad_token_id"] = pad_token_id

    if eos_ids:
        gen_kwargs["eos_token_id"] = eos_ids

    with torch.inference_mode():
        generated = model.generate(
            **inputs,
            **gen_kwargs,
        )

    input_len = inputs["input_ids"].shape[1]
    new_ids = generated[0, input_len:].detach().cpu().tolist()

    tokenizer = get_tokenizer(processor)

    text = tokenizer.decode(
        new_ids,
        skip_special_tokens=True,
        clean_up_tokenization_spaces=False,
    )

    return clean_translation_output(text)


def generate_text_only_translation(
    model,
    processor,
    source_text: str,
    device: torch.device,
    dtype: torch.dtype,
) -> str:
    messages = build_messages_for_translation(source_text)

    inputs = prepare_inputs_from_messages(
        processor=processor,
        messages=messages,
        image=None,
        device=device,
        dtype=dtype,
    )

    return generate_from_inputs(
        model=model,
        processor=processor,
        inputs=inputs,
        max_new_tokens=MAX_NEW_TOKENS_TRANSLATE,
    )


def generate_local_repair(
    model,
    processor,
    image: Image.Image,
    source_text: str,
    initial_translation: str,
    suspicious_spans: List[Dict[str, Any]],
    device: torch.device,
    dtype: torch.dtype,
) -> str:
    if not suspicious_spans:
        return initial_translation

    messages = build_messages_for_repair(
        source_text=source_text,
        initial_translation=initial_translation,
        suspicious_spans=suspicious_spans,
    )

    inputs = prepare_inputs_from_messages(
        processor=processor,
        messages=messages,
        image=image,
        device=device,
        dtype=dtype,
    )

    repaired = generate_from_inputs(
        model=model,
        processor=processor,
        inputs=inputs,
        max_new_tokens=MAX_NEW_TOKENS_REPAIR,
    )

    if not repaired:
        return initial_translation

    if not is_mostly_english_output(repaired):
        return initial_translation

    return repaired


# =====================================================
# 7. Forced scoring：4 条件 logprob
# =====================================================

def encode_translation_tokens(processor, text: str) -> List[int]:
    tokenizer = get_tokenizer(processor)

    token_ids = tokenizer.encode(
        text,
        add_special_tokens=False,
    )

    return [int(x) for x in token_ids]


def append_target_tokens(
    base_inputs: Dict[str, Any],
    target_ids: List[int],
) -> Dict[str, Any]:
    input_ids = base_inputs["input_ids"]

    target_tensor = torch.tensor(
        [target_ids],
        dtype=input_ids.dtype,
        device=input_ids.device,
    )

    full_input_ids = torch.cat([input_ids, target_tensor], dim=1)

    if "attention_mask" in base_inputs:
        base_mask = base_inputs["attention_mask"]
        target_mask = torch.ones(
            (base_mask.shape[0], len(target_ids)),
            dtype=base_mask.dtype,
            device=base_mask.device,
        )
        attention_mask = torch.cat([base_mask, target_mask], dim=1)
    else:
        attention_mask = torch.ones_like(full_input_ids)

    merged = {}

    for k, v in base_inputs.items():
        if k in ["input_ids", "attention_mask"]:
            continue
        merged[k] = v

    merged["input_ids"] = full_input_ids
    merged["attention_mask"] = attention_mask

    return merged


def forced_logprobs_for_condition(
    model,
    base_inputs: Dict[str, Any],
    target_ids: List[int],
) -> List[float]:
    """
    一次 forward 得到整句每个 target token 的 logprob。

    对 target token 第 i 个 token:
        用 prompt + target_ids[:i] 预测 target_ids[i]

    logits 位置：
        base_len - 1 + i
    """
    if not target_ids:
        return []

    base_len = base_inputs["input_ids"].shape[1]
    full_inputs = append_target_tokens(
        base_inputs=base_inputs,
        target_ids=target_ids,
    )

    with torch.inference_mode():
        outputs = model(
            **full_inputs,
            use_cache=False,
        )

    logits = outputs.logits.float()

    pred_logits = logits[:, base_len - 1: base_len - 1 + len(target_ids), :]
    log_probs = F.log_softmax(pred_logits, dim=-1)

    target_tensor = torch.tensor(
        target_ids,
        dtype=torch.long,
        device=log_probs.device,
    ).view(1, -1, 1)

    gathered = torch.gather(log_probs, dim=-1, index=target_tensor).squeeze(-1)
    return gathered[0].detach().cpu().tolist()


def compute_four_condition_logprobs(
    model,
    processor,
    image: Image.Image,
    source_text: str,
    translation: str,
    device: torch.device,
    dtype: torch.dtype,
) -> Dict[str, Any]:
    target_ids = encode_translation_tokens(processor, translation)

    if not target_ids:
        return {
            "target_ids": [],
            "token_texts": [],
            "text_only": [],
            "full": [],
            "image_only": [],
            "prior_only": [],
        }

    condition_inputs = prepare_four_condition_inputs(
        processor=processor,
        image=image,
        source_text=source_text,
        device=device,
        dtype=dtype,
    )

    tokenizer = get_tokenizer(processor)

    token_texts = [
        tokenizer.decode(
            [tid],
            skip_special_tokens=True,
            clean_up_tokenization_spaces=False,
        )
        for tid in target_ids
    ]

    scores = {
        "target_ids": target_ids,
        "token_texts": token_texts,
        "text_only": forced_logprobs_for_condition(
            model=model,
            base_inputs=condition_inputs["text_only"],
            target_ids=target_ids,
        ),
        "full": forced_logprobs_for_condition(
            model=model,
            base_inputs=condition_inputs["full"],
            target_ids=target_ids,
        ),
        "image_only": forced_logprobs_for_condition(
            model=model,
            base_inputs=condition_inputs["image_only"],
            target_ids=target_ids,
        ),
        "prior_only": forced_logprobs_for_condition(
            model=model,
            base_inputs=condition_inputs["prior_only"],
            target_ids=target_ids,
        ),
    }

    return scores


# =====================================================
# 8. Contrast 检测可疑 token/span
# =====================================================

def is_punctuation_or_empty(token_text: str) -> bool:
    t = token_text.strip()
    if not t:
        return True
    return re.fullmatch(r"[\W_]+", t, flags=re.UNICODE) is not None


def compute_token_risk_scores(logprob_info: Dict[str, Any]) -> List[float]:
    """
    contrast logits 不直接用于生成，只用于风险检测。

    这里的风险分数由三个通用信号组成：

    1. image_only 比 text_only 更支持该 token:
        max(0, logp_image - logp_text)

    2. prior_only 比 text_only 更支持该 token:
        max(0, logp_prior - logp_text)

    3. 加入图像后 full 反而低于 text_only:
        max(0, logp_text - logp_full)

    直觉：
        如果某个 token 不是由源句文本稳定支持，
        却容易由图像先验或语言先验产生，
        或者 full 条件不支持它，
        则它更适合作为局部修复候选。
    """
    text_scores = logprob_info.get("text_only", [])
    full_scores = logprob_info.get("full", [])
    image_scores = logprob_info.get("image_only", [])
    prior_scores = logprob_info.get("prior_only", [])
    token_texts = logprob_info.get("token_texts", [])

    n = min(
        len(text_scores),
        len(full_scores),
        len(image_scores),
        len(prior_scores),
        len(token_texts),
    )

    risks = []

    for i in range(n):
        if is_punctuation_or_empty(token_texts[i]):
            risks.append(0.0)
            continue

        logp_text = float(text_scores[i])
        logp_full = float(full_scores[i])
        logp_image = float(image_scores[i])
        logp_prior = float(prior_scores[i])

        risk = 0.0
        risk += max(0.0, logp_image - logp_text)
        risk += max(0.0, logp_prior - logp_text)
        risk += max(0.0, logp_text - logp_full)

        risks.append(round(risk, 6))

    return risks


def robust_suspicious_indices(risks: List[float]) -> List[int]:
    """
    使用样本内部的分布自适应选择异常 token。
    不使用具体词表，也不使用任务相关词规则。

    方法：
        upper fence = Q3 + IQR
        risk > upper fence 的 token 作为可疑 token

    如果所有 risk 都接近 0，则不返回可疑 token。
    """
    valid = [x for x in risks if x > 0]

    if not valid:
        return []

    arr = np.array(valid, dtype=np.float32)

    q1 = float(np.percentile(arr, 25))
    q3 = float(np.percentile(arr, 75))
    iqr = q3 - q1
    fence = q3 + iqr

    indices = [
        i for i, r in enumerate(risks)
        if r > fence and r > 0
    ]

    return indices


def build_token_offsets(token_texts: List[str]) -> Tuple[str, List[Tuple[int, int]]]:
    text = ""
    offsets = []

    for tok in token_texts:
        start = len(text)
        text += tok
        end = len(text)
        offsets.append((start, end))

    return text, offsets


def normalize_span_text(span: str) -> str:
    span = span.strip()
    span = re.sub(r"\s+", " ", span).strip()
    span = span.strip(" ,.;:!?\"'")
    return span


def merge_indices_to_spans(
    suspicious_indices: List[int],
    risks: List[float],
    logprob_info: Dict[str, Any],
) -> List[Dict[str, Any]]:
    if not suspicious_indices:
        return []

    token_texts = logprob_info.get("token_texts", [])
    text_scores = logprob_info.get("text_only", [])
    full_scores = logprob_info.get("full", [])
    image_scores = logprob_info.get("image_only", [])
    prior_scores = logprob_info.get("prior_only", [])

    suspicious_indices = sorted(set(suspicious_indices))

    groups = []
    cur = [suspicious_indices[0]]

    for idx in suspicious_indices[1:]:
        if idx == cur[-1] + 1:
            cur.append(idx)
        else:
            groups.append(cur)
            cur = [idx]

    groups.append(cur)

    decoded_text, offsets = build_token_offsets(token_texts)

    spans = []

    for group in groups:
        start_i = group[0]
        end_i = group[-1]

        if start_i >= len(offsets) or end_i >= len(offsets):
            continue

        char_start = offsets[start_i][0]
        char_end = offsets[end_i][1]

        span_text = decoded_text[char_start:char_end]
        span_text = normalize_span_text(span_text)

        if not span_text:
            continue

        mean_risk = sum(risks[i] for i in group) / max(1, len(group))

        def safe_mean(values):
            xs = []
            for i in group:
                if i < len(values):
                    xs.append(float(values[i]))
            if not xs:
                return float("nan")
            return sum(xs) / len(xs)

        spans.append({
            "span": span_text,
            "start_token": int(start_i),
            "end_token": int(end_i),
            "mean_risk": round(float(mean_risk), 6),
            "mean_logp_text_only": round(safe_mean(text_scores), 6),
            "mean_logp_full": round(safe_mean(full_scores), 6),
            "mean_logp_image_only": round(safe_mean(image_scores), 6),
            "mean_logp_prior_only": round(safe_mean(prior_scores), 6),
        })

    spans.sort(key=lambda x: x.get("mean_risk", 0.0), reverse=True)
    return spans


def detect_suspicious_spans(
    model,
    processor,
    image: Image.Image,
    source_text: str,
    translation: str,
    device: torch.device,
    dtype: torch.dtype,
) -> Dict[str, Any]:
    logprob_info = compute_four_condition_logprobs(
        model=model,
        processor=processor,
        image=image,
        source_text=source_text,
        translation=translation,
        device=device,
        dtype=dtype,
    )

    risks = compute_token_risk_scores(logprob_info)
    suspicious_indices = robust_suspicious_indices(risks)

    spans = merge_indices_to_spans(
        suspicious_indices=suspicious_indices,
        risks=risks,
        logprob_info=logprob_info,
    )

    token_diag = []
    token_texts = logprob_info.get("token_texts", [])
    target_ids = logprob_info.get("target_ids", [])

    for i, tok in enumerate(token_texts):
        token_diag.append({
            "idx": i,
            "token_id": int(target_ids[i]) if i < len(target_ids) else None,
            "token": tok,
            "risk": risks[i] if i < len(risks) else 0.0,
            "logp_text_only": logprob_info["text_only"][i] if i < len(logprob_info["text_only"]) else None,
            "logp_full": logprob_info["full"][i] if i < len(logprob_info["full"]) else None,
            "logp_image_only": logprob_info["image_only"][i] if i < len(logprob_info["image_only"]) else None,
            "logp_prior_only": logprob_info["prior_only"][i] if i < len(logprob_info["prior_only"]) else None,
        })

    return {
        "suspicious_spans": spans,
        "token_risk_diag": token_diag,
    }


# =====================================================
# 9. 单样本流程
# =====================================================

def process_one_row(
    model,
    processor,
    row: Dict[str, Any],
    idx: int,
    device: torch.device,
    dtype: torch.dtype,
) -> Dict[str, Any]:
    out = dict(row)

    row_id = get_row_id(row, fallback_idx=idx)

    source_text = normalize_text(row.get(SOURCE_FIELD, ""))
    reference_translation = normalize_text(row.get(REFERENCE_FIELD, ""))

    if not source_text:
        raise ValueError(f"missing source field: {SOURCE_FIELD}")

    image_path = resolve_image_path(row)

    if not image_path:
        raise FileNotFoundError(f"cannot resolve image path for id={row_id}")

    image = load_rgb_image(image_path)

    existing_initial = normalize_text(row.get("initial_translation_en", ""))

    if USE_EXISTING_INITIAL_IF_PRESENT and existing_initial:
        text_only_translation = existing_initial
        used_existing_initial = True
    else:
        text_only_translation = generate_text_only_translation(
            model=model,
            processor=processor,
            source_text=source_text,
            device=device,
            dtype=dtype,
        )
        used_existing_initial = False

    text_only_translation = clean_translation_output(text_only_translation)

    detect_result = detect_suspicious_spans(
        model=model,
        processor=processor,
        image=image,
        source_text=source_text,
        translation=text_only_translation,
        device=device,
        dtype=dtype,
    )

    suspicious_spans = detect_result["suspicious_spans"]

    repair_spans = suspicious_spans[:MAX_REPAIR_SPANS]

    if suspicious_spans:
        primary_span = [suspicious_spans[0]]
    else:
        primary_span = []

    candidate_1 = generate_local_repair(
        model=model,
        processor=processor,
        image=image,
        source_text=source_text,
        initial_translation=text_only_translation,
        suspicious_spans=primary_span,
        device=device,
        dtype=dtype,
    )

    candidate_2 = generate_local_repair(
        model=model,
        processor=processor,
        image=image,
        source_text=source_text,
        initial_translation=text_only_translation,
        suspicious_spans=repair_spans,
        device=device,
        dtype=dtype,
    )

    candidate_3 = text_only_translation

    out["source_text"] = source_text
    out["reference_translation"] = reference_translation
    out[OUTPUT_FIELD_TEXT_ONLY] = text_only_translation
    out["text_only_used_existing_initial"] = used_existing_initial

    out["suspicious_spans"] = suspicious_spans
    out["token_risk_diag"] = detect_result["token_risk_diag"]

    out["candidate_1"] = candidate_1
    out["candidate_1_strategy"] = "local_repair_primary_suspicious_span"

    out["candidate_2"] = candidate_2
    out["candidate_2_strategy"] = "local_repair_all_suspicious_spans"

    out["candidate_3"] = candidate_3
    out["candidate_3_strategy"] = "keep_text_only_translation"

    out["image_path_used"] = image_path

    out["config"] = {
        "main_translation": "text_only_generate_or_existing_initial",
        "contrast_usage": "detection_only",
        "repair_usage": "local_candidate_generation_only",
        "not_used": "contrast_logits_are_not_used_for_step_by_step_full_sentence_decoding",
        "risk_formula": "max(0, image_only-text_only) + max(0, prior_only-text_only) + max(0, text_only-full)",
        "suspicious_selection": "within_sentence_upper_fence_Q3_plus_IQR",
        "model_path": MODEL_PATH,
        "source_field": SOURCE_FIELD,
        "reference_field": REFERENCE_FIELD,
        "image_field": IMAGE_FIELD,
        "dtype": DTYPE_NAME,
        "max_new_tokens_translate": MAX_NEW_TOKENS_TRANSLATE,
        "max_new_tokens_repair": MAX_NEW_TOKENS_REPAIR,
        "max_repair_spans": MAX_REPAIR_SPANS,
        "seed": SEED,
    }

    return out


# =====================================================
# 10. 模型加载
# =====================================================

def load_model_and_processor(
    model_path: str,
    dtype: torch.dtype,
    device: torch.device,
):
    if Qwen2VLForConditionalGeneration is None:
        raise ImportError(
            "当前 transformers 环境无法导入 Qwen2VLForConditionalGeneration。"
            "请确认该环境支持 Qwen2-VL。"
        )

    processor = AutoProcessor.from_pretrained(
        model_path,
        trust_remote_code=True,
        local_files_only=True,
    )

    model = Qwen2VLForConditionalGeneration.from_pretrained(
        model_path,
        torch_dtype=dtype,
        trust_remote_code=True,
        local_files_only=True,
    )

    model.to(device)
    model.eval()

    return model, processor


# =====================================================
# 11. 主程序
# =====================================================

def main():
    torch.manual_seed(SEED)
    np.random.seed(SEED)

    input_jsonl, output_jsonl = get_paths(LANGUAGE)
    ensure_dir(output_jsonl)

    dtype = get_torch_dtype(DTYPE_NAME)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    print("========== Runtime Config ==========")
    print(f"[INFO] LANGUAGE: {LANGUAGE}")
    print(f"[INFO] GPU: {GPU}")
    print(f"[INFO] CUDA_VISIBLE_DEVICES: {os.environ.get('CUDA_VISIBLE_DEVICES')}")
    print(f"[INFO] torch.cuda.is_available: {torch.cuda.is_available()}")
    print(f"[INFO] torch.cuda.device_count: {torch.cuda.device_count()}")
    print(f"[INFO] device: {device}")
    print(f"[INFO] dtype: {DTYPE_NAME}")
    print(f"[INFO] MODEL_PATH: {MODEL_PATH}")
    print(f"[INFO] INPUT_JSONL: {input_jsonl}")
    print(f"[INFO] OUTPUT_JSONL: {output_jsonl}")
    print("====================================")

    if not os.path.exists(input_jsonl):
        raise FileNotFoundError(f"输入文件不存在: {input_jsonl}")

    print("[INFO] loading model...", flush=True)

    model, processor = load_model_and_processor(
        model_path=MODEL_PATH,
        dtype=dtype,
        device=device,
    )

    print("[INFO] model loaded.", flush=True)

    rows = read_jsonl(input_jsonl)
    total = len(rows)

    print(f"[INFO] read rows: {total}", flush=True)

    stats = {
        "total": total,
        "saved": 0,
        "error": 0,
        "has_suspicious": 0,
        "no_suspicious": 0,
        "candidate_1_changed": 0,
        "candidate_2_changed": 0,
        "used_existing_initial": 0,
    }

    start_time = time.time()

    for idx, row in enumerate(rows, start=1):
        iter_start = time.time()
        row_id = get_row_id(row, fallback_idx=idx)

        try:
            out = process_one_row(
                model=model,
                processor=processor,
                row=row,
                idx=idx,
                device=device,
                dtype=dtype,
            )

            suspicious_spans = out.get("suspicious_spans", [])

            if suspicious_spans:
                stats["has_suspicious"] += 1
            else:
                stats["no_suspicious"] += 1

            text_only = normalize_text(out.get(OUTPUT_FIELD_TEXT_ONLY, ""))
            c1 = normalize_text(out.get("candidate_1", ""))
            c2 = normalize_text(out.get("candidate_2", ""))

            if c1 and c1 != text_only:
                stats["candidate_1_changed"] += 1

            if c2 and c2 != text_only:
                stats["candidate_2_changed"] += 1

            if out.get("text_only_used_existing_initial", False):
                stats["used_existing_initial"] += 1

        except Exception as e:
            stats["error"] += 1
            out = dict(row)
            out["error"] = repr(e)
            out[OUTPUT_FIELD_TEXT_ONLY] = ""
            out["suspicious_spans"] = []
            out["token_risk_diag"] = []
            out["candidate_1"] = ""
            out["candidate_2"] = ""
            out["candidate_3"] = ""

        append_jsonl(output_jsonl, out)
        stats["saved"] += 1

        elapsed = time.time() - start_time
        avg = elapsed / max(1, idx)
        eta = avg * max(0, total - idx)
        finish_time = time.strftime(
            "%Y-%m-%d %H:%M:%S",
            time.localtime(time.time() + eta),
        )
        iter_time = time.time() - iter_start

        print(
            f"[{idx}/{total}] id={row_id} | iter={iter_time:.2f}s | "
            f"ETA={format_seconds(eta)} | finish={finish_time} | "
            f"saved={stats['saved']} | error={stats['error']} | "
            f"has_suspicious={stats['has_suspicious']} | "
            f"c1_changed={stats['candidate_1_changed']} | "
            f"c2_changed={stats['candidate_2_changed']}",
            flush=True,
        )

    print("[done] " + json.dumps(stats, ensure_ascii=False), flush=True)
    print(f"[INFO] output saved to: {output_jsonl}", flush=True)


if __name__ == "__main__":
    main()