#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
text_main_contrast_translation_qwen2vl_multi30k.py

功能：
1. 读取 Multi30K 低资源语言输入：
   /mnt/raid/cycy/data/txt_multi30k/en_{lang}_test.jsonl

   常见字段：
   {
     "image_id": 1007129816,
     "image": "/mnt/raid/wjx/vision-rag-mt/images_multi30k/1007129816.jpg",
     "source": "A man in an orange hat starring at something.",
     "target": "नारंगी रंग की टोपी पहने एक आदमी किसी चीज़ पर अभिनय कर रहा है।"
   }

2. 使用 Qwen2-VL-7B-Instruct 做 text-main contrastive decoding。

3. 每一步生成 token 时计算三种条件 logits：
   - logits_text  : source-only / text-only
   - logits_full  : source + image
   - logits_prior : source hidden, no image

4. 使用公式：
   new_logits = logits_text + CONTRAST_ALPHA * (logits_full - logits_prior)

5. 使用 HEAD_BETA 做 text-head plausibility constraint：
   只允许 text-only 概率不低于 HEAD_BETA * max_text_prob 的 token 进入最终 argmax。
   这样可以防止视觉对比项把输出拉到 source 不支持的视觉猜测上。

6. 输出：
   /home/chenyi/offline_blaser_qe/out/Qwen2_VL_7B/Multi30k/{lang}/{lang}_text_main_contrast_translation.jsonl

输出字段包括：
   - source_text
   - reference_translation
   - text_main_contrast_translation_en

后续评分脚本可以直接读取 text_main_contrast_translation_en 字段。
"""

import os
import argparse

# =====================================================
# 0. 命令行参数：必须在 import torch 前解析并设置 GPU
# =====================================================

ALLOWED_LANGUAGES = {"hi", "lv", "tr"}


def parse_args():
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--lang",
        type=str,
        required=True,
        choices=sorted(ALLOWED_LANGUAGES),
        help="Language code: hi, lv, tr.",
    )

    parser.add_argument(
        "--gpu",
        type=str,
        required=True,
        help="Physical GPU id, for example: 0, 1, 2, 5, 6, 7.",
    )

    parser.add_argument(
        "--max_new_tokens",
        type=int,
        default=64,
        help="Maximum generated English tokens.",
    )

    return parser.parse_args()


ARGS = parse_args()
LANGUAGE = ARGS.lang
GPU = ARGS.gpu
MAX_NEW_TOKENS = ARGS.max_new_tokens

# ====== 环境变量必须在 import torch 前设置 ======
os.environ["CUDA_VISIBLE_DEVICES"] = str(GPU)
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"

os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"
os.environ["TOKENIZERS_PARALLELISM"] = "false"

os.environ["HF_HOME"] = "/home/chenyi/model_cache/huggingface"
os.environ["TRANSFORMERS_CACHE"] = "/home/chenyi/model_cache/huggingface/hub"

SYSLIBS_DIR = "/home/chenyi/offline_blaser_qe/syslibs"
os.environ["LD_LIBRARY_PATH"] = SYSLIBS_DIR + ":" + os.environ.get("LD_LIBRARY_PATH", "")

import re
import json
import time
import warnings
from typing import Dict, Any, List, Optional, Tuple

from PIL import Image

import torch
import torch.nn.functional as F
from transformers import AutoProcessor

try:
    from transformers import Qwen2VLForConditionalGeneration
except Exception:
    Qwen2VLForConditionalGeneration = None


warnings.filterwarnings("ignore", category=UserWarning)
torch.set_grad_enabled(False)


# =====================================================
# 1. 固定配置
# =====================================================

MODEL_PATH = "/mnt/raid/hss/model/Qwen2-VL-7B-Instruct"

INPUT_ROOT = "/mnt/raid/cycy/data/txt_multi30k"
OUTPUT_ROOT = "/home/chenyi/offline_blaser_qe/out/Qwen2_VL_7B/Multi30k"
IMAGE_DIR = "/mnt/raid/wjx/vision-rag-mt/images_multi30k"

DTYPE_NAME = "bfloat16"

# =====================================================
# 样本量控制：写在程序里，可直接修改
# =====================================================
# None 表示跑全量
# 例如：
# MAX_SAMPLES = 100   表示只跑前100条
# MAX_SAMPLES = 1000  表示只跑前1000条
MAX_SAMPLES = 100

# ====== contrastive decoding 参数 ======
CONTRAST_ALPHA = 0.1
HEAD_BETA = 0.1

# 至少生成 1 个 token 后才允许 EOS，避免第一步直接空输出
MIN_NEW_TOKENS = 1

SEED = 42

SOURCE_FIELD_PRIMARY = "target"
SOURCE_FIELD_FALLBACK = "source_text"

REFERENCE_FIELD_PRIMARY = "reference_translation"
REFERENCE_FIELD_FALLBACK = "source"

OUTPUT_FIELD = "text_main_contrast_translation_en"


# =====================================================
# 2. 路径与基础工具
# =====================================================

def contrast_formula_str() -> str:
    return f"new_logits = logits_text + {CONTRAST_ALPHA} * (logits_full - logits_prior)"


def get_paths(lang: str) -> Tuple[str, str]:
    input_jsonl = os.path.join(
        INPUT_ROOT,
        f"en_{lang}_test.jsonl",
    )

    output_dir = os.path.join(
        OUTPUT_ROOT,
        lang,
    )

    output_jsonl = os.path.join(
        output_dir,
        f"{lang}_text_main_contrast_translation.jsonl",
    )

    return input_jsonl, output_jsonl


def get_torch_dtype(name: str):
    if name == "float16":
        return torch.float16
    if name == "bfloat16":
        return torch.bfloat16
    return torch.float32


def ensure_dir(path: str):
    d = os.path.dirname(os.path.abspath(path))
    if d:
        os.makedirs(d, exist_ok=True)


def read_jsonl(path: str, max_samples: Optional[int] = None) -> List[Dict[str, Any]]:
    rows = []

    with open(path, "r", encoding="utf-8") as f:
        for line_idx, line in enumerate(f, start=1):
            line = line.strip()

            if not line:
                continue

            try:
                rows.append(json.loads(line))
            except Exception as e:
                print(f"[WARN] JSON parse failed at line {line_idx}: {e}", flush=True)
                continue

            if max_samples is not None and len(rows) >= max_samples:
                break

    return rows


def init_jsonl(path: str):
    ensure_dir(path)
    with open(path, "w", encoding="utf-8"):
        pass


def append_jsonl(path: str, row: Dict[str, Any]):
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(row, ensure_ascii=False) + "\n")


def normalize_text(x: Any) -> str:
    if x is None:
        return ""
    return str(x).strip()


def first_non_empty(row: Dict[str, Any], fields: List[str]) -> str:
    for field in fields:
        value = normalize_text(row.get(field, ""))
        if value:
            return value
    return ""


def clean_translation_output(text: str) -> str:
    text = normalize_text(text)

    bad_prefixes = [
        "Translation:",
        "English translation:",
        "The English translation is:",
        "Output:",
        "Answer:",
        "Final translation:",
        "Final answer:",
    ]

    for p in bad_prefixes:
        if text.lower().startswith(p.lower()):
            text = text[len(p):].strip()

    lines = [x.strip() for x in text.splitlines() if x.strip()]
    if lines:
        text = lines[0]

    text = text.strip().strip('"').strip("'").strip()
    text = re.sub(r"\s+", " ", text).strip()

    return text


def get_row_id(row: Dict[str, Any], fallback_idx: int) -> str:
    for k in ["id", "image_id", "qid", "question_id"]:
        if k in row and row[k] is not None:
            return str(row[k])
    return str(fallback_idx)


def format_seconds(sec: float) -> str:
    sec = max(0, int(sec))
    h = sec // 3600
    m = (sec % 3600) // 60
    s = sec % 60
    return f"{h:02d}:{m:02d}:{s:02d}"


def is_mostly_english_output(text: str) -> bool:
    if not text:
        return False

    bad_script_pattern = re.compile(
        r"[\u4e00-\u9fff\u3400-\u4dbf"
        r"\u3040-\u30ff"
        r"\uac00-\ud7af"
        r"\u0900-\u097f"
        r"\u0980-\u09ff"
        r"\u0d00-\u0d7f"
        r"\u0600-\u06ff]"
    )

    return bad_script_pattern.search(text) is None


def cleanup_cuda():
    if torch.cuda.is_available():
        torch.cuda.empty_cache()


# =====================================================
# 3. 图片路径解析
# =====================================================

def resolve_image_path(row: Dict[str, Any]) -> Optional[str]:
    for k in ["image_path", "image"]:
        if row.get(k):
            p = str(row[k])
            if os.path.exists(p):
                return p

    image_id = row.get("image_id", row.get("id", None))
    if image_id is None:
        return None

    image_id = str(image_id)

    for ext in [".jpg", ".jpeg", ".png", ".webp"]:
        p = os.path.join(IMAGE_DIR, image_id + ext)
        if os.path.exists(p):
            return p

    return None


def load_rgb_image(path: str) -> Image.Image:
    return Image.open(path).convert("RGB")


# =====================================================
# 4. Prompt
# =====================================================

def build_translate_system_prompt() -> str:
    return (
        "You are a professional translator. "
        "Your job is to translate the given source sentence into English. "
        "STRICT RULES: "
        "1. Be faithful to the source sentence. "
        "2. Do NOT add, remove, or change objects, attributes, actions, or relations. "
        "3. Use the image only when it helps resolve ambiguity. "
        "4. Do not turn the task into image captioning. "
        "5. Output ONLY the English translation. "
        "6. No explanations. "
        "7. Do NOT output any thinking process or <think>...</think> content."
    )


def build_condition_user_prompt(source_text: str, source_visible: bool) -> str:
    if source_visible:
        src = source_text
    else:
        src = "[SOURCE SENTENCE HIDDEN]"

    return (
        "Translate the following source sentence into English.\n"
        f"Source sentence: {src}\n"
        "Output only the English translation."
    )


def build_messages_for_condition(
    source_text: str,
    use_image: bool,
    source_visible: bool,
):
    user_content = []

    if use_image:
        user_content.append({"type": "image"})

    user_content.append(
        {
            "type": "text",
            "text": build_condition_user_prompt(
                source_text=source_text,
                source_visible=source_visible,
            ),
        }
    )

    return [
        {
            "role": "system",
            "content": build_translate_system_prompt(),
        },
        {
            "role": "user",
            "content": user_content,
        },
    ]


# =====================================================
# 5. Qwen2-VL 输入
# =====================================================

def get_tokenizer(processor):
    tokenizer = getattr(processor, "tokenizer", None)
    if tokenizer is None:
        raise RuntimeError("processor.tokenizer is None")
    return tokenizer


def move_inputs_to_device(
    inputs: Dict[str, Any],
    device: torch.device,
    dtype: torch.dtype,
) -> Dict[str, Any]:
    moved = {}

    for k, v in inputs.items():
        if torch.is_tensor(v):
            if torch.is_floating_point(v):
                moved[k] = v.to(device=device, dtype=dtype)
            else:
                moved[k] = v.to(device=device)
        else:
            moved[k] = v

    return moved


def prepare_inputs_from_messages(
    processor,
    messages,
    device: torch.device,
    dtype: torch.dtype,
    image: Optional[Image.Image] = None,
) -> Dict[str, Any]:
    text = processor.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True,
    )

    if image is not None:
        inputs = processor(
            text=[text],
            images=[image],
            padding=True,
            return_tensors="pt",
        )
    else:
        inputs = processor(
            text=[text],
            padding=True,
            return_tensors="pt",
        )

    return move_inputs_to_device(
        inputs=inputs,
        device=device,
        dtype=dtype,
    )


def prepare_condition_inputs(
    processor,
    image: Optional[Image.Image],
    source_text: str,
    use_image: bool,
    source_visible: bool,
    device: torch.device,
    dtype: torch.dtype,
) -> Dict[str, Any]:
    messages = build_messages_for_condition(
        source_text=source_text,
        use_image=use_image,
        source_visible=source_visible,
    )

    actual_image = image if use_image else None

    return prepare_inputs_from_messages(
        processor=processor,
        messages=messages,
        image=actual_image,
        device=device,
        dtype=dtype,
    )


def prepare_three_condition_inputs(
    processor,
    image: Image.Image,
    source_text: str,
    device: torch.device,
    dtype: torch.dtype,
) -> Dict[str, Dict[str, Any]]:
    return {
        "text": prepare_condition_inputs(
            processor=processor,
            image=None,
            source_text=source_text,
            use_image=False,
            source_visible=True,
            device=device,
            dtype=dtype,
        ),
        "full": prepare_condition_inputs(
            processor=processor,
            image=image,
            source_text=source_text,
            use_image=True,
            source_visible=True,
            device=device,
            dtype=dtype,
        ),
        "prior": prepare_condition_inputs(
            processor=processor,
            image=None,
            source_text=source_text,
            use_image=False,
            source_visible=False,
            device=device,
            dtype=dtype,
        ),
    }


# =====================================================
# 6. EOS / PAD
# =====================================================

def get_pad_eos_ids(processor, model) -> Tuple[Optional[int], List[int]]:
    tokenizer = get_tokenizer(processor)

    pad_token_id = tokenizer.pad_token_id
    eos_ids = []

    if tokenizer.eos_token_id is not None:
        eos_ids.append(int(tokenizer.eos_token_id))

    for tok in ["<|im_end|>", "<|endoftext|>"]:
        try:
            tid = tokenizer.convert_tokens_to_ids(tok)
            if isinstance(tid, int) and tid >= 0:
                eos_ids.append(tid)
        except Exception:
            pass

    gen_cfg = getattr(model, "generation_config", None)

    if gen_cfg is not None:
        eid = getattr(gen_cfg, "eos_token_id", None)

        if isinstance(eid, int):
            eos_ids.append(eid)
        elif isinstance(eid, (list, tuple)):
            for x in eid:
                if x is not None:
                    eos_ids.append(int(x))

    eos_ids = sorted(set(eos_ids))

    return pad_token_id, eos_ids


# =====================================================
# 7. Contrastive decoding 核心
# =====================================================

def build_step_inputs(
    base_inputs: Dict[str, Any],
    generated_ids: List[int],
) -> Dict[str, Any]:
    base_input_ids = base_inputs["input_ids"]
    device = base_input_ids.device

    merged = {}

    for k, v in base_inputs.items():
        if k in ["input_ids", "attention_mask"]:
            continue
        merged[k] = v

    if generated_ids:
        gen_tensor = torch.tensor(
            [generated_ids],
            dtype=base_input_ids.dtype,
            device=device,
        )
        input_ids = torch.cat([base_input_ids, gen_tensor], dim=1)
    else:
        input_ids = base_input_ids

    if "attention_mask" in base_inputs:
        base_mask = base_inputs["attention_mask"]

        if generated_ids:
            gen_mask = torch.ones(
                (base_mask.shape[0], len(generated_ids)),
                dtype=base_mask.dtype,
                device=base_mask.device,
            )
            attention_mask = torch.cat([base_mask, gen_mask], dim=1)
        else:
            attention_mask = base_mask
    else:
        attention_mask = torch.ones_like(input_ids)

    merged["input_ids"] = input_ids
    merged["attention_mask"] = attention_mask

    return merged


def get_next_logits_no_cache(
    model,
    base_inputs: Dict[str, Any],
    generated_ids: List[int],
) -> torch.Tensor:
    step_inputs = build_step_inputs(
        base_inputs=base_inputs,
        generated_ids=generated_ids,
    )

    with torch.inference_mode():
        outputs = model(
            **step_inputs,
            use_cache=False,
        )

    logits = outputs.logits[:, -1, :].float()
    return logits


def sanitize_logits(logits: torch.Tensor) -> torch.Tensor:
    logits = logits.float()
    logits = torch.nan_to_num(
        logits,
        nan=-1e4,
        posinf=1e4,
        neginf=-1e4,
    )
    return logits


def apply_text_head_constraint(
    new_logits: torch.Tensor,
    logits_text: torch.Tensor,
    head_beta: float,
    eos_ids: List[int],
    step_idx: int,
) -> torch.Tensor:
    """
    Text-head plausibility constraint.

    保留：
        p_text(token) >= HEAD_BETA * max_token p_text(token)

    作用：
        让 text-only 作为主模型，防止 full-prior 视觉对比项把输出推向 source 不支持的 token。
    """

    if head_beta is None or head_beta <= 0:
        return new_logits

    probs_text = F.softmax(logits_text.float(), dim=-1)
    max_prob = torch.max(probs_text, dim=-1, keepdim=True).values

    head_mask = probs_text >= (float(head_beta) * max_prob)

    # 生成至少 MIN_NEW_TOKENS 后，允许 EOS 结束。
    if step_idx >= MIN_NEW_TOKENS:
        for eid in eos_ids:
            if 0 <= eid < head_mask.shape[-1]:
                head_mask[:, eid] = True

    # 理论上 max token 一定被保留；这里做保险。
    if not bool(head_mask.any().item()):
        top_id = torch.argmax(logits_text, dim=-1, keepdim=True)
        head_mask.scatter_(dim=-1, index=top_id, value=True)

    filtered_logits = new_logits.masked_fill(~head_mask, -1e9)

    return filtered_logits


def contrastive_next_logits(
    model,
    condition_inputs: Dict[str, Dict[str, Any]],
    generated_ids: List[int],
    eos_ids: List[int],
    step_idx: int,
) -> Tuple[torch.Tensor, Dict[str, Any]]:
    logits_text = get_next_logits_no_cache(
        model=model,
        base_inputs=condition_inputs["text"],
        generated_ids=generated_ids,
    )

    logits_full = get_next_logits_no_cache(
        model=model,
        base_inputs=condition_inputs["full"],
        generated_ids=generated_ids,
    )

    logits_prior = get_next_logits_no_cache(
        model=model,
        base_inputs=condition_inputs["prior"],
        generated_ids=generated_ids,
    )

    logits_text = sanitize_logits(logits_text)
    logits_full = sanitize_logits(logits_full)
    logits_prior = sanitize_logits(logits_prior)

    # =====================================================
    # 核心公式
    # =====================================================
    new_logits = logits_text + CONTRAST_ALPHA * (logits_full - logits_prior)

    new_logits = sanitize_logits(new_logits)

    # =====================================================
    # HEAD_BETA 约束
    # =====================================================
    new_logits = apply_text_head_constraint(
        new_logits=new_logits,
        logits_text=logits_text,
        head_beta=HEAD_BETA,
        eos_ids=eos_ids,
        step_idx=step_idx,
    )

    diag = {
        "contrast_alpha": CONTRAST_ALPHA,
        "head_beta": HEAD_BETA,
    }

    return new_logits, diag


def decode_generated_ids(
    processor,
    generated_ids: List[int],
) -> str:
    tokenizer = get_tokenizer(processor)

    text = tokenizer.decode(
        generated_ids,
        skip_special_tokens=True,
        clean_up_tokenization_spaces=False,
    )

    return clean_translation_output(text)


def generate_text_main_contrast_translation(
    model,
    processor,
    image: Image.Image,
    source_text: str,
    device: torch.device,
    dtype: torch.dtype,
    max_new_tokens: int,
) -> Tuple[str, Dict[str, Any]]:
    _, eos_ids = get_pad_eos_ids(processor, model)

    condition_inputs = prepare_three_condition_inputs(
        processor=processor,
        image=image,
        source_text=source_text,
        device=device,
        dtype=dtype,
    )

    generated_ids: List[int] = []
    step_diag: List[Dict[str, Any]] = []

    for step_idx in range(max_new_tokens):
        new_logits, diag = contrastive_next_logits(
            model=model,
            condition_inputs=condition_inputs,
            generated_ids=generated_ids,
            eos_ids=eos_ids,
            step_idx=step_idx,
        )

        next_id = int(torch.argmax(new_logits, dim=-1).item())

        diag["step"] = step_idx
        diag["next_id"] = next_id
        diag["is_eos"] = next_id in eos_ids
        step_diag.append(diag)

        if next_id in eos_ids and step_idx >= MIN_NEW_TOKENS:
            break

        generated_ids.append(next_id)

    text = decode_generated_ids(
        processor=processor,
        generated_ids=generated_ids,
    )

    info = {
        "generated_token_count": len(generated_ids),
        "stopped_by_eos": bool(step_diag[-1]["is_eos"]) if step_diag else False,
        "max_new_tokens": max_new_tokens,
        "contrast_formula": contrast_formula_str(),
        "contrast_alpha": CONTRAST_ALPHA,
        "head_beta": HEAD_BETA,
        "head_constraint": "p_text(token) >= HEAD_BETA * max_token p_text(token)",
    }

    return text, info


# =====================================================
# 8. 单样本处理
# =====================================================

def process_one_row(
    model,
    processor,
    row: Dict[str, Any],
    idx: int,
    device: torch.device,
    dtype: torch.dtype,
    max_new_tokens: int,
) -> Dict[str, Any]:
    out = dict(row)

    row_id = get_row_id(row, fallback_idx=idx)

    source_text = first_non_empty(
        row,
        [
            SOURCE_FIELD_PRIMARY,
            SOURCE_FIELD_FALLBACK,
        ],
    )

    reference_translation = first_non_empty(
        row,
        [
            REFERENCE_FIELD_PRIMARY,
            REFERENCE_FIELD_FALLBACK,
        ],
    )

    if not source_text:
        raise ValueError("missing source text: target/source_text")

    image_path = resolve_image_path(row)

    if not image_path:
        raise FileNotFoundError(f"cannot resolve image path for id={row_id}")

    image = load_rgb_image(image_path)

    translation, generation_info = generate_text_main_contrast_translation(
        model=model,
        processor=processor,
        image=image,
        source_text=source_text,
        device=device,
        dtype=dtype,
        max_new_tokens=max_new_tokens,
    )

    if not translation:
        raise RuntimeError("empty generation output")

    if not is_mostly_english_output(translation):
        raise RuntimeError(f"non-English or invalid generation output: {translation}")

    out["id"] = row_id
    out["source_text"] = source_text
    out["reference_translation"] = reference_translation
    out[OUTPUT_FIELD] = translation
    out["image_path_used"] = image_path

    out["generation_config"] = {
        "model_path": MODEL_PATH,
        "dtype": DTYPE_NAME,
        "decoding": "greedy_text_main_contrastive",
        "formula": contrast_formula_str(),
        "contrast_alpha": CONTRAST_ALPHA,
        "head_beta": HEAD_BETA,
        "min_new_tokens": MIN_NEW_TOKENS,
        "max_new_tokens": max_new_tokens,
        "max_samples": MAX_SAMPLES,
        "text_condition": "source visible, no image",
        "full_condition": "source visible, image visible",
        "prior_condition": "source hidden, no image",
        "generation_info": generation_info,
    }

    return out


# =====================================================
# 9. 模型加载
# =====================================================

def load_model_and_processor(
    model_path: str,
    dtype: torch.dtype,
    device: torch.device,
):
    if Qwen2VLForConditionalGeneration is None:
        raise ImportError(
            "当前 transformers 环境无法导入 Qwen2VLForConditionalGeneration。"
            "请确认该环境支持 Qwen2-VL。"
        )

    processor = AutoProcessor.from_pretrained(
        model_path,
        trust_remote_code=True,
        local_files_only=True,
    )

    model = Qwen2VLForConditionalGeneration.from_pretrained(
        model_path,
        torch_dtype=dtype,
        trust_remote_code=True,
        local_files_only=True,
    )

    model.to(device)
    model.eval()

    return model, processor


# =====================================================
# 10. 主程序
# =====================================================

def main():
    torch.manual_seed(SEED)

    input_jsonl, output_jsonl = get_paths(LANGUAGE)
    ensure_dir(output_jsonl)

    dtype = get_torch_dtype(DTYPE_NAME)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    print("========== Runtime Config ==========")
    print(f"[INFO] LANGUAGE: {LANGUAGE}")
    print(f"[INFO] GPU: {GPU}")
    print(f"[INFO] MAX_SAMPLES: {MAX_SAMPLES}")
    print(f"[INFO] MAX_NEW_TOKENS: {MAX_NEW_TOKENS}")
    print(f"[INFO] CUDA_VISIBLE_DEVICES: {os.environ.get('CUDA_VISIBLE_DEVICES')}")
    print(f"[INFO] torch.cuda.is_available: {torch.cuda.is_available()}")
    print(f"[INFO] torch.cuda.device_count: {torch.cuda.device_count()}")
    print(f"[INFO] device: {device}")
    print(f"[INFO] dtype: {DTYPE_NAME}")
    print(f"[INFO] MODEL_PATH: {MODEL_PATH}")
    print(f"[INFO] INPUT_JSONL: {input_jsonl}")
    print(f"[INFO] OUTPUT_JSONL: {output_jsonl}")
    print(f"[INFO] IMAGE_DIR: {IMAGE_DIR}")
    print(f"[INFO] OUTPUT_FIELD: {OUTPUT_FIELD}")
    print(f"[INFO] CONTRAST_ALPHA: {CONTRAST_ALPHA}")
    print(f"[INFO] HEAD_BETA: {HEAD_BETA}")
    print(f"[INFO] formula: {contrast_formula_str()}")
    print("====================================")

    if not os.path.exists(input_jsonl):
        raise FileNotFoundError(f"输入文件不存在: {input_jsonl}")

    print("[INFO] loading model...", flush=True)

    model, processor = load_model_and_processor(
        model_path=MODEL_PATH,
        dtype=dtype,
        device=device,
    )

    print("[INFO] model loaded.", flush=True)

    rows = read_jsonl(
        path=input_jsonl,
        max_samples=MAX_SAMPLES,
    )

    total = len(rows)

    print(f"[INFO] read rows: {total}", flush=True)

    init_jsonl(output_jsonl)

    stats = {
        "total": total,
        "saved": 0,
        "error": 0,
        "empty_or_invalid": 0,
    }

    start_time = time.time()

    for idx, row in enumerate(rows, start=1):
        iter_start = time.time()
        row_id = get_row_id(row, fallback_idx=idx)

        try:
            out = process_one_row(
                model=model,
                processor=processor,
                row=row,
                idx=idx,
                device=device,
                dtype=dtype,
                max_new_tokens=MAX_NEW_TOKENS,
            )

        except Exception as e:
            stats["error"] += 1

            out = dict(row)
            out["id"] = row_id
            out["source_text"] = first_non_empty(
                row,
                [
                    SOURCE_FIELD_PRIMARY,
                    SOURCE_FIELD_FALLBACK,
                ],
            )
            out["reference_translation"] = first_non_empty(
                row,
                [
                    REFERENCE_FIELD_PRIMARY,
                    REFERENCE_FIELD_FALLBACK,
                ],
            )
            out[OUTPUT_FIELD] = ""
            out["error"] = repr(e)

            print(f"[WARN] id={row_id} failed: {repr(e)}", flush=True)

        append_jsonl(output_jsonl, out)
        stats["saved"] += 1

        elapsed = time.time() - start_time
        avg = elapsed / max(1, idx)
        eta = avg * max(0, total - idx)

        finish_time = time.strftime(
            "%Y-%m-%d %H:%M:%S",
            time.localtime(time.time() + eta),
        )

        iter_time = time.time() - iter_start

        hyp = normalize_text(out.get(OUTPUT_FIELD, ""))
        if not hyp:
            stats["empty_or_invalid"] += 1

        print(
            f"[{idx}/{total}] id={row_id} | iter={iter_time:.2f}s | "
            f"ETA={format_seconds(eta)} | finish={finish_time} | "
            f"saved={stats['saved']} | error={stats['error']} | "
            f"hyp={hyp[:80]}",
            flush=True,
        )

        cleanup_cuda()

    print("[done] " + json.dumps(stats, ensure_ascii=False), flush=True)
    print(f"[INFO] output saved to: {output_jsonl}", flush=True)


if __name__ == "__main__":
    main()