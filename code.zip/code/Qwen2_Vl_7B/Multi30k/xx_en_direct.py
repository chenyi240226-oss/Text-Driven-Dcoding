#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import argparse

# ============================================================
# 命令行参数：必须在 import torch 前解析并设置 CUDA_VISIBLE_DEVICES
# ============================================================

ALLOWED_LANGUAGES = {"hi", "lv", "tr"}


def parse_args():
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--lang",
        type=str,
        required=True,
        choices=sorted(ALLOWED_LANGUAGES),
        help="Input language code. Only supports: hi, lv, tr."
    )

    parser.add_argument(
        "--gpu",
        type=str,
        required=True,
        help="Physical GPU id, for example: 0, 1, 5, 6, 7."
    )

    return parser.parse_args()


ARGS = parse_args()

os.environ["CUDA_VISIBLE_DEVICES"] = str(ARGS.gpu)
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"

import json
import time
import re
from typing import Any, Dict, List, Optional, Tuple

import torch

# =========================
# Torch compatibility patch
# =========================
if not hasattr(torch, "compiler"):
    class _DummyCompiler:
        @staticmethod
        def is_compiling():
            return False
    torch.compiler = _DummyCompiler()
else:
    if not hasattr(torch.compiler, "is_compiling"):
        torch.compiler.is_compiling = lambda: False

from PIL import Image
from transformers import Qwen2VLForConditionalGeneration, AutoProcessor

# ============================================================
# 可控参数
# ============================================================

MAX_SAMPLES = None     # None 表示处理全部；例如 100 表示只处理前 100 条

# ============================================================
# 路径配置
# ============================================================

MULTI30K_DATA_ROOT = "/mnt/raid/cycy/data/txt_multi30k"
OUTPUT_ROOT = "/home/chenyi/offline_blaser_qe/out/Qwen2_VL_7B/Multi30k"

QWEN_PATH = "/mnt/raid/hss/model/Qwen2-VL-7B-Instruct"

# ============================================================
# 模型与生成参数
# ============================================================

DTYPE = torch.bfloat16 if torch.cuda.is_available() else torch.float32
FLUSH_EVERY = 20

torch.set_grad_enabled(False)

TARGET_LANG_NAME = "English"

SYSTEM_PROMPT_TEMPLATE = (
    "/no_think\n"
    "You are a professional translator.\n"
    "Your job is to translate the given source sentence into {lang_name}.\n"
    "STRICT RULES:\n"
    "1) Faithful: Do NOT add, remove, or change objects, attributes, actions, or relations.\n"
    "2) Use the image only when it helps resolve ambiguity.\n"
    "3) Do not turn the task into image captioning.\n"
    "4) Output ONLY the translation in {lang_name}. No explanations.\n"
    "5) NEVER output any <think>...</think> content.\n"
)


# ============================================================
# 配置检查与路径构造
# ============================================================

def validate_config(language: str) -> None:
    if language not in ALLOWED_LANGUAGES:
        raise ValueError(
            f"Unsupported language: {language}. "
            f"Allowed languages are: {sorted(ALLOWED_LANGUAGES)}"
        )

    if MAX_SAMPLES is not None and MAX_SAMPLES <= 0:
        raise ValueError("MAX_SAMPLES must be positive or None.")


def build_paths(language: str) -> Tuple[str, str]:
    input_jsonl = os.path.join(
        MULTI30K_DATA_ROOT,
        f"en_{language}_test.jsonl"
    )

    output_jsonl = os.path.join(
        OUTPUT_ROOT,
        language,
        f"{language}_test_translation.jsonl"
    )

    return input_jsonl, output_jsonl


# ============================================================
# 基础工具
# ============================================================

def format_time(seconds: float) -> str:
    seconds = max(0, int(seconds))
    h = seconds // 3600
    m = (seconds % 3600) // 60
    s = seconds % 60
    return f"{h:02d}:{m:02d}:{s:02d}"


def load_jsonl(path: str) -> List[Dict[str, Any]]:
    if not os.path.isfile(path):
        raise FileNotFoundError(f"Input JSONL not found: {path}")

    data = []

    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue

            data.append(json.loads(line))

            if MAX_SAMPLES is not None and len(data) >= MAX_SAMPLES:
                break

    return data


def resolve_image_path(item: Dict[str, Any]) -> Optional[str]:
    """
    Multi30k 输入中直接使用 image 字段作为图片路径。
    例如：
    {
      "image": "/mnt/raid/.../1007129816.jpg",
      "target": "...",
      "source": "..."
    }
    """
    image_path = str(item.get("image", "")).strip()

    if image_path and os.path.isfile(image_path):
        return image_path

    return None


def cleanup_cuda() -> None:
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        torch.cuda.ipc_collect()


# ============================================================
# 模型加载
# ============================================================

def load_model():
    print("[Info] Loading Qwen2-VL model ...")
    print(f"[Info] QWEN_PATH: {QWEN_PATH}")
    print(f"[Info] CUDA_VISIBLE_DEVICES: {os.environ.get('CUDA_VISIBLE_DEVICES')}")
    print(f"[Info] torch.cuda.is_available(): {torch.cuda.is_available()}")

    if torch.cuda.is_available():
        print(f"[Info] Visible GPU count: {torch.cuda.device_count()}")
        print(f"[Info] Current device: {torch.cuda.current_device()}")

    model = Qwen2VLForConditionalGeneration.from_pretrained(
        QWEN_PATH,
        torch_dtype=DTYPE,
        device_map="auto",
        trust_remote_code=True
    )

    processor = AutoProcessor.from_pretrained(
        QWEN_PATH,
        trust_remote_code=True
    )

    model.eval()

    print("[Info] Model loaded.")
    return model, processor


# ============================================================
# 输出清洗
# ============================================================

def is_effectively_empty_output(text: str) -> bool:
    if text is None:
        return True

    text = str(text).strip()
    if not text:
        return True

    if re.fullmatch(r"[\s\.\,\!\?\:\;\"\'\-\(\)\[\]\{\}]+", text):
        return True

    lower = text.lower()
    bad_patterns = [
        "i can't",
        "i cannot",
        "cannot determine",
        "cannot translate",
        "unable to",
        "no translation",
        "no output",
        "sorry",
    ]

    if any(p in lower for p in bad_patterns):
        return True

    return False


def clean_generation_text(text: str) -> str:
    text = str(text).strip()
    text = re.sub(r"^\s*(translation\s*[:：-]\s*)", "", text, flags=re.I)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def strip_think_blocks(text: str) -> str:
    if not text:
        return text

    text = re.sub(
        r"<think>.*?</think>",
        "",
        text,
        flags=re.DOTALL | re.IGNORECASE
    )
    text = re.sub(r"</?think>", "", text, flags=re.IGNORECASE)

    return text.strip()


# ============================================================
# Prompt 与多模态输入
# ============================================================

def build_messages(image: Image.Image, src: str):
    system_prompt = SYSTEM_PROMPT_TEMPLATE.format(
        lang_name=TARGET_LANG_NAME
    )

    user_text = (
        "SOURCE:\n"
        f"{src}\n\n"
        f"Translate into {TARGET_LANG_NAME}."
    )

    messages = [
        {
            "role": "system",
            "content": [
                {"type": "text", "text": system_prompt}
            ],
        },
        {
            "role": "user",
            "content": [
                {"type": "image", "image": image},
                {"type": "text", "text": user_text}
            ],
        }
    ]

    return messages


def translate(
    model,
    processor,
    image: Image.Image,
    src: str,
    image_id: Any = ""
) -> str:
    messages = build_messages(image, src)

    try:
        text = processor.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True
        )

        inputs = processor(
            text=[text],
            images=[image],
            padding=True,
            return_tensors="pt"
        )

        prepared_inputs = {}
        for k, v in inputs.items():
            if hasattr(v, "to"):
                prepared_inputs[k] = v.to(model.device)
            else:
                prepared_inputs[k] = v

        eos_token_id = getattr(processor.tokenizer, "eos_token_id", None)
        pad_token_id = getattr(processor.tokenizer, "pad_token_id", None)

        if pad_token_id is None:
            pad_token_id = eos_token_id

        with torch.no_grad():
            out = model.generate(
                **prepared_inputs,
                max_new_tokens=64,
                do_sample=False,
                use_cache=True,
                pad_token_id=pad_token_id,
                eos_token_id=eos_token_id,
            )

        prompt_len = prepared_inputs["input_ids"].shape[1]
        out = out[:, prompt_len:]

        result = processor.batch_decode(
            out,
            skip_special_tokens=True,
            clean_up_tokenization_spaces=True
        )[0]

        result = strip_think_blocks(result)
        result = clean_generation_text(result)

        if is_effectively_empty_output(result):
            print(
                f"[Warn] empty_generation | "
                f"image_id={image_id} | "
                f"src={src} | "
                f"raw={repr(result)}"
            )
            return ""

        return result

    except Exception as e:
        print(f"[TranslateError] image_id={image_id} | src={src} | {repr(e)}")
        return ""


def write_jsonl_records(f, records: List[Dict[str, Any]]) -> None:
    for record in records:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")
    f.flush()


# ============================================================
# 主流程
# ============================================================

def main():
    language = ARGS.lang
    gpu = ARGS.gpu

    validate_config(language)

    input_jsonl, output_jsonl = build_paths(language)

    print(f"[Info] LANGUAGE: {language}")
    print(f"[Info] GPU: {gpu}")
    print(f"[Info] MAX_SAMPLES: {MAX_SAMPLES}")
    print(f"[Info] INPUT_JSONL: {input_jsonl}")
    print(f"[Info] OUTPUT_JSONL: {output_jsonl}")

    data = load_jsonl(input_jsonl)
    total = len(data)

    print(f"[Info] Total selected samples: {total}")
    print(f"[Info] CUDA available: {torch.cuda.is_available()}")

    if torch.cuda.is_available():
        print(f"[Info] Visible GPU count: {torch.cuda.device_count()}")
        print(f"[Info] Current device: {torch.cuda.current_device()}")

    model, processor = load_model()

    os.makedirs(os.path.dirname(output_jsonl), exist_ok=True)

    start_time = time.time()
    buffer = []
    saved = 0

    with open(output_jsonl, "w", encoding="utf-8") as f:
        for i, item in enumerate(data, 1):
            iter_start = time.time()

            image_id = item.get("image_id", "")
            source_text = str(item.get("target", "")).strip()
            reference_translation = str(item.get("source", "")).strip()

            translation = ""

            if not source_text:
                buffer.append({
                    "image_id": image_id,
                    "source_text": source_text,
                    "reference_translation": reference_translation,
                    "initial_translation_en": ""
                })
                saved += 1

                if len(buffer) >= FLUSH_EVERY:
                    write_jsonl_records(f, buffer)
                    buffer = []

                elapsed = time.time() - start_time
                avg = elapsed / i
                eta = avg * (total - i)

                print(
                    f"[{i}/{total}] empty_src | "
                    f"elapsed={format_time(elapsed)} | "
                    f"ETA={format_time(eta)} | "
                    f"saved={saved}"
                )
                continue

            img_path = resolve_image_path(item)

            try:
                if img_path is not None:
                    image = Image.open(img_path).convert("RGB")

                    translation = translate(
                        model=model,
                        processor=processor,
                        image=image,
                        src=source_text,
                        image_id=image_id
                    )

                    image.close()
                else:
                    print(
                        f"[Warn] image_not_found | "
                        f"image_id={image_id} | "
                        f"image_field={item.get('image', '')}"
                    )
                    translation = ""

                buffer.append({
                    "image_id": image_id,
                    "source_text": source_text,
                    "reference_translation": reference_translation,
                    "initial_translation_en": translation
                })
                saved += 1

            except Exception as e:
                print(f"[Error] image_id={image_id} | {repr(e)}")

                buffer.append({
                    "image_id": image_id,
                    "source_text": source_text,
                    "reference_translation": reference_translation,
                    "initial_translation_en": ""
                })
                saved += 1

            finally:
                cleanup_cuda()

            if len(buffer) >= FLUSH_EVERY:
                write_jsonl_records(f, buffer)
                buffer = []

            iter_time = time.time() - iter_start
            elapsed = time.time() - start_time
            avg = elapsed / i
            eta = avg * (total - i)

            print(
                f"[{i}/{total}] "
                f"image_id={image_id} | "
                f"iter={iter_time:.2f}s | "
                f"avg={avg:.2f}s | "
                f"elapsed={format_time(elapsed)} | "
                f"ETA={format_time(eta)} | "
                f"saved={saved}"
            )

        if buffer:
            write_jsonl_records(f, buffer)

    total_time = time.time() - start_time

    print("\n==============================")
    print(f"LANGUAGE: {language}")
    print(f"GPU: {gpu}")
    print(f"MAX_SAMPLES: {MAX_SAMPLES}")
    print(f"SAVED RECORDS: {saved}")
    print(f"TOTAL TIME: {format_time(total_time)}")
    print(f"SAVED TO: {output_jsonl}")
    print("==============================")


if __name__ == "__main__":
    main()