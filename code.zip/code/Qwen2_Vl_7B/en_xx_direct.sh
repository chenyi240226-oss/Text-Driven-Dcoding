#!/bin/bash
set -e


source /home/chenyi/venvs/qwen3_vl_env/bin/activate
cd /home/chenyi/offline_blaser_qe/code/Qwen2_Vl_7B




python en_xx_direct.py --data vg --lang ha --gpu 5 
# python en_xx_direct.py --data vg --lang hi --gpu 0
# python en_xx_direct.py --data vg --lang ma --gpu 0 
# python en_xx_direct.py --data vg --lang bn --gpu 0 


# python en_xx_direct.py --data multi30k --lang lv --gpu 0 
# python en_xx_direct.py --data multi30k --lang tr --gpu 0 
# python en_xx_direct.py --data multi30k --lang hi --gpu 0



echo "All  finished."