#!/bin/bash
set -e


source /home/guozhengyi/anaconda3/envs/evaluate/bin/activate
cd /home/chenyi/offline_blaser_qe/code/Qwen3_VL_8B



python eval_direct_text.py --data vg --lang ha --gpu 2 --alpha 0
# python eval_direct_both.py --data vg --lang ha --gpu 2 --alpha 0
# python eval_direct.py --data vg --lang hi --gpu 5 --alpha 0
# python eval_direct.py --data vg --lang ma --gpu 5 --alpha 0
# python eval_direct.py --data vg --lang bn --gpu 5 --alpha 0


# python eval_direct.py --data multi30k --lang lv --gpu 5 --alpha 0
# python eval_direct.py --data multi30k --lang tr --gpu 5 --alpha 0
# python eval_direct.py --data multi30k --lang hi --gpu 5 --alpha 0



echo "All  finished."