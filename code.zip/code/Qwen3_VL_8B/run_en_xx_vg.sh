#!/bin/bash
set -e


source /home/chenyi/venvs/qwen3_vl_env/bin/activate
cd /home/chenyi/offline_blaser_qe/code/Qwen3_VL_8B

for alpha in 0.2 0.25 0.3 0.35 0.4 
do
    echo "Running alpha: $lalpha"
    python en_xx_contract_decoding.py --data vg --lang bn --gpu 1 --alpha $alpha
    python en_xx_contract_decoding.py --data vg --lang ha --gpu 1 --alpha $alpha
    python en_xx_contract_decoding.py --data vg --lang hi --gpu 1 --alpha $alpha
    python en_xx_contract_decoding.py --data vg --lang ma --gpu 1 --alpha $alpha
    echo "Finished language: $alpha"
done

echo "All  finished."