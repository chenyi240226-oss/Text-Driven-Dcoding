#!/bin/bash
set -e


source /home/chenyi/venvs/qwen3_vl_env/bin/activate
cd /home/chenyi/offline_blaser_qe/code/Qwen3_VL_8B




python en_xx_direct_both.py --data vg --lang ha --gpu 6 
python en_xx_direct_both.py --data vg --lang hi --gpu 6 
python en_xx_direct_both.py --data vg --lang ma --gpu 6 
python en_xx_direct_both.py --data vg --lang bn --gpu 6 


python en_xx_direct_both.py --data multi30k --lang lv --gpu 6 
python en_xx_direct_both.py --data multi30k --lang tr --gpu 6 
python en_xx_direct_both.py --data multi30k --lang hi --gpu 6



echo "All  finished."