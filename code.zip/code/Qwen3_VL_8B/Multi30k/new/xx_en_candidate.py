#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import argparse

# =========================================================
# Arguments: parse before importing torch / loading model
# =========================================================
ALLOWED_LANGUAGES = {"hi", "lv", "tr"}

LANGUAGE_NAME_MAP = {
    "hi": "Hindi",
    "lv": "Latvian",
    "tr": "Turkish",
}


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--lang",
        type=str,
        required=True,
        choices=sorted(ALLOWED_LANGUAGES),
        help="Language code: hi, lv, tr.",
    )
    parser.add_argument(
        "--gpu",
        type=str,
        required=True,
        help="Physical GPU id, for example: 0, 1, 5, 6, 7.",
    )
    return parser.parse_args()


ARGS = parse_args()
LANGUAGE = ARGS.lang
GPU = ARGS.gpu
SOURCE_LANGUAGE_NAME = LANGUAGE_NAME_MAP[LANGUAGE]

os.environ["CUDA_VISIBLE_DEVICES"] = str(GPU)
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"

import re
import json
import time
import difflib
from typing import Any, Dict, List, Optional, Tuple

from PIL import Image
import torch

# =========================================================
# Torch compatibility patch
# =========================================================
if not hasattr(torch, "compiler"):
    class _DummyCompiler:
        @staticmethod
        def is_compiling():
            return False
    torch.compiler = _DummyCompiler()
elif not hasattr(torch.compiler, "is_compiling"):
    torch.compiler.is_compiling = lambda: False

from transformers import AutoProcessor, AutoModelForVision2Seq

torch.set_grad_enabled(False)

# =========================================================
# Paths
# =========================================================
QWEN_PATH = "/mnt/raid/hss/model/Qwen3-VL-8B-Instruct"

OUTPUT_ROOT = "/home/chenyi/offline_blaser_qe/out/Qwen_3_VL_8B/Multi30k"

INPUT_JSONL = os.path.join(
    OUTPUT_ROOT,
    LANGUAGE,
    f"{LANGUAGE}_detect_span.jsonl",
)

REFERENCE_JSONL = os.path.join(
    OUTPUT_ROOT,
    LANGUAGE,
    f"{LANGUAGE}_test_translation.jsonl",
)

OUTPUT_JSONL = os.path.join(
    OUTPUT_ROOT,
    LANGUAGE,
    f"{LANGUAGE}_3_candidates_from_span.jsonl",
)

MAX_ROWS = None

DTYPE = torch.bfloat16 if torch.cuda.is_available() else torch.float32

MAX_NEW_TOKENS_CANDIDATE = 420

ALLOWED_EDIT_TYPES = {"keep", "delete", "paraphrase", "visual_refill"}

MAX_ACTIONABLE_OPS_PER_ROW = 2
MAX_WEAK_OPTIONAL_OPS_PER_ROW = 1

CANDIDATE_FORMULA_VERSION = (
    "candidate_mask_slot_repair_v4_"
    "no_light_verb_lexicon_"
    "structure_based_local_phrase_expansion_"
    "weak_source_supported_phrase_filtered_"
    "weak_sort_by_evidence_not_length_"
    "actionable_force_retry_"
    "anchor_overlap_pruned_"
    "no_top_level_eligible_field_"
    "qwen3_multi30k_cli_lang_gpu"
)

# =========================================================
# Generic lexical utilities
# =========================================================
FUNCTION_WORDS = {
    "a", "an", "the",
    "of", "in", "on", "at", "by", "with", "from", "to", "for",
    "into", "onto", "over", "under", "between", "around", "through",
    "during", "while", "near", "inside", "outside", "along", "across",
    "behind", "beside", "toward", "towards", "against", "about",
    "before", "after", "front", "back", "next",
    "is", "are", "was", "were", "am", "be", "been", "being",
    "and", "or", "but", "who", "which", "that",
    "this", "these", "those",
    "his", "her", "their", "theirs", "its", "our", "ours", "your", "yours", "my", "mine",
    "he", "him", "she", "it", "they", "them", "we", "us", "you", "i", "me",
    "himself", "herself", "itself", "themselves", "ourselves", "yourself", "yourselves", "myself",
    "as", "if", "than", "then",
    "there", "here",
    "not", "no",
    "do", "does", "did", "done",
    "have", "has", "had",
    "will", "would", "can", "could", "should", "may", "might", "must",
    "still", "very", "just", "also",
}

RELATION_WORDS = {
    "in", "on", "at", "by", "with", "from", "to", "for",
    "into", "onto", "over", "under", "between", "around", "through",
    "during", "while", "near", "inside", "outside", "along", "across",
    "behind", "beside", "toward", "towards", "against", "before", "after",
    "front", "back", "next", "out", "up", "down", "off",
}

REFLEXIVE_PRONOUNS = {
    "myself", "yourself", "yourselves", "himself", "herself",
    "itself", "ourselves", "themselves",
}

PRONOUN_GROUPS = {
    "male": {"he", "him", "his", "himself"},
    "female": {"she", "her", "hers", "herself"},
    "neutral": {"it", "its", "itself"},
    "plural": {"they", "them", "their", "theirs", "themselves"},
    "first": {"i", "me", "my", "mine", "myself", "we", "us", "our", "ours", "ourselves"},
    "second": {"you", "your", "yours", "yourself", "yourselves"},
}

IDENTITY_NOUN_TERMS = {
    "man", "men", "woman", "women",
    "boy", "boys", "girl", "girls",
    "male", "female", "gentleman", "lady",
    "mother", "father", "mom", "dad",
    "son", "daughter", "child", "children", "baby", "babies",
}

VOWEL_INITIAL = set("aeiou")


# =========================================================
# Basic utils
# =========================================================
def clean_text(x: Any) -> str:
    if x is None:
        return ""
    return re.sub(r"\s+", " ", str(x).strip())


def norm(x: Any) -> str:
    x = clean_text(x).lower()
    x = x.replace("’", "'").replace("“", '"').replace("”", '"')
    x = re.sub(r"[^a-z0-9_\-\s]", " ", x)
    return re.sub(r"\s+", " ", x).strip()


def norm_sent(x: Any) -> str:
    x = clean_text(x)
    x = re.sub(r"\s+([,.;:!?])", r"\1", x)
    x = x.strip().strip('"').strip("'").strip()
    return x.rstrip(".,;:!?")


def same(a: Any, b: Any) -> bool:
    return norm(a) == norm(b)


def safe_json(obj: Any) -> str:
    try:
        return json.dumps(obj, ensure_ascii=False)
    except Exception:
        return "[]"


def cleanup_cuda():
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        torch.cuda.ipc_collect()


def load_image(path: str) -> Optional[Image.Image]:
    path = clean_text(path)
    if not path or not os.path.isfile(path):
        return None
    try:
        return Image.open(path).convert("RGB")
    except Exception:
        return None


def format_time(sec: float) -> str:
    sec = int(sec)
    return f"{sec // 3600:02d}:{(sec % 3600) // 60:02d}:{sec % 60:02d}"


def tokenize_words(x: Any) -> List[str]:
    return re.findall(r"[A-Za-z0-9_\-]+", norm(x))


def content_tokens(x: Any) -> List[str]:
    return [t for t in tokenize_words(x) if t and t not in FUNCTION_WORDS]


def relation_tokens(x: Any) -> List[str]:
    return [t for t in tokenize_words(x) if t in RELATION_WORDS]


def first_nonempty(row: Dict, keys: List[str]) -> str:
    for k in keys:
        v = clean_text(row.get(k, ""))
        if v:
            return v
    return ""


def dict_first_nonempty(d: Dict, keys: List[str]) -> str:
    for k in keys:
        v = clean_text(d.get(k, ""))
        if v:
            return v
    return ""


def overlap(a: str, b: str) -> bool:
    a, b = norm(a), norm(b)
    if not a or not b:
        return False
    return a == b or a in b or b in a


def ratio_score(flags: List[bool]) -> float:
    if not flags:
        return 0.0
    return sum(1 for x in flags if bool(x)) / float(len(flags))


def safe_float(x: Any, default: float = 0.0) -> float:
    try:
        return float(x)
    except Exception:
        return default


def safe_int(x: Any, default: int = 0) -> int:
    try:
        return int(x)
    except Exception:
        return default


def is_function_word_token(t: str) -> bool:
    return norm(t) in FUNCTION_WORDS


def is_relation_token(t: str) -> bool:
    return norm(t) in RELATION_WORDS


def is_bridge_token(t: str) -> bool:
    nt = norm(t)
    return nt in FUNCTION_WORDS or nt in RELATION_WORDS


def is_content_token(t: str) -> bool:
    nt = norm(t)
    return bool(nt) and nt not in FUNCTION_WORDS


# =========================================================
# Load model
# =========================================================
print("Loading model...")
print(f"[INFO] LANGUAGE: {LANGUAGE}")
print(f"[INFO] GPU: {GPU}")
print(f"[INFO] SOURCE_LANGUAGE_NAME: {SOURCE_LANGUAGE_NAME}")
print(f"[INFO] CUDA_VISIBLE_DEVICES: {os.environ.get('CUDA_VISIBLE_DEVICES')}")
print(f"[INFO] QWEN_PATH: {QWEN_PATH}")
print(f"[INFO] OUTPUT_ROOT: {OUTPUT_ROOT}")
print(f"[INFO] INPUT_JSONL: {INPUT_JSONL}")
print(f"[INFO] REFERENCE_JSONL: {REFERENCE_JSONL}")
print(f"[INFO] OUTPUT_JSONL: {OUTPUT_JSONL}")

processor = AutoProcessor.from_pretrained(QWEN_PATH, trust_remote_code=True)
model = AutoModelForVision2Seq.from_pretrained(
    QWEN_PATH,
    torch_dtype=DTYPE,
    device_map="auto",
    trust_remote_code=True,
).eval()
tokenizer = processor.tokenizer
print("Model loaded.")


# =========================================================
# Reference translation adapter
# =========================================================
def row_id_keys(row: Dict) -> List[str]:
    keys = []

    for k in ["id", "image_id"]:
        v = clean_text(row.get(k, ""))
        if v:
            keys.append(f"id::{v}")

    image_path = clean_text(row.get("image_path", row.get("image", "")))
    if image_path:
        base = os.path.basename(image_path)
        stem = os.path.splitext(base)[0]
        if stem:
            keys.append(f"id::{stem}")

    source_text = clean_text(row.get("source_text", ""))
    if source_text:
        keys.append(f"src::{norm(source_text)}")

    target = clean_text(row.get("target", ""))
    if target:
        keys.append(f"src::{norm(target)}")

    return keys


def read_jsonl_records(path: str) -> List[Dict]:
    rows = []

    if not os.path.isfile(path):
        return rows

    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))

    return rows


def build_reference_map(reference_jsonl: str) -> Dict[str, str]:
    ref_map: Dict[str, str] = {}

    if not reference_jsonl or not os.path.isfile(reference_jsonl):
        print(f"[WARN] REFERENCE_JSONL not found: {reference_jsonl}")
        return ref_map

    rows = read_jsonl_records(reference_jsonl)

    for row in rows:
        ref = first_nonempty(
            row,
            [
                "reference_translation",
                "src_en",
                "source_text_en",
                "reference",
                "source",
            ],
        )

        if not ref:
            continue

        for k in row_id_keys(row):
            if k not in ref_map:
                ref_map[k] = ref

    print(f"[INFO] Loaded reference map: {len(ref_map)} keys from {reference_jsonl}")
    return ref_map


def get_reference_translation(row: Dict, ref_map: Dict[str, str]) -> str:
    ref = first_nonempty(
        row,
        [
            "reference_translation",
            "src_en",
            "source_text_en",
            "reference",
            "source",
        ],
    )

    if ref:
        return ref

    for k in row_id_keys(row):
        if k in ref_map and clean_text(ref_map[k]):
            return clean_text(ref_map[k])

    return ""


# =========================================================
# Qwen generation / JSON parsing
# =========================================================
def run_qwen_json(
    system_prompt: str,
    user_prompt: str,
    image: Optional[Image.Image],
    max_new_tokens: int,
) -> str:
    messages = [
        {"role": "system", "content": system_prompt},
        {
            "role": "user",
            "content": (
                ([{"type": "image", "image": image}] if image is not None else [])
                + [{"type": "text", "text": user_prompt}]
            ),
        },
    ]

    text = processor.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True,
    )

    if image is not None:
        inputs = processor(text=[text], images=[image], return_tensors="pt")
    else:
        inputs = processor(text=[text], return_tensors="pt")

    inputs = {
        k: v.to(model.device) if isinstance(v, torch.Tensor) else v
        for k, v in inputs.items()
    }

    with torch.no_grad():
        out = model.generate(
            **inputs,
            do_sample=False,
            max_new_tokens=max_new_tokens,
            repetition_penalty=1.02,
            pad_token_id=tokenizer.eos_token_id,
        )

    gen = out[:, inputs["input_ids"].shape[1]:]
    return processor.batch_decode(gen, skip_special_tokens=True)[0]


def extract_json(raw: str) -> Dict:
    raw = clean_text(raw)

    if not raw:
        return {}

    raw = raw.strip()
    raw = re.sub(r"^```(?:json)?", "", raw, flags=re.I).strip()
    raw = re.sub(r"```$", "", raw).strip()

    try:
        obj = json.loads(raw)
        if isinstance(obj, dict):
            return obj
    except Exception:
        pass

    start = raw.find("{")
    end = raw.rfind("}")

    if start >= 0 and end > start:
        s = raw[start:end + 1]
        try:
            obj = json.loads(s)
            if isinstance(obj, dict):
                return obj
        except Exception:
            pass

    candidates = re.findall(
        r"\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}",
        raw,
        flags=re.S,
    )

    for c in candidates:
        try:
            obj = json.loads(c)
            if isinstance(obj, dict):
                return obj
        except Exception:
            continue

    return {}


# =========================================================
# Detect output adapter
# =========================================================
def normalize_edit_type(x: Any) -> str:
    et = clean_text(x).lower()

    if et in ALLOWED_EDIT_TYPES:
        return et

    return ""


def get_span_item_from_list(items: Any, span: str) -> Dict:
    if not isinstance(items, list):
        return {}

    ns = norm(span)

    for it in items:
        if isinstance(it, dict) and norm(it.get("span", "")) == ns:
            out = dict(it)
            out["edit_type"] = normalize_edit_type(out.get("edit_type", ""))
            return out

    return {}


def get_span_item(row: Dict, span: str) -> Dict:
    item = get_span_item_from_list(row.get("suspicious_spans", []), span)
    if item:
        return item
    return get_span_item_from_list(row.get("weak_suspicious_spans", []), span)


def get_et_from_list(items: Any, span: str) -> str:
    if not isinstance(items, list):
        return ""

    ns = norm(span)

    for it in items:
        if isinstance(it, dict) and norm(it.get("span", "")) == ns:
            return normalize_edit_type(it.get("edit_type", ""))

    return ""


def get_et(row: Dict, span: str) -> str:
    for key in [
        "primary_edit_types",
        "action_primary_edit_types",
        "primary_edit_types_detect",
        "action_primary_edit_types_detect",
    ]:
        et = get_et_from_list(row.get(key, []), span)
        if et:
            return et

    spans = row.get("suspicious_spans", [])
    if isinstance(spans, list):
        for it in spans:
            if isinstance(it, dict) and norm(it.get("span", "")) == norm(span):
                et = normalize_edit_type(it.get("edit_type", ""))
                if et:
                    return et

    pairs = [
        ("primary_suspicious_span", "primary_edit_type"),
        ("action_primary_suspicious_span", "action_primary_edit_type"),
        ("score_primary_suspicious_span", "score_primary_edit_type"),
        ("primary_suspicious_span_detect", "primary_edit_type_detect"),
        ("action_primary_suspicious_span_detect", "action_primary_edit_type_detect"),
        ("score_primary_suspicious_span_detect", "score_primary_edit_type_detect"),
    ]

    for sk, ek in pairs:
        if norm(row.get(sk, "")) == norm(span):
            et = normalize_edit_type(row.get(ek, ""))
            if et:
                return et

    return ""


def add_operand(
    out: List[Dict],
    row: Dict,
    span: Any,
    et: Any = "",
    source: str = "",
    span_item_override: Optional[Dict] = None,
):
    sp = clean_text(span)
    if not sp:
        return

    e = normalize_edit_type(et) if et else get_et(row, sp)
    if not e:
        e = "keep"

    item = dict(span_item_override) if isinstance(span_item_override, dict) else get_span_item(row, sp)

    for old in out:
        if overlap(old.get("span", ""), sp):
            old_et = normalize_edit_type(old.get("edit_type", ""))

            if len(sp) > len(clean_text(old.get("span", ""))):
                old["span"] = sp
                old["edit_type"] = e
                old["span_item"] = item
                old["source"] = source
            elif old_et == "keep" and e != "keep":
                old["edit_type"] = e
                old["span_item"] = item
            elif old_et != "delete" and e == "delete":
                old["edit_type"] = e
                old["span_item"] = item

            return

    out.append({
        "span": sp,
        "edit_type": e,
        "span_item": item,
        "source": source,
        "order": len(out),
    })


def collect_repair_ops(row: Dict) -> List[Dict]:
    out: List[Dict] = []

    spans = row.get("suspicious_spans", [])
    if isinstance(spans, list) and spans:
        for it in spans:
            if isinstance(it, dict):
                add_operand(
                    out,
                    row,
                    it.get("span", ""),
                    it.get("edit_type", ""),
                    "suspicious_spans",
                    span_item_override=it,
                )

    if not out:
        for key in [
            "primary_edit_types",
            "action_primary_edit_types",
            "primary_edit_types_detect",
            "action_primary_edit_types_detect",
        ]:
            v = row.get(key, [])
            if isinstance(v, list):
                for it in v:
                    if isinstance(it, dict):
                        add_operand(
                            out,
                            row,
                            it.get("span", ""),
                            it.get("edit_type", ""),
                            key,
                        )

        for sk, ek in [
            ("primary_suspicious_span", "primary_edit_type"),
            ("action_primary_suspicious_span", "action_primary_edit_type"),
            ("score_primary_suspicious_span", "score_primary_edit_type"),
            ("primary_suspicious_span_detect", "primary_edit_type_detect"),
            ("action_primary_suspicious_span_detect", "action_primary_edit_type_detect"),
            ("score_primary_suspicious_span_detect", "score_primary_edit_type_detect"),
        ]:
            add_operand(out, row, row.get(sk, ""), row.get(ek, ""), sk)

    ops = [
        x for x in out
        if normalize_edit_type(x.get("edit_type", "")) in {"delete", "paraphrase", "visual_refill"}
    ]

    return ops[:MAX_ACTIONABLE_OPS_PER_ROW]


# =========================================================
# Weak filtering / sorting
# =========================================================
def stable_supported_span_item(item: Dict) -> bool:
    return (
        safe_float(item.get("mean_source_support", 0.0)) > 0.0
        and safe_float(item.get("mean_image_support", 0.0)) > 0.0
        and safe_float(item.get("mean_joint_support", 0.0)) > 0.0
        and safe_float(item.get("mean_prior_dominance", 0.0)) < 0.0
    )


def source_supported_single_word_noise(item: Dict) -> bool:
    span = clean_text(item.get("span", ""))
    num_words = safe_int(item.get("num_words", len(tokenize_words(span))), len(tokenize_words(span)))

    return (
        num_words <= 1
        and safe_float(item.get("mean_source_support", 0.0)) > 0.0
        and safe_float(item.get("mean_joint_support", 0.0)) > 0.0
        and safe_float(item.get("mean_prior_dominance", 0.0)) < 0.0
        and clean_text(item.get("evidence_type", "")) == "source_only_repair"
    )


def source_supported_phrase_noise(item: Dict) -> bool:
    src = safe_float(item.get("mean_source_support", 0.0))
    img = safe_float(item.get("mean_image_support", 0.0))
    joint = safe_float(item.get("mean_joint_support", 0.0))
    prior = safe_float(item.get("mean_prior_dominance", 0.0))

    evidence_type = clean_text(item.get("evidence_type", ""))

    if src > 0.0 and joint > 0.0 and prior < 0.0 and img <= 0.0:
        return True

    if evidence_type == "source_only_repair" and src > 0.0 and joint > 0.0 and prior < 0.0:
        return True

    return False


def source_supported_uncertain_noise(item: Dict) -> bool:
    src = safe_float(item.get("mean_source_support", 0.0))
    joint = safe_float(item.get("mean_joint_support", 0.0))
    prior = safe_float(item.get("mean_prior_dominance", 0.0))
    evidence_type = clean_text(item.get("evidence_type", ""))

    if evidence_type != "uncertain_cross_condition_suspicion":
        return False

    if src > 0.0 and joint > 0.0 and prior < 0.0:
        return True

    return False


def weak_item_high_value(item: Dict) -> bool:
    span = clean_text(item.get("span", ""))
    if not span:
        return False

    et = normalize_edit_type(item.get("edit_type", ""))
    if not et:
        et = "paraphrase"

    if et == "delete":
        et = "paraphrase"

    if et not in {"paraphrase", "visual_refill"}:
        return False

    if stable_supported_span_item(item):
        return False

    if source_supported_single_word_noise(item):
        return False

    if source_supported_phrase_noise(item):
        return False

    if source_supported_uncertain_noise(item):
        return False

    prior = safe_float(item.get("mean_prior_dominance", 0.0))
    src = safe_float(item.get("mean_source_support", 0.0))
    image = safe_float(item.get("mean_image_support", 0.0))
    joint = safe_float(item.get("mean_joint_support", 0.0))
    gain = safe_float(item.get("mean_source_image_gain", 0.0))
    gain_vote = safe_int(item.get("gain_vote_count", 0), 0)
    rank_vote = safe_int(item.get("rank_consensus_vote_count", 0), 0)
    gain_dims = item.get("gain_dimensions", [])
    evidence_type = clean_text(item.get("evidence_type", ""))

    if src <= 0.0 and joint > 0.0:
        return True

    if prior > 0.0:
        return True

    if image > 0.0 and src <= 0.0:
        return True

    if evidence_type == "uncertain_cross_condition_suspicion" and rank_vote > 0 and (src <= 0.0 or prior > 0.0):
        return True

    if gain > 0.0 and gain_vote > 0 and isinstance(gain_dims, list) and "source_image_gain" in gain_dims:
        if src <= 0.0 or prior > 0.0:
            return True

    return False


def weak_item_sort_key(item: Dict) -> Tuple:
    src = safe_float(item.get("mean_source_support", 0.0))
    image = safe_float(item.get("mean_image_support", 0.0))
    joint = safe_float(item.get("mean_joint_support", 0.0))
    prior = safe_float(item.get("mean_prior_dominance", 0.0))
    gain = safe_float(item.get("mean_source_image_gain", 0.0))
    evidence_type = clean_text(item.get("evidence_type", ""))

    return (
        int(src <= 0.0 and joint > 0.0),
        int(prior > 0.0),
        int(image > 0.0 and src <= 0.0),
        int(evidence_type == "uncertain_cross_condition_suspicion"),
        safe_int(item.get("gain_vote_count", 0), 0),
        safe_int(item.get("rank_consensus_vote_count", 0), 0),
        gain,
        safe_float(item.get("mean_joint_prior_distance", 0.0)),
        -safe_int(item.get("start_token", 0), 0),
    )


def collect_weak_repair_ops(row: Dict) -> List[Dict]:
    weak_items = row.get("weak_suspicious_spans", [])
    if not isinstance(weak_items, list):
        return []

    candidates = []

    for it in weak_items:
        if not isinstance(it, dict):
            continue

        if not weak_item_high_value(it):
            continue

        sp = clean_text(it.get("span", ""))
        et = normalize_edit_type(it.get("edit_type", ""))
        if not et or et == "delete":
            et = "paraphrase"

        item = dict(it)
        item["edit_type"] = et

        candidates.append({
            "span": sp,
            "edit_type": et,
            "span_item": item,
            "source": "weak_suspicious_spans_optional",
            "order": len(candidates),
        })

    candidates = sorted(
        candidates,
        key=lambda x: weak_item_sort_key(x.get("span_item", {})),
        reverse=True,
    )

    out = []
    for x in candidates:
        duplicated = False
        for old in out:
            if overlap(old.get("span", ""), x.get("span", "")):
                duplicated = True
                break
        if not duplicated:
            out.append(x)
        if len(out) >= MAX_WEAK_OPTIONAL_OPS_PER_ROW:
            break

    return out


def collect_all_weak_spans_for_output(row: Dict) -> List[Dict]:
    out = []
    weak_items = row.get("weak_suspicious_spans", [])

    if not isinstance(weak_items, list):
        return out

    for it in weak_items:
        if not isinstance(it, dict):
            continue

        out.append({
            "span": clean_text(it.get("span", "")),
            "edit_type": normalize_edit_type(it.get("edit_type", "")) or "paraphrase",
            "edit_reason": clean_text(it.get("edit_reason", "")),
            "evidence_type": clean_text(it.get("evidence_type", "")),
            "tier": clean_text(it.get("tier", "weak")),
            "mean_prior_dominance": safe_float(it.get("mean_prior_dominance", 0.0)),
            "mean_source_support": safe_float(it.get("mean_source_support", 0.0)),
            "mean_image_support": safe_float(it.get("mean_image_support", 0.0)),
            "mean_joint_support": safe_float(it.get("mean_joint_support", 0.0)),
            "mean_source_image_gain": safe_float(it.get("mean_source_image_gain", 0.0)),
        })

    return out


def collect_anchor_spans(row: Dict) -> List[str]:
    anchors = []

    for key in ["primary_anchor_span"]:
        v = clean_text(row.get(key, ""))
        if v:
            anchors.append(v)

    for key in ["primary_anchor_spans", "anchor_spans"]:
        v = row.get(key, [])
        if isinstance(v, list):
            for it in v:
                if isinstance(it, dict):
                    sp = clean_text(it.get("span", ""))
                else:
                    sp = clean_text(it)
                if sp:
                    anchors.append(sp)

    out = []
    seen = set()

    for sp in anchors:
        n = norm(sp)
        if n and n not in seen:
            seen.add(n)
            out.append(sp)

    return out


def prune_anchors_for_ops(anchors: List[str], ops: List[Dict]) -> List[str]:
    out = []

    for a in anchors:
        blocked = False
        for op in ops:
            sp = clean_text(op.get("span", ""))
            if sp and overlap(a, sp):
                blocked = True
                break
        if not blocked:
            out.append(a)

    return out


def compact_operands(ops: List[Dict]) -> List[Dict]:
    arr = []

    for x in ops:
        item = x.get("span_item", {}) if isinstance(x.get("span_item", {}), dict) else {}
        arr.append({
            "span": clean_text(x.get("span", "")),
            "edit_type": normalize_edit_type(x.get("edit_type", "")),
            "edit_reason": clean_text(item.get("edit_reason", "")),
            "evidence_type": clean_text(item.get("evidence_type", "")),
            "tier": clean_text(item.get("tier", "")),
            "source": clean_text(x.get("source", "")),
            "original_span": clean_text(x.get("original_span", "")),
            "span_expanded": bool(x.get("span_expanded", False)),
        })

    return arr


def has_delete_op(ops: List[Dict]) -> bool:
    return any(normalize_edit_type(x.get("edit_type", "")) == "delete" for x in ops)


def has_visual_refill_op(ops: List[Dict]) -> bool:
    return any(normalize_edit_type(x.get("edit_type", "")) == "visual_refill" for x in ops)


# =========================================================
# Structure-based local phrase expansion before mask
# =========================================================
def sentence_word_spans(text: str) -> List[Dict]:
    arr = []
    for m in re.finditer(r"[A-Za-z0-9_\-]+", clean_text(text)):
        raw = m.group(0)
        arr.append({
            "text": raw,
            "norm": norm(raw),
            "start": m.start(),
            "end": m.end(),
        })
    return arr


def gap_has_hard_punct(text: str, left_end: int, right_start: int) -> bool:
    gap = text[left_end:right_start]
    return bool(re.search(r"[,.;:!?]", gap))


def find_span_word_range(text: str, span: str) -> Optional[Tuple[int, int, List[Dict]]]:
    toks = sentence_word_spans(text)
    sp_toks = tokenize_words(span)

    if not toks or not sp_toks:
        return None

    n = len(sp_toks)

    for i in range(0, len(toks) - n + 1):
        if [t["norm"] for t in toks[i:i + n]] == sp_toks:
            return i, i + n - 1, toks

    return None


def span_text_by_token_range(text: str, toks: List[Dict], a: int, b: int) -> str:
    a = max(0, a)
    b = min(len(toks) - 1, b)
    if a > b:
        return ""
    return clean_text(text[toks[a]["start"]:toks[b]["end"]])


def can_extend_between(text: str, toks: List[Dict], left_idx: int, right_idx: int) -> bool:
    if left_idx < 0 or right_idx >= len(toks):
        return False
    return not gap_has_hard_punct(text, toks[left_idx]["end"], toks[right_idx]["start"])


def left_content_through_bridge(text: str, toks: List[Dict], a: int) -> Optional[int]:
    """
    Generic structure:
    content + bridge* + span

    Example:
    performing a role -> span=role, left content=performing
    """
    j = a - 1

    while j >= 0 and can_extend_between(text, toks, j, j + 1) and is_bridge_token(toks[j]["norm"]):
        j -= 1

    if j >= 0 and can_extend_between(text, toks, j, j + 1) and is_content_token(toks[j]["norm"]):
        return j

    return None


def right_content_through_bridge(text: str, toks: List[Dict], b: int) -> Optional[int]:
    """
    Generic structure:
    span + bridge* + content

    Example:
    taking a picture -> span=taking, right content=picture
    """
    j = b + 1

    while j < len(toks) and can_extend_between(text, toks, j - 1, j) and is_bridge_token(toks[j]["norm"]):
        j += 1

    if j < len(toks) and can_extend_between(text, toks, j - 1, j) and is_content_token(toks[j]["norm"]):
        return j

    return None


def right_relation_particle(text: str, toks: List[Dict], b: int) -> Optional[int]:
    """
    Generic structure:
    span + relation particle

    Example:
    tagged out -> span=tagged, right relation=out
    """
    j = b + 1
    if j < len(toks) and can_extend_between(text, toks, b, j) and is_relation_token(toks[j]["norm"]):
        return j
    return None


def direct_right_content(text: str, toks: List[Dict], b: int) -> Optional[int]:
    """
    Generic structure:
    span + content

    Example:
    jeans clothing -> span=jeans, right content=clothing
    """
    j = b + 1
    if j < len(toks) and can_extend_between(text, toks, b, j) and is_content_token(toks[j]["norm"]):
        return j
    return None


def expand_single_op_span(initial: str, op: Dict) -> Dict:
    """
    No data-biased verb lexicon.

    Local expansion is based only on neighboring structure:
    - content + bridge* + span
    - span + bridge* + content
    - span + relation particle
    - span + direct content

    It does not check whether the left content word is a specific verb.
    """
    new_op = dict(op)
    span = clean_text(op.get("span", ""))

    if not span:
        return new_op

    span_words = tokenize_words(span)

    if len(span_words) > 3:
        return new_op

    found = find_span_word_range(initial, span)

    if found is None:
        return new_op

    a, b, toks = found

    if len(span_words) >= 2:
        return new_op

    candidate_ranges: List[Tuple[int, int, str]] = []

    left_idx = left_content_through_bridge(initial, toks, a)
    right_idx = right_content_through_bridge(initial, toks, b)
    particle_idx = right_relation_particle(initial, toks, b)
    direct_right_idx = direct_right_content(initial, toks, b)

    if left_idx is not None:
        candidate_ranges.append((left_idx, b, "left_content_bridge"))

    if right_idx is not None:
        candidate_ranges.append((a, right_idx, "right_bridge_content"))

    if left_idx is not None and right_idx is not None:
        candidate_ranges.append((left_idx, right_idx, "left_and_right_bridge"))

    if particle_idx is not None:
        candidate_ranges.append((a, particle_idx, "right_relation_particle"))

    if direct_right_idx is not None:
        candidate_ranges.append((a, direct_right_idx, "direct_right_content"))

    if not candidate_ranges:
        return new_op

    def range_key(r: Tuple[int, int, str]) -> Tuple[int, int]:
        x, y, _ = r
        phrase = span_text_by_token_range(initial, toks, x, y)
        return (
            len(tokenize_words(phrase)),
            abs((x + y) - (a + b)),
        )

    candidate_ranges = sorted(candidate_ranges, key=range_key)

    new_a, new_b, reason = candidate_ranges[0]
    expanded_span = span_text_by_token_range(initial, toks, new_a, new_b)

    if expanded_span and norm(span) in norm(expanded_span) and norm(expanded_span) != norm(span):
        new_op["original_span"] = span
        new_op["span"] = expanded_span
        new_op["span_expanded"] = True
        new_op["span_expansion_reason"] = reason
        return new_op

    return new_op


def expand_ops_for_mask(initial: str, ops: List[Dict], mode: str) -> List[Dict]:
    out = []
    seen = set()

    for op in ops:
        new_op = expand_single_op_span(initial, op)

        n = norm(new_op.get("span", ""))
        if not n:
            continue

        if n in seen:
            continue

        seen.add(n)
        out.append(new_op)

    return out


# =========================================================
# Mask-slot construction
# =========================================================
def mask_translation(initial: str, ops: List[Dict]) -> Tuple[str, List[Dict]]:
    masked = clean_text(initial)
    slot_infos = []

    for idx, op in enumerate(ops, 1):
        span = clean_text(op.get("span", ""))
        et = normalize_edit_type(op.get("edit_type", ""))

        if not span:
            continue

        mask_id = f"<mask_{idx}>"

        pattern = re.compile(re.escape(span), flags=re.I)
        m = pattern.search(masked)

        matched_phrase = ""

        if m:
            matched_phrase = masked[m.start():m.end()]
            masked = masked[:m.start()] + mask_id + masked[m.end():]
        else:
            matched_phrase = ""

        slot_infos.append({
            "mask_id": mask_id,
            "span": span,
            "original_span": clean_text(op.get("original_span", "")),
            "span_expanded": bool(op.get("span_expanded", False)),
            "span_expansion_reason": clean_text(op.get("span_expansion_reason", "")),
            "edit_type": et,
            "matched_phrase": matched_phrase,
        })

    return masked, slot_infos


# =========================================================
# String diff for edited_spans
# =========================================================
def diff_edits(old: str, new: str) -> List[Dict]:
    old, new = norm_sent(old), norm_sent(new)

    if same(old, new):
        return []

    old_toks = re.findall(r"\S+", old)
    new_toks = re.findall(r"\S+", new)

    old_norm = [norm(x) for x in old_toks]
    new_norm = [norm(x) for x in new_toks]

    edits = []

    for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(
        a=old_norm,
        b=new_norm,
    ).get_opcodes():
        if tag == "equal":
            continue

        frm = " ".join(old_toks[i1:i2]).strip()
        to = " ".join(new_toks[j1:j2]).strip()

        if frm or to:
            edits.append({"from": frm, "to": to})

    out = []
    seen = set()

    for ed in edits:
        if same(ed.get("from", ""), ed.get("to", "")):
            continue

        k = (norm(ed.get("from", "")), norm(ed.get("to", "")))
        if k not in seen:
            seen.add(k)
            out.append(ed)

    return out


def model_repairs_to_edits(obj: Dict, initial: str, candidate: str) -> List[Dict]:
    if not isinstance(obj, dict):
        return []

    repairs = obj.get("slot_repairs", None)

    if repairs is None:
        repairs = obj.get("local_repairs", [])

    if not isinstance(repairs, list):
        return []

    out = []
    seen = set()

    for r in repairs:
        if not isinstance(r, dict):
            continue

        frm = dict_first_nonempty(
            r,
            [
                "old_phrase",
                "from",
                "local_phrase",
                "span",
                "original",
                "source_phrase",
                "matched_phrase",
            ],
        )
        to = dict_first_nonempty(
            r,
            [
                "new_phrase",
                "to",
                "replacement",
                "corrected_phrase",
                "target_phrase",
                "fill",
                "fill_phrase",
            ],
        )

        frm = norm_sent(frm)
        to = norm_sent(to)

        if not frm:
            continue

        if same(frm, to):
            continue

        if norm(frm) not in norm(initial):
            continue

        k = (norm(frm), norm(to))
        if k in seen:
            continue

        seen.add(k)
        out.append({"from": frm, "to": to})

    return out


def make_candidate_edits(initial: str, candidate: str, obj: Optional[Dict] = None) -> List[Dict]:
    phrase_edits = model_repairs_to_edits(obj or {}, initial, candidate)

    if phrase_edits:
        return phrase_edits

    return diff_edits(initial, candidate)


# =========================================================
# Deterministic checks
# =========================================================
def has_bad_repetition(text: str) -> bool:
    toks = tokenize_words(text)
    for i in range(1, len(toks)):
        if toks[i] == toks[i - 1]:
            return True
    return False


def has_repeated_ngram(text: str, min_n: int = 2, max_n: int = 5) -> bool:
    toks = tokenize_words(text)

    if len(toks) < min_n * 2:
        return False

    for n in range(min_n, max_n + 1):
        if len(toks) < 2 * n:
            continue

        for i in range(0, len(toks) - 2 * n + 1):
            if toks[i:i + n] == toks[i + n:i + 2 * n]:
                return True

    return False


def has_unbalanced_punctuation(text: str) -> bool:
    s = clean_text(text)

    for l, r in [("(", ")"), ("[", "]")]:
        if s.count(l) != s.count(r):
            return True

    if s.count('"') % 2 != 0:
        return True

    return False


def has_bad_article_sequence(text: str) -> bool:
    toks = tokenize_words(text)

    for i in range(len(toks) - 1):
        cur = toks[i]
        nxt = toks[i + 1]

        if cur == "a" and nxt and nxt[0] in VOWEL_INITIAL:
            return True

        if cur == "an" and nxt and nxt[0] not in VOWEL_INITIAL:
            return True

    return False


def looks_like_fragment(text: str) -> bool:
    toks = tokenize_words(text)

    if len(toks) < 3:
        return True

    low = norm(text)

    if re.match(r"^(is|are|was|were|am|be|been|being)\b", low):
        return True

    if re.match(r"^(in|on|at|by|with|from|to|of|for|between|around|through|during|while)\b", low):
        return True

    last = toks[-1] if toks else ""

    if last in {
        "and", "or", "but", "while", "who", "which", "that",
        "of", "to", "from", "with", "in", "on", "at", "by", "for"
    }:
        return True

    return False


def edited_spans_have_real_change(edited_spans: List[Dict]) -> bool:
    for ed in edited_spans:
        frm = clean_text(ed.get("from", ""))
        to = clean_text(ed.get("to", ""))

        if frm or to:
            if not same(frm, to):
                return True

    return False


def target_span_touched(ops: List[Dict], edited_spans: List[Dict]) -> Tuple[bool, float, List[str], List[str]]:
    target_spans = [clean_text(x.get("span", "")) for x in ops if clean_text(x.get("span", ""))]
    original_target_spans = [
        clean_text(x.get("original_span", ""))
        for x in ops
        if clean_text(x.get("original_span", ""))
    ]

    changed_from = [clean_text(x.get("from", "")) for x in edited_spans if isinstance(x, dict)]
    changed_to = [clean_text(x.get("to", "")) for x in edited_spans if isinstance(x, dict)]

    if not target_spans:
        return False, 0.0, target_spans, changed_from

    touched = 0
    joined_from = " ".join(changed_from)
    joined_to = " ".join(changed_to)

    for idx, sp in enumerate(target_spans):
        original_sp = original_target_spans[idx] if idx < len(original_target_spans) else ""
        candidates = [sp]
        if original_sp:
            candidates.append(original_sp)

        hit = False
        for cand_sp in candidates:
            if overlap(cand_sp, joined_from) or overlap(cand_sp, joined_to):
                hit = True
                break

        if hit:
            touched += 1

    ratio = touched / max(1, len(target_spans))

    return touched > 0, ratio, target_spans, changed_from


def anchors_preserved(initial: str, candidate: str, anchors: List[str]) -> Tuple[bool, List[str], List[str]]:
    checked = []
    missing = []

    ni = norm(initial)
    nc = norm(candidate)

    for sp in anchors:
        ns = norm(sp)
        if not ns:
            continue

        if ns not in ni:
            continue

        checked.append(sp)

        if ns not in nc:
            missing.append(sp)

    return len(missing) == 0, checked, missing


def local_edit_ok(initial: str, candidate: str, edited_spans: List[Dict], ops: List[Dict]) -> Tuple[bool, str]:
    if not edited_spans_have_real_change(edited_spans):
        return False, "no_real_edited_span"

    edit_count = len(edited_spans)

    if edit_count > max(1, len(ops) + 1):
        return False, "too_many_edit_segments"

    changed_from_total = 0

    for ed in edited_spans:
        changed_from_total += len(content_tokens(ed.get("from", "")))

    if changed_from_total > max(6, len(ops) * 5):
        return False, "non_local_edit_too_much_source_changed"

    return True, "local_edit_ok"


def content_deletion_detected(edited_spans: List[Dict]) -> bool:
    for ed in edited_spans:
        frm = clean_text(ed.get("from", ""))
        to = clean_text(ed.get("to", ""))

        ft = content_tokens(frm)
        tt = content_tokens(to)

        if ft and not tt:
            return True

        if ft:
            removed = [x for x in ft if x not in set(tt)]
            added = [x for x in tt if x not in set(ft)]

            if removed and not added:
                return True

    return False


def phrase_compression_detected(edited_spans: List[Dict]) -> bool:
    for ed in edited_spans:
        frm = clean_text(ed.get("from", ""))
        to = clean_text(ed.get("to", ""))

        ft = content_tokens(frm)
        tt = content_tokens(to)

        if len(ft) >= 1 and len(tt) <= len(ft):
            if set(tt).issubset(set(ft)) or len(tt) == 0:
                return True

    return False


def pronoun_groups(tokens: List[str]) -> set:
    groups = set()

    st = set(tokens)
    for group_name, group_terms in PRONOUN_GROUPS.items():
        if st & group_terms:
            groups.add(group_name)

    return groups


def only_reflexive_pronoun_difference(from_tokens: List[str], to_tokens: List[str]) -> bool:
    all_pronouns = set().union(*PRONOUN_GROUPS.values())

    f_pron = set([x for x in from_tokens if x in all_pronouns])
    t_pron = set([x for x in to_tokens if x in all_pronouns])

    diff = f_pron.symmetric_difference(t_pron)

    if not diff:
        return True

    return diff.issubset(REFLEXIVE_PRONOUNS)


def deterministic_pronoun_or_identity_shift(edited_spans: List[Dict]) -> bool:
    for ed in edited_spans:
        if not isinstance(ed, dict):
            continue

        ft_all = tokenize_words(ed.get("from", ""))
        tt_all = tokenize_words(ed.get("to", ""))

        f_id = set(ft_all) & IDENTITY_NOUN_TERMS
        t_id = set(tt_all) & IDENTITY_NOUN_TERMS

        if f_id != t_id and (f_id or t_id):
            return True

        f_pron = pronoun_groups(ft_all)
        t_pron = pronoun_groups(tt_all)

        if f_pron and t_pron and f_pron != t_pron:
            if not only_reflexive_pronoun_difference(ft_all, tt_all):
                return True

        if bool(f_pron) != bool(t_pron):
            if not only_reflexive_pronoun_difference(ft_all, tt_all):
                return True

    return False


def edit_content_stats(edited_spans: List[Dict]) -> Dict:
    edit_count = 0
    from_content_total = 0
    to_content_total = 0
    shared_content_total = 0
    changed_content_from_total = 0
    changed_content_to_total = 0
    phrase_compression_repair_count = 0

    for ed in edited_spans if isinstance(edited_spans, list) else []:
        frm = clean_text(ed.get("from", ""))
        to = clean_text(ed.get("to", ""))

        if same(frm, to):
            continue

        ft = content_tokens(frm)
        tt = content_tokens(to)
        fs = set(ft)
        ts = set(tt)

        removed = [x for x in ft if x not in ts]
        added = [x for x in tt if x not in fs]
        shared = fs & ts

        edit_count += 1
        from_content_total += len(ft)
        to_content_total += len(tt)
        shared_content_total += len(shared)
        changed_content_from_total += len(removed)
        changed_content_to_total += len(added)

        if ft and len(tt) <= len(ft):
            if ts.issubset(fs) or not tt:
                phrase_compression_repair_count += 1

    return {
        "edit_count": edit_count,
        "from_content_total": from_content_total,
        "to_content_total": to_content_total,
        "shared_content_total": shared_content_total,
        "one_content_token_replacement_count": 0,
        "empty_from_count": 0,
        "empty_to_count": 0,
        "changed_content_from_total": changed_content_from_total,
        "changed_content_to_total": changed_content_to_total,
        "non_empty_removed_content_total": 0,
        "non_empty_uncompensated_removed_content_total": 0,
        "relation_change_count": 0,
        "relation_repair_core_preserved_count": 0,
        "unsafe_relation_rewrite_count": 0,
        "core_content_replacement_count": 0,
        "phrase_compression_repair_count": phrase_compression_repair_count,
    }


def local_hard_filter_candidate(
    initial: str,
    candidate: str,
    edited_spans: List[Dict],
) -> Tuple[bool, str]:
    candidate = clean_text(candidate)
    initial = clean_text(initial)

    if not candidate:
        return False, "empty_candidate"

    if same(candidate, initial):
        return False, "same_as_initial"

    if not edited_spans_have_real_change(edited_spans):
        return False, "no_real_edited_span"

    if has_bad_article_sequence(candidate):
        return False, "bad_article_sequence"

    if has_bad_repetition(candidate):
        return False, "bad_repetition"

    if has_repeated_ngram(candidate):
        return False, "repeated_ngram"

    if has_unbalanced_punctuation(candidate):
        return False, "unbalanced_punctuation"

    if looks_like_fragment(candidate):
        return False, "fragment_or_truncated_sentence"

    return True, "hard_filter_passed"


def make_static_verification(reason: str, tier: str = "unchanged_candidate") -> Dict:
    edit_stats = edit_content_stats([])

    verifier = {
        "verifier_type": "deterministic_mask_slot_no_llm",
        "verifier_parse_ok": True,

        "target_spans": [],
        "changed_from_spans": [],
        "target_span_touched": False,
        "target_span_coverage_ratio": 0.0,

        "anchors_checked": [],
        "anchors_missing": [],
        "anchor_preservation_ok": True,

        "deterministic_allow_candidate": False,
        "deterministic_score": 0.0,
        "deterministic_risk_ratio": 0.0,
        "deterministic_risk_items": [],

        "content_deletion": False,
        "empty_to_content_deletion": False,
        "non_empty_content_deletion": False,
        "relation_repair": False,
        "unsafe_relation_rewrite": False,
        "core_content_replacement": False,
        "phrase_compression_repair": False,
        "pronoun_or_identity_shift": False,
        "single_word_replacement": False,
        "surface_rewrite": False,
        "local_content_substitution": False,
        "non_local_edit": False,
        "length_delta_risk": False,
        "edit_stats": edit_stats,

        "initial_phrase_problem": "not_judged_by_llm",
        "candidate_repair_type": "unchanged",

        "replacement_supported_by_source": False,
        "candidate_fixes_initial_problem": False,
        "adds_unsupported_information": False,
        "removes_source_information": False,
        "changes_core_meaning": False,
        "local_edit_only": True,
        "grammar_ok": True,

        "style_or_synonym_only": False,
        "exact_source_word_meaning_uncertain": False,
        "candidate_is_more_specific_than_source": False,
        "candidate_introduces_unrequested_rewrite": False,

        "safety_ok": False,
        "useful_repair_ok": False,
        "verified_better_than_initial": False,
        "soft_source_supported": False,
        "selection_tier": tier,

        "source_supported_candidate": False,
        "prior_fluency_candidate": False,
        "local_probability_gate_type": "rejected",
        "source_probability_quality_gate_pass": False,

        "evidence": "",
        "reason_tag": reason,
    }

    reward_details = {
        "reward_formula_version": CANDIDATE_FORMULA_VERSION,
        "reward_gate_pass": False,
        "reward_gate_failed_reasons": [reason],
        "repair_reward_raw": 0.0,
        "repair_reward_components": [],
        "risk_penalty": 0.0,
        "risk_penalty_reasons": [],
        "risk_level": "none",
        "verifier_reward_score": 0.0,
        "reward_tier": tier,
        "needs_pairwise_check": False,
        "edit_stats": edit_stats,
    }

    return {
        "hard_filter_ok": False,
        "hard_filter_reason": reason,

        "deterministic_allow_candidate": False,
        "deterministic_score": 0.0,
        "deterministic_risk_ratio": 0.0,
        "deterministic_risk_items": [],

        "verified_better_than_initial": False,
        "soft_source_supported": False,
        "selection_tier": tier,

        "source_supported_candidate": False,
        "prior_fluency_candidate": False,
        "local_probability_gate_type": "rejected",
        "source_probability_quality_gate_pass": False,

        "verifier": verifier,

        "reward_gate_pass": False,
        "reward_gate_failed_reasons": [reason],
        "repair_reward_raw": 0.0,
        "risk_penalty": 0.0,
        "verifier_reward_score": 0.0,
        "reward_tier": tier,
        "reward_risk_level": "none",
        "reward_components": [],
        "risk_penalty_reasons": [],
        "needs_pairwise_check": False,
        "reward_details": reward_details,
    }


def deterministic_evaluate_candidate(
    source_text: str,
    initial: str,
    candidate: str,
    ops: List[Dict],
    anchors: List[str],
    edited_spans: List[Dict],
    candidate_mode: str,
) -> Dict:
    hard_ok, hard_reason = local_hard_filter_candidate(
        initial=initial,
        candidate=candidate,
        edited_spans=edited_spans,
    )

    touched, coverage_ratio, target_spans, changed_from = target_span_touched(
        ops=ops,
        edited_spans=edited_spans,
    )

    anchor_ok, anchors_checked, anchors_missing = anchors_preserved(
        initial=initial,
        candidate=candidate,
        anchors=anchors,
    )

    local_ok, local_reason = local_edit_ok(
        initial=initial,
        candidate=candidate,
        edited_spans=edited_spans,
        ops=ops,
    )

    delete_intended = has_delete_op(ops)
    deletion_seen = content_deletion_detected(edited_spans)
    phrase_compression = phrase_compression_detected(edited_spans)

    pronoun_identity_shift = deterministic_pronoun_or_identity_shift(edited_spans)

    unsafe_content_deletion = deletion_seen and not delete_intended
    non_local_edit = not local_ok

    risk_items = [
        {"name": "target_span_not_touched", "triggered": not touched},
        {"name": "anchor_not_preserved", "triggered": not anchor_ok},
        {"name": "unsafe_content_deletion", "triggered": unsafe_content_deletion},
        {"name": "pronoun_or_identity_shift", "triggered": pronoun_identity_shift},
        {"name": "non_local_edit", "triggered": non_local_edit},
        {"name": "bad_hard_filter", "triggered": not hard_ok},
        {"name": "local_paraphrase_deletion", "triggered": bool(delete_intended and deletion_seen)},
        {"name": "phrase_compression_repair", "triggered": bool(phrase_compression)},
        {"name": "weak_optional_repair", "triggered": candidate_mode == "weak_optional_conservative_repair"},
    ]

    risk_flags_for_score = [
        not touched,
        not anchor_ok,
        unsafe_content_deletion,
        pronoun_identity_shift,
        non_local_edit,
        not hard_ok,
    ]

    risk_ratio = ratio_score(risk_flags_for_score)

    deterministic_allow = (
        hard_ok
        and touched
        and anchor_ok
        and local_ok
        and not unsafe_content_deletion
        and not pronoun_identity_shift
    )

    deterministic_score = coverage_ratio * (1.0 - risk_ratio)
    deterministic_score = max(0.0, min(1.0, deterministic_score))

    source_supported_candidate = bool(deterministic_allow)
    prior_fluency_candidate = False
    gate_type = "source_supported_pass" if deterministic_allow else "rejected"

    edit_stats = edit_content_stats(edited_spans)

    if candidate_mode == "weak_optional_conservative_repair":
        repair_type = "weak_optional_conservative_repair"
    elif delete_intended and deletion_seen:
        repair_type = "local_paraphrase_deletion"
    elif candidate_mode == "source_image_mask_repair":
        repair_type = "source_image_mask_repair"
    elif candidate_mode == "source_only_mask_repair":
        repair_type = "source_only_mask_repair"
    else:
        repair_type = "conservative_paraphrase_delete_repair"

    verifier = {
        "verifier_type": "deterministic_mask_slot_no_llm",
        "verifier_parse_ok": True,

        "target_spans": target_spans,
        "changed_from_spans": changed_from,
        "target_span_touched": touched,
        "target_span_coverage_ratio": round(coverage_ratio, 4),

        "anchors_checked": anchors_checked,
        "anchors_missing": anchors_missing,
        "anchor_preservation_ok": anchor_ok,

        "deterministic_allow_candidate": deterministic_allow,
        "deterministic_score": round(deterministic_score, 4),
        "deterministic_risk_ratio": round(risk_ratio, 4),
        "deterministic_risk_items": risk_items,

        "content_deletion": bool(unsafe_content_deletion),
        "empty_to_content_deletion": False,
        "non_empty_content_deletion": bool(unsafe_content_deletion),
        "relation_repair": False,
        "unsafe_relation_rewrite": False,
        "core_content_replacement": False,
        "phrase_compression_repair": bool(phrase_compression or (delete_intended and deletion_seen)),
        "pronoun_or_identity_shift": pronoun_identity_shift,
        "single_word_replacement": False,
        "surface_rewrite": False,
        "local_content_substitution": False,
        "non_local_edit": non_local_edit,
        "length_delta_risk": False,
        "edit_stats": edit_stats,

        "initial_phrase_problem": (
            "weak_optional_suspicious_span"
            if candidate_mode == "weak_optional_conservative_repair"
            else "detected_suspicious_span"
        ),
        "candidate_repair_type": repair_type,

        "replacement_supported_by_source": deterministic_allow,
        "candidate_fixes_initial_problem": deterministic_allow,
        "adds_unsupported_information": False,
        "removes_source_information": bool(unsafe_content_deletion),
        "changes_core_meaning": bool(pronoun_identity_shift),
        "local_edit_only": local_ok,
        "grammar_ok": hard_ok,

        "style_or_synonym_only": False,
        "exact_source_word_meaning_uncertain": candidate_mode == "weak_optional_conservative_repair",
        "candidate_is_more_specific_than_source": False,
        "candidate_introduces_unrequested_rewrite": non_local_edit,

        "safety_ok": deterministic_allow,
        "useful_repair_ok": deterministic_allow,
        "verified_better_than_initial": False,
        "soft_source_supported": deterministic_allow,
        "selection_tier": "deterministic_mask_slot_candidate" if deterministic_allow else "rejected",

        "source_supported_candidate": source_supported_candidate,
        "prior_fluency_candidate": prior_fluency_candidate,
        "local_probability_gate_type": gate_type,
        "source_probability_quality_gate_pass": deterministic_allow,

        "evidence": "",
        "reason_tag": "deterministic_mask_slot_candidate" if deterministic_allow else "deterministic_rejected",
    }

    reward_details = {
        "reward_formula_version": CANDIDATE_FORMULA_VERSION,
        "reward_gate_pass": deterministic_allow,
        "reward_gate_failed_reasons": [] if deterministic_allow else [
            x["name"] for x in risk_items if x.get("triggered", False)
        ],
        "repair_reward_raw": round(deterministic_score, 4),
        "repair_reward_components": [
            "target_span_touched",
            "anchor_preserved",
            "local_mask_slot_edit",
        ] if deterministic_allow else [],
        "risk_penalty": round(risk_ratio, 4),
        "risk_penalty_reasons": risk_items,
        "risk_level": (
            "none" if risk_ratio == 0
            else "low" if risk_ratio < 1 / 3
            else "medium" if risk_ratio < 2 / 3
            else "high"
        ),
        "verifier_reward_score": round(deterministic_score, 4),
        "reward_tier": "deterministic_mask_slot_candidate" if deterministic_allow else "rejected",
        "needs_pairwise_check": True,
        "edit_stats": edit_stats,
    }

    return {
        "hard_filter_ok": hard_ok,
        "hard_filter_reason": hard_reason if hard_ok else hard_reason,

        "deterministic_allow_candidate": deterministic_allow,
        "deterministic_score": round(deterministic_score, 4),
        "deterministic_risk_ratio": round(risk_ratio, 4),
        "deterministic_risk_items": risk_items,

        "verified_better_than_initial": False,
        "soft_source_supported": deterministic_allow,
        "selection_tier": "deterministic_mask_slot_candidate" if deterministic_allow else "rejected",

        "source_supported_candidate": source_supported_candidate,
        "prior_fluency_candidate": prior_fluency_candidate,
        "local_probability_gate_type": gate_type,
        "source_probability_quality_gate_pass": deterministic_allow,

        "verifier": verifier,

        "reward_gate_pass": deterministic_allow,
        "reward_gate_failed_reasons": [] if deterministic_allow else [
            x["name"] for x in risk_items if x.get("triggered", False)
        ],
        "repair_reward_raw": round(deterministic_score, 4),
        "risk_penalty": round(risk_ratio, 4),
        "verifier_reward_score": round(deterministic_score, 4),
        "reward_tier": "deterministic_mask_slot_candidate" if deterministic_allow else "rejected",
        "reward_risk_level": reward_details["risk_level"],
        "reward_components": reward_details["repair_reward_components"],
        "risk_penalty_reasons": risk_items,
        "needs_pairwise_check": True,
        "reward_details": reward_details,
    }


# =========================================================
# Candidate generation prompts: mask-slot repair
# =========================================================
def is_actionable_mode(mode: str) -> bool:
    return "weak_optional" not in clean_text(mode)


def system_candidate_prompt(mode: str) -> str:
    optional_mode = mode == "weak_optional_conservative_repair"

    if mode.startswith("source_only_mask_repair"):
        mode_rule = """
Mode:
- Source-only mask repair.
- Use the source sentence as the only semantic evidence.
- Do not use visual assumptions.
- The target span comes from high-confidence actionable suspicious_spans.
- You should attempt a local repair.
""".strip()

    elif mode.startswith("source_image_mask_repair"):
        mode_rule = """
Mode:
- Source+image mask repair.
- Use the source sentence as the primary evidence.
- Use the image only as secondary evidence for visually ambiguous actionable spans.
- The target span comes from high-confidence actionable suspicious_spans.
- You should attempt a local repair.
""".strip()

    elif mode == "weak_optional_conservative_repair":
        mode_rule = """
Mode:
- Weak optional conservative repair.
- The listed span is NOT a forced repair target.
- It is only a soft suspicious hint from weak_suspicious_spans.
- Repair it only if the source sentence clearly shows that the current phrase is over-specific, unsupported, or locally awkward.
- If a faithful local repair is not clear, return the original translation and an empty slot_repairs list.
- Do not use the image unless the weak span itself is visually ambiguous and the source allows it.
""".strip()

    else:
        mode_rule = """
Mode:
- Conservative paraphrase/delete repair.
- The target span comes from high-confidence actionable suspicious_spans.
- You should attempt a local repair.
- For edit_type=delete, do NOT simply make an ungrammatical deletion.
- Convert delete into local paraphrase deletion or phrase compression.
- Remove only unsupported extra content while keeping the sentence grammatical.
- For edit_type=paraphrase, rewrite only the smallest local phrase.
- For edit_type=visual_refill, repair only if the source makes the repair clear; otherwise keep unchanged.
""".strip()

    force_rule = (
        "3. The listed weak span is optional. Repair it only if the source clearly supports the repair; otherwise return the original translation."
        if optional_mode else
        "3. The listed actionable suspicious span should be repaired locally. Return unchanged only if the span is already fully faithful to the source."
    )

    return f"""
You are a professional translation candidate generator.

Your task is mask-slot local repair for an English translation.

{mode_rule}

Strict rules:
1. The source sentence is the primary constraint.
2. The image, if provided, is only secondary evidence.
{force_rule}
4. You must preserve every anchor span exactly if possible, or at least semantically unchanged.
5. Do not change unrelated text.
6. Do not rewrite the whole sentence.
7. Do not add source-unsupported objects, actions, attributes, numbers, identities, or relations.
8. Do not delete source-supported information.
9. For edit_type=delete, use local paraphrase deletion / phrase compression:
   remove or neutralize the unsupported local phrase, then keep the sentence grammatical.
10. For edit_type=visual_refill, refill the masked local phrase using source+image evidence only when justified.
11. For edit_type=paraphrase, repair awkward, unsupported, or over-specific local wording using source evidence.
12. The candidate must be a complete grammatical English sentence.
13. Return JSON only. Do not output chain-of-thought.

Return exactly:
{{
  "candidate": "...",
  "slot_repairs": [
    {{
      "mask_id": "<mask_1>",
      "span": "...",
      "edit_type": "delete|paraphrase|visual_refill",
      "old_phrase": "...",
      "new_phrase": "...",
      "repair_intent": "source_only_mask_repair|source_image_mask_repair|local_paraphrase_deletion|conservative_paraphrase|weak_optional_conservative_repair|no_change"
    }}
  ]
}}

Requirements:
- old_phrase must be an exact phrase copied from the current English translation.
- new_phrase must be the replacement phrase inside the candidate.
- For delete repair, new_phrase may be shorter than old_phrase, but the final candidate must remain grammatical.
- If no faithful repair is possible, return the original translation and an empty slot_repairs list.
""".strip()


def user_candidate_prompt(
    source_text: str,
    initial: str,
    masked_translation: str,
    slots: List[Dict],
    ops: List[Dict],
    anchors: List[str],
    mode: str,
    avoid: str = "",
) -> str:
    avoid_part = ""
    if clean_text(avoid):
        avoid_part = f"""
Avoid returning this previous candidate exactly:
{avoid}
""".strip()

    optional_note = ""
    if mode == "weak_optional_conservative_repair":
        optional_note = """
Important:
- These target spans come from weak_suspicious_spans.
- They are optional hints, not forced repairs.
- Return the original translation if the repair is not clearly supported by the source.
""".strip()
    else:
        optional_note = """
Important:
- These target spans come from actionable suspicious_spans.
- Try to produce a faithful local repair.
- Return unchanged only if the span is already fully faithful to the source.
""".strip()

    return f"""
Candidate mode:
{mode}

{SOURCE_LANGUAGE_NAME} source sentence:
{source_text}

Current English translation:
{initial}

Masked English translation:
{masked_translation}

Mask slots:
{safe_json(slots)}

Target spans:
{safe_json(compact_operands(ops))}

Anchor spans that must be preserved exactly or semantically unchanged:
{safe_json(anchors)}

{optional_note}

{avoid_part}

Instructions:
- Repair the masked local slots only.
- The target span must be touched if you make a repair.
- Preserve anchor spans.
- Preserve unrelated parts of the current translation.
- Do not introduce new concrete information not supported by the source sentence.
- Do not make a style-only or synonym-only rewrite.
- Return JSON only.
""".strip()


def gen_candidate_once(
    source_text: str,
    initial: str,
    image_path: str,
    ops: List[Dict],
    anchors: List[str],
    mode: str,
    use_image: bool,
    avoid: str = "",
) -> Tuple[str, Dict, str]:
    image = load_image(image_path) if use_image and image_path else None

    masked_translation, slots = mask_translation(initial, ops)

    try:
        raw = run_qwen_json(
            system_candidate_prompt(mode),
            user_candidate_prompt(
                source_text=source_text,
                initial=initial,
                masked_translation=masked_translation,
                slots=slots,
                ops=ops,
                anchors=anchors,
                mode=mode,
                avoid=avoid,
            ),
            image,
            MAX_NEW_TOKENS_CANDIDATE,
        )

        obj = extract_json(raw)
        cand = norm_sent(obj.get("candidate", "")) if isinstance(obj, dict) else ""
        return cand, obj if isinstance(obj, dict) else {}, raw

    finally:
        if image is not None:
            image.close()
        cleanup_cuda()


# =========================================================
# Candidate item helpers
# =========================================================
def unchanged(initial: str, reason: str, mode: str = "unchanged") -> Dict:
    return {
        "candidate": norm_sent(initial),
        "edit_label": "unchanged",
        "edited_spans": [],
        "reason": reason,
        "candidate_mode": mode,
    }


def changed_item(
    initial: str,
    cand: str,
    reason: str,
    mode: str,
    edited_spans: Optional[List[Dict]] = None,
) -> Dict:
    edits = edited_spans if edited_spans is not None else diff_edits(initial, cand)

    return {
        "candidate": norm_sent(cand),
        "edit_label": "mask_slot_repair" if edits else "unchanged",
        "edited_spans": edits,
        "reason": reason,
        "candidate_mode": mode,
    }


def candidate_generation_risk_reason(
    initial: str,
    candidate: str,
    edits: List[Dict],
    ops: List[Dict],
    anchors: List[str],
) -> str:
    if has_bad_article_sequence(candidate):
        return "blocked_bad_article_sequence"

    if has_bad_repetition(candidate):
        return "blocked_bad_repetition"

    if has_repeated_ngram(candidate):
        return "blocked_repeated_ngram"

    if has_unbalanced_punctuation(candidate):
        return "blocked_unbalanced_punctuation"

    if looks_like_fragment(candidate):
        return "blocked_fragment_or_truncated_sentence"

    anchor_ok, _, missing = anchors_preserved(initial, candidate, anchors)

    if not anchor_ok:
        return "blocked_anchor_not_preserved:" + "|".join(missing)

    touched, _, _, _ = target_span_touched(ops, edits)

    if not touched:
        return "blocked_target_span_not_touched"

    local_ok, local_reason = local_edit_ok(initial, candidate, edits, ops)

    if not local_ok:
        return "blocked_" + local_reason

    if content_deletion_detected(edits) and not has_delete_op(ops):
        return "blocked_unsafe_content_deletion_without_delete_intent"

    return ""


def build_candidate(
    source_text: str,
    initial: str,
    image_path: str,
    ops: List[Dict],
    anchors: List[str],
    mode: str,
    use_image: bool,
    avoid: str = "",
) -> Dict:
    base = norm_sent(initial)

    if not ops:
        return unchanged(base, "no_repair_op", mode=mode)

    cand, obj, raw = gen_candidate_once(
        source_text=source_text,
        initial=base,
        image_path=image_path,
        ops=ops,
        anchors=anchors,
        mode=mode,
        use_image=use_image,
        avoid=avoid,
    )

    if (not cand or same(cand, base)) and is_actionable_mode(mode):
        cand2, obj2, raw2 = gen_candidate_once(
            source_text=source_text,
            initial=base,
            image_path=image_path,
            ops=ops,
            anchors=anchors,
            mode=mode + "_force_local_repair",
            use_image=use_image,
            avoid=avoid,
        )

        if cand2 and not same(cand2, base):
            cand, obj = cand2, obj2

    if not cand:
        return unchanged(base, "generation_failed_empty", mode=mode)

    if same(cand, base):
        return unchanged(base, "model_returned_unchanged", mode=mode)

    if avoid and same(cand, avoid):
        cand2, obj2, raw2 = gen_candidate_once(
            source_text=source_text,
            initial=base,
            image_path=image_path,
            ops=ops,
            anchors=anchors,
            mode=mode + "_alternative",
            use_image=use_image,
            avoid=avoid,
        )

        if cand2 and not same(cand2, base) and not same(cand2, avoid):
            cand, obj = cand2, obj2
        else:
            return unchanged(base, "duplicated_previous_or_unchanged", mode=mode)

    edits = make_candidate_edits(base, cand, obj)

    if not edits:
        return unchanged(base, "diff_no_actual_change", mode=mode)

    risk_reason = candidate_generation_risk_reason(
        initial=base,
        candidate=cand,
        edits=edits,
        ops=ops,
        anchors=anchors,
    )

    if risk_reason:
        cand2, obj2, raw2 = gen_candidate_once(
            source_text=source_text,
            initial=base,
            image_path=image_path,
            ops=ops,
            anchors=anchors,
            mode=mode + "_strict_retry",
            use_image=use_image,
            avoid=cand,
        )

        if cand2 and not same(cand2, base) and not same(cand2, cand):
            edits2 = make_candidate_edits(base, cand2, obj2)
            risk_reason2 = candidate_generation_risk_reason(
                initial=base,
                candidate=cand2,
                edits=edits2,
                ops=ops,
                anchors=anchors,
            )

            if edits2 and not risk_reason2:
                cand, obj, edits = cand2, obj2, edits2
            else:
                return unchanged(base, risk_reason, mode=mode)
        else:
            return unchanged(base, risk_reason, mode=mode)

    reason = clean_text(obj.get("reason", "")) if isinstance(obj, dict) else ""

    if not reason:
        reason = f"{mode}_candidate"

    return changed_item(
        initial=base,
        cand=cand,
        reason=reason,
        mode=mode,
        edited_spans=edits,
    )


def dedup(c1: Dict, c2: Dict, c3: Dict, initial: str) -> Tuple[Dict, Dict, Dict]:
    base = norm_sent(initial)
    seen = set()
    out = []

    for idx, item in enumerate([c1, c2, c3], 1):
        cand = norm_sent(item.get("candidate", ""))

        if not cand:
            item = unchanged(base, f"empty_candidate_{idx}_fallback", mode=item.get("candidate_mode", "unknown"))
            cand = base

        nc = norm(cand)

        if nc in seen and nc != norm(base):
            item = unchanged(
                base,
                f"candidate_{idx}_duplicated_previous_candidate",
                mode=item.get("candidate_mode", "unknown"),
            )
            nc = norm(base)

        seen.add(nc)
        out.append(item)

    return out[0], out[1], out[2]


# =========================================================
# Verification field writer
# =========================================================
def add_verification_fields(
    rec: Dict,
    idx: int,
    verify_result: Dict,
):
    prefix = f"candidate_{idx}"

    rec[f"{prefix}_hard_filter_ok"] = verify_result.get("hard_filter_ok", False)
    rec[f"{prefix}_hard_filter_reason"] = verify_result.get("hard_filter_reason", "")

    rec[f"{prefix}_deterministic_allow_candidate"] = verify_result.get(
        "deterministic_allow_candidate",
        False,
    )
    rec[f"{prefix}_deterministic_score"] = verify_result.get(
        "deterministic_score",
        0.0,
    )
    rec[f"{prefix}_deterministic_risk_ratio"] = verify_result.get(
        "deterministic_risk_ratio",
        0.0,
    )
    rec[f"{prefix}_deterministic_risk_items"] = verify_result.get(
        "deterministic_risk_items",
        [],
    )

    rec[f"{prefix}_verified_better_than_initial"] = verify_result.get(
        "verified_better_than_initial",
        False,
    )
    rec[f"{prefix}_soft_source_supported"] = verify_result.get(
        "soft_source_supported",
        False,
    )

    # Do NOT output candidate_i_eligible_for_selection.
    # select only reads candidate_i_deterministic_allow_candidate.
    rec[f"{prefix}_selection_tier"] = verify_result.get(
        "selection_tier",
        "rejected",
    )

    rec[f"{prefix}_source_supported_candidate"] = verify_result.get(
        "source_supported_candidate",
        False,
    )
    rec[f"{prefix}_prior_fluency_candidate"] = verify_result.get(
        "prior_fluency_candidate",
        False,
    )
    rec[f"{prefix}_local_probability_gate_type"] = verify_result.get(
        "local_probability_gate_type",
        "rejected",
    )
    rec[f"{prefix}_source_probability_quality_gate_pass"] = verify_result.get(
        "source_probability_quality_gate_pass",
        False,
    )

    rec[f"{prefix}_verifier"] = verify_result.get("verifier", {})

    rec[f"{prefix}_reward_gate_pass"] = verify_result.get(
        "reward_gate_pass",
        False,
    )
    rec[f"{prefix}_reward_gate_failed_reasons"] = verify_result.get(
        "reward_gate_failed_reasons",
        [],
    )
    rec[f"{prefix}_repair_reward_raw"] = verify_result.get(
        "repair_reward_raw",
        0.0,
    )
    rec[f"{prefix}_risk_penalty"] = verify_result.get(
        "risk_penalty",
        0.0,
    )
    rec[f"{prefix}_verifier_reward_score"] = verify_result.get(
        "verifier_reward_score",
        0.0,
    )
    rec[f"{prefix}_reward_tier"] = verify_result.get(
        "reward_tier",
        "rejected",
    )
    rec[f"{prefix}_reward_risk_level"] = verify_result.get(
        "reward_risk_level",
        "none",
    )
    rec[f"{prefix}_reward_components"] = verify_result.get(
        "reward_components",
        [],
    )
    rec[f"{prefix}_risk_penalty_reasons"] = verify_result.get(
        "risk_penalty_reasons",
        [],
    )
    rec[f"{prefix}_needs_pairwise_check"] = verify_result.get(
        "needs_pairwise_check",
        False,
    )
    rec[f"{prefix}_reward_details"] = verify_result.get(
        "reward_details",
        {},
    )


def add_error_verification_fields(
    rec: Dict,
    idx: int,
    hard_reason: str = "error_fallback",
):
    verify_result = make_static_verification(
        reason=hard_reason,
        tier="error_fallback",
    )

    add_verification_fields(rec, idx, verify_result)


def write_record(path: str, rec: Dict):
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")


# =========================================================
# Main
# =========================================================
def main():
    rows = []

    with open(INPUT_JSONL, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))

    total_all = len(rows)

    if MAX_ROWS is not None:
        rows = rows[:MAX_ROWS]

    ref_map = build_reference_map(REFERENCE_JSONL)

    os.makedirs(os.path.dirname(OUTPUT_JSONL), exist_ok=True)

    with open(OUTPUT_JSONL, "w", encoding="utf-8"):
        pass

    print(f"[INFO] LANGUAGE: {LANGUAGE}")
    print(f"[INFO] GPU: {GPU}")
    print(f"[INFO] SOURCE_LANGUAGE_NAME: {SOURCE_LANGUAGE_NAME}")
    print(f"[INFO] OUTPUT_ROOT: {OUTPUT_ROOT}")
    print(f"[INFO] INPUT_JSONL: {INPUT_JSONL}")
    print(f"[INFO] REFERENCE_JSONL: {REFERENCE_JSONL}")
    print(f"[INFO] OUTPUT_JSONL: {OUTPUT_JSONL}")
    print(f"[INFO] Total loaded rows: {total_all}")
    print(f"[INFO] Actual run rows: {len(rows)}")
    print("[INFO] candidate_1 = source-only mask repair over actionable suspicious_spans only")
    print("[INFO] candidate_2 = source+image mask repair over actionable suspicious_spans only")
    print("[INFO] candidate_3 = conservative repair over actionable spans; if none, optional weak repair")
    print("[INFO] weak_suspicious_spans are optional hints only, never must-repair for c1/c2")
    print("[INFO] weak source-supported phrase noise is filtered")
    print("[INFO] structure-based local phrase expansion before mask is enabled")
    print("[INFO] no LIGHT_VERB_LIKE or hand-written verb preference list is used")
    print("[INFO] actionable unchanged retry is enabled")
    print("[INFO] delete restored as local paraphrase deletion / phrase compression")
    print("[INFO] anchor preservation enabled with target-overlap pruning")
    print("[INFO] no top-level candidate_i_eligible_for_selection fields are emitted")

    stats = {
        "total": 0,
        "candidate_slots_total": 0,

        "missing_reference_translation": 0,

        "rows_with_actionable_repair_ops": 0,
        "rows_with_weak_optional_ops": 0,
        "rows_with_anchor_spans": 0,

        "actionable_ops_total": 0,
        "weak_optional_ops_total": 0,
        "expanded_actionable_ops_total": 0,
        "expanded_weak_ops_total": 0,

        "delete_ops_total": 0,
        "paraphrase_ops_total": 0,
        "visual_refill_ops_total": 0,

        "candidate_3_weak_optional_rows": 0,
        "candidate_3_actionable_rows": 0,

        "changed_candidate_rows": 0,
        "candidate_changed_total": 0,
        "unchanged_candidate_total": 0,

        "deterministic_allowed_candidates": 0,
        "deterministic_rejected_candidates": 0,
        "changed_allowed_candidate_count": 0,
        "changed_rejected_candidate_count": 0,

        "target_span_not_touched_candidates": 0,
        "anchor_not_preserved_candidates": 0,
        "unsafe_content_deletion_candidates": 0,
        "local_paraphrase_deletion_candidates": 0,
        "phrase_compression_repair_candidates": 0,
        "pronoun_identity_shift_candidates": 0,
        "non_local_edit_candidates": 0,
        "bad_hard_filter_candidates": 0,
        "weak_optional_repair_candidates": 0,
    }

    times = []

    for i, row in enumerate(rows, 1):
        t0 = time.time()

        sid = clean_text(row.get("id", row.get("image_id", "")))
        image_path = clean_text(row.get("image_path", ""))
        source_text = clean_text(row.get("source_text", ""))
        reference_translation = get_reference_translation(row, ref_map)
        initial = clean_text(row.get("initial_translation", row.get("initial_translation_en", "")))
        base = norm_sent(initial)

        stats["total"] += 1

        if not reference_translation:
            stats["missing_reference_translation"] += 1

        try:
            actionable_ops_raw = collect_repair_ops(row)
            weak_optional_ops_raw = collect_weak_repair_ops(row)
            anchors_all = collect_anchor_spans(row)

            actionable_ops = expand_ops_for_mask(base, actionable_ops_raw, mode="actionable")
            weak_optional_ops = expand_ops_for_mask(base, weak_optional_ops_raw, mode="weak_optional")

            if actionable_ops:
                stats["rows_with_actionable_repair_ops"] += 1

            if weak_optional_ops:
                stats["rows_with_weak_optional_ops"] += 1

            if anchors_all:
                stats["rows_with_anchor_spans"] += 1

            stats["actionable_ops_total"] += len(actionable_ops)
            stats["weak_optional_ops_total"] += len(weak_optional_ops)

            stats["expanded_actionable_ops_total"] += sum(1 for x in actionable_ops if x.get("span_expanded", False))
            stats["expanded_weak_ops_total"] += sum(1 for x in weak_optional_ops if x.get("span_expanded", False))

            for op in actionable_ops:
                et = normalize_edit_type(op.get("edit_type", ""))
                if et == "delete":
                    stats["delete_ops_total"] += 1
                elif et == "paraphrase":
                    stats["paraphrase_ops_total"] += 1
                elif et == "visual_refill":
                    stats["visual_refill_ops_total"] += 1

            anchors_for_actionable = prune_anchors_for_ops(anchors_all, actionable_ops)
            anchors_for_weak = prune_anchors_for_ops(anchors_all, weak_optional_ops)

            if actionable_ops:
                c1 = build_candidate(
                    source_text=source_text,
                    initial=base,
                    image_path=image_path,
                    ops=actionable_ops,
                    anchors=anchors_for_actionable,
                    mode="source_only_mask_repair",
                    use_image=False,
                )

                c2 = build_candidate(
                    source_text=source_text,
                    initial=base,
                    image_path=image_path,
                    ops=actionable_ops,
                    anchors=anchors_for_actionable,
                    mode="source_image_mask_repair",
                    use_image=True,
                    avoid=c1.get("candidate", ""),
                )

                c3 = build_candidate(
                    source_text=source_text,
                    initial=base,
                    image_path=image_path,
                    ops=actionable_ops,
                    anchors=anchors_for_actionable,
                    mode="conservative_paraphrase_delete_repair",
                    use_image=False,
                    avoid=c2.get("candidate", ""),
                )

                c1_ops = actionable_ops
                c2_ops = actionable_ops
                c3_ops = actionable_ops

                c1_anchors = anchors_for_actionable
                c2_anchors = anchors_for_actionable
                c3_anchors = anchors_for_actionable

                c3_used_weak_optional = False
                stats["candidate_3_actionable_rows"] += 1

            elif weak_optional_ops:
                c1 = unchanged(base, "no_actionable_repair_op", mode="source_only_mask_repair")
                c2 = unchanged(base, "no_actionable_repair_op", mode="source_image_mask_repair")

                c3 = build_candidate(
                    source_text=source_text,
                    initial=base,
                    image_path=image_path,
                    ops=weak_optional_ops,
                    anchors=anchors_for_weak,
                    mode="weak_optional_conservative_repair",
                    use_image=False,
                    avoid="",
                )

                c1_ops = []
                c2_ops = []
                c3_ops = weak_optional_ops

                c1_anchors = anchors_all
                c2_anchors = anchors_all
                c3_anchors = anchors_for_weak

                c3_used_weak_optional = True
                stats["candidate_3_weak_optional_rows"] += 1

            else:
                c1 = unchanged(base, "no_actionable_or_weak_repair_op", mode="source_only_mask_repair")
                c2 = unchanged(base, "no_actionable_or_weak_repair_op", mode="source_image_mask_repair")
                c3 = unchanged(base, "no_actionable_or_weak_repair_op", mode="conservative_paraphrase_delete_repair")

                c1_ops = []
                c2_ops = []
                c3_ops = []

                c1_anchors = anchors_all
                c2_anchors = anchors_all
                c3_anchors = anchors_all

                c3_used_weak_optional = False

            c1, c2, c3 = dedup(c1, c2, c3, base)

            candidate_items = [c1, c2, c3]
            candidate_modes = [
                c1.get("candidate_mode", "source_only_mask_repair"),
                c2.get("candidate_mode", "source_image_mask_repair"),
                c3.get("candidate_mode", "conservative_paraphrase_delete_repair"),
            ]
            candidate_ops_list = [c1_ops, c2_ops, c3_ops]
            candidate_anchor_list = [c1_anchors, c2_anchors, c3_anchors]

            verify_results = []

            for cand_idx, (cand_item, cand_mode, cand_ops, cand_anchors) in enumerate(
                zip(candidate_items, candidate_modes, candidate_ops_list, candidate_anchor_list),
                start=1,
            ):
                stats["candidate_slots_total"] += 1

                cand_text = cand_item.get("candidate", base)
                is_changed = not same(cand_text, base)

                if not is_changed:
                    stats["unchanged_candidate_total"] += 1

                    verify_results.append(
                        make_static_verification(
                            reason=cand_item.get("reason", "unchanged_candidate"),
                            tier="unchanged_candidate",
                        )
                    )
                    continue

                stats["candidate_changed_total"] += 1

                verify_result = deterministic_evaluate_candidate(
                    source_text=source_text,
                    initial=base,
                    candidate=cand_text,
                    ops=cand_ops,
                    anchors=cand_anchors,
                    edited_spans=cand_item.get("edited_spans", []),
                    candidate_mode=cand_mode,
                )

                verify_results.append(verify_result)

                if verify_result.get("deterministic_allow_candidate", False):
                    stats["deterministic_allowed_candidates"] += 1
                    stats["changed_allowed_candidate_count"] += 1
                else:
                    stats["deterministic_rejected_candidates"] += 1
                    stats["changed_rejected_candidate_count"] += 1

                for item in verify_result.get("deterministic_risk_items", []):
                    if not isinstance(item, dict):
                        continue

                    if not item.get("triggered", False):
                        continue

                    name = clean_text(item.get("name", ""))

                    if name == "target_span_not_touched":
                        stats["target_span_not_touched_candidates"] += 1
                    elif name == "anchor_not_preserved":
                        stats["anchor_not_preserved_candidates"] += 1
                    elif name == "unsafe_content_deletion":
                        stats["unsafe_content_deletion_candidates"] += 1
                    elif name == "local_paraphrase_deletion":
                        stats["local_paraphrase_deletion_candidates"] += 1
                    elif name == "phrase_compression_repair":
                        stats["phrase_compression_repair_candidates"] += 1
                    elif name == "pronoun_or_identity_shift":
                        stats["pronoun_identity_shift_candidates"] += 1
                    elif name == "non_local_edit":
                        stats["non_local_edit_candidates"] += 1
                    elif name == "bad_hard_filter":
                        stats["bad_hard_filter_candidates"] += 1
                    elif name == "weak_optional_repair":
                        stats["weak_optional_repair_candidates"] += 1

            changed_count = sum(
                not same(x.get("candidate", ""), base)
                for x in candidate_items
            )

            if changed_count > 0:
                stats["changed_candidate_rows"] += 1

            v1, v2, v3 = verify_results

            allowed_count = sum(
                bool(v.get("deterministic_allow_candidate", False))
                for v in verify_results
            )

            rec = {
                "id": sid,
                "image_path": image_path,
                "source_text": source_text,
                "reference_translation": reference_translation,
                "initial_translation": initial,
                "language": LANGUAGE,
                "source_language_name": SOURCE_LANGUAGE_NAME,

                "candidate_1": c1.get("candidate", base),
                "candidate_2": c2.get("candidate", base),
                "candidate_3": c3.get("candidate", base),

                "candidate_1_mode": c1.get("candidate_mode", "source_only_mask_repair"),
                "candidate_2_mode": c2.get("candidate_mode", "source_image_mask_repair"),
                "candidate_3_mode": c3.get("candidate_mode", "conservative_paraphrase_delete_repair"),

                "edit_label_1": c1.get("edit_label", "unchanged"),
                "edit_label_2": c2.get("edit_label", "unchanged"),
                "edit_label_3": c3.get("edit_label", "unchanged"),

                "edited_spans_1": c1.get("edited_spans", []),
                "edited_spans_2": c2.get("edited_spans", []),
                "edited_spans_3": c3.get("edited_spans", []),

                "repair_ops": compact_operands(actionable_ops),
                "repair_ops_raw": compact_operands(actionable_ops_raw),
                "weak_repair_ops": compact_operands(weak_optional_ops),
                "weak_repair_ops_raw": compact_operands(weak_optional_ops_raw),
                "all_weak_suspicious_spans": collect_all_weak_spans_for_output(row),
                "anchor_spans": anchors_all,

                "candidate_1_effective_repair_ops": compact_operands(c1_ops),
                "candidate_2_effective_repair_ops": compact_operands(c2_ops),
                "candidate_3_effective_repair_ops": compact_operands(c3_ops),

                "candidate_1_effective_anchor_spans": c1_anchors,
                "candidate_2_effective_anchor_spans": c2_anchors,
                "candidate_3_effective_anchor_spans": c3_anchors,

                "candidate_3_used_weak_optional_repair": bool(c3_used_weak_optional),

                "candidate_formula_version": CANDIDATE_FORMULA_VERSION,

                "mask_slot_repair_enabled": True,
                "candidate_1_source_only_mask_repair": True,
                "candidate_2_source_image_mask_repair": True,
                "candidate_3_conservative_paraphrase_delete_repair": True,
                "candidate_3_weak_optional_repair_enabled": True,

                "actionable_suspicious_spans_are_must_repair": True,
                "weak_suspicious_spans_are_optional_only": True,
                "weak_source_supported_phrase_noise_filtered": True,
                "weak_sort_by_evidence_not_span_length": True,
                "structure_based_local_phrase_expansion_before_mask": True,
                "no_light_verb_lexicon": True,
                "actionable_unchanged_force_retry_enabled": True,

                "delete_restored": True,
                "delete_as_local_paraphrase_deletion": True,
                "anchor_preservation_enabled": True,
                "anchor_overlap_with_target_pruned": True,

                "llm_verifier_removed": True,
                "llm_guard_removed": True,
                "reference_translation_used_only_as_output_field": True,
                "candidate_eligible_for_selection_field_removed": True,
            }

            add_verification_fields(rec, 1, v1)
            add_verification_fields(rec, 2, v2)
            add_verification_fields(rec, 3, v3)

            write_record(OUTPUT_JSONL, rec)

            dt = time.time() - t0
            times.append(dt)
            avg = sum(times) / len(times)
            eta = avg * (len(rows) - i)

            print(
                f"[{i}/{len(rows)}] id={sid} | {dt:.2f}s | "
                f"avg={avg:.2f}s | ETA={format_time(eta)} | "
                f"actionable_ops={len(actionable_ops)} | weak_ops={len(weak_optional_ops)} | "
                f"expanded_actionable={sum(1 for x in actionable_ops if x.get('span_expanded', False))} | "
                f"expanded_weak={sum(1 for x in weak_optional_ops if x.get('span_expanded', False))} | "
                f"anchors={len(anchors_all)} | changed={changed_count} | "
                f"det_allowed={allowed_count} | c3_weak={c3_used_weak_optional} | "
                f"ref_empty={not bool(reference_translation)}"
            )

        except Exception as e:
            rec = {
                "id": sid,
                "image_path": image_path,
                "source_text": source_text,
                "reference_translation": reference_translation,
                "initial_translation": initial,
                "language": LANGUAGE,
                "source_language_name": SOURCE_LANGUAGE_NAME,

                "candidate_1": base,
                "candidate_2": base,
                "candidate_3": base,

                "candidate_1_mode": "source_only_mask_repair",
                "candidate_2_mode": "source_image_mask_repair",
                "candidate_3_mode": "conservative_paraphrase_delete_repair",

                "edit_label_1": "unchanged",
                "edit_label_2": "unchanged",
                "edit_label_3": "unchanged",

                "edited_spans_1": [],
                "edited_spans_2": [],
                "edited_spans_3": [],

                "repair_ops": [],
                "repair_ops_raw": [],
                "weak_repair_ops": [],
                "weak_repair_ops_raw": [],
                "all_weak_suspicious_spans": [],
                "anchor_spans": [],

                "candidate_1_effective_repair_ops": [],
                "candidate_2_effective_repair_ops": [],
                "candidate_3_effective_repair_ops": [],

                "candidate_1_effective_anchor_spans": [],
                "candidate_2_effective_anchor_spans": [],
                "candidate_3_effective_anchor_spans": [],

                "candidate_3_used_weak_optional_repair": False,

                "candidate_formula_version": CANDIDATE_FORMULA_VERSION,

                "mask_slot_repair_enabled": True,
                "candidate_1_source_only_mask_repair": True,
                "candidate_2_source_image_mask_repair": True,
                "candidate_3_conservative_paraphrase_delete_repair": True,
                "candidate_3_weak_optional_repair_enabled": True,

                "actionable_suspicious_spans_are_must_repair": True,
                "weak_suspicious_spans_are_optional_only": True,
                "weak_source_supported_phrase_noise_filtered": True,
                "weak_sort_by_evidence_not_span_length": True,
                "structure_based_local_phrase_expansion_before_mask": True,
                "no_light_verb_lexicon": True,
                "actionable_unchanged_force_retry_enabled": True,

                "delete_restored": True,
                "delete_as_local_paraphrase_deletion": True,
                "anchor_preservation_enabled": True,
                "anchor_overlap_with_target_pruned": True,

                "llm_verifier_removed": True,
                "llm_guard_removed": True,
                "reference_translation_used_only_as_output_field": True,
                "candidate_eligible_for_selection_field_removed": True,

                "error": repr(e),
            }

            add_error_verification_fields(rec, 1, "error_fallback")
            add_error_verification_fields(rec, 2, "error_fallback")
            add_error_verification_fields(rec, 3, "error_fallback")

            write_record(OUTPUT_JSONL, rec)
            print(f"[WARN] id={sid} failed: {repr(e)}")
            cleanup_cuda()

    print(f"[DONE] Saved to: {OUTPUT_JSONL}")
    print("[stats]", stats)

    if stats["missing_reference_translation"] > 0:
        print(
            f"[WARN] {stats['missing_reference_translation']} rows still have empty reference_translation. "
            f"Please check whether REFERENCE_JSONL is correct and whether ids/source_text match."
        )


if __name__ == "__main__":
    main()