#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import argparse

# =========================================================
# Arguments: parse before importing torch
# =========================================================
ALLOWED_LANGUAGES = {"hi", "lv", "tr"}

SONAR_SRC_LANG_MAP = {
    "hi": "hin_Deva",
    "lv": "lav_Latn",
    "tr": "tur_Latn",
}


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--lang",
        type=str,
        required=True,
        choices=sorted(ALLOWED_LANGUAGES),
        help="Language code: hi, lv, tr.",
    )
    parser.add_argument(
        "--gpu",
        type=str,
        required=True,
        help="Physical GPU id, for example: 0, 1, 5, 6, 7.",
    )
    return parser.parse_args()


ARGS = parse_args()
LANGUAGE = ARGS.lang
GPU = ARGS.gpu

# =========================================================
# Environment variables
# =========================================================
os.environ["CUDA_VISIBLE_DEVICES"] = str(GPU)
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"

os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"
os.environ["TOKENIZERS_PARALLELISM"] = "false"

os.environ["HF_HOME"] = "/home/chenyi/model_cache/huggingface"
os.environ["TRANSFORMERS_CACHE"] = "/home/chenyi/model_cache/huggingface/hub"

SYSLIBS_DIR = "/home/chenyi/offline_blaser_qe/syslibs"
os.environ["LD_LIBRARY_PATH"] = SYSLIBS_DIR + ":" + os.environ.get("LD_LIBRARY_PATH", "")

import json
import re
import time
from collections import defaultdict
from difflib import SequenceMatcher
from typing import Any, Dict, List, Optional, Tuple

import torch
import sentencepiece as spm

from sonar.models.sonar_text.model import SequenceBatch
from sonar.models.sonar_text import SonarTextEncoderConfig, create_sonar_text_encoder_model
from sonar.models.blaser.builder import create_blaser_model, _arch_blaser_basic_qe
from sonar.models.blaser.loader import convert_blaser_checkpoint

from comet import load_from_checkpoint

torch.set_grad_enabled(False)

try:
    torch.set_float32_matmul_precision("high")
except Exception:
    pass


# =========================================================
# Paths
# =========================================================
OUTPUT_ROOT = "/home/chenyi/offline_blaser_qe/out/Qwen_3_VL_8B/Multi30k"

INPUT_JSONL = os.path.join(
    OUTPUT_ROOT,
    LANGUAGE,
    f"{LANGUAGE}_3_candidates_from_span.jsonl",
)

OUTPUT_DIR = os.path.join(
    OUTPUT_ROOT,
    LANGUAGE,
)

OUTPUT_SOURCE_BEST_JSONL = os.path.join(
    OUTPUT_DIR,
    f"{LANGUAGE}_source_reference_best.jsonl",
)

CHECKPOINTS_DIR = "/home/chenyi/offline_blaser_qe/checkpoints"

SONAR_MODEL = os.path.join(CHECKPOINTS_DIR, "sonar_text_encoder.pt")
SPM_MODEL = os.path.join(CHECKPOINTS_DIR, "sentencepiece.source.256000.model")
BLASER_QE_CKPT = os.path.join(CHECKPOINTS_DIR, "blaser_2_0_qe_model.pt")

COMET_QE_CKPT = (
    "/home/chenyi/offline_blaser_qe/comet_qe_models/"
    "wmt21-comet-qe-da/checkpoints/model_local_xlmr.ckpt"
)

DEVICE = "cuda"
MAX_LEN = 256

BATCH_ROWS = 64
COMET_BATCH_SIZE = 16

SRC_LANG = SONAR_SRC_LANG_MAP[LANGUAGE]
TGT_LANG = "eng_Latn"

SELECTION_FORMULA_VERSION = (
    "select_rank_key_no_fixed_bonus_"
    "span_anchor_qe_relative_initial_v1_"
    "qwen3_multi30k_cli_lang_gpu"
)


# =========================================================
# Basic utils
# =========================================================
def clean_text(x: Any) -> str:
    if x is None:
        return ""
    return re.sub(r"\s+", " ", str(x).strip())


def norm(x: Any) -> str:
    x = clean_text(x).lower()
    x = x.replace("’", "'").replace("“", '"').replace("”", '"')
    x = re.sub(r"[^a-z0-9_\-\s]", " ", x)
    return re.sub(r"\s+", " ", x).strip()


def same(a: Any, b: Any) -> bool:
    return norm(a) == norm(b)


def safe_bool(x: Any, default: bool = False) -> bool:
    if isinstance(x, bool):
        return x

    s = norm(x)

    if s in {"true", "yes", "1"}:
        return True

    if s in {"false", "no", "0"}:
        return False

    return default


def safe_float(x: Any, default: float = 0.0) -> float:
    try:
        return float(x)
    except Exception:
        return default


def format_time(sec: float) -> str:
    sec = int(sec)
    return f"{sec // 3600:02d}:{(sec % 3600) // 60:02d}:{sec % 60:02d}"


def read_jsonl_records(path: str) -> List[Dict]:
    if not os.path.isfile(path):
        raise FileNotFoundError(f"JSONL not found: {path}")

    rows = []

    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))

    return rows


def write_jsonl_record(fp, obj: Dict):
    fp.write(json.dumps(obj, ensure_ascii=False) + "\n")


def parse_json_value(v: Any) -> Any:
    if isinstance(v, (dict, list)):
        return v

    if isinstance(v, str):
        s = clean_text(v)
        if not s:
            return None
        try:
            return json.loads(s)
        except Exception:
            return None

    return None


def get_nested_dict(row: Dict, key: str) -> Dict:
    v = parse_json_value(row.get(key, {}))
    return v if isinstance(v, dict) else {}


def get_nested_list(row: Dict, key: str) -> List:
    v = parse_json_value(row.get(key, []))
    return v if isinstance(v, list) else []


def first_nonempty(row: Dict, keys: List[str]) -> str:
    for k in keys:
        v = clean_text(row.get(k, ""))
        if v:
            return v
    return ""


def get_reference_translation(row: Dict) -> str:
    return first_nonempty(
        row,
        [
            "reference_translation",
            "src_en",
            "source_text_en",
            "reference",
            "source",
        ],
    )


def get_initial_translation(row: Dict) -> str:
    return first_nonempty(
        row,
        [
            "initial_translation",
            "initial_translation_en",
        ],
    )


def get_source_for_score(row: Dict) -> Tuple[str, str]:
    source_text = clean_text(row.get("source_text", ""))

    if source_text:
        return source_text, SRC_LANG

    return "", SRC_LANG


def tokenize_words(x: Any) -> List[str]:
    return re.findall(r"[A-Za-z0-9_\-]+", norm(x))


def overlap(a: str, b: str) -> bool:
    a = norm(a)
    b = norm(b)

    if not a or not b:
        return False

    return a == b or a in b or b in a


# =========================================================
# Candidate adapter
# =========================================================
def get_candidate_texts(row: Dict) -> List[str]:
    initial = get_initial_translation(row)

    cands = [
        initial,
        clean_text(row.get("candidate_1", "")),
        clean_text(row.get("candidate_2", "")),
        clean_text(row.get("candidate_3", "")),
    ]

    out = []

    for x in cands:
        x = clean_text(x)
        out.append(x if x else initial)

    return out


def get_candidate_mode(row: Dict, cand_idx: int) -> str:
    if cand_idx == 0:
        return "initial"
    return clean_text(row.get(f"candidate_{cand_idx}_mode", ""))


def get_candidate_verifier(row: Dict, cand_idx: int) -> Dict:
    if cand_idx == 0:
        return {}
    return get_nested_dict(row, f"candidate_{cand_idx}_verifier")


def get_candidate_edits(row: Dict, cand_idx: int) -> List[Dict]:
    if cand_idx == 0:
        return []

    edits = get_nested_list(row, f"edited_spans_{cand_idx}")

    clean_edits = []

    for ed in edits:
        if isinstance(ed, dict):
            clean_edits.append({
                "from": clean_text(ed.get("from", "")),
                "to": clean_text(ed.get("to", "")),
            })

    return clean_edits


def get_repair_ops(row: Dict) -> List[Dict]:
    ops = row.get("repair_ops", [])

    if isinstance(ops, str):
        parsed = parse_json_value(ops)
        ops = parsed if isinstance(parsed, list) else []

    if not isinstance(ops, list):
        return []

    out = []

    for op in ops:
        if not isinstance(op, dict):
            continue

        sp = clean_text(op.get("span", ""))
        et = clean_text(op.get("edit_type", "")).lower()

        if not sp:
            continue

        out.append({
            "span": sp,
            "edit_type": et,
            "edit_reason": clean_text(op.get("edit_reason", "")),
            "evidence_type": clean_text(op.get("evidence_type", "")),
        })

    return out


def get_anchor_spans(row: Dict) -> List[str]:
    anchors = row.get("anchor_spans", [])

    if isinstance(anchors, str):
        parsed = parse_json_value(anchors)
        anchors = parsed if isinstance(parsed, list) else []

    out = []

    if isinstance(anchors, list):
        for x in anchors:
            if isinstance(x, dict):
                sp = clean_text(x.get("span", ""))
            else:
                sp = clean_text(x)

            if sp:
                out.append(sp)

    seen = set()
    uniq = []

    for sp in out:
        n = norm(sp)
        if n and n not in seen:
            seen.add(n)
            uniq.append(sp)

    return uniq


def candidate_is_changed(initial: str, candidate: str) -> bool:
    return not same(initial, candidate)


def get_candidate_deterministic_allow(row: Dict, cand_idx: int) -> bool:
    if cand_idx == 0:
        return True

    direct = row.get(f"candidate_{cand_idx}_deterministic_allow_candidate", None)

    if direct is not None:
        return safe_bool(direct, False)

    verifier = get_candidate_verifier(row, cand_idx)

    return safe_bool(verifier.get("deterministic_allow_candidate", False), False)


def verifier_flag(row: Dict, cand_idx: int, key: str, default: bool = False) -> bool:
    verifier = get_candidate_verifier(row, cand_idx)
    return safe_bool(verifier.get(key, default), default)


def verifier_float(row: Dict, cand_idx: int, key: str, default: float = 0.0) -> float:
    verifier = get_candidate_verifier(row, cand_idx)
    return safe_float(verifier.get(key, default), default)


def verifier_triggered(row: Dict, cand_idx: int, risk_name: str) -> bool:
    verifier = get_candidate_verifier(row, cand_idx)
    items = verifier.get("deterministic_risk_items", [])

    if not isinstance(items, list):
        return False

    for item in items:
        if not isinstance(item, dict):
            continue

        if clean_text(item.get("name", "")) == risk_name and safe_bool(item.get("triggered", False), False):
            return True

    return False


def candidate_source_supported(row: Dict, cand_idx: int) -> bool:
    if cand_idx == 0:
        return False

    direct = row.get(f"candidate_{cand_idx}_source_supported_candidate", None)

    if direct is not None:
        return safe_bool(direct, False)

    verifier = get_candidate_verifier(row, cand_idx)

    if safe_bool(verifier.get("source_supported_candidate", False), False):
        return True

    gate_type = clean_text(verifier.get("local_probability_gate_type", ""))

    if gate_type == "source_supported_pass":
        return True

    return False


def candidate_is_phrase_compression_repair(row: Dict, cand_idx: int) -> bool:
    return (
        verifier_flag(row, cand_idx, "phrase_compression_repair", False)
        or verifier_triggered(row, cand_idx, "phrase_compression_repair")
        or verifier_triggered(row, cand_idx, "local_paraphrase_deletion")
    )


# =========================================================
# Span / anchor / edit-distance checks
# =========================================================
def candidate_span_repair_status(row: Dict, cand_idx: int) -> Tuple[bool, float, List[str], List[str]]:
    if cand_idx == 0:
        return False, 0.0, [], []

    verifier = get_candidate_verifier(row, cand_idx)

    verifier_touched = safe_bool(verifier.get("target_span_touched", False), False)
    verifier_coverage = safe_float(verifier.get("target_span_coverage_ratio", 0.0), 0.0)

    repair_ops = get_repair_ops(row)
    target_spans = [clean_text(x.get("span", "")) for x in repair_ops if clean_text(x.get("span", ""))]
    edits = get_candidate_edits(row, cand_idx)

    changed_from = [clean_text(x.get("from", "")) for x in edits]
    changed_to = [clean_text(x.get("to", "")) for x in edits]

    if not target_spans:
        # Fallback to verifier target spans if repair_ops is missing.
        vt = verifier.get("target_spans", [])
        if isinstance(vt, list):
            target_spans = [clean_text(x) for x in vt if clean_text(x)]

    if not target_spans:
        return verifier_touched, verifier_coverage, [], changed_from

    joined_from = " ".join(changed_from)
    joined_to = " ".join(changed_to)

    touched_count = 0

    for sp in target_spans:
        if overlap(sp, joined_from) or overlap(sp, joined_to):
            touched_count += 1

    calc_coverage = touched_count / max(1, len(target_spans))
    calc_touched = touched_count > 0

    touched = verifier_touched or calc_touched
    coverage = max(verifier_coverage, calc_coverage)

    return touched, coverage, target_spans, changed_from


def anchors_preserved_by_text(initial: str, candidate: str, anchors: List[str]) -> Tuple[bool, List[str], List[str]]:
    checked = []
    missing = []

    ni = norm(initial)
    nc = norm(candidate)

    for sp in anchors:
        ns = norm(sp)

        if not ns:
            continue

        if ns not in ni:
            continue

        checked.append(sp)

        if ns not in nc:
            missing.append(sp)

    return len(missing) == 0, checked, missing


def candidate_anchor_status(row: Dict, cand_idx: int, initial: str, candidate: str) -> Tuple[bool, List[str], List[str]]:
    if cand_idx == 0:
        return True, [], []

    verifier = get_candidate_verifier(row, cand_idx)

    anchors = get_anchor_spans(row)
    text_ok, checked, missing = anchors_preserved_by_text(initial, candidate, anchors)

    if "anchor_preservation_ok" in verifier:
        verifier_ok = safe_bool(verifier.get("anchor_preservation_ok", False), False)
        ok = verifier_ok and text_ok
    else:
        ok = text_ok

    verifier_missing = verifier.get("anchors_missing", [])
    if isinstance(verifier_missing, list):
        for sp in verifier_missing:
            sp = clean_text(sp)
            if sp and sp not in missing:
                missing.append(sp)

    if missing:
        ok = False

    return ok, checked, missing


def word_edit_distance_count(initial: str, candidate: str) -> int:
    a = tokenize_words(initial)
    b = tokenize_words(candidate)

    if not a and not b:
        return 0

    sm = SequenceMatcher(a=a, b=b)

    dist = 0

    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal":
            continue

        dist += max(i2 - i1, j2 - j1)

    return int(dist)


def score_ranks(scores: List[float]) -> List[int]:
    """
    Higher score gets higher rank.
    Ties receive the same rank.
    Example with 4 items:
      best unique score -> 4
      worst unique score -> 1
    """
    ranks = []

    for s in scores:
        rank = 1 + sum(1 for other in scores if s > other)
        ranks.append(int(rank))

    return ranks


def candidate_mode_evidence_match(row: Dict, cand_idx: int) -> bool:
    if cand_idx == 0:
        return False

    mode = get_candidate_mode(row, cand_idx)
    ops = get_repair_ops(row)

    edit_types = {clean_text(x.get("edit_type", "")).lower() for x in ops}

    if "source_image_mask_repair" in mode and "visual_refill" in edit_types:
        return True

    if "source_only_mask_repair" in mode and ("paraphrase" in edit_types or "visual_refill" not in edit_types):
        return True

    if "conservative_paraphrase_delete_repair" in mode and ({"delete", "paraphrase"} & edit_types):
        return True

    return False


def repair_evidence_rank(row: Dict, cand_idx: int, touched: bool, anchor_ok: bool) -> int:
    if cand_idx == 0:
        return 0

    flags = [
        get_candidate_deterministic_allow(row, cand_idx),
        touched,
        anchor_ok,
        candidate_source_supported(row, cand_idx),
        candidate_mode_evidence_match(row, cand_idx),
        candidate_is_phrase_compression_repair(row, cand_idx),
    ]

    return int(sum(1 for x in flags if bool(x)))


# =========================================================
# Selection: no fixed bonus, rank-key only
# =========================================================
def compute_selectable_candidates(
    row: Dict,
    candidates: List[str],
    blaser_scores: List[float],
    comet_scores: List[float],
) -> Tuple[List[bool], List[str], List[Dict]]:
    initial = candidates[0]

    initial_blaser = blaser_scores[0]
    initial_comet = comet_scores[0]

    blaser_ranks = score_ranks(blaser_scores)
    comet_ranks = score_ranks(comet_scores)

    selectable = [False] * 4
    block_reasons = [""] * 4
    candidate_keys: List[Dict] = []

    for idx in range(4):
        if idx == 0:
            key = {
                "is_selectable": True,
                "repair_evidence_rank": 0,
                "blaser_win": False,
                "comet_win": False,
                "anchor_preservation": True,
                "suspicious_span_coverage": 0.0,
                "blaser_rank": blaser_ranks[idx],
                "comet_rank": comet_ranks[idx],
                "negative_edit_distance_rank": 0,
                "tuple": [
                    True,
                    0,
                    False,
                    False,
                    True,
                    0.0,
                    blaser_ranks[idx],
                    comet_ranks[idx],
                    0,
                ],
            }
            selectable[idx] = True
            block_reasons[idx] = "initial_baseline"
            candidate_keys.append(key)
            continue

        cand = candidates[idx]

        changed = candidate_is_changed(initial, cand)
        deterministic_allow = get_candidate_deterministic_allow(row, idx)

        span_touched, span_coverage, target_spans, changed_from = candidate_span_repair_status(
            row=row,
            cand_idx=idx,
        )

        anchor_ok, anchors_checked, anchors_missing = candidate_anchor_status(
            row=row,
            cand_idx=idx,
            initial=initial,
            candidate=cand,
        )

        blaser_win = blaser_scores[idx] > initial_blaser
        comet_win = comet_scores[idx] > initial_comet
        qe_win = blaser_win or comet_win

        edit_distance = word_edit_distance_count(initial, cand)

        ev_rank = repair_evidence_rank(
            row=row,
            cand_idx=idx,
            touched=span_touched,
            anchor_ok=anchor_ok,
        )

        is_selectable = (
            changed
            and deterministic_allow
            and span_touched
            and anchor_ok
            and qe_win
        )

        if not changed:
            reason = "same_as_initial"
        elif not deterministic_allow:
            reason = "deterministic_not_allowed"
        elif not span_touched:
            reason = "suspicious_span_not_repaired"
        elif not anchor_ok:
            reason = "anchor_not_preserved"
        elif not qe_win:
            reason = "qe_not_higher_than_initial"
        else:
            if blaser_win and comet_win:
                reason = "span_anchor_dual_qe_win"
            elif blaser_win:
                reason = "span_anchor_blaser_win"
            else:
                reason = "span_anchor_comet_win"

        selectable[idx] = bool(is_selectable)
        block_reasons[idx] = reason

        key_tuple = [
            bool(is_selectable),
            int(ev_rank),
            bool(blaser_win),
            bool(comet_win),
            bool(anchor_ok),
            round(float(span_coverage), 6),
            int(blaser_ranks[idx]),
            int(comet_ranks[idx]),
            -int(edit_distance),
        ]

        key = {
            "is_selectable": bool(is_selectable),
            "repair_evidence_rank": int(ev_rank),
            "blaser_win": bool(blaser_win),
            "comet_win": bool(comet_win),
            "anchor_preservation": bool(anchor_ok),
            "suspicious_span_coverage": round(float(span_coverage), 6),
            "blaser_rank": int(blaser_ranks[idx]),
            "comet_rank": int(comet_ranks[idx]),
            "negative_edit_distance_rank": -int(edit_distance),
            "edit_distance": int(edit_distance),

            "deterministic_allow": bool(deterministic_allow),
            "target_spans": target_spans,
            "changed_from_spans": changed_from,
            "anchors_checked": anchors_checked,
            "anchors_missing": anchors_missing,

            "tuple": key_tuple,
        }

        candidate_keys.append(key)

    return selectable, block_reasons, candidate_keys


def select_best(
    row: Dict,
    blaser_scores: List[float],
    comet_scores: List[float],
    candidates: List[str],
) -> Dict:
    selectable, block_reasons, candidate_keys = compute_selectable_candidates(
        row=row,
        candidates=candidates,
        blaser_scores=blaser_scores,
        comet_scores=comet_scores,
    )

    ranking = sorted(
        range(4),
        key=lambda i: (
            tuple(candidate_keys[i]["tuple"]),
            -i,
        ),
        reverse=True,
    )

    best_idx = ranking[0]

    if best_idx == 0:
        best_from = "initial_translation"
    else:
        best_from = f"candidate_{best_idx}"

    return {
        "best_idx": best_idx,
        "best_from": best_from,
        "best_translation": candidates[best_idx],
        "selectable": selectable,
        "block_reasons": block_reasons,
        "candidate_keys": candidate_keys,
        "ranking": ranking,
    }


# =========================================================
# SentencePiece encode
# =========================================================
def sp_encode_batch(
    sp: spm.SentencePieceProcessor,
    texts: List[str],
    lang: str,
    max_len: int = 512,
    pad_id: int = 0,
):
    tagged = [f"__{lang}__ {str(t).strip()}" for t in texts]

    ids = [sp.encode(t, out_type=int)[:max_len] for t in tagged]
    lens = [len(x) for x in ids]
    maxl = max(lens) if lens else 0

    x = torch.full((len(ids), maxl), pad_id, dtype=torch.long)

    for i, row in enumerate(ids):
        if row:
            x[i, :len(row)] = torch.tensor(row, dtype=torch.long)

    attn = x != pad_id

    return x, attn


def build_vocab_info_from_spm(
    spm_path: str,
    vocab_size_override: Optional[int] = None,
):
    from fairseq2.data.vocabulary_info import VocabularyInfo

    sp = spm.SentencePieceProcessor(model_file=spm_path)

    unk = sp.unk_id()
    bos = sp.bos_id()
    eos = sp.eos_id()
    pad = sp.pad_id() if hasattr(sp, "pad_id") else -1

    if pad is None or pad < 0:
        pad = 0

    size = vocab_size_override if vocab_size_override is not None else sp.get_piece_size()

    return VocabularyInfo(
        size=int(size),
        unk_idx=int(unk),
        bos_idx=int(bos),
        eos_idx=int(eos),
        pad_idx=int(pad),
    )


# =========================================================
# SONAR text encoder offline load
# =========================================================
def load_sonar_text_encoder_offline(
    encoder_ckpt: str,
    spm_path: str,
    device: torch.device,
    max_seq_len: int = 512,
):
    if not os.path.isfile(encoder_ckpt):
        raise FileNotFoundError(f"SONAR text encoder checkpoint not found: {encoder_ckpt}")

    if not os.path.isfile(spm_path):
        raise FileNotFoundError(f"SentencePiece model not found: {spm_path}")

    ckpt = torch.load(encoder_ckpt, map_location="cpu")

    if not isinstance(ckpt, dict) or "model" not in ckpt:
        raise RuntimeError(
            f"Unexpected SONAR checkpoint format: type={type(ckpt)} "
            f"keys={list(ckpt.keys()) if isinstance(ckpt, dict) else None}"
        )

    state_dict = ckpt["model"]

    if not isinstance(state_dict, dict):
        raise RuntimeError(
            f"Expected ckpt['model'] to be a state_dict dict/OrderedDict, got {type(state_dict)}"
        )

    emb_w = state_dict["encoder_frontend.embed.weight"]
    vocab_size = emb_w.shape[0]
    model_dim = emb_w.shape[1]

    ffn_w = state_dict["encoder.layers.0.ffn.inner_proj.weight"]
    ffn_inner_dim = ffn_w.shape[0]

    max_layer = -1

    for k in state_dict.keys():
        if k.startswith("encoder.layers."):
            parts = k.split(".")
            if len(parts) > 2 and parts[2].isdigit():
                max_layer = max(max_layer, int(parts[2]))

    num_encoder_layers = max_layer + 1

    vocab_info = build_vocab_info_from_spm(
        spm_path,
        vocab_size_override=int(vocab_size),
    )

    cfg = SonarTextEncoderConfig(
        model_dim=int(model_dim),
        max_seq_len=int(max_seq_len),
        vocab_info=vocab_info,
        num_encoder_layers=int(num_encoder_layers),
        num_decoder_layers=0,
        num_encoder_attn_heads=16,
        num_decoder_attn_heads=0,
        ffn_inner_dim=int(ffn_inner_dim),
        pooling="mean",
    )

    encoder = create_sonar_text_encoder_model(cfg, device=device).eval()

    missing, unexpected = encoder.load_state_dict(state_dict, strict=False)

    if missing or unexpected:
        print(
            f"[warn] SONAR encoder load_state_dict(strict=False): "
            f"missing={len(missing)} unexpected={len(unexpected)}"
        )

    sp = spm.SentencePieceProcessor(model_file=spm_path)

    return encoder, sp


@torch.no_grad()
def sonar_encode(
    encoder,
    sp: spm.SentencePieceProcessor,
    texts: List[str],
    lang: str,
    device: torch.device,
    max_len: int = 512,
) -> torch.Tensor:
    toks, attn = sp_encode_batch(
        sp,
        texts,
        lang=lang,
        max_len=max_len,
        pad_id=0,
    )

    toks = toks.to(device)
    attn = attn.to(device)

    padding_mask = None

    try:
        from fairseq2.nn.padding import PaddingMask

        pad = ~attn

        if hasattr(PaddingMask, "from_bool_tensor"):
            padding_mask = PaddingMask.from_bool_tensor(pad)
        elif hasattr(PaddingMask, "from_bool"):
            padding_mask = PaddingMask.from_bool(pad)
        else:
            padding_mask = PaddingMask(pad)

    except Exception:
        padding_mask = None

    batch = SequenceBatch(seqs=toks, padding_mask=padding_mask)
    out = encoder(batch)

    if hasattr(out, "sentence_embeddings"):
        emb = out.sentence_embeddings
    elif isinstance(out, dict) and "sentence_embeddings" in out:
        emb = out["sentence_embeddings"]
    elif isinstance(out, (list, tuple)):
        emb = out[0]
    elif isinstance(out, torch.Tensor):
        emb = out
    else:
        raise RuntimeError(f"Unsupported SONAR encoder output type: {type(out)}")

    if emb.dim() != 2:
        raise RuntimeError(f"Unexpected embedding shape: {tuple(emb.shape)}")

    return emb


# =========================================================
# BLASER-QE offline load + scoring
# =========================================================
def load_blaser_qe_offline(
    blaser_ckpt: str,
    device: torch.device,
):
    if not os.path.isfile(blaser_ckpt):
        raise FileNotFoundError(f"BLASER-QE checkpoint not found: {blaser_ckpt}")

    cfg = _arch_blaser_basic_qe()
    model = create_blaser_model(cfg, device=device).eval()

    raw = torch.load(blaser_ckpt, map_location="cpu")
    candidate = raw

    if isinstance(candidate, dict) and "model" in candidate and isinstance(candidate["model"], dict):
        candidate = candidate["model"]
    elif isinstance(candidate, dict) and "state_dict" in candidate and isinstance(candidate["state_dict"], dict):
        candidate = candidate["state_dict"]

    try:
        state = convert_blaser_checkpoint(candidate, cfg)
    except Exception as e:
        print(f"[warn] convert_blaser_checkpoint failed, fallback to direct state_dict. err={repr(e)}")
        state = candidate

    if isinstance(state, dict) and "model" in state and isinstance(state["model"], dict):
        state = state["model"]

    missing, unexpected = model.load_state_dict(state, strict=False)

    if missing or unexpected:
        print(
            f"[warn] BLASER load_state_dict(strict=False): "
            f"missing={len(missing)} unexpected={len(unexpected)}"
        )

    return model


@torch.no_grad()
def blaser_qe_scores(
    blaser_model,
    src_emb: torch.Tensor,
    mt_emb: torch.Tensor,
) -> List[float]:
    try:
        s = blaser_model(src_emb, mt_emb)
    except TypeError:
        s = blaser_model(src=src_emb, mt=mt_emb)

    if isinstance(s, (tuple, list)):
        s = s[0]

    if s.dim() == 2 and s.size(-1) == 1:
        s = s.squeeze(-1)

    return s.detach().cpu().tolist()


# =========================================================
# COMET-QE offline load + scoring
# =========================================================
def load_comet_qe_offline(comet_ckpt: str):
    if not os.path.isfile(comet_ckpt):
        raise FileNotFoundError(f"COMET-QE checkpoint not found: {comet_ckpt}")

    print(f"[info] loading COMET-QE from: {comet_ckpt}")
    model = load_from_checkpoint(comet_ckpt)
    model.eval()
    return model


def extract_comet_scores(pred: Any) -> List[float]:
    if hasattr(pred, "scores"):
        return [float(x) for x in pred.scores]

    if isinstance(pred, dict) and "scores" in pred:
        return [float(x) for x in pred["scores"]]

    try:
        pred_dict = dict(pred)
        if "scores" in pred_dict:
            return [float(x) for x in pred_dict["scores"]]
    except Exception:
        pass

    if isinstance(pred, (list, tuple)):
        for item in pred:
            if isinstance(item, tuple) and len(item) == 2 and item[0] == "scores":
                return [float(x) for x in item[1]]

    raise RuntimeError(f"Cannot extract COMET scores from prediction object: {type(pred)} | {repr(pred)[:500]}")


def comet_qe_scores(
    comet_model,
    src_texts: List[str],
    mt_texts: List[str],
    device: torch.device,
    batch_size: int = 8,
) -> List[float]:
    if len(src_texts) != len(mt_texts):
        raise ValueError(f"src_texts and mt_texts length mismatch: {len(src_texts)} vs {len(mt_texts)}")

    data = [
        {
            "src": clean_text(src),
            "mt": clean_text(mt),
        }
        for src, mt in zip(src_texts, mt_texts)
    ]

    gpus = 1 if device.type == "cuda" else 0

    pred = comet_model.predict(
        data,
        batch_size=batch_size,
        gpus=gpus,
    )

    scores = extract_comet_scores(pred)

    if len(scores) != len(data):
        raise RuntimeError(f"COMET score count mismatch: got {len(scores)}, expected {len(data)}")

    return scores


# =========================================================
# Main
# =========================================================
def main():
    device = torch.device(DEVICE if torch.cuda.is_available() else "cpu")

    print("device:", device, "visible_cuda_count:", torch.cuda.device_count())
    print(f"[info] LANGUAGE={LANGUAGE}")
    print(f"[info] GPU={GPU}")
    print(f"[info] SRC_LANG={SRC_LANG}")
    print(f"[info] TGT_LANG={TGT_LANG}")
    print(f"[info] OUTPUT_ROOT={OUTPUT_ROOT}")
    print(f"[info] INPUT_JSONL={INPUT_JSONL}")
    print(f"[info] OUTPUT_SOURCE_BEST_JSONL={OUTPUT_SOURCE_BEST_JSONL}")
    print(f"[info] selection formula={SELECTION_FORMULA_VERSION}")
    print(f"[info] HF_HUB_OFFLINE={os.environ.get('HF_HUB_OFFLINE')}")
    print(f"[info] TRANSFORMERS_OFFLINE={os.environ.get('TRANSFORMERS_OFFLINE')}")
    print(f"[info] COMET_QE_CKPT={COMET_QE_CKPT}")
    print("[info] fixed bonus removed")
    print("[info] candidate_i_eligible_for_selection ignored")
    print("[info] replacement requires: span repaired + anchor preserved + QE win over initial")

    rows = read_jsonl_records(INPUT_JSONL)
    total = len(rows)

    print(f"[info] loaded rows: {total}")

    if total == 0:
        print("[warn] no rows found.")
        return

    print("[info] loading SONAR encoder...")
    sonar_encoder, sp = load_sonar_text_encoder_offline(
        SONAR_MODEL,
        SPM_MODEL,
        device=device,
        max_seq_len=MAX_LEN,
    )

    print("[info] loading BLASER-QE...")
    blaser = load_blaser_qe_offline(
        BLASER_QE_CKPT,
        device=device,
    )

    print("[info] loading COMET-QE...")
    comet_model = load_comet_qe_offline(COMET_QE_CKPT)

    os.makedirs(OUTPUT_DIR, exist_ok=True)

    stats = defaultdict(int)
    stats["total"] = 0

    t_start = time.time()

    with open(OUTPUT_SOURCE_BEST_JSONL, "w", encoding="utf-8") as f_best:
        for b0 in range(0, total, BATCH_ROWS):
            b1 = min(b0 + BATCH_ROWS, total)
            batch = rows[b0:b1]

            src_texts: List[str] = []
            src_langs: List[str] = []
            mt_texts: List[str] = []
            row_meta: List[Tuple[int, int]] = []

            for row_idx, row in enumerate(batch):
                source_for_score, src_lang = get_source_for_score(row)
                candidates = get_candidate_texts(row)

                for cand_idx, cand in enumerate(candidates):
                    src_texts.append(source_for_score)
                    src_langs.append(src_lang)
                    mt_texts.append(cand)
                    row_meta.append((row_idx, cand_idx))

            src_emb_list: List[Optional[torch.Tensor]] = [None] * len(src_texts)
            lang_to_indices: Dict[str, List[int]] = {}

            for i, lg in enumerate(src_langs):
                lang_to_indices.setdefault(lg, []).append(i)

            for lg, idxs in lang_to_indices.items():
                sub_texts = [src_texts[i] for i in idxs]

                emb_sub = sonar_encode(
                    sonar_encoder,
                    sp,
                    sub_texts,
                    lang=lg,
                    device=device,
                    max_len=MAX_LEN,
                )

                for j, global_i in enumerate(idxs):
                    src_emb_list[global_i] = emb_sub[j]

            src_emb = torch.stack(src_emb_list, dim=0)

            mt_emb = sonar_encode(
                sonar_encoder,
                sp,
                mt_texts,
                lang=TGT_LANG,
                device=device,
                max_len=MAX_LEN,
            )

            blaser_scores_flat = blaser_qe_scores(
                blaser,
                src_emb,
                mt_emb,
            )

            comet_scores_flat = comet_qe_scores(
                comet_model=comet_model,
                src_texts=src_texts,
                mt_texts=mt_texts,
                device=device,
                batch_size=COMET_BATCH_SIZE,
            )

            blaser_score_map: Dict[Tuple[int, int], float] = {}
            comet_score_map: Dict[Tuple[int, int], float] = {}

            for k, (row_idx, cand_idx) in enumerate(row_meta):
                blaser_score_map[(row_idx, cand_idx)] = float(blaser_scores_flat[k])
                comet_score_map[(row_idx, cand_idx)] = float(comet_scores_flat[k])

            for row_idx, row in enumerate(batch):
                global_idx = b0 + row_idx + 1

                sid = clean_text(row.get("id", row.get("image_id", "")))
                source_text = clean_text(row.get("source_text", ""))
                reference_translation = get_reference_translation(row)

                if not reference_translation:
                    stats["missing_reference_translation"] += 1

                candidates = get_candidate_texts(row)

                blaser_scores = [
                    blaser_score_map[(row_idx, 0)],
                    blaser_score_map[(row_idx, 1)],
                    blaser_score_map[(row_idx, 2)],
                    blaser_score_map[(row_idx, 3)],
                ]

                comet_scores = [
                    comet_score_map[(row_idx, 0)],
                    comet_score_map[(row_idx, 1)],
                    comet_score_map[(row_idx, 2)],
                    comet_score_map[(row_idx, 3)],
                ]

                selected = select_best(
                    row=row,
                    blaser_scores=blaser_scores,
                    comet_scores=comet_scores,
                    candidates=candidates,
                )

                best_idx = selected["best_idx"]
                best_translation = selected["best_translation"]

                stats["total"] += 1

                selectable_candidates = [
                    i for i in [1, 2, 3]
                    if selected["selectable"][i]
                ]

                if selectable_candidates:
                    stats["selectable_candidate_rows"] += 1
                    stats["selectable_candidate_total"] += len(selectable_candidates)

                for i in [1, 2, 3]:
                    cand_key = selected["candidate_keys"][i]
                    reason = selected["block_reasons"][i]

                    if candidate_is_changed(candidates[0], candidates[i]):
                        stats["changed_candidate_total"] += 1

                    if get_candidate_deterministic_allow(row, i):
                        stats["deterministic_allowed_candidate_total"] += 1

                    if cand_key.get("target_spans"):
                        stats["candidate_has_target_spans_total"] += 1

                    if cand_key.get("anchor_preservation", False):
                        stats["candidate_anchor_preserved_total"] += 1

                    if cand_key.get("blaser_win", False):
                        stats["candidate_blaser_win_total"] += 1

                    if cand_key.get("comet_win", False):
                        stats["candidate_comet_win_total"] += 1

                    if selected["selectable"][i]:
                        stats[f"admitted_{reason}"] += 1
                    else:
                        stats[f"blocked_{reason}"] += 1

                if best_idx == 0:
                    stats["keep_initial"] += 1
                else:
                    stats["replace_with_candidate"] += 1
                    stats[f"replace_candidate_{best_idx}"] += 1

                    best_key = selected["candidate_keys"][best_idx]

                    if best_key.get("blaser_win", False) and best_key.get("comet_win", False):
                        stats["selected_dual_qe_win"] += 1
                    elif best_key.get("blaser_win", False):
                        stats["selected_blaser_only_win"] += 1
                    elif best_key.get("comet_win", False):
                        stats["selected_comet_only_win"] += 1

                    if candidate_is_phrase_compression_repair(row, best_idx):
                        stats["selected_phrase_compression_repair"] += 1

                minimal_out = {
                    "id": sid,
                    "source_text": source_text,
                    "reference_translation": reference_translation,
                    "initial_translation": candidates[0],
                    "best_translation": best_translation,
                    "best_from": selected["best_from"],

                    "candidate_1": candidates[1],
                    "candidate_2": candidates[2],
                    "candidate_3": candidates[3],

                    "candidate_1_mode": get_candidate_mode(row, 1),
                    "candidate_2_mode": get_candidate_mode(row, 2),
                    "candidate_3_mode": get_candidate_mode(row, 3),

                    "candidate_1_block_reason": selected["block_reasons"][1],
                    "candidate_2_block_reason": selected["block_reasons"][2],
                    "candidate_3_block_reason": selected["block_reasons"][3],

                    "candidate_1_select_key": selected["candidate_keys"][1],
                    "candidate_2_select_key": selected["candidate_keys"][2],
                    "candidate_3_select_key": selected["candidate_keys"][3],

                    "candidate_1_blaser_qe": blaser_scores[1],
                    "candidate_2_blaser_qe": blaser_scores[2],
                    "candidate_3_blaser_qe": blaser_scores[3],
                    "initial_blaser_qe": blaser_scores[0],

                    "candidate_1_comet_qe": comet_scores[1],
                    "candidate_2_comet_qe": comet_scores[2],
                    "candidate_3_comet_qe": comet_scores[3],
                    "initial_comet_qe": comet_scores[0],

                    "selection_ranking": selected["ranking"],
                    "best_select_key": selected["candidate_keys"][best_idx],

                    "selection_formula_version": SELECTION_FORMULA_VERSION,
                    "selection_rule": (
                        "replace initial only if candidate is changed, "
                        "deterministic_allow_candidate is true, suspicious span is repaired, "
                        "anchor is preserved, and BLASER-QE or COMET-QE is higher than initial; "
                        "ranking uses parameter-free lexicographic candidate key"
                    ),
                    "candidate_eligible_for_selection_ignored": True,
                    "fixed_bonus_removed": True,

                    "language": LANGUAGE,
                    "src_lang": SRC_LANG,
                    "tgt_lang": TGT_LANG,
                }

                write_jsonl_record(f_best, minimal_out)

                if global_idx % 10 == 0 or global_idx == total:
                    elapsed = time.time() - t_start
                    avg = elapsed / global_idx
                    eta = avg * (total - global_idx)

                    print(
                        f"[{global_idx}/{total}] "
                        f"id={sid} | best={selected['best_from']} | "
                        f"elapsed={format_time(elapsed)} | ETA={format_time(eta)}"
                    )

            if torch.cuda.is_available():
                torch.cuda.empty_cache()

    print("[DONE]")
    print(f"[DONE] output: {OUTPUT_SOURCE_BEST_JSONL}")
    print("[stats]", dict(stats))

    if stats["missing_reference_translation"] > 0:
        print(
            f"[WARN] {stats['missing_reference_translation']} rows have empty reference_translation. "
            f"Please check whether candidate output already contains reference_translation."
        )


if __name__ == "__main__":
    main()