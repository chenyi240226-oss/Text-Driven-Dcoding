#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import argparse

# =========================================================
# Arguments
# =========================================================
ALLOWED_LANGUAGES = {"hi", "lv", "tr"}

LANGUAGE_NAME_MAP = {
    "hi": "Hindi",
    "lv": "Latvian",
    "tr": "Turkish",
}


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--lang", type=str, required=True, choices=sorted(ALLOWED_LANGUAGES))
    parser.add_argument("--gpu", type=str, required=True)
    parser.add_argument("--max_rows", type=int, default=None)
    return parser.parse_args()


ARGS = parse_args()
LANGUAGE = ARGS.lang
GPU = ARGS.gpu
MAX_ROWS = ARGS.max_rows
SOURCE_LANGUAGE_NAME = LANGUAGE_NAME_MAP[LANGUAGE]

os.environ["CUDA_VISIBLE_DEVICES"] = str(GPU)
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"

import re
import json
import time
from typing import Any, Dict, List, Optional, Tuple

import torch
from PIL import Image
from transformers import AutoProcessor, AutoModelForVision2Seq

# =========================================================
# Torch compatibility patch
# =========================================================
if not hasattr(torch, "compiler"):
    class _DummyCompiler:
        @staticmethod
        def is_compiling():
            return False

    torch.compiler = _DummyCompiler()
elif not hasattr(torch.compiler, "is_compiling"):
    torch.compiler.is_compiling = lambda: False

torch.set_grad_enabled(False)

# =========================================================
# Paths
# =========================================================
QWEN_PATH = "/mnt/raid/hss/model/Qwen3-VL-8B-Instruct"

OUTPUT_ROOT = "/home/chenyi/offline_blaser_qe/out/Qwen_3_VL_8B/Multi30k"

INPUT_JSONL = os.path.join(
    OUTPUT_ROOT,
    LANGUAGE,
    f"{LANGUAGE}_test_translation.jsonl",
)

OUTPUT_JSONL = os.path.join(
    OUTPUT_ROOT,
    LANGUAGE,
    f"{LANGUAGE}_detect_span.jsonl",
)

SOURCE_DATA_JSONL = f"/mnt/raid/cycy/data/txt_multi30k/en_{LANGUAGE}_test.jsonl"

MULTI30K_IMAGE_ROOT = "/mnt/raid/wjx/vision-rag-mt/images_multi30k"

DTYPE = torch.bfloat16 if torch.cuda.is_available() else torch.float32

SELECTED_LAYERS = [0, 1, 2, 3]

DETECTION_FORMULA_VERSION = (
    "sentence_first_span_localization_v2_"
    "strict_must_repair_with_gain_confirmed_"
    "relaxed_try_repair_"
    "four_condition_forward_"
    "early_layer_hidden_and_final_probability_"
    "source_jsonl_image_id_mapping_"
    "must_try_blocked_output_"
    "candidate_compatible_fields"
)

# =========================================================
# Generic lexical utilities
# =========================================================
FUNCTION_WORDS = {
    "a", "an", "the",
    "of", "in", "on", "at", "by", "with", "from", "to", "for",
    "into", "onto", "over", "under", "between", "around", "through",
    "during", "while", "near", "inside", "outside", "along", "across",
    "behind", "beside", "toward", "towards", "against", "about",
    "before", "after", "front", "back", "next",
    "is", "are", "was", "were", "am", "be", "been", "being",
    "and", "or", "but", "who", "which", "that",
    "this", "these", "those",
    "his", "her", "their", "theirs", "its", "our", "ours", "your", "yours", "my", "mine",
    "he", "him", "she", "it", "they", "them", "we", "us", "you", "i", "me",
    "himself", "herself", "itself", "themselves", "ourselves", "yourself", "yourselves", "myself",
    "as", "if", "than", "then",
    "there", "here",
    "not", "no",
    "do", "does", "did", "done",
    "have", "has", "had",
    "will", "would", "can", "could", "should", "may", "might", "must",
    "still", "very", "just", "also",
}

RELATION_WORDS = {
    "in", "on", "at", "by", "with", "from", "to", "for",
    "into", "onto", "over", "under", "between", "around", "through",
    "during", "while", "near", "inside", "outside", "along", "across",
    "behind", "beside", "toward", "towards", "against", "before", "after",
    "front", "back", "next", "out", "up", "down", "off",
}

NUMBER_WORDS = {
    "zero", "one", "two", "three", "four", "five",
    "six", "seven", "eight", "nine", "ten",
    "eleven", "twelve", "couple", "pair", "both",
    "many", "several", "few",
}

BRIDGE_WORDS = FUNCTION_WORDS | RELATION_WORDS


# =========================================================
# Basic utils
# =========================================================
def clean_text(x: Any) -> str:
    if x is None:
        return ""
    return re.sub(r"\s+", " ", str(x).strip())


def norm(x: Any) -> str:
    x = clean_text(x).lower()
    x = x.replace("’", "'").replace("“", '"').replace("”", '"')
    x = re.sub(r"[^a-z0-9_\-\s]", " ", x)
    return re.sub(r"\s+", " ", x).strip()


def norm_sent(x: Any) -> str:
    x = clean_text(x)
    x = re.sub(r"\s+([,.;:!?])", r"\1", x)
    x = x.strip().strip('"').strip("'").strip()
    return x.rstrip(".,;:!?")


def tokenize_words(x: Any) -> List[str]:
    return re.findall(r"[A-Za-z0-9_\-]+", norm(x))


def content_tokens(x: Any) -> List[str]:
    return [t for t in tokenize_words(x) if t and t not in FUNCTION_WORDS]


def is_content_word(w: str) -> bool:
    return bool(norm(w)) and norm(w) not in FUNCTION_WORDS


def is_bridge_word(w: str) -> bool:
    return norm(w) in BRIDGE_WORDS


def safe_float(x: Any, default: float = 0.0) -> float:
    try:
        return float(x)
    except Exception:
        return default


def format_time(sec: float) -> str:
    sec = int(sec)
    return f"{sec // 3600:02d}:{(sec % 3600) // 60:02d}:{sec % 60:02d}"


def cleanup_cuda():
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        torch.cuda.ipc_collect()


def first_nonempty(row: Dict, keys: List[str]) -> str:
    for k in keys:
        v = clean_text(row.get(k, ""))
        if v:
            return v
    return ""


def overlap_span(a0: int, a1: int, b0: int, b1: int) -> bool:
    return not (a1 < b0 or b1 < a0)


def path_stem(x: str) -> str:
    x = clean_text(x)
    if not x:
        return ""
    return os.path.splitext(os.path.basename(x))[0]


def normalize_image_path(p: str) -> str:
    p = clean_text(p)
    if not p:
        return ""

    if os.path.isabs(p):
        return p

    return os.path.join(MULTI30K_IMAGE_ROOT, p)


def image_path_from_id(image_id: Any) -> str:
    image_id = clean_text(image_id)
    if not image_id:
        return ""

    if image_id.lower().endswith((".jpg", ".jpeg", ".png")):
        return os.path.join(MULTI30K_IMAGE_ROOT, image_id)

    return os.path.join(MULTI30K_IMAGE_ROOT, f"{image_id}.jpg")


def load_image(path: str) -> Optional[Image.Image]:
    path = clean_text(path)
    if not path or not os.path.isfile(path):
        return None
    try:
        return Image.open(path).convert("RGB")
    except Exception:
        return None


# =========================================================
# Source-data image index
# =========================================================
def add_index_key(index: Dict[str, Dict], key: Any, entry: Dict):
    key = clean_text(key)
    if not key:
        return
    index[key] = entry


def load_source_image_index(path: str) -> Dict[str, Dict]:
    index = {}

    if not os.path.isfile(path):
        print(f"[WARN] SOURCE_DATA_JSONL not found: {path}")
        return index

    n = 0

    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue

            try:
                row = json.loads(line)
            except Exception:
                continue

            image_path = first_nonempty(row, ["image", "image_path", "img_path"])
            image_rel = first_nonempty(row, ["image_rel", "image_name"])
            image_id = first_nonempty(row, ["image_id"])

            if image_path:
                image_path = normalize_image_path(image_path)
            elif image_rel:
                image_path = normalize_image_path(image_rel)
            elif image_id:
                image_path = image_path_from_id(image_id)
            else:
                image_path = ""

            entry = {
                "image_path": image_path,
                "source_text": first_nonempty(row, ["target", "source_text", "tgt", "target_text"]),
                "reference_translation": first_nonempty(row, ["source", "reference_translation", "src", "source_text_en"]),
                "image_id": clean_text(image_id),
            }

            add_index_key(index, row.get("image_id", ""), entry)
            add_index_key(index, row.get("image", ""), entry)
            add_index_key(index, row.get("image_rel", ""), entry)
            add_index_key(index, row.get("image_name", ""), entry)

            if image_path:
                add_index_key(index, image_path, entry)
                add_index_key(index, os.path.basename(image_path), entry)
                add_index_key(index, path_stem(image_path), entry)

            image_rel_stem = path_stem(image_rel)
            if image_rel_stem:
                add_index_key(index, image_rel_stem, entry)

            if not image_id:
                add_index_key(index, row.get("id", ""), entry)

            n += 1

    print(f"[INFO] Loaded source image index: {n} rows, {len(index)} keys")
    return index


SOURCE_IMAGE_INDEX = load_source_image_index(SOURCE_DATA_JSONL)


def lookup_source_info(row: Dict) -> Dict:
    keys = []

    for k in ["image_id", "image", "image_path", "img_path", "image_rel", "image_name"]:
        v = clean_text(row.get(k, ""))
        if v:
            keys.append(v)
            keys.append(os.path.basename(v))
            keys.append(path_stem(v))

    row_id = clean_text(row.get("id", ""))
    if row_id:
        keys.append(row_id)
        keys.append(path_stem(row_id))

    for key in keys:
        key = clean_text(key)
        if key and key in SOURCE_IMAGE_INDEX:
            return SOURCE_IMAGE_INDEX[key]

    return {}


# =========================================================
# Read input adapter
# =========================================================
def get_source_text(row: Dict, source_info: Optional[Dict] = None) -> str:
    v = first_nonempty(row, ["source_text", "target", "src", "source_sentence", "target_text"])
    if v:
        return v

    if source_info:
        return clean_text(source_info.get("source_text", ""))

    return ""


def get_initial_translation(row: Dict) -> str:
    return first_nonempty(
        row,
        [
            "initial_translation",
            "initial_translation_en",
            f"initial_translation_{LANGUAGE}",
            "translation",
            "hypothesis",
        ],
    )


def get_image_path(row: Dict, source_info: Optional[Dict] = None) -> str:
    p = first_nonempty(row, ["image_path", "image", "img_path"])
    if p:
        p = normalize_image_path(p)
        if os.path.isfile(p):
            return p

    if source_info:
        p = normalize_image_path(source_info.get("image_path", ""))
        if p:
            return p

    image_rel = first_nonempty(row, ["image_rel", "image_name"])
    if image_rel:
        p = normalize_image_path(image_rel)
        if os.path.isfile(p):
            return p

    image_id = first_nonempty(row, ["image_id"])
    if image_id:
        p = image_path_from_id(image_id)
        if os.path.isfile(p):
            return p

    row_id = clean_text(row.get("id", ""))
    if row_id:
        p = image_path_from_id(row_id)
        if os.path.isfile(p):
            return p

    return p if "p" in locals() else ""


def get_id(row: Dict, source_info: Optional[Dict] = None) -> str:
    v = first_nonempty(row, ["image_id"])
    if v:
        return v

    if source_info:
        v = clean_text(source_info.get("image_id", ""))
        if v:
            return v

    v = first_nonempty(row, ["id"])
    if v:
        return v

    image_path = get_image_path(row, source_info)
    if image_path:
        return os.path.splitext(os.path.basename(image_path))[0]

    return ""


# =========================================================
# Load model
# =========================================================
print("Loading model...")
print(f"[INFO] LANGUAGE: {LANGUAGE}")
print(f"[INFO] GPU: {GPU}")
print(f"[INFO] SOURCE_LANGUAGE_NAME: {SOURCE_LANGUAGE_NAME}")
print(f"[INFO] CUDA_VISIBLE_DEVICES: {os.environ.get('CUDA_VISIBLE_DEVICES')}")
print(f"[INFO] QWEN_PATH: {QWEN_PATH}")
print(f"[INFO] INPUT_JSONL: {INPUT_JSONL}")
print(f"[INFO] SOURCE_DATA_JSONL: {SOURCE_DATA_JSONL}")
print(f"[INFO] OUTPUT_JSONL: {OUTPUT_JSONL}")

processor = AutoProcessor.from_pretrained(QWEN_PATH, trust_remote_code=True)
model = AutoModelForVision2Seq.from_pretrained(
    QWEN_PATH,
    torch_dtype=DTYPE,
    device_map="auto",
    trust_remote_code=True,
).eval()
tokenizer = processor.tokenizer
print("Model loaded.")


# =========================================================
# Prompt construction
# =========================================================
def condition_user_prompt(source_text: str, condition: str) -> str:
    if condition == "xi":
        return f"""
Task:
Score the likelihood of the following English translation.

{SOURCE_LANGUAGE_NAME} source sentence:
{source_text}

Use the image only as secondary evidence.
English translation:
""".strip()

    if condition == "x":
        return f"""
Task:
Score the likelihood of the following English translation.

{SOURCE_LANGUAGE_NAME} source sentence:
{source_text}

Do not use any visual assumption.
English translation:
""".strip()

    if condition == "i":
        return """
Task:
Score the likelihood of the following English sentence using only the image context.
Do not assume the source sentence.
English sentence:
""".strip()

    if condition == "n":
        return """
Task:
Score the likelihood of the following English sentence using only general language prior.
Do not use source sentence or image evidence.
English sentence:
""".strip()

    return "English translation:"


def build_prefix_text(source_text: str, condition: str, image: Optional[Image.Image]) -> str:
    system_prompt = (
        "You are a translation faithfulness scorer. "
        "Do not generate explanations. Only provide likelihood through the model forward pass."
    )

    content = []
    if condition in {"xi", "i"} and image is not None:
        content.append({"type": "image", "image": image})

    content.append(
        {
            "type": "text",
            "text": condition_user_prompt(source_text, condition),
        }
    )

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": content},
    ]

    return processor.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True,
    )


# =========================================================
# Forced scoring
# =========================================================
def processor_encode(text: str, image: Optional[Image.Image]) -> Dict:
    if image is not None:
        inputs = processor(text=[text], images=[image], return_tensors="pt")
    else:
        inputs = processor(text=[text], return_tensors="pt")

    return {
        k: v.to(model.device) if isinstance(v, torch.Tensor) else v
        for k, v in inputs.items()
    }


def score_condition(
    source_text: str,
    initial_translation: str,
    image_path: str,
    condition: str,
) -> Dict:
    image = load_image(image_path) if condition in {"xi", "i"} else None

    try:
        prefix_text = build_prefix_text(source_text, condition, image)
        full_text = prefix_text + clean_text(initial_translation)

        prefix_inputs = processor_encode(prefix_text, image)
        full_inputs = processor_encode(full_text, image)

        input_ids = full_inputs["input_ids"]
        prefix_len = int(prefix_inputs["input_ids"].shape[1])
        seq_len = int(input_ids.shape[1])

        with torch.no_grad():
            outputs = model(
                **full_inputs,
                output_hidden_states=True,
                return_dict=True,
            )

        logits = outputs.logits
        log_probs = torch.log_softmax(logits, dim=-1)

        token_ids = []
        token_logps = []
        token_probs = []

        for pos in range(prefix_len, seq_len):
            if pos <= 0:
                continue

            tid = int(input_ids[0, pos].item())
            lp_tensor = log_probs[0, pos - 1, tid].detach().float().cpu()
            lp = float(lp_tensor.item())
            prob = float(torch.exp(lp_tensor).item())

            token_ids.append(tid)
            token_logps.append(lp)
            token_probs.append(prob)

        hidden_vectors = []

        if getattr(outputs, "hidden_states", None) is not None:
            hs_list = outputs.hidden_states
            layer_ids = []
            for li in SELECTED_LAYERS:
                real_idx = li + 1
                if real_idx < len(hs_list):
                    layer_ids.append(real_idx)

            if layer_ids:
                for pos in range(prefix_len, seq_len):
                    vecs = []
                    for real_idx in layer_ids:
                        h = hs_list[real_idx][0, pos].detach().float()
                        vecs.append(h)
                    if vecs:
                        v = torch.stack(vecs, dim=0).mean(dim=0)
                        hidden_vectors.append(v.cpu())

        return {
            "condition": condition,
            "token_ids": token_ids,
            "token_logps": token_logps,
            "token_probs": token_probs,
            "hidden_vectors": hidden_vectors,
            "prefix_len": prefix_len,
            "seq_len": seq_len,
            "image_used": image is not None,
            "error": "",
        }

    except Exception as e:
        return {
            "condition": condition,
            "token_ids": [],
            "token_logps": [],
            "token_probs": [],
            "hidden_vectors": [],
            "prefix_len": 0,
            "seq_len": 0,
            "image_used": False,
            "error": repr(e),
        }

    finally:
        if image is not None:
            image.close()
        cleanup_cuda()


def score_all_conditions(source_text: str, initial_translation: str, image_path: str) -> Dict[str, Dict]:
    out = {}
    for c in ["xi", "x", "i", "n"]:
        out[c] = score_condition(source_text, initial_translation, image_path, c)
    return out


# =========================================================
# Token-to-word alignment
# =========================================================
def token_char_offsets_from_decoding(token_ids: List[int]) -> Tuple[str, List[Tuple[int, int]]]:
    parts = []
    offsets = []
    cur = 0

    for tid in token_ids:
        try:
            s = tokenizer.decode(
                [tid],
                skip_special_tokens=True,
                clean_up_tokenization_spaces=False,
            )
        except Exception:
            s = ""

        start = cur
        cur += len(s)
        end = cur
        offsets.append((start, end))
        parts.append(s)

    return "".join(parts), offsets


def word_offsets(text: str) -> List[Dict]:
    arr = []
    for m in re.finditer(r"[A-Za-z0-9_\-]+", text):
        arr.append(
            {
                "word": m.group(0),
                "norm": norm(m.group(0)),
                "char_start": m.start(),
                "char_end": m.end(),
            }
        )
    return arr


def aggregate_token_values_to_words(
    token_ids: List[int],
    values: List[float],
    fallback_text: str,
) -> List[Dict]:
    decoded_text, tok_offsets = token_char_offsets_from_decoding(token_ids)
    w_offsets = word_offsets(decoded_text)

    if not w_offsets:
        w_offsets = word_offsets(fallback_text)

    word_values = []

    for wi, w in enumerate(w_offsets):
        vals = []
        for ti, (a, b) in enumerate(tok_offsets):
            if ti >= len(values):
                continue
            if b <= w["char_start"] or a >= w["char_end"]:
                continue
            vals.append(float(values[ti]))

        if not vals:
            vals = [0.0]

        word_values.append(
            {
                "word": w["word"],
                "norm": w["norm"],
                "word_index": wi,
                "value": sum(vals) / len(vals),
                "token_count": len(vals),
            }
        )

    return word_values


def aggregate_token_vectors_to_words(
    token_ids: List[int],
    vectors: List[torch.Tensor],
    fallback_text: str,
) -> List[Optional[torch.Tensor]]:
    decoded_text, tok_offsets = token_char_offsets_from_decoding(token_ids)
    w_offsets = word_offsets(decoded_text)

    if not w_offsets:
        w_offsets = word_offsets(fallback_text)

    out = []

    for w in w_offsets:
        vecs = []
        for ti, (a, b) in enumerate(tok_offsets):
            if ti >= len(vectors):
                continue
            if b <= w["char_start"] or a >= w["char_end"]:
                continue
            vecs.append(vectors[ti])

        if vecs:
            out.append(torch.stack(vecs, dim=0).mean(dim=0))
        else:
            out.append(None)

    return out


def l2_distance(a: Optional[torch.Tensor], b: Optional[torch.Tensor]) -> float:
    if a is None or b is None:
        return 0.0
    try:
        return float(torch.norm(a - b, p=2).item())
    except Exception:
        return 0.0


def logp_to_prob(x: float) -> float:
    try:
        return float(torch.exp(torch.tensor(float(x))).item())
    except Exception:
        return 0.0


def build_word_records(initial_translation: str, scores: Dict[str, Dict]) -> List[Dict]:
    xi_ids = scores["xi"].get("token_ids", [])
    if not xi_ids:
        return []

    min_len = min(
        len(scores[c].get("token_logps", []))
        for c in ["xi", "x", "i", "n"]
    )

    if min_len <= 0:
        return []

    xi_ids = scores["xi"]["token_ids"][:min_len]

    logps = {
        c: scores[c]["token_logps"][:min_len]
        for c in ["xi", "x", "i", "n"]
    }

    probs = {}
    for c in ["xi", "x", "i", "n"]:
        raw_probs = scores[c].get("token_probs", [])
        if len(raw_probs) >= min_len:
            probs[c] = raw_probs[:min_len]
        else:
            probs[c] = [logp_to_prob(v) for v in logps[c]]

    word_base = aggregate_token_values_to_words(xi_ids, logps["xi"], initial_translation)

    word_values = {}
    for c in ["xi", "x", "i", "n"]:
        word_values[c] = aggregate_token_values_to_words(
            xi_ids,
            logps[c],
            initial_translation,
        )

    word_probs = {}
    for c in ["xi", "x", "i", "n"]:
        word_probs[c] = aggregate_token_values_to_words(
            xi_ids,
            probs[c],
            initial_translation,
        )

    word_vecs = {}
    for c in ["xi", "x", "i", "n"]:
        vectors = scores[c].get("hidden_vectors", [])
        vectors = vectors[:min_len] if vectors else []
        word_vecs[c] = aggregate_token_vectors_to_words(
            xi_ids,
            vectors,
            initial_translation,
        )

    n_words = min(
        min(len(word_values[c]) for c in ["xi", "x", "i", "n"]),
        min(len(word_probs[c]) for c in ["xi", "x", "i", "n"]),
    )

    records = []

    for wi in range(n_words):
        word = word_base[wi]["word"]

        lp_xi = word_values["xi"][wi]["value"]
        lp_x = word_values["x"][wi]["value"]
        lp_i = word_values["i"][wi]["value"]
        lp_n = word_values["n"][wi]["value"]

        p_xi = word_probs["xi"][wi]["value"]
        p_x = word_probs["x"][wi]["value"]
        p_i = word_probs["i"][wi]["value"]
        p_n = word_probs["n"][wi]["value"]

        z_xi = word_vecs["xi"][wi] if wi < len(word_vecs["xi"]) else None
        z_x = word_vecs["x"][wi] if wi < len(word_vecs["x"]) else None
        z_i = word_vecs["i"][wi] if wi < len(word_vecs["i"]) else None
        z_n = word_vecs["n"][wi] if wi < len(word_vecs["n"]) else None

        records.append(
            {
                "word_index": wi,
                "word": word,
                "norm": norm(word),
                "is_content": is_content_word(word),

                "logp_xi": lp_xi,
                "logp_x": lp_x,
                "logp_i": lp_i,
                "logp_n": lp_n,

                "prob_xi": p_xi,
                "prob_x": p_x,
                "prob_i": p_i,
                "prob_n": p_n,

                "source_support": lp_x - lp_n,
                "image_support": lp_i - lp_n,
                "joint_support": lp_xi - lp_n,
                "source_image_gain": lp_xi - max(lp_x, lp_i),
                "prior_dominance": lp_n - lp_xi,
                "source_absence": lp_n - lp_x,
                "image_absence": lp_n - lp_i,

                "prob_source_support": p_x - p_n,
                "prob_image_support": p_i - p_n,
                "prob_joint_support": p_xi - p_n,
                "prob_source_image_gain": p_xi - max(p_x, p_i),
                "prob_prior_dominance": p_n - p_xi,
                "prob_source_absence": p_n - p_x,
                "prob_image_absence": p_n - p_i,

                "source_instability": l2_distance(z_xi, z_x),
                "image_instability": l2_distance(z_xi, z_i),
                "joint_prior_distance": l2_distance(z_xi, z_n),
            }
        )

    return records


# =========================================================
# Pareto utilities
# =========================================================
def dominates(a: Dict, b: Dict, dim1: str, dim2: str) -> bool:
    a1 = safe_float(a.get(dim1, 0.0))
    a2 = safe_float(a.get(dim2, 0.0))
    b1 = safe_float(b.get(dim1, 0.0))
    b2 = safe_float(b.get(dim2, 0.0))

    return (a1 >= b1 and a2 >= b2) and (a1 > b1 or a2 > b2)


def on_pareto_frontier(item: Dict, population: List[Dict], dim1: str, dim2: str) -> bool:
    for other in population:
        if other is item:
            continue
        if dominates(other, item, dim1, dim2):
            return False
    return True


CONFLICT_DIM_PAIRS = [
    ("prior_dominance", "source_absence"),
    ("prior_dominance", "image_absence"),
    ("source_absence", "image_absence"),
    ("prior_dominance", "source_instability"),
    ("source_absence", "source_instability"),
    ("image_absence", "image_instability"),
    ("joint_prior_distance", "source_instability"),
    ("joint_prior_distance", "image_instability"),
]

GAIN_DIM_PAIRS = [
    ("source_image_gain", "source_instability"),
    ("source_image_gain", "image_instability"),
    ("source_image_gain", "joint_prior_distance"),
    ("joint_support", "source_image_gain"),
]

ANCHOR_DIM_PAIRS = [
    ("source_support", "joint_support"),
    ("source_support", "image_support"),
    ("joint_support", "image_support"),
]

FINAL_PROB_CONFLICT_DIM_PAIRS = [
    ("prob_prior_dominance", "prob_source_absence"),
    ("prob_prior_dominance", "prob_image_absence"),
    ("prob_source_absence", "prob_image_absence"),
    ("prob_prior_dominance", "source_instability"),
    ("prob_source_absence", "source_instability"),
    ("prob_image_absence", "image_instability"),
    ("prob_prior_dominance", "joint_prior_distance"),
]

FINAL_PROB_GAIN_DIM_PAIRS = [
    ("prob_source_image_gain", "source_instability"),
    ("prob_source_image_gain", "image_instability"),
    ("prob_source_image_gain", "joint_prior_distance"),
    ("prob_joint_support", "prob_source_image_gain"),
]

FINAL_PROB_ANCHOR_DIM_PAIRS = [
    ("prob_source_support", "prob_joint_support"),
    ("prob_source_support", "prob_image_support"),
    ("prob_joint_support", "prob_image_support"),
]


def frontier_info(item: Dict, population: List[Dict], pairs: List[Tuple[str, str]]) -> Tuple[int, List[str], List[str]]:
    count = 0
    dims = set()
    pair_names = []

    for a, b in pairs:
        if on_pareto_frontier(item, population, a, b):
            count += 1
            dims.add(a)
            dims.add(b)
            pair_names.append(f"{a}+{b}")

    return count, sorted(dims), pair_names


# =========================================================
# Phrase candidates
# =========================================================
def phrase_from_words(words: List[Dict], start: int, end: int) -> Dict:
    items = words[start:end + 1]
    span = " ".join(x["word"] for x in items).strip()
    c_tokens = content_tokens(span)

    out = {
        "span": span,
        "start_token": start,
        "end_token": end,
        "num_words": len(c_tokens) if c_tokens else len(tokenize_words(span)),
        "word_count": end - start + 1,
        "content_count": sum(1 for x in items if x.get("is_content", False)),
        "contains_bridge": any(is_bridge_word(x.get("word", "")) for x in items),
    }

    metric_keys = [
        "source_support",
        "image_support",
        "joint_support",
        "source_image_gain",
        "prior_dominance",
        "source_absence",
        "image_absence",

        "prob_source_support",
        "prob_image_support",
        "prob_joint_support",
        "prob_source_image_gain",
        "prob_prior_dominance",
        "prob_source_absence",
        "prob_image_absence",

        "source_instability",
        "image_instability",
        "joint_prior_distance",

        "logp_xi",
        "logp_x",
        "logp_i",
        "logp_n",

        "prob_xi",
        "prob_x",
        "prob_i",
        "prob_n",
    ]

    for k in metric_keys:
        vals = [safe_float(x.get(k, 0.0)) for x in items]
        out[f"mean_{k}"] = sum(vals) / max(1, len(vals))
        out[k] = out[f"mean_{k}"]

    return out


def build_phrase_candidates(words: List[Dict]) -> List[Dict]:
    phrases = []
    n = len(words)

    for i in range(n):
        for j in range(i, min(n, i + 4)):
            ph = phrase_from_words(words, i, j)

            if ph["content_count"] <= 0:
                continue

            if not content_tokens(ph["span"]):
                continue

            phrases.append(ph)

    return phrases


def add_frontier_fields(items: List[Dict]) -> List[Dict]:
    for it in items:
        c, dims, pairs = frontier_info(it, items, CONFLICT_DIM_PAIRS)
        it["rank_consensus_vote_count"] = c
        it["rank_consensus_dimensions"] = dims
        it["rank_consensus_frontier_pairs"] = pairs

        g, gdims, gpairs = frontier_info(it, items, GAIN_DIM_PAIRS)
        it["gain_vote_count"] = g
        it["gain_dimensions"] = gdims
        it["gain_frontier_pairs"] = gpairs

        a, adims, apairs = frontier_info(it, items, ANCHOR_DIM_PAIRS)
        it["anchor_vote_count"] = a
        it["anchor_dimensions"] = adims
        it["anchor_frontier_pairs"] = apairs

        pc, pcdims, pcpairs = frontier_info(it, items, FINAL_PROB_CONFLICT_DIM_PAIRS)
        it["final_prob_vote_count"] = pc
        it["final_prob_dimensions"] = pcdims
        it["final_prob_frontier_pairs"] = pcpairs

        pg, pgdims, pgpairs = frontier_info(it, items, FINAL_PROB_GAIN_DIM_PAIRS)
        it["final_prob_gain_vote_count"] = pg
        it["final_prob_gain_dimensions"] = pgdims
        it["final_prob_gain_frontier_pairs"] = pgpairs

        pa, padims, papairs = frontier_info(it, items, FINAL_PROB_ANCHOR_DIM_PAIRS)
        it["final_prob_anchor_vote_count"] = pa
        it["final_prob_anchor_dimensions"] = padims
        it["final_prob_anchor_frontier_pairs"] = papairs

    return items


# =========================================================
# Sentence-first + span-localization judgement
# =========================================================
def is_single_content_phrase(item: Dict) -> bool:
    try:
        return int(item.get("num_words", item.get("content_count", 1))) <= 1
    except Exception:
        span = clean_text(item.get("span", ""))
        return len(content_tokens(span)) <= 1


def is_number_only_span(item: Dict) -> bool:
    toks = content_tokens(item.get("span", ""))
    if not toks:
        return False

    for t in toks:
        if t.isdigit():
            continue
        if t.lower() in NUMBER_WORDS:
            continue
        return False

    return True


def meaningful_source_image_gain(item: Dict) -> bool:
    gain = safe_float(item.get("source_image_gain", 0.0))
    if gain <= 0.0:
        return False

    src = safe_float(item.get("source_support", 0.0))
    img = safe_float(item.get("image_support", 0.0))

    if src > 0.0 and img > 0.0:
        return gain > min(src, img)

    return True


def meaningful_final_prob_source_image_gain(item: Dict) -> bool:
    gain = safe_float(item.get("prob_source_image_gain", 0.0))
    if gain <= 0.0:
        return False

    src = safe_float(item.get("prob_source_support", 0.0))
    img = safe_float(item.get("prob_image_support", 0.0))

    if src > 0.0 and img > 0.0:
        return gain > min(src, img)

    return True


def final_prob_stable_multi_condition_supported(item: Dict) -> bool:
    return (
        safe_float(item.get("prob_source_support", 0.0)) > 0.0
        and safe_float(item.get("prob_joint_support", 0.0)) > 0.0
        and safe_float(item.get("prob_prior_dominance", 0.0)) < 0.0
    )


def stable_multi_condition_supported(item: Dict) -> bool:
    logp_stable = (
        safe_float(item.get("source_support", 0.0)) > 0.0
        and safe_float(item.get("joint_support", 0.0)) > 0.0
        and safe_float(item.get("prior_dominance", 0.0)) < 0.0
    )

    return logp_stable and final_prob_stable_multi_condition_supported(item)


def strongly_source_supported(item: Dict) -> bool:
    return (
        safe_float(item.get("source_support", 0.0)) > 0.0
        and safe_float(item.get("joint_support", 0.0)) > 0.0
        and safe_float(item.get("prob_source_support", 0.0)) > 0.0
        and safe_float(item.get("prob_joint_support", 0.0)) > 0.0
        and safe_float(item.get("prior_dominance", 0.0)) < 0.0
        and safe_float(item.get("prob_prior_dominance", 0.0)) < 0.0
    )


def clean_anchor(item: Dict) -> bool:
    return (
        safe_float(item.get("source_support", 0.0)) > 0.0
        and safe_float(item.get("prob_source_support", 0.0)) > 0.0
        and safe_float(item.get("joint_support", 0.0)) > 0.0
        and safe_float(item.get("prob_joint_support", 0.0)) > 0.0
        and safe_float(item.get("prior_dominance", 0.0)) <= 0.0
        and safe_float(item.get("prob_prior_dominance", 0.0)) <= 0.0
    )


def clearly_source_and_joint_supported(item: Dict) -> bool:
    return clean_anchor(item)


def span_distance(a: Dict, b: Dict) -> int:
    a0 = int(a.get("start_token", 0))
    a1 = int(a.get("end_token", 0))
    b0 = int(b.get("start_token", 0))
    b1 = int(b.get("end_token", 0))

    if overlap_span(a0, a1, b0, b1):
        return 0

    if a1 < b0:
        return max(0, b0 - a1 - 1)

    if b1 < a0:
        return max(0, a0 - b1 - 1)

    return 0


def source_negative(sp: Dict) -> bool:
    return (
        safe_float(sp.get("source_support", 0.0)) < 0.0
        and safe_float(sp.get("prob_source_support", 0.0)) < 0.0
        and safe_float(sp.get("source_absence", 0.0)) > 0.0
        and safe_float(sp.get("prob_source_absence", 0.0)) > 0.0
    )


def prior_negative(sp: Dict) -> bool:
    return (
        safe_float(sp.get("prior_dominance", 0.0)) > 0.0
        and safe_float(sp.get("prob_prior_dominance", 0.0)) > 0.0
    )


def joint_positive(sp: Dict) -> bool:
    return (
        safe_float(sp.get("joint_support", 0.0)) > 0.0
        and safe_float(sp.get("prob_joint_support", 0.0)) > 0.0
    )


def image_or_gain_positive(sp: Dict) -> bool:
    return (
        safe_float(sp.get("image_support", 0.0)) > 0.0
        or safe_float(sp.get("prob_image_support", 0.0)) > 0.0
        or meaningful_source_image_gain(sp)
        or meaningful_final_prob_source_image_gain(sp)
    )


def final_confirmed(sp: Dict) -> bool:
    return (
        int(sp.get("final_prob_vote_count", 0)) >= 3
        or int(sp.get("final_prob_gain_vote_count", 0)) >= 3
    )


def final_soft_confirmed(sp: Dict) -> bool:
    return (
        int(sp.get("final_prob_vote_count", 0)) >= 2
        or int(sp.get("final_prob_gain_vote_count", 0)) >= 2
    )


def gain_confirmed(sp: Dict) -> bool:
    return (
        int(sp.get("gain_vote_count", 0)) >= 3
        and int(sp.get("final_prob_gain_vote_count", 0)) >= 3
        and (
            meaningful_source_image_gain(sp)
            or meaningful_final_prob_source_image_gain(sp)
        )
    )


def span_has_strong_local_conflict(sp: Dict) -> bool:
    return (
        source_negative(sp)
        and joint_positive(sp)
        and image_or_gain_positive(sp)
        and (
            gain_confirmed(sp)
            or final_confirmed(sp)
        )
    )


def protected_by_clean_anchor(sp: Dict, anchors: List[Dict]) -> bool:
    """
    clean anchor 只能保护没有强局部冲突的 span。
    如果 span 自身 source-negative + joint/gain-positive 很强，
    即使它被 anchor 覆盖，也不能被 anchor 保护。
    """
    if span_has_strong_local_conflict(sp):
        return False

    for a in anchors:
        if span_distance(sp, a) > 1:
            continue

        if not clean_anchor(a):
            continue

        return True

    return False


def source_unsupported_addition(sp: Dict) -> bool:
    """
    多内容词、source/image/joint 都无法合理支持、且 prior/source/image 三方都负，
    才视为 source unsupported addition。
    """
    if is_single_content_phrase(sp):
        return False

    logp_conflict = (
        safe_float(sp.get("prior_dominance", 0.0)) > 0.0
        and safe_float(sp.get("source_absence", 0.0)) > 0.0
        and safe_float(sp.get("image_absence", 0.0)) > 0.0
    )

    prob_conflict = (
        safe_float(sp.get("prob_prior_dominance", 0.0)) > 0.0
        and safe_float(sp.get("prob_source_absence", 0.0)) > 0.0
        and safe_float(sp.get("prob_image_absence", 0.0)) > 0.0
    )

    return logp_conflict and prob_conflict and final_confirmed(sp)


def must_repair_target(sp: Dict, anchors: List[Dict]) -> bool:
    if is_number_only_span(sp):
        return False

    if clearly_source_and_joint_supported(sp):
        return False

    if protected_by_clean_anchor(sp, anchors):
        return False

    if source_unsupported_addition(sp):
        return True

    base_local_conflict = (
        source_negative(sp)
        and joint_positive(sp)
        and image_or_gain_positive(sp)
        and final_confirmed(sp)
    )

    if not base_local_conflict:
        return False

    # 单内容词进入 must 必须有 gain_confirmed。
    if is_single_content_phrase(sp):
        return gain_confirmed(sp)

    # 多内容短语进入 must：gain_confirmed 或 prior_negative 至少一个成立。
    return gain_confirmed(sp) or prior_negative(sp)


def try_repair_target(sp: Dict, anchors: List[Dict]) -> bool:
    if is_number_only_span(sp):
        return False

    if clearly_source_and_joint_supported(sp):
        return False

    if protected_by_clean_anchor(sp, anchors):
        return False

    weak_negative = (
        safe_float(sp.get("source_absence", 0.0)) > 0.0
        or safe_float(sp.get("prob_source_absence", 0.0)) > 0.0
        or safe_float(sp.get("prior_dominance", 0.0)) > 0.0
        or safe_float(sp.get("prob_prior_dominance", 0.0)) > 0.0
    )

    has_joint_or_gain = (
        safe_float(sp.get("joint_support", 0.0)) > 0.0
        or safe_float(sp.get("prob_joint_support", 0.0)) > 0.0
        or safe_float(sp.get("source_image_gain", 0.0)) > 0.0
        or safe_float(sp.get("prob_source_image_gain", 0.0)) > 0.0
        or safe_float(sp.get("image_support", 0.0)) > 0.0
        or safe_float(sp.get("prob_image_support", 0.0)) > 0.0
    )

    return weak_negative and has_joint_or_gain and final_soft_confirmed(sp)


def repair_quality(sp: Dict, anchors: List[Dict]) -> str:
    if must_repair_target(sp, anchors):
        return "must_repair"

    if try_repair_target(sp, anchors):
        return "try_repair"

    return "blocked"


def edit_type_for_repair(sp: Dict, quality: str) -> str:
    if quality == "blocked":
        return "keep"

    if source_unsupported_addition(sp):
        return "delete"

    if image_or_gain_positive(sp):
        return "visual_refill"

    return "paraphrase"


def item_priority(item: Dict) -> Tuple:
    quality = item.get("repair_quality", "")
    q_rank = {
        "must_repair": 3,
        "try_repair": 2,
        "blocked": 1,
    }.get(quality, 0)

    return (
        q_rank,
        int(item.get("num_words", 1)),
        safe_float(item.get("rank_consensus_vote_count", 0.0)),
        safe_float(item.get("final_prob_vote_count", 0.0)),
        safe_float(item.get("gain_vote_count", 0.0)),
        safe_float(item.get("final_prob_gain_vote_count", 0.0)),
        safe_float(item.get("source_absence", 0.0)),
        safe_float(item.get("prob_source_absence", 0.0)),
        safe_float(item.get("source_image_gain", 0.0)),
        safe_float(item.get("prob_source_image_gain", 0.0)),
        safe_float(item.get("joint_prior_distance", 0.0)),
        -int(item.get("start_token", 0)),
    )


def anchor_priority(item: Dict) -> Tuple:
    return (
        item.get("word_count", 1),
        safe_float(item.get("anchor_vote_count", 0.0)),
        safe_float(item.get("final_prob_anchor_vote_count", 0.0)),
        safe_float(item.get("source_support", 0.0)) + safe_float(item.get("joint_support", 0.0)),
        safe_float(item.get("prob_source_support", 0.0)) + safe_float(item.get("prob_joint_support", 0.0)),
        safe_float(item.get("image_support", 0.0)),
        safe_float(item.get("prob_image_support", 0.0)),
        -int(item.get("start_token", 0)),
    )


def phrase_overlaps_any(item: Dict, spans: List[Dict]) -> bool:
    s0 = int(item.get("start_token", 0))
    s1 = int(item.get("end_token", 0))

    for sp in spans:
        a0 = int(sp.get("start_token", 0))
        a1 = int(sp.get("end_token", 0))
        if overlap_span(s0, s1, a0, a1):
            return True

    return False


def non_overlapping_select(items: List[Dict]) -> List[Dict]:
    selected = []

    for it in items:
        if phrase_overlaps_any(it, selected):
            continue
        selected.append(it)

    return selected


def classify_sentence_and_spans(
    phrases: List[Dict],
) -> Tuple[str, List[Dict], List[Dict], List[Dict], List[Dict]]:
    """
    返回：
    sentence_repair_confidence,
    must_repair_spans,
    try_repair_spans,
    blocked_spans,
    anchor_spans
    """
    anchor_candidates = []

    for ph in phrases:
        if stable_multi_condition_supported(ph) or strongly_source_supported(ph):
            item = dict(ph)
            item["anchor_reason"] = "stable_or_source_supported_anchor"
            anchor_candidates.append(item)

    anchor_candidates = sorted(anchor_candidates, key=anchor_priority, reverse=True)
    anchor_spans = non_overlapping_select(anchor_candidates)

    judged = []

    for ph in phrases:
        item = dict(ph)
        q = repair_quality(item, anchor_spans)
        item["repair_quality"] = q
        item["edit_type"] = edit_type_for_repair(item, q)

        if q == "must_repair":
            if source_unsupported_addition(item):
                item["edit_reason"] = "source_unsupported_addition"
                item["evidence_type"] = "source_unsupported_addition"
            else:
                item["edit_reason"] = "sentence_level_must_repair_gain_confirmed_local_conflict"
                item["evidence_type"] = "must_repair_local_conflict"
        elif q == "try_repair":
            item["edit_reason"] = "sentence_level_try_repair_soft_local_conflict"
            item["evidence_type"] = "try_repair_local_conflict"
        else:
            item["edit_reason"] = "blocked_by_sentence_level_judgement"
            item["evidence_type"] = "blocked"

        judged.append(item)

    must_raw = [x for x in judged if x["repair_quality"] == "must_repair"]
    try_raw = [x for x in judged if x["repair_quality"] == "try_repair"]
    blocked_raw = [x for x in judged if x["repair_quality"] == "blocked"]

    must_repair = non_overlapping_select(sorted(must_raw, key=item_priority, reverse=True))

    try_raw = [
        x for x in try_raw
        if not phrase_overlaps_any(x, must_repair)
    ]
    try_repair = non_overlapping_select(sorted(try_raw, key=item_priority, reverse=True))

    repair_targets = must_repair + try_repair

    blocked_raw = [
        x for x in blocked_raw
        if not phrase_overlaps_any(x, repair_targets)
    ]
    blocked = non_overlapping_select(sorted(blocked_raw, key=item_priority, reverse=True))

    final_anchors = []
    for a in anchor_spans:
        if phrase_overlaps_any(a, repair_targets):
            continue
        final_anchors.append(a)

    final_anchors = non_overlapping_select(sorted(final_anchors, key=anchor_priority, reverse=True))

    if must_repair:
        sentence_conf = "must_repair"
    elif try_repair:
        sentence_conf = "try_repair"
    else:
        sentence_conf = "no_repair"

    return sentence_conf, must_repair, try_repair, blocked, final_anchors


# =========================================================
# Compact output
# =========================================================
def compact_repair_item(item: Dict) -> Dict:
    return {
        "span": clean_text(item.get("span", "")),
        "edit_type": clean_text(item.get("edit_type", "")),
        "edit_reason": clean_text(item.get("edit_reason", "")),
        "evidence_type": clean_text(item.get("evidence_type", "")),
        "repair_quality": clean_text(item.get("repair_quality", "")),
        "tier": clean_text(item.get("repair_quality", "")),

        "start_token": int(item.get("start_token", 0)),
        "end_token": int(item.get("end_token", 0)),
        "num_words": int(item.get("num_words", item.get("word_count", 1))),

        "rank_consensus_vote_count": int(item.get("rank_consensus_vote_count", 0)),
        "final_prob_vote_count": int(item.get("final_prob_vote_count", 0)),
        "gain_vote_count": int(item.get("gain_vote_count", 0)),
        "final_prob_gain_vote_count": int(item.get("final_prob_gain_vote_count", 0)),

        "mean_prior_dominance": round(safe_float(item.get("prior_dominance", 0.0)), 6),
        "mean_source_absence": round(safe_float(item.get("source_absence", 0.0)), 6),
        "mean_image_absence": round(safe_float(item.get("image_absence", 0.0)), 6),
        "mean_source_support": round(safe_float(item.get("source_support", 0.0)), 6),
        "mean_image_support": round(safe_float(item.get("image_support", 0.0)), 6),
        "mean_joint_support": round(safe_float(item.get("joint_support", 0.0)), 6),
        "mean_source_image_gain": round(safe_float(item.get("source_image_gain", 0.0)), 6),

        "mean_prob_prior_dominance": round(safe_float(item.get("prob_prior_dominance", 0.0)), 8),
        "mean_prob_source_absence": round(safe_float(item.get("prob_source_absence", 0.0)), 8),
        "mean_prob_image_absence": round(safe_float(item.get("prob_image_absence", 0.0)), 8),
        "mean_prob_source_support": round(safe_float(item.get("prob_source_support", 0.0)), 8),
        "mean_prob_image_support": round(safe_float(item.get("prob_image_support", 0.0)), 8),
        "mean_prob_joint_support": round(safe_float(item.get("prob_joint_support", 0.0)), 8),
        "mean_prob_source_image_gain": round(safe_float(item.get("prob_source_image_gain", 0.0)), 8),
    }


def compact_anchor_item(item: Dict) -> Dict:
    return {
        "span": clean_text(item.get("span", "")),
        "anchor_reason": clean_text(item.get("anchor_reason", "stable_or_source_supported_anchor")),

        "start_token": int(item.get("start_token", 0)),
        "end_token": int(item.get("end_token", 0)),
        "num_words": int(item.get("num_words", item.get("word_count", 1))),

        "anchor_vote_count": int(item.get("anchor_vote_count", 0)),
        "final_prob_anchor_vote_count": int(item.get("final_prob_anchor_vote_count", 0)),

        "mean_source_support": round(safe_float(item.get("source_support", 0.0)), 6),
        "mean_image_support": round(safe_float(item.get("image_support", 0.0)), 6),
        "mean_joint_support": round(safe_float(item.get("joint_support", 0.0)), 6),
        "mean_prob_source_support": round(safe_float(item.get("prob_source_support", 0.0)), 8),
        "mean_prob_image_support": round(safe_float(item.get("prob_image_support", 0.0)), 8),
        "mean_prob_joint_support": round(safe_float(item.get("prob_joint_support", 0.0)), 8),
    }


def primary_span(spans: List[Dict]) -> str:
    if not spans:
        return ""
    return clean_text(spans[0].get("span", ""))


def primary_edit_type(spans: List[Dict]) -> str:
    if not spans:
        return ""
    return clean_text(spans[0].get("edit_type", ""))


def write_record(path: str, rec: Dict):
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")


# =========================================================
# Main
# =========================================================
def main():
    rows = []

    with open(INPUT_JSONL, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))

    total_all = len(rows)

    if MAX_ROWS is not None:
        rows = rows[:MAX_ROWS]

    os.makedirs(os.path.dirname(OUTPUT_JSONL), exist_ok=True)
    with open(OUTPUT_JSONL, "w", encoding="utf-8"):
        pass

    print(f"[INFO] Total loaded rows: {total_all}")
    print(f"[INFO] Actual run rows: {len(rows)}")
    print("[INFO] detect mode: sentence-first + span-localization v2")
    print("[INFO] must_repair: strict gain_confirmed local conflict")
    print("[INFO] try_repair: relaxed soft local conflict")
    print("[INFO] output fields: must_repair_spans / try_repair_spans / blocked_spans / anchor_spans")
    print("[INFO] compatibility: suspicious_spans=must_repair_spans, weak_repairable_spans=try_repair_spans")
    print("[INFO] no reference translation is used for decision")

    stats = {
        "total": 0,
        "error": 0,

        "image_path_found": 0,
        "image_path_missing": 0,
        "image_used_xi": 0,
        "image_used_i": 0,

        "sentence_must_repair": 0,
        "sentence_try_repair": 0,
        "sentence_no_repair": 0,
        "sentence_repair_needed": 0,

        "has_must_repair": 0,
        "has_try_repair": 0,
        "has_blocked": 0,
        "has_anchor": 0,

        "must_repair_total": 0,
        "try_repair_total": 0,
        "blocked_total": 0,
        "anchor_span_total": 0,

        # Backward-compatible stats
        "has_suspicious": 0,
        "has_weak_repairable": 0,
        "suspicious_span_total": 0,
        "weak_repairable_total": 0,

        "delete_total": 0,
        "visual_refill_total": 0,
        "paraphrase_total": 0,
        "keep_total": 0,

        "source_unsupported_total": 0,
        "final_prob_must_supported_total": 0,
        "final_prob_try_supported_total": 0,
        "final_prob_anchor_supported_total": 0,
    }

    times = []

    for idx, row in enumerate(rows, 1):
        t0 = time.time()

        source_info = lookup_source_info(row)

        sid = get_id(row, source_info)
        image_path = get_image_path(row, source_info)
        source_text = get_source_text(row, source_info)
        initial_translation = get_initial_translation(row)
        initial_translation = norm_sent(initial_translation)

        stats["total"] += 1

        if image_path and os.path.isfile(image_path):
            stats["image_path_found"] += 1
        else:
            stats["image_path_missing"] += 1

        try:
            scores = score_all_conditions(
                source_text=source_text,
                initial_translation=initial_translation,
                image_path=image_path,
            )

            if scores.get("xi", {}).get("image_used", False):
                stats["image_used_xi"] += 1
            if scores.get("i", {}).get("image_used", False):
                stats["image_used_i"] += 1

            condition_errors = {
                c: scores[c].get("error", "")
                for c in ["xi", "x", "i", "n"]
                if scores[c].get("error", "")
            }

            if condition_errors:
                raise RuntimeError(f"condition scoring failed: {condition_errors}")

            words = build_word_records(initial_translation, scores)
            phrases = build_phrase_candidates(words)
            phrases = add_frontier_fields(phrases)

            (
                sentence_conf,
                must_raw,
                try_raw,
                blocked_raw,
                anchor_raw,
            ) = classify_sentence_and_spans(phrases=phrases)

            must_repair_spans = [compact_repair_item(x) for x in must_raw]
            try_repair_spans = [compact_repair_item(x) for x in try_raw]
            blocked_spans = [compact_repair_item(x) for x in blocked_raw]
            anchor_spans = [compact_anchor_item(x) for x in anchor_raw]

            sentence_repair_needed = sentence_conf in {"must_repair", "try_repair"}

            if sentence_conf == "must_repair":
                stats["sentence_must_repair"] += 1
            elif sentence_conf == "try_repair":
                stats["sentence_try_repair"] += 1
            else:
                stats["sentence_no_repair"] += 1

            if sentence_repair_needed:
                stats["sentence_repair_needed"] += 1

            if must_repair_spans:
                stats["has_must_repair"] += 1
                stats["has_suspicious"] += 1

            if try_repair_spans:
                stats["has_try_repair"] += 1
                stats["has_weak_repairable"] += 1

            if blocked_spans:
                stats["has_blocked"] += 1

            if anchor_spans:
                stats["has_anchor"] += 1

            stats["must_repair_total"] += len(must_repair_spans)
            stats["try_repair_total"] += len(try_repair_spans)
            stats["blocked_total"] += len(blocked_spans)
            stats["anchor_span_total"] += len(anchor_spans)

            stats["suspicious_span_total"] += len(must_repair_spans)
            stats["weak_repairable_total"] += len(try_repair_spans)

            for sp in must_repair_spans + try_repair_spans + blocked_spans:
                et = sp.get("edit_type", "")
                reason = sp.get("edit_reason", "")

                if et == "delete":
                    stats["delete_total"] += 1
                elif et == "visual_refill":
                    stats["visual_refill_total"] += 1
                elif et == "paraphrase":
                    stats["paraphrase_total"] += 1
                elif et == "keep":
                    stats["keep_total"] += 1

                if reason == "source_unsupported_addition":
                    stats["source_unsupported_total"] += 1

            for sp in must_repair_spans:
                if int(sp.get("final_prob_vote_count", 0)) >= 3 or int(sp.get("final_prob_gain_vote_count", 0)) >= 3:
                    stats["final_prob_must_supported_total"] += 1

            for sp in try_repair_spans:
                if int(sp.get("final_prob_vote_count", 0)) >= 2 or int(sp.get("final_prob_gain_vote_count", 0)) >= 2:
                    stats["final_prob_try_supported_total"] += 1

            for sp in anchor_spans:
                if int(sp.get("final_prob_anchor_vote_count", 0)) >= 1:
                    stats["final_prob_anchor_supported_total"] += 1

            primary_must_repair_spans = [x["span"] for x in must_repair_spans]
            primary_try_repair_spans = [x["span"] for x in try_repair_spans]
            primary_blocked_spans = [x["span"] for x in blocked_spans]
            primary_anchor_spans = [x["span"] for x in anchor_spans]

            rec = {
                "id": sid,
                "image_id": sid,
                "image_path": image_path,
                "source_text": source_text,
                "initial_translation": initial_translation,

                "language": LANGUAGE,
                "source_language_name": SOURCE_LANGUAGE_NAME,

                "sentence_repair_needed": sentence_repair_needed,
                "sentence_repair_confidence": sentence_conf,
                "detection_formula_version": DETECTION_FORMULA_VERSION,

                # New sentence-first output
                "must_repair_spans": must_repair_spans,
                "try_repair_spans": try_repair_spans,
                "blocked_spans": blocked_spans,
                "anchor_spans": anchor_spans,

                "primary_must_repair_span": primary_span(must_repair_spans),
                "primary_must_repair_spans": primary_must_repair_spans,

                "primary_try_repair_span": primary_span(try_repair_spans),
                "primary_try_repair_spans": primary_try_repair_spans,

                "primary_blocked_span": primary_span(blocked_spans),
                "primary_blocked_spans": primary_blocked_spans,

                "primary_anchor_span": primary_span(anchor_spans),
                "primary_anchor_spans": primary_anchor_spans,

                # Backward-compatible fields for old candidate program
                "suspicious_spans": must_repair_spans,
                "weak_repairable_spans": try_repair_spans,

                "primary_suspicious_span": primary_span(must_repair_spans),
                "primary_edit_type": primary_edit_type(must_repair_spans),
                "primary_suspicious_spans": primary_must_repair_spans,
                "primary_edit_types": [
                    {"span": x["span"], "edit_type": x["edit_type"]}
                    for x in must_repair_spans
                ],

                "primary_weak_suspicious_span": primary_span(try_repair_spans),
                "primary_weak_edit_type": primary_edit_type(try_repair_spans),
                "primary_weak_suspicious_spans": primary_try_repair_spans,
                "primary_weak_edit_types": [
                    {"span": x["span"], "edit_type": x["edit_type"]}
                    for x in try_repair_spans
                ],

                "candidate_repair_target_available": bool(must_repair_spans or try_repair_spans),
                "candidate_must_repair_target_available": bool(must_repair_spans),
                "candidate_optional_repair_target_available": bool(try_repair_spans),

                "suspicious_tokens": [],
            }

            write_record(OUTPUT_JSONL, rec)

            dt = time.time() - t0
            times.append(dt)
            avg = sum(times) / max(1, len(times))
            eta = avg * (len(rows) - idx)

            print(
                f"[{idx}/{len(rows)}] id={sid} | {dt:.2f}s | "
                f"avg={avg:.2f}s | ETA={format_time(eta)} | "
                f"image={'yes' if image_path and os.path.isfile(image_path) else 'no'} | "
                f"sent={sentence_conf} | "
                f"must={len(must_repair_spans)} | "
                f"try={len(try_repair_spans)} | "
                f"blocked={len(blocked_spans)} | "
                f"anchor={len(anchor_spans)}"
            )

        except Exception as e:
            stats["error"] += 1

            rec = {
                "id": sid,
                "image_id": sid,
                "image_path": image_path,
                "source_text": source_text,
                "initial_translation": initial_translation,

                "language": LANGUAGE,
                "source_language_name": SOURCE_LANGUAGE_NAME,

                "sentence_repair_needed": False,
                "sentence_repair_confidence": "error",
                "detection_formula_version": DETECTION_FORMULA_VERSION,

                "must_repair_spans": [],
                "try_repair_spans": [],
                "blocked_spans": [],
                "anchor_spans": [],

                "primary_must_repair_span": "",
                "primary_must_repair_spans": [],

                "primary_try_repair_span": "",
                "primary_try_repair_spans": [],

                "primary_blocked_span": "",
                "primary_blocked_spans": [],

                "primary_anchor_span": "",
                "primary_anchor_spans": [],

                "suspicious_spans": [],
                "weak_repairable_spans": [],

                "primary_suspicious_span": "",
                "primary_edit_type": "",
                "primary_suspicious_spans": [],
                "primary_edit_types": [],

                "primary_weak_suspicious_span": "",
                "primary_weak_edit_type": "",
                "primary_weak_suspicious_spans": [],
                "primary_weak_edit_types": [],

                "candidate_repair_target_available": False,
                "candidate_must_repair_target_available": False,
                "candidate_optional_repair_target_available": False,

                "suspicious_tokens": [],

                "error": repr(e),
            }

            write_record(OUTPUT_JSONL, rec)
            print(f"[WARN] id={sid} failed: {repr(e)}")
            cleanup_cuda()

    print(f"[DONE] Saved to: {OUTPUT_JSONL}")
    print("[stats]", json.dumps(stats, ensure_ascii=False))


if __name__ == "__main__":
    main()