#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import json
import logging
import warnings
from typing import List, Tuple, Dict, Any

import pandas as pd
import torch
import sacrebleu

# ====== 环境 & 日志降噪 ======
os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"
os.environ["TOKENIZERS_PARALLELISM"] = "false"

warnings.filterwarnings("ignore", category=UserWarning)

logging.getLogger("pytorch_lightning").setLevel(logging.ERROR)
logging.getLogger("lightning.pytorch").setLevel(logging.ERROR)
logging.getLogger("lightning").setLevel(logging.ERROR)

# ====== COMET / XCOMET ======
try:
    from comet.models.regression.regression_metric import RegressionMetric
except Exception:
    RegressionMetric = None

try:
    from comet.models.multitask.xcomet_metric import XCOMETMetric
except Exception:
    XCOMETMetric = None


# =====================================================
# 1. 路径配置
# =====================================================
INPUT_TRANSLATION_JSONL = "/home/chenyi/offline_blaser_qe/out/Qwen_3_VL_8B/Multi30k/tr/tr_test_translation.jsonl"
INPUT_REFERENCE_JSONL   = "/mnt/raid/cycy/data/txt_multi30k/en_tr_test.jsonl"
OUTPUT_DIR              = "/home/chenyi/offline_blaser_qe/out/Qwen_3_VL_8B/Multi30k/tr"

# ===== COMET / XCOMET 模型路径 =====
COMET_MODEL_DIR = "/mnt/raid/gzy/comet_model/wmt22-comet-da"
COMET_MODEL_CKPT = os.path.join(COMET_MODEL_DIR, "checkpoints", "model.ckpt")
COMET_ENCODER_DIR = os.path.join(COMET_MODEL_DIR, "xlm-roberta-large")

XCOMET_MODEL_DIR = "/mnt/raid/gzy/comet_model/XCOMET-XL"
XCOMET_MODEL_CKPT = os.path.join(XCOMET_MODEL_DIR, "checkpoints", "model.ckpt")
XCOMET_ENCODER_DIR = os.path.join(XCOMET_MODEL_DIR, "xlm-roberta-xl")

COMET_BATCH_SIZE = 16
USE_GPU = True

MAX_ROWS = None

# 输出文件
OUTPUT_JSONL = os.path.join(OUTPUT_DIR, "tr_test_translation_scored_with_ref.jsonl")
OUTPUT_CSV   = os.path.join(OUTPUT_DIR, "tr_test_translation_scored_with_ref.csv")


# =====================================================
# 2. 工具函数
# =====================================================
def get_gpus_flag() -> int:
    if USE_GPU and torch.cuda.is_available():
        return 1
    return 0


def read_jsonl(path: str) -> List[dict]:
    rows = []
    with open(path, "r", encoding="utf-8") as f:
        for line_idx, line in enumerate(f, start=1):
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except Exception as e:
                print(f"[WARN] 文件 {path} 第 {line_idx} 行 JSON 解析失败，已跳过: {e}")
    return rows


def write_jsonl(path: str, rows: List[dict]) -> None:
    with open(path, "w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


def normalize_text(x: Any) -> str:
    if x is None:
        return ""
    return str(x).strip()


def safe_sentence_bleu(hyp: str, ref: str) -> float:
    if hyp == "":
        return 0.0
    return round(sacrebleu.sentence_bleu(hyp, [ref]).score, 2)


def safe_sentence_chrf(hyp: str, ref: str) -> float:
    if hyp == "":
        return 0.0
    return round(sacrebleu.sentence_chrf(hyp, [ref]).score, 2)


def compute_bleu_chrf_with_empty_as_zero(
    hyps: List[str],
    refs: List[str]
) -> Tuple[List[float], List[float], float, float]:
    """
    空译文直接记 0 分，并参与最终平均分。
    系统分采用“逐句分数平均”的方式，确保空译文按 0 纳入最终评价。
    """
    bleu_seg = [safe_sentence_bleu(h, r) for h, r in zip(hyps, refs)]
    chrf_seg = [safe_sentence_chrf(h, r) for h, r in zip(hyps, refs)]

    bleu_sys = round(sum(bleu_seg) / len(bleu_seg), 2) if bleu_seg else 0.0
    chrf_sys = round(sum(chrf_seg) / len(chrf_seg), 2) if chrf_seg else 0.0

    print(f"[RESULT] BLEU   = {bleu_sys:.2f}")
    print(f"[RESULT] chrF++ = {chrf_sys:.2f}")

    return bleu_seg, chrf_seg, bleu_sys, chrf_sys


def compute_comet(
    comet_model,
    srcs: List[str],
    hyps: List[str],
    refs: List[str]
) -> Tuple[List[float], float]:
    samples = [{"src": s, "mt": h, "ref": r} for s, h, r in zip(srcs, hyps, refs)]

    gpus = get_gpus_flag()
    result = comet_model.predict(
        samples,
        batch_size=COMET_BATCH_SIZE,
        gpus=gpus,
        progress_bar=False
    )

    if isinstance(result, dict):
        sys_score = result.get("system_score", float("nan"))
        scores = result.get("scores", [float("nan")] * len(srcs))
    else:
        scores, sys_score = result

    scores_100 = [round(float(s) * 100, 2) if s == s else 0.0 for s in scores]

    if isinstance(sys_score, str):
        try:
            sys_score_float = round(float(sys_score) * 100, 2)
        except ValueError:
            print(f"[RESULT] COMET system score = {sys_score}")
            return scores_100, 0.0
    else:
        sys_score_float = round(float(sys_score) * 100, 2)

    print(f"[RESULT] COMET (wmt22-comet-da) system score = {sys_score_float:.2f}")
    return scores_100, sys_score_float


def compute_xcomet(
    xcomet_model,
    srcs: List[str],
    hyps: List[str]
) -> Tuple[List[float], float]:
    samples = [{"src": s, "mt": h} for s, h in zip(srcs, hyps)]

    gpus = get_gpus_flag()
    result = xcomet_model.predict(
        samples,
        batch_size=COMET_BATCH_SIZE,
        gpus=gpus,
        progress_bar=False
    )

    if isinstance(result, dict):
        sys_score = result.get("system_score", float("nan"))
        scores = result.get("scores", [float("nan")] * len(srcs))
    else:
        scores, sys_score = result

    scores_100 = [round(float(s) * 100, 2) if s == s else 0.0 for s in scores]

    if isinstance(sys_score, str):
        try:
            sys_score_float = round(float(sys_score) * 100, 2)
        except ValueError:
            print(f"[RESULT] XCOMET-XL system score = {sys_score}")
            return scores_100, 0.0
    else:
        sys_score_float = round(float(sys_score) * 100, 2)

    print(f"[RESULT] XCOMET-XL system score = {sys_score_float:.2f}")
    return scores_100, sys_score_float


# =====================================================
# 3. 数据对齐
# =====================================================
def build_reference_map(ref_rows: List[dict]) -> Dict[str, str]:
    """
    从参考文件中建立 image_id -> source 的映射
    Multi30k en_hi_test.jsonl:
      - target: 原语言（这里作为 source_text）
      - source: 参考英文译文（这里作为 reference_en）
    """
    ref_map = {}
    for row in ref_rows:
        image_id = row.get("image_id", row.get("id", None))
        ref_en = normalize_text(row.get("source", ""))

        if image_id is None:
            continue

        image_id_key = str(image_id)
        ref_map[image_id_key] = ref_en

    return ref_map


def align_rows(
    trans_rows: List[dict],
    ref_map: Dict[str, str]
) -> List[dict]:
    """
    按 image_id 对齐:
    translation jsonl: image_id, source_text, initial_translation_en
    reference   jsonl: image_id, source
    """
    aligned = []
    miss_ref = 0

    for row in trans_rows:
        image_id = row.get("image_id", row.get("id", None))
        if image_id is None:
            continue

        image_id_key = str(image_id)

        source_text = normalize_text(row.get("source_text", ""))
        hyp = normalize_text(row.get("initial_translation_en", ""))

        if image_id_key not in ref_map:
            miss_ref += 1
            continue

        ref = normalize_text(ref_map[image_id_key])

        aligned.append({
            "image_id": image_id,
            "source_text": source_text,
            "initial_translation_en": hyp,
            "reference_en": ref
        })

    print(f"[INFO] 成功对齐条数: {len(aligned)}")
    print(f"[INFO] 缺少参考译文而跳过的条数: {miss_ref}")
    return aligned


# =====================================================
# 4. 主函数
# =====================================================
def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    if not os.path.exists(INPUT_TRANSLATION_JSONL):
        raise FileNotFoundError(f"待评分文件不存在: {INPUT_TRANSLATION_JSONL}")
    if not os.path.exists(INPUT_REFERENCE_JSONL):
        raise FileNotFoundError(f"参考文件不存在: {INPUT_REFERENCE_JSONL}")

    print(f"[INFO] 读取待评分文件: {INPUT_TRANSLATION_JSONL}")
    trans_rows = read_jsonl(INPUT_TRANSLATION_JSONL)
    if MAX_ROWS is not None:
        trans_rows = trans_rows[:MAX_ROWS]
    print(f"[INFO] 待读取条数: {len(trans_rows)}")

    print(f"[INFO] 读取参考文件: {INPUT_REFERENCE_JSONL}")
    ref_rows = read_jsonl(INPUT_REFERENCE_JSONL)
    print(f"[INFO] 参考文件条数: {len(ref_rows)}")

    ref_map = build_reference_map(ref_rows)
    aligned_rows = align_rows(trans_rows, ref_map)

    if len(aligned_rows) == 0:
        raise RuntimeError("没有成功对齐的数据，无法打分。请检查 image_id 和参考字段。")

    # -----------------------------------------------------
    # 先为所有样本初始化分数
    # 空译文：直接记 0 分，并参与最终评价
    # 非空译文：后续再用模型打分
    # -----------------------------------------------------
    for row in aligned_rows:
        hyp = row["initial_translation_en"]
        row["is_empty_translation"] = 1 if hyp == "" else 0
        row["BLEU"] = 0.0
        row["Chrf++"] = 0.0
        row["COMET"] = 0.0
        row["XCOMET-XL"] = 0.0

    non_empty_rows = [row for row in aligned_rows if row["is_empty_translation"] == 0]
    empty_count = len(aligned_rows) - len(non_empty_rows)

    print(f"[INFO] 空初始翻译条数: {empty_count}")
    print(f"[INFO] 非空初始翻译条数: {len(non_empty_rows)}")

    # -----------------------------------------------------
    # BLEU / chrF++：全部样本都算，空译文直接为 0
    # -----------------------------------------------------
    all_hyp_list = [row["initial_translation_en"] for row in aligned_rows]
    all_ref_list = [row["reference_en"] for row in aligned_rows]

    print("[INFO] 评估 BLEU / chrF++ ...")
    bleu_seg, chrf_seg, bleu_sys, chrf_sys = compute_bleu_chrf_with_empty_as_zero(
        all_hyp_list, all_ref_list
    )

    for i, row in enumerate(aligned_rows):
        row["BLEU"] = bleu_seg[i]
        row["Chrf++"] = chrf_seg[i]

    # -----------------------------------------------------
    # COMET / XCOMET：只对非空译文调用模型
    # 空译文保持 0 分
    # 最终系统分使用“所有样本逐句平均”，保证空译文参与最终评价
    # -----------------------------------------------------
    comet_sys = 0.0
    xcomet_sys = 0.0

    if len(non_empty_rows) > 0:
        src_list_nonempty = [row["source_text"] for row in non_empty_rows]
        hyp_list_nonempty = [row["initial_translation_en"] for row in non_empty_rows]
        ref_list_nonempty = [row["reference_en"] for row in non_empty_rows]

        # -------------------------------------------------
        # 加载 COMET
        # -------------------------------------------------
        print("[INFO] 正在加载 COMET 模型 (wmt22-comet-da)...")
        if RegressionMetric is None:
            raise RuntimeError("找不到 RegressionMetric，请检查 comet 安装版本。")

        comet_model = RegressionMetric.load_from_checkpoint(
            COMET_MODEL_CKPT,
            pretrained_model=COMET_ENCODER_DIR,
            load_pretrained_weights=False,
            strict=False
        )
        if get_gpus_flag() > 0:
            comet_model = comet_model.cuda()
        comet_model.eval()

        # -------------------------------------------------
        # 加载 XCOMET
        # -------------------------------------------------
        print("[INFO] 正在加载 XCOMET 模型 (XCOMET-XL)...")
        if XCOMETMetric is None:
            raise RuntimeError("找不到 XCOMETMetric，请确认 unbabel-comet 版本 >= 2.2.0。")

        xcomet_model = XCOMETMetric.load_from_checkpoint(
            XCOMET_MODEL_CKPT,
            pretrained_model=XCOMET_ENCODER_DIR,
            load_pretrained_weights=False,
            strict=False
        )
        if get_gpus_flag() > 0:
            xcomet_model = xcomet_model.cuda()
        xcomet_model.eval()

        print("[INFO] 模型加载完成，开始评估 COMET / XCOMET。")

        # -------------------------------------------------
        # COMET
        # -------------------------------------------------
        print("[INFO] 评估 COMET ...")
        comet_seg_nonempty, _ = compute_comet(
            comet_model, src_list_nonempty, hyp_list_nonempty, ref_list_nonempty
        )

        # -------------------------------------------------
        # XCOMET
        # -------------------------------------------------
        print("[INFO] 评估 XCOMET-XL ...")
        xcomet_seg_nonempty, _ = compute_xcomet(
            xcomet_model, src_list_nonempty, hyp_list_nonempty
        )

        # 写回非空样本分数
        for row, c_score, x_score in zip(non_empty_rows, comet_seg_nonempty, xcomet_seg_nonempty):
            row["COMET"] = c_score
            row["XCOMET-XL"] = x_score

        # 包含空译文的最终平均
        comet_sys = round(sum(row["COMET"] for row in aligned_rows) / len(aligned_rows), 2)
        xcomet_sys = round(sum(row["XCOMET-XL"] for row in aligned_rows) / len(aligned_rows), 2)

    else:
        print("[INFO] 所有初始翻译都为空，COMET / XCOMET-XL 全部记为 0。")
        comet_sys = 0.0
        xcomet_sys = 0.0

    print(f"[RESULT] COMET (含空译文记0后的最终平均) = {comet_sys:.2f}")
    print(f"[RESULT] XCOMET-XL (含空译文记0后的最终平均) = {xcomet_sys:.2f}")

    # -----------------------------------------------------
    # 整理输出
    # -----------------------------------------------------
    output_rows = []
    for row in aligned_rows:
        out = {
            "image_id": row["image_id"],
            "source_text": row["source_text"],
            "initial_translation_en": row["initial_translation_en"],
            "reference_en": row["reference_en"],
            "is_empty_translation": row["is_empty_translation"],
            "BLEU": row["BLEU"],
            "Chrf++": row["Chrf++"],
            "COMET": row["COMET"],
            "XCOMET-XL": row["XCOMET-XL"]
        }
        output_rows.append(out)

    # 保存 jsonl
    write_jsonl(OUTPUT_JSONL, output_rows)
    print(f"[INFO] JSONL 结果已保存到: {OUTPUT_JSONL}")

    # 保存 csv，并追加平均分
    df = pd.DataFrame(output_rows)

    avg_row = {
        "image_id": "AVERAGE SCORE",
        "source_text": "---",
        "initial_translation_en": "---",
        "reference_en": "---",
        "is_empty_translation": "---",
        "BLEU": bleu_sys,
        "Chrf++": chrf_sys,
        "COMET": comet_sys,
        "XCOMET-XL": xcomet_sys
    }
    df = pd.concat([df, pd.DataFrame([avg_row])], ignore_index=True)

    df.to_csv(OUTPUT_CSV, index=False, encoding="utf-8-sig")
    print(f"[INFO] CSV 结果已保存到: {OUTPUT_CSV}")
    print("[DONE] 全部评估完成。")


if __name__ == "__main__":
    main()