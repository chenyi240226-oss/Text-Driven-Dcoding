#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import json
import logging
import warnings
from typing import List, Tuple, Dict, Any

import pandas as pd
import torch
import sacrebleu

# ====== 环境 & 日志降噪 ======
os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"
os.environ["TOKENIZERS_PARALLELISM"] = "false"

warnings.filterwarnings("ignore", category=UserWarning)

logging.getLogger("pytorch_lightning").setLevel(logging.ERROR)
logging.getLogger("lightning.pytorch").setLevel(logging.ERROR)
logging.getLogger("lightning").setLevel(logging.ERROR)

# ====== COMET / XCOMET ======
try:
    from comet.models.regression.regression_metric import RegressionMetric
except Exception:
    RegressionMetric = None

try:
    from comet.models.multitask.xcomet_metric import XCOMETMetric
except Exception:
    XCOMETMetric = None


# =====================================================
# 1. 路径配置
# =====================================================
INPUT_JSONL = "/home/chenyi/offline_blaser_qe/out/Qwen_3_VL_8B/Multi30k/hi/en_hi_test_translation.jsonl"
OUTPUT_DIR = "/home/chenyi/offline_blaser_qe/out/Qwen_3_VL_8B/Multi30k/hi"

# ===== COMET / XCOMET 模型路径 =====
COMET_MODEL_DIR = "/mnt/raid/gzy/comet_model/wmt22-comet-da"
COMET_MODEL_CKPT = os.path.join(COMET_MODEL_DIR, "checkpoints", "model.ckpt")
COMET_ENCODER_DIR = os.path.join(COMET_MODEL_DIR, "xlm-roberta-large")

XCOMET_MODEL_DIR = "/mnt/raid/gzy/comet_model/XCOMET-XL"
XCOMET_MODEL_CKPT = os.path.join(XCOMET_MODEL_DIR, "checkpoints", "model.ckpt")
XCOMET_ENCODER_DIR = os.path.join(XCOMET_MODEL_DIR, "xlm-roberta-xl")

COMET_BATCH_SIZE = 16
USE_GPU = True

MAX_ROWS = None

# 输出文件
OUTPUT_JSONL = os.path.join(OUTPUT_DIR, "en_hi_test_translation_scored.jsonl")
OUTPUT_CSV   = os.path.join(OUTPUT_DIR, "en_hi_test_translation_scored.csv")


# =====================================================
# 2. 工具函数
# =====================================================
def get_gpus_flag() -> int:
    if USE_GPU and torch.cuda.is_available():
        return 1
    return 0


def read_jsonl(path: str) -> List[dict]:
    rows = []
    with open(path, "r", encoding="utf-8") as f:
        for line_idx, line in enumerate(f, start=1):
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except Exception as e:
                print(f"[WARN] 文件 {path} 第 {line_idx} 行 JSON 解析失败，已跳过: {e}")
    return rows


def write_jsonl(path: str, rows: List[dict]) -> None:
    with open(path, "w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


def normalize_text(x: Any) -> str:
    if x is None:
        return ""
    return str(x).strip()


def safe_sentence_bleu(hyp: str, ref: str) -> float:
    if hyp == "":
        return 0.0
    return round(sacrebleu.sentence_bleu(hyp, [ref]).score, 2)


def safe_sentence_chrf(hyp: str, ref: str) -> float:
    if hyp == "":
        return 0.0
    return round(sacrebleu.sentence_chrf(hyp, [ref]).score, 2)


def compute_bleu_chrf_with_empty_as_zero(
    hyps: List[str],
    refs: List[str]
) -> Tuple[List[float], List[float], float, float]:
    """
    空译文直接记 0 分，并参与最终平均分。
    系统分采用逐句分数平均，确保空译文按 0 纳入最终评价。
    """
    bleu_seg = [safe_sentence_bleu(h, r) for h, r in zip(hyps, refs)]
    chrf_seg = [safe_sentence_chrf(h, r) for h, r in zip(hyps, refs)]

    bleu_sys = round(sum(bleu_seg) / len(bleu_seg), 2) if bleu_seg else 0.0
    chrf_sys = round(sum(chrf_seg) / len(chrf_seg), 2) if chrf_seg else 0.0

    print(f"[RESULT] BLEU   = {bleu_sys:.2f}")
    print(f"[RESULT] chrF++ = {chrf_sys:.2f}")

    return bleu_seg, chrf_seg, bleu_sys, chrf_sys


def compute_comet(
    comet_model,
    srcs: List[str],
    hyps: List[str],
    refs: List[str]
) -> Tuple[List[float], float]:
    samples = [{"src": s, "mt": h, "ref": r} for s, h, r in zip(srcs, hyps, refs)]

    gpus = get_gpus_flag()
    result = comet_model.predict(
        samples,
        batch_size=COMET_BATCH_SIZE,
        gpus=gpus,
        progress_bar=False
    )

    if isinstance(result, dict):
        sys_score = result.get("system_score", float("nan"))
        scores = result.get("scores", [float("nan")] * len(srcs))
    else:
        scores, sys_score = result

    scores_100 = [round(float(s) * 100, 2) if s == s else 0.0 for s in scores]

    if isinstance(sys_score, str):
        try:
            sys_score_float = round(float(sys_score) * 100, 2)
        except ValueError:
            print(f"[RESULT] COMET system score = {sys_score}")
            return scores_100, 0.0
    else:
        sys_score_float = round(float(sys_score) * 100, 2)

    print(f"[RESULT] COMET (wmt22-comet-da) system score = {sys_score_float:.2f}")
    return scores_100, sys_score_float


def compute_xcomet(
    xcomet_model,
    srcs: List[str],
    hyps: List[str]
) -> Tuple[List[float], float]:
    samples = [{"src": s, "mt": h} for s, h in zip(srcs, hyps)]

    gpus = get_gpus_flag()
    result = xcomet_model.predict(
        samples,
        batch_size=COMET_BATCH_SIZE,
        gpus=gpus,
        progress_bar=False
    )

    if isinstance(result, dict):
        sys_score = result.get("system_score", float("nan"))
        scores = result.get("scores", [float("nan")] * len(srcs))
    else:
        scores, sys_score = result

    scores_100 = [round(float(s) * 100, 2) if s == s else 0.0 for s in scores]

    if isinstance(sys_score, str):
        try:
            sys_score_float = round(float(sys_score) * 100, 2)
        except ValueError:
            print(f"[RESULT] XCOMET-XL system score = {sys_score}")
            return scores_100, 0.0
    else:
        sys_score_float = round(float(sys_score) * 100, 2)

    print(f"[RESULT] XCOMET-XL system score = {sys_score_float:.2f}")
    return scores_100, sys_score_float


# =====================================================
# 3. 数据读取与整理
# =====================================================
def prepare_rows(rows: List[dict]) -> List[dict]:
    """
    直接从输入文件读取：
      - image_id
      - source_text
      - reference_translation
      - initial_translation_hi
    不再加载额外参考文件。
    """
    prepared = []
    skipped = 0

    for row in rows:
        image_id = row.get("image_id", row.get("id", ""))
        source_text = normalize_text(row.get("source_text", ""))
        ref = normalize_text(row.get("reference_translation", ""))
        hyp = normalize_text(row.get("initial_translation_hi", ""))

        if not ref:
            skipped += 1
            continue

        prepared.append({
            "image_id": image_id,
            "source_text": source_text,
            "reference_translation": ref,
            "initial_translation_hi": hyp
        })

    print(f"[INFO] 可评分条数: {len(prepared)}")
    print(f"[INFO] 因 reference_translation 为空而跳过: {skipped}")
    return prepared


# =====================================================
# 4. 主函数
# =====================================================
def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    if not os.path.exists(INPUT_JSONL):
        raise FileNotFoundError(f"输入文件不存在: {INPUT_JSONL}")

    print(f"[INFO] 读取输入文件: {INPUT_JSONL}")
    rows = read_jsonl(INPUT_JSONL)
    if MAX_ROWS is not None:
        rows = rows[:MAX_ROWS]
    print(f"[INFO] 读入条数: {len(rows)}")

    prepared_rows = prepare_rows(rows)

    if len(prepared_rows) == 0:
        raise RuntimeError("没有可评分的数据，无法继续。请检查 reference_translation 字段。")

    # source_text 为源句（英文），初始译文和参考译文都是 Hindi
    src_list = [row["source_text"] for row in prepared_rows]
    hyp_list = [row["initial_translation_hi"] for row in prepared_rows]
    ref_list = [row["reference_translation"] for row in prepared_rows]

    # -----------------------------------------------------
    # 初始化分数
    # -----------------------------------------------------
    for row in prepared_rows:
        hyp = row["initial_translation_hi"]
        row["is_empty_translation"] = 1 if hyp == "" else 0
        row["BLEU"] = 0.0
        row["Chrf++"] = 0.0
        row["COMET"] = 0.0
        row["XCOMET-XL"] = 0.0

    non_empty_rows = [row for row in prepared_rows if row["is_empty_translation"] == 0]
    empty_count = len(prepared_rows) - len(non_empty_rows)

    print(f"[INFO] 空初始翻译条数: {empty_count}")
    print(f"[INFO] 非空初始翻译条数: {len(non_empty_rows)}")

    # -----------------------------------------------------
    # BLEU / chrF++
    # -----------------------------------------------------
    print("[INFO] 评估 BLEU / chrF++ ...")
    bleu_seg, chrf_seg, bleu_sys, chrf_sys = compute_bleu_chrf_with_empty_as_zero(
        hyp_list, ref_list
    )

    for i, row in enumerate(prepared_rows):
        row["BLEU"] = bleu_seg[i]
        row["Chrf++"] = chrf_seg[i]

    # -----------------------------------------------------
    # COMET / XCOMET
    # -----------------------------------------------------
    comet_sys = 0.0
    xcomet_sys = 0.0

    if len(non_empty_rows) > 0:
        src_list_nonempty = [row["source_text"] for row in non_empty_rows]
        hyp_list_nonempty = [row["initial_translation_hi"] for row in non_empty_rows]
        ref_list_nonempty = [row["reference_translation"] for row in non_empty_rows]

        print("[INFO] 正在加载 COMET 模型 (wmt22-comet-da)...")
        if RegressionMetric is None:
            raise RuntimeError("找不到 RegressionMetric，请检查 comet 安装版本。")

        comet_model = RegressionMetric.load_from_checkpoint(
            COMET_MODEL_CKPT,
            pretrained_model=COMET_ENCODER_DIR,
            load_pretrained_weights=False,
            strict=False
        )
        if get_gpus_flag() > 0:
            comet_model = comet_model.cuda()
        comet_model.eval()

        print("[INFO] 正在加载 XCOMET 模型 (XCOMET-XL)...")
        if XCOMETMetric is None:
            raise RuntimeError("找不到 XCOMETMetric，请确认 unbabel-comet 版本 >= 2.2.0。")

        xcomet_model = XCOMETMetric.load_from_checkpoint(
            XCOMET_MODEL_CKPT,
            pretrained_model=XCOMET_ENCODER_DIR,
            load_pretrained_weights=False,
            strict=False
        )
        if get_gpus_flag() > 0:
            xcomet_model = xcomet_model.cuda()
        xcomet_model.eval()

        print("[INFO] 模型加载完成，开始评估 COMET / XCOMET。")

        print("[INFO] 评估 COMET ...")
        comet_seg_nonempty, _ = compute_comet(
            comet_model, src_list_nonempty, hyp_list_nonempty, ref_list_nonempty
        )

        print("[INFO] 评估 XCOMET-XL ...")
        xcomet_seg_nonempty, _ = compute_xcomet(
            xcomet_model, src_list_nonempty, hyp_list_nonempty
        )

        for row, c_score, x_score in zip(non_empty_rows, comet_seg_nonempty, xcomet_seg_nonempty):
            row["COMET"] = c_score
            row["XCOMET-XL"] = x_score

        comet_sys = round(sum(row["COMET"] for row in prepared_rows) / len(prepared_rows), 2)
        xcomet_sys = round(sum(row["XCOMET-XL"] for row in prepared_rows) / len(prepared_rows), 2)

    else:
        print("[INFO] 所有初始翻译都为空，COMET / XCOMET-XL 全部记为 0。")

    print(f"[RESULT] COMET (含空译文记0后的最终平均) = {comet_sys:.2f}")
    print(f"[RESULT] XCOMET-XL (含空译文记0后的最终平均) = {xcomet_sys:.2f}")

    # -----------------------------------------------------
    # 整理输出
    # -----------------------------------------------------
    output_rows = []
    for row in prepared_rows:
        out = {
            "image_id": row["image_id"],
            "source_text": row["source_text"],
            "reference_translation": row["reference_translation"],
            "initial_translation_hi": row["initial_translation_hi"],
            "is_empty_translation": row["is_empty_translation"],
            "BLEU": row["BLEU"],
            "Chrf++": row["Chrf++"],
            "COMET": row["COMET"],
            "XCOMET-XL": row["XCOMET-XL"]
        }
        output_rows.append(out)

    write_jsonl(OUTPUT_JSONL, output_rows)
    print(f"[INFO] JSONL 结果已保存到: {OUTPUT_JSONL}")

    df = pd.DataFrame(output_rows)

    avg_row = {
        "image_id": "AVERAGE SCORE",
        "source_text": "---",
        "reference_translation": "---",
        "initial_translation_hi": "---",
        "is_empty_translation": "---",
        "BLEU": bleu_sys,
        "Chrf++": chrf_sys,
        "COMET": comet_sys,
        "XCOMET-XL": xcomet_sys
    }
    df = pd.concat([df, pd.DataFrame([avg_row])], ignore_index=True)

    df.to_csv(OUTPUT_CSV, index=False, encoding="utf-8-sig")
    print(f"[INFO] CSV 结果已保存到: {OUTPUT_CSV}")
    print("[DONE] 全部评估完成。")


if __name__ == "__main__":
    main()