import os
os.environ["CUDA_VISIBLE_DEVICES"] = "4"
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"

import json
import re
from typing import List, Dict, Optional, Tuple, Any

import torch
import sentencepiece as spm

# =========================
# SONAR / BLASER
# =========================
from sonar.models.sonar_text.model import SequenceBatch
from sonar.models.sonar_text import SonarTextEncoderConfig, create_sonar_text_encoder_model
from sonar.models.blaser.builder import create_blaser_model, _arch_blaser_basic_qe
from sonar.models.blaser.loader import convert_blaser_checkpoint

torch.set_grad_enabled(False)

# =========================================================
# 固定路径配置
# =========================================================
INPUT_JSONL = "/home/chenyi/offline_blaser_qe/out/Qwen_3_VL_8B/Multi30k/hi/hi_3_candidates_from_span.jsonl"
REFERENCE_JSONL = "/home/chenyi/offline_blaser_qe/out/Qwen_3_VL_8B/Multi30k/hi/hi_test_translation.jsonl"

OUTPUT_DIR = "/home/chenyi/offline_blaser_qe/out/Qwen_3_VL_8B/Multi30k/hi"

OUTPUT_JSONL = os.path.join(OUTPUT_DIR, "hi_candidates_blaser_only_selected.jsonl")
OUTPUT_REF_BEST_JSONL = os.path.join(OUTPUT_DIR, "hi_source_reference_best.jsonl")

CHECKPOINTS_DIR = "/home/chenyi/offline_blaser_qe/checkpoints"
SYSLIBS_DIR = "/home/chenyi/offline_blaser_qe/syslibs"

SONAR_MODEL = os.path.join(CHECKPOINTS_DIR, "sonar_text_encoder.pt")
SPM_MODEL = os.path.join(CHECKPOINTS_DIR, "sentencepiece.source.256000.model")
BLASER_QE_CKPT = os.path.join(CHECKPOINTS_DIR, "blaser_2_0_qe_model.pt")

DEVICE = "cuda"
MAX_LEN = 256
BATCH_ROWS = 64

# 印地语 -> 英语
SRC_LANG = "hin_Deva"
TGT_LANG = "eng_Latn"

# 如果 source_text 为空，可回退到 source_text_en（此时用 eng_Latn 编码）
FALLBACK_TO_SOURCE_TEXT_EN = True

ROUND_DIGITS = 4
MAX_SAMPLES = None

# =========================================================
# 选择规则说明（无 reference）
# =========================================================
SELECTION_RULE = (
    "actionability_aware_no_reference:"
    " if row not actionable -> keep initial; "
    "else select best valid edited candidate with non-negative raw BLASER delta over initial "
    "using lexicographic priority "
    "(delta>=0, actionability_strength, mode_priority, evidence_priority, candidate_slot, delta, raw_score); "
    "if none -> keep initial"
)

# =========================================================
# 通用工具
# =========================================================
def clean_text(x) -> str:
    if x is None:
        return ""
    return str(x).strip()


def normalize_text(x: Any) -> str:
    s = clean_text(x).lower()
    s = s.replace("’", "'").replace("“", '"').replace("”", '"')
    s = re.sub(r"\s+", " ", s)
    s = s.strip(" \t\r\n.,;:!?\"'")
    return s


def tokenize_words(x: Any) -> List[str]:
    return re.findall(r"[A-Za-z0-9\-]+", normalize_text(x))


def format_score(x: float) -> float:
    return round(float(x), ROUND_DIGITS)


def write_jsonl_record(fp, obj: Dict):
    fp.write(json.dumps(obj, ensure_ascii=False) + "\n")


def same_text(a: Any, b: Any) -> bool:
    return normalize_text(a) == normalize_text(b)


def has_bad_repetition(text: str) -> bool:
    toks = tokenize_words(text)
    if not toks:
        return False
    for i in range(1, len(toks)):
        if toks[i] == toks[i - 1]:
            return True
    return False


def is_fragment_like_candidate(text: str) -> bool:
    toks = tokenize_words(text)
    if len(toks) < 3:
        return True

    low = normalize_text(text)
    if re.match(r"^(is|are|was|were|be|been|being)\b", low):
        return True
    if re.match(r"^(in|on|at|by|with|from|to|of|for|between|around|through|during|while)\b", low):
        return True

    return False


def candidate_slot_name(idx: int) -> str:
    mapping = {
        0: "initial_translation",
        1: "candidate_1",
        2: "candidate_2",
        3: "candidate_3",
    }
    return mapping.get(idx, "unknown")


def candidate_slot_priority(idx: int) -> int:
    # 倾向于更相信前两个修正候选，candidate_3 常是保底
    mapping = {
        1: 3,
        2: 2,
        3: 1,
        0: 0,
    }
    return mapping.get(idx, 0)


def get_evidence_priority(evidence: str) -> int:
    ev = normalize_text(evidence)
    if not ev:
        return 1
    if "error" in ev:
        return 0
    if "fallback" in ev:
        return 1
    if "keep original translation" in ev:
        return 0
    return 2


def get_primary_actionability_rank(row: Dict) -> int:
    v = row.get("primary_actionability_rank_detect", row.get("primary_actionability_rank", 3))
    try:
        return int(v)
    except Exception:
        return 3


def get_actionability_strength(rank: int) -> int:
    # 越大表示越值得改
    # 0: delete/paraphrase
    # 1: explicit visual_refill
    # 2: fallback visual_refill
    # 3: keep
    mapping = {
        0: 3,
        1: 2,
        2: 1,
        3: 0,
    }
    return mapping.get(rank, 0)


def get_rewrite_mode(row: Dict) -> str:
    return clean_text(row.get("rewrite_mode", ""))


def get_effective_rewrite_mode(row: Dict) -> str:
    return clean_text(row.get("effective_rewrite_mode", ""))


def get_mode_priority(row: Dict) -> int:
    rewrite_mode = get_rewrite_mode(row).lower()
    effective = get_effective_rewrite_mode(row).lower()

    if "joint_full_sentence" in rewrite_mode or "joint_full_sentence" in effective:
        return 4
    if "paraphrase" in effective or rewrite_mode == "paraphrase":
        return 3
    if "delete" in effective or rewrite_mode == "delete":
        return 3
    if "visual_refill" in effective or rewrite_mode == "visual_refill":
        return 2
    if rewrite_mode == "multi_primary":
        return 2
    if rewrite_mode == "no_action" or effective == "no_action":
        return 0
    return 1


def row_is_actionable(row: Dict) -> bool:
    rank = get_primary_actionability_rank(row)
    if rank <= 2:
        return True

    rewrite_mode = get_rewrite_mode(row).lower()
    effective = get_effective_rewrite_mode(row).lower()
    if rewrite_mode and rewrite_mode != "no_action":
        return True
    if effective and effective != "no_action":
        return True

    primary_operands = row.get("primary_operands", [])
    if isinstance(primary_operands, list):
        for op in primary_operands:
            if not isinstance(op, dict):
                continue
            et = normalize_text(op.get("edit_type", ""))
            allow = bool(op.get("gate_allow_operate", False))
            if et and et != "keep" and allow:
                return True

    return False


def is_valid_edited_candidate(text: str, initial_text: str, evidence: str) -> Tuple[bool, str]:
    text = clean_text(text)
    if not text:
        return False, "empty"

    if same_text(text, initial_text):
        return False, "same_as_initial"

    if has_bad_repetition(text):
        return False, "bad_repetition"

    if is_fragment_like_candidate(text):
        return False, "fragment_like"

    ev = normalize_text(evidence)
    if "error_fallback" in ev:
        return False, "error_fallback"

    return True, "ok"


# =========================================================
# JSONL
# =========================================================
def read_jsonl_records(path: str) -> List[Dict]:
    if not os.path.isfile(path):
        raise FileNotFoundError(f"JSONL not found: {path}")
    data = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            data.append(json.loads(line))
    return data


def build_reference_map(records: List[Dict]) -> Tuple[Dict[str, str], Dict[str, str]]:
    image_id_to_ref = {}
    source_text_to_ref = {}

    for r in records:
        image_id = clean_text(r.get("image_id", r.get("id", "")))
        source_text = clean_text(r.get("source_text", r.get("tgt", "")))
        ref_text = clean_text(r.get("reference_translation", r.get("src_en", "")))

        if image_id and ref_text and image_id not in image_id_to_ref:
            image_id_to_ref[image_id] = ref_text

        if source_text and ref_text and source_text not in source_text_to_ref:
            source_text_to_ref[source_text] = ref_text

    return image_id_to_ref, source_text_to_ref


def get_reference_translation(
    row: Dict,
    image_id_to_ref: Dict[str, str],
    source_text_to_ref: Dict[str, str]
) -> str:
    image_id = clean_text(row.get("id", row.get("image_id", "")))
    source_text = clean_text(row.get("source_text", ""))

    if image_id and image_id in image_id_to_ref:
        return image_id_to_ref[image_id]

    if source_text and source_text in source_text_to_ref:
        return source_text_to_ref[source_text]

    return ""


# =========================================================
# sentencepiece encode
# =========================================================
def sp_encode_batch(
    sp: spm.SentencePieceProcessor,
    texts: List[str],
    lang: str,
    max_len: int = 512,
    pad_id: int = 0
):
    tagged = [f"__{lang}__ {str(t).strip()}" for t in texts]

    ids = [sp.encode(t, out_type=int)[:max_len] for t in tagged]
    lens = [len(x) for x in ids]
    maxl = max(lens) if lens else 0

    x = torch.full((len(ids), maxl), pad_id, dtype=torch.long)
    for i, row in enumerate(ids):
        if row:
            x[i, :len(row)] = torch.tensor(row, dtype=torch.long)

    attn = (x != pad_id)
    return x, attn


def build_vocab_info_from_spm(spm_path: str, vocab_size_override: Optional[int] = None):
    from fairseq2.data.vocabulary_info import VocabularyInfo

    sp = spm.SentencePieceProcessor(model_file=spm_path)
    unk = sp.unk_id()
    bos = sp.bos_id()
    eos = sp.eos_id()
    pad = sp.pad_id() if hasattr(sp, "pad_id") else -1
    if pad is None or pad < 0:
        pad = 0

    size = vocab_size_override if vocab_size_override is not None else sp.get_piece_size()

    return VocabularyInfo(
        size=int(size),
        unk_idx=int(unk),
        bos_idx=int(bos),
        eos_idx=int(eos),
        pad_idx=int(pad),
    )


# =========================================================
# SONAR Text Encoder: offline load from state_dict
# =========================================================
def load_sonar_text_encoder_offline(
    encoder_ckpt: str,
    spm_path: str,
    device: torch.device,
    max_seq_len: int = 512
):
    if not os.path.isfile(encoder_ckpt):
        raise FileNotFoundError(f"SONAR text encoder checkpoint not found: {encoder_ckpt}")
    if not os.path.isfile(spm_path):
        raise FileNotFoundError(f"SentencePiece model not found: {spm_path}")

    ckpt = torch.load(encoder_ckpt, map_location="cpu")
    if not isinstance(ckpt, dict) or "model" not in ckpt:
        raise RuntimeError(
            f"Unexpected encoder checkpoint format: type={type(ckpt)} "
            f"keys={list(ckpt.keys()) if isinstance(ckpt, dict) else None}"
        )

    state_dict = ckpt["model"]
    if not isinstance(state_dict, dict):
        raise RuntimeError(
            f"Expected ckpt['model'] to be a state_dict dict/OrderedDict, got {type(state_dict)}"
        )

    emb_w = state_dict["encoder_frontend.embed.weight"]
    vocab_size = emb_w.shape[0]
    model_dim = emb_w.shape[1]

    ffn_w = state_dict["encoder.layers.0.ffn.inner_proj.weight"]
    ffn_inner_dim = ffn_w.shape[0]

    max_layer = -1
    for k in state_dict.keys():
        if k.startswith("encoder.layers."):
            parts = k.split(".")
            if len(parts) > 2 and parts[2].isdigit():
                max_layer = max(max_layer, int(parts[2]))
    num_encoder_layers = max_layer + 1

    vocab_info = build_vocab_info_from_spm(spm_path, vocab_size_override=int(vocab_size))
    num_heads = 16

    cfg = SonarTextEncoderConfig(
        model_dim=int(model_dim),
        max_seq_len=int(max_seq_len),
        vocab_info=vocab_info,
        num_encoder_layers=int(num_encoder_layers),
        num_decoder_layers=0,
        num_encoder_attn_heads=int(num_heads),
        num_decoder_attn_heads=0,
        ffn_inner_dim=int(ffn_inner_dim),
        pooling="mean",
    )

    encoder = create_sonar_text_encoder_model(cfg, device=device).eval()

    missing, unexpected = encoder.load_state_dict(state_dict, strict=False)
    if missing or unexpected:
        print(
            f"[warn] SONAR encoder load_state_dict(strict=False): "
            f"missing={len(missing)} unexpected={len(unexpected)}"
        )

    sp = spm.SentencePieceProcessor(model_file=spm_path)
    return encoder, sp


@torch.no_grad()
def sonar_encode(
    encoder,
    sp: spm.SentencePieceProcessor,
    texts: List[str],
    lang: str,
    device: torch.device,
    max_len: int = 512
) -> torch.Tensor:
    toks, attn = sp_encode_batch(
        sp,
        texts,
        lang=lang,
        max_len=max_len,
        pad_id=0
    )
    toks = toks.to(device)
    attn = attn.to(device)

    padding_mask = None
    try:
        from fairseq2.nn.padding import PaddingMask
        pad = ~attn
        if hasattr(PaddingMask, "from_bool_tensor"):
            padding_mask = PaddingMask.from_bool_tensor(pad)
        elif hasattr(PaddingMask, "from_bool"):
            padding_mask = PaddingMask.from_bool(pad)
        else:
            padding_mask = PaddingMask(pad)
    except Exception:
        padding_mask = None

    batch = SequenceBatch(seqs=toks, padding_mask=padding_mask)
    out = encoder(batch)

    if hasattr(out, "sentence_embeddings"):
        emb = out.sentence_embeddings
    elif isinstance(out, dict) and "sentence_embeddings" in out:
        emb = out["sentence_embeddings"]
    elif isinstance(out, (list, tuple)):
        emb = out[0]
    elif isinstance(out, torch.Tensor):
        emb = out
    else:
        raise RuntimeError(f"Unsupported SONAR encoder output type: {type(out)}")

    if emb.dim() != 2:
        raise RuntimeError(f"Unexpected embedding shape: {tuple(emb.shape)}")

    return emb


# =========================================================
# BLASER-QE offline load + scoring
# =========================================================
def load_blaser_qe_offline(blaser_ckpt: str, device: torch.device):
    if not os.path.isfile(blaser_ckpt):
        raise FileNotFoundError(f"BLASER-QE checkpoint not found: {blaser_ckpt}")

    cfg = _arch_blaser_basic_qe()
    model = create_blaser_model(cfg, device=device).eval()

    raw = torch.load(blaser_ckpt, map_location="cpu")

    candidate = raw
    if isinstance(candidate, dict) and "model" in candidate and isinstance(candidate["model"], dict):
        candidate = candidate["model"]
    elif isinstance(candidate, dict) and "state_dict" in candidate and isinstance(candidate["state_dict"], dict):
        candidate = candidate["state_dict"]

    try:
        state = convert_blaser_checkpoint(candidate, cfg)
    except Exception as e:
        print(f"[warn] convert_blaser_checkpoint failed, fallback to direct state_dict. err={repr(e)}")
        state = candidate

    if isinstance(state, dict) and "model" in state and isinstance(state["model"], dict):
        state = state["model"]

    missing, unexpected = model.load_state_dict(state, strict=False)
    if missing or unexpected:
        print(
            f"[warn] BLASER load_state_dict(strict=False): "
            f"missing={len(missing)} unexpected={len(unexpected)}"
        )

    return model


@torch.no_grad()
def blaser_qe_scores(blaser_model, src_emb: torch.Tensor, mt_emb: torch.Tensor) -> List[float]:
    try:
        s = blaser_model(src_emb, mt_emb)
    except TypeError:
        s = blaser_model(src=src_emb, mt=mt_emb)

    if s.dim() == 2 and s.size(-1) == 1:
        s = s.squeeze(-1)

    return s.detach().cpu().tolist()


# =========================================================
# Softmax normalization
# =========================================================
def softmax_n(scores: List[float]) -> List[float]:
    t = torch.tensor(scores, dtype=torch.float32)
    probs = torch.softmax(t, dim=0)
    return probs.tolist()


# =========================================================
# 新的无 reference 选择逻辑
# =========================================================
def build_candidate_diagnostics(row: Dict, cands: List[str], raw_scores: List[float]) -> List[Dict]:
    initial_text = cands[0]
    initial_raw = float(raw_scores[0])

    row_actionable = row_is_actionable(row)
    rank = get_primary_actionability_rank(row)
    actionability_strength = get_actionability_strength(rank)
    mode_priority = get_mode_priority(row)

    diags = []

    for idx in range(4):
        name = candidate_slot_name(idx)
        text = clean_text(cands[idx])
        raw = float(raw_scores[idx])
        delta = raw - initial_raw

        evidence = ""
        if idx in [1, 2, 3]:
            evidence = clean_text(row.get(f"visual_evidence_{idx}", ""))

        valid = True
        valid_reason = "initial"
        if idx != 0:
            valid, valid_reason = is_valid_edited_candidate(
                text=text,
                initial_text=initial_text,
                evidence=evidence
            )

        evidence_priority = get_evidence_priority(evidence) if idx != 0 else 0
        slot_priority = candidate_slot_priority(idx)

        select_key = None
        if idx != 0 and valid and row_actionable:
            select_key = (
                1 if delta >= 0.0 else 0,
                actionability_strength,
                mode_priority,
                evidence_priority,
                slot_priority,
                round(delta, 8),
                round(raw, 8),
            )

        diags.append({
            "candidate_name": name,
            "text": text,
            "raw_blaser": round(raw, 6),
            "delta_vs_initial": round(delta, 6),
            "valid": valid,
            "valid_reason": valid_reason,
            "evidence": evidence,
            "evidence_priority": evidence_priority,
            "slot_priority": slot_priority,
            "row_actionable": row_actionable,
            "primary_actionability_rank_detect": rank,
            "actionability_strength": actionability_strength,
            "mode_priority": mode_priority,
            "select_key": list(select_key) if select_key is not None else None,
        })

    return diags


def select_best_index_actionability_aware(
    row: Dict,
    cands: List[str],
    raw_scores: List[float]
) -> Tuple[int, Dict[str, Any], List[Dict]]:
    """
    无 reference 规则：
    1. 如果这条样本不 actionable，则直接保留 initial
    2. 否则只在“有效编辑候选”里选
    3. 候选必须满足 raw BLASER 不低于 initial（delta >= 0）
    4. 在可选集合中按以下字典序选最大：
       (delta>=0, actionability_strength, mode_priority, evidence_priority, candidate_slot_priority, delta, raw_score)
    5. 若没有满足条件的有效编辑候选，则保留 initial
    """
    diags = build_candidate_diagnostics(row=row, cands=cands, raw_scores=raw_scores)

    initial_raw = float(raw_scores[0])
    row_actionable = row_is_actionable(row)

    if not row_actionable:
        return 0, {
            "selection_reason": "row_not_actionable_keep_initial",
            "best_raw_score": round(initial_raw, 4),
            "initial_raw_score": round(initial_raw, 4),
            "margin_over_initial": 0.0,
        }, diags

    candidate_pool = []
    for d in diags:
        if d["candidate_name"] == "initial_translation":
            continue
        if not d["valid"]:
            continue
        if d["select_key"] is None:
            continue
        if d["delta_vs_initial"] < 0:
            continue
        candidate_pool.append(d)

    if not candidate_pool:
        return 0, {
            "selection_reason": "no_valid_non_negative_delta_candidate_keep_initial",
            "best_raw_score": round(initial_raw, 4),
            "initial_raw_score": round(initial_raw, 4),
            "margin_over_initial": 0.0,
        }, diags

    best_d = max(candidate_pool, key=lambda x: tuple(x["select_key"]))
    name_to_idx = {
        "candidate_1": 1,
        "candidate_2": 2,
        "candidate_3": 3,
    }
    best_idx = name_to_idx[best_d["candidate_name"]]
    best_raw = float(raw_scores[best_idx])

    return best_idx, {
        "selection_reason": "selected_best_valid_edited_candidate_with_non_negative_delta",
        "best_raw_score": round(best_raw, 4),
        "initial_raw_score": round(initial_raw, 4),
        "margin_over_initial": round(best_raw - initial_raw, 4),
    }, diags


# =========================================================
# Main
# =========================================================
def main():
    os.environ["LD_LIBRARY_PATH"] = SYSLIBS_DIR + ":" + os.environ.get("LD_LIBRARY_PATH", "")

    device = torch.device(DEVICE if torch.cuda.is_available() else "cpu")
    print("device:", device, "visible_cuda_count:", torch.cuda.device_count())
    print(f"[info] SRC_LANG={SRC_LANG}, TGT_LANG={TGT_LANG}")
    print(f"[info] selection_rule={SELECTION_RULE}")

    records = read_jsonl_records(INPUT_JSONL)
    total = len(records)
    print(f"[info] loaded candidate rows: {total}")
    if total == 0:
        print("[warn] no rows found.")
        return

    if MAX_SAMPLES is not None and MAX_SAMPLES > 0:
        records = records[:MAX_SAMPLES]
        total = len(records)
        print(f"[info] applying MAX_SAMPLES, now processing {total} rows")

    # reference 仍只用于后续输出对照，不参与选择
    ref_records = read_jsonl_records(REFERENCE_JSONL)
    image_id_to_ref, source_text_to_ref = build_reference_map(ref_records)
    print(f"[info] loaded reference rows: {len(ref_records)}")

    print("[info] loading SONAR encoder...")
    sonar_encoder, sp = load_sonar_text_encoder_offline(
        SONAR_MODEL,
        SPM_MODEL,
        device=device,
        max_seq_len=MAX_LEN
    )

    print("[info] loading BLASER-QE...")
    blaser = load_blaser_qe_offline(BLASER_QE_CKPT, device=device)

    os.makedirs(OUTPUT_DIR, exist_ok=True)

    with open(OUTPUT_JSONL, "w", encoding="utf-8") as f_main, \
         open(OUTPUT_REF_BEST_JSONL, "w", encoding="utf-8") as f_ref_best:

        for b0 in range(0, total, BATCH_ROWS):
            b1 = min(b0 + BATCH_ROWS, total)
            batch = records[b0:b1]

            src_texts: List[str] = []
            src_langs: List[str] = []
            cand_texts: List[str] = []
            row_meta: List[Tuple[int, int]] = []

            for row_idx, row in enumerate(batch):
                source_text = clean_text(row.get("source_text", ""))
                source_text_en = clean_text(row.get("source_text_en", ""))

                if source_text:
                    src_for_score = source_text
                    src_lang = SRC_LANG
                elif FALLBACK_TO_SOURCE_TEXT_EN and source_text_en:
                    src_for_score = source_text_en
                    src_lang = TGT_LANG
                else:
                    src_for_score = ""
                    src_lang = SRC_LANG

                initial_translation = clean_text(row.get("initial_translation", row.get("initial_translation_en", "")))
                cands = [
                    initial_translation,
                    clean_text(row.get("candidate_1", "")),
                    clean_text(row.get("candidate_2", "")),
                    clean_text(row.get("candidate_3", "")),
                ]

                for cand_idx, cand in enumerate(cands):
                    src_texts.append(src_for_score)
                    src_langs.append(src_lang)
                    cand_texts.append(cand)
                    row_meta.append((row_idx, cand_idx))

            src_emb_list = [None] * len(src_texts)
            lang_to_indices: Dict[str, List[int]] = {}
            for i, lg in enumerate(src_langs):
                lang_to_indices.setdefault(lg, []).append(i)

            for lg, idxs in lang_to_indices.items():
                texts_sub = [src_texts[i] for i in idxs]
                emb_sub = sonar_encode(
                    sonar_encoder,
                    sp,
                    texts_sub,
                    lang=lg,
                    device=device,
                    max_len=MAX_LEN
                )
                for j, global_i in enumerate(idxs):
                    src_emb_list[global_i] = emb_sub[j]

            src_emb = torch.stack(src_emb_list, dim=0)

            mt_emb = sonar_encode(
                sonar_encoder,
                sp,
                cand_texts,
                lang=TGT_LANG,
                device=device,
                max_len=MAX_LEN
            )

            raw_scores = blaser_qe_scores(blaser, src_emb, mt_emb)

            row_to_raw_scores: Dict[int, List[float]] = {i: [0.0, 0.0, 0.0, 0.0] for i in range(len(batch))}
            for score, (row_idx, cand_idx) in zip(raw_scores, row_meta):
                row_to_raw_scores[row_idx][cand_idx] = float(score)

            for row_idx, row in enumerate(batch):
                row_id = clean_text(row.get("id", row.get("image_id", "")))
                image_path = clean_text(row.get("image_path", ""))
                source_text = clean_text(row.get("source_text", ""))
                initial_translation = clean_text(row.get("initial_translation", row.get("initial_translation_en", "")))

                cands = [
                    initial_translation,
                    clean_text(row.get("candidate_1", "")),
                    clean_text(row.get("candidate_2", "")),
                    clean_text(row.get("candidate_3", "")),
                ]

                raw4 = row_to_raw_scores[row_idx]
                blaser_prob4 = softmax_n(raw4)

                best_idx, decision_info, candidate_diags = select_best_index_actionability_aware(
                    row=row,
                    cands=cands,
                    raw_scores=raw4
                )

                best_translation = cands[best_idx]
                best_from = candidate_slot_name(best_idx)

                out_main = {
                    "id": row_id,
                    "image_path": image_path,
                    "source_text": source_text,
                    "initial_translation": initial_translation,
                    "target_hallucination_span": clean_text(row.get("target_hallucination_span", "")),
                    "primary_hallucination_type": clean_text(row.get("primary_hallucination_type", "")),
                    "hallucination_mode": clean_text(row.get("hallucination_mode", "")),

                    # detection / candidate 侧无参考辅助信号
                    "primary_actionability_rank_detect": row.get("primary_actionability_rank_detect", row.get("primary_actionability_rank", None)),
                    "primary_selection_mode_detect": clean_text(row.get("primary_selection_mode_detect", row.get("primary_selection_mode", ""))),
                    "primary_pool_spans_detect": row.get("primary_pool_spans_detect", row.get("primary_pool_spans", [])),
                    "rewrite_mode": clean_text(row.get("rewrite_mode", "")),
                    "effective_rewrite_mode": clean_text(row.get("effective_rewrite_mode", "")),
                    "row_actionable": row_is_actionable(row),
                    "mode_priority": get_mode_priority(row),

                    "initial_blaser_raw": format_score(raw4[0]),
                    "initial_blaser_softmax": format_score(blaser_prob4[0]),

                    "candidate_1": cands[1],
                    "candidate_1_blaser_raw": format_score(raw4[1]),
                    "blaser_softmax_1": format_score(blaser_prob4[1]),
                    "visual_evidence_1": clean_text(row.get("visual_evidence_1", "")),

                    "candidate_2": cands[2],
                    "candidate_2_blaser_raw": format_score(raw4[2]),
                    "blaser_softmax_2": format_score(blaser_prob4[2]),
                    "visual_evidence_2": clean_text(row.get("visual_evidence_2", "")),

                    "candidate_3": cands[3],
                    "candidate_3_blaser_raw": format_score(raw4[3]),
                    "blaser_softmax_3": format_score(blaser_prob4[3]),
                    "visual_evidence_3": clean_text(row.get("visual_evidence_3", "")),

                    "selection_rule": SELECTION_RULE,
                    "selection_reason": decision_info["selection_reason"],
                    "best_raw_score": decision_info["best_raw_score"],
                    "initial_raw_score": decision_info["initial_raw_score"],
                    "margin_over_initial": decision_info["margin_over_initial"],
                    "best_from": best_from,
                    "best_translation": best_translation,

                    "candidate_diagnostics": candidate_diags,

                    "local_evidence": row.get("local_evidence", {}),
                    "raw_model_output": row.get("raw_model_output", ""),
                }
                write_jsonl_record(f_main, out_main)

                reference_translation = get_reference_translation(
                    row=row,
                    image_id_to_ref=image_id_to_ref,
                    source_text_to_ref=source_text_to_ref
                )

                out_ref_best = {
                    "id": row_id,
                    "source_text": source_text,
                    "reference_translation": reference_translation,
                    "best_translation": best_translation,
                }
                write_jsonl_record(f_ref_best, out_ref_best)

            f_main.flush()
            os.fsync(f_main.fileno())
            f_ref_best.flush()
            os.fsync(f_ref_best.fileno())

            print(f"[info] processed {b1}/{total}")

    print(f"[done] main saved to: {OUTPUT_JSONL}")
    print(f"[done] ref-best saved to: {OUTPUT_REF_BEST_JSONL}")


if __name__ == "__main__":
    main()