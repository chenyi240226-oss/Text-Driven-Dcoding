import os
os.environ["CUDA_VISIBLE_DEVICES"] = "2"
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"

import re
import json
import time
from typing import Dict, List, Optional, Tuple, Any

from PIL import Image

import torch

# =========================
# Torch compatibility patch
# =========================
if not hasattr(torch, "compiler"):
    class _DummyCompiler:
        @staticmethod
        def is_compiling():
            return False
    torch.compiler = _DummyCompiler()
else:
    if not hasattr(torch.compiler, "is_compiling"):
        torch.compiler.is_compiling = lambda: False

from transformers import AutoProcessor, AutoModelForVision2Seq

torch.set_grad_enabled(False)

# =========================
# PATH
# =========================
QWEN_PATH = "/mnt/raid/hss/model/Qwen3-VL-8B-Instruct"
INPUT_JSONL = "/home/chenyi/offline_blaser_qe/out/Qwen_3_VL_8B/Multi30k/hi/hi_detect_span.jsonl"
OUTPUT_JSONL = "/home/chenyi/offline_blaser_qe/out/Qwen_3_VL_8B/Multi30k/hi/hi_3_candidates_from_span_v8.jsonl"

# =========================
# SAMPLE SIZE
# =========================
MAX_ROWS = 100

DTYPE = torch.bfloat16 if torch.cuda.is_available() else torch.float32

# =========================
# LOAD MODEL
# =========================
print("Loading model...")
processor = AutoProcessor.from_pretrained(
    QWEN_PATH,
    trust_remote_code=True,
)
model = AutoModelForVision2Seq.from_pretrained(
    QWEN_PATH,
    torch_dtype=DTYPE,
    device_map="auto",
    trust_remote_code=True
).eval()
tokenizer = processor.tokenizer
print("Model loaded.")

# =========================
# UTIL
# =========================
def format_time(sec: float) -> str:
    sec = int(sec)
    return f"{sec//3600:02d}:{(sec%3600)//60:02d}:{sec%60:02d}"

def cleanup_cuda():
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        torch.cuda.ipc_collect()

def load_image(path: str) -> Optional[Image.Image]:
    if not path or not os.path.isfile(path):
        return None
    try:
        return Image.open(path).convert("RGB")
    except Exception:
        return None

def clean_text(s: str) -> str:
    if s is None:
        return ""
    s = str(s).strip()
    s = re.sub(r"\s+", " ", s)
    return s

def simple_post_clean(text: str) -> str:
    text = clean_text(text)
    return text.strip(' "\'')

def normalize_token(text: str) -> str:
    text = text.lower().strip()
    text = re.sub(r"[^a-z0-9\- ]", "", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()

def tokenize_words(text: str) -> List[str]:
    return re.findall(r"[A-Za-z0-9\-]+", clean_text(text).lower())

def deduplicate_keep_order(items: List[str]) -> List[str]:
    out = []
    seen = set()
    for x in items:
        x = simple_post_clean(x)
        if not x:
            continue
        k = x.lower()
        if k in seen:
            continue
        seen.add(k)
        out.append(x)
    return out

def lowercase_first(text: str) -> str:
    text = simple_post_clean(text)
    if not text:
        return text
    return text[0].lower() + text[1:]

def normalize_sentence(text: str) -> str:
    text = clean_text(text)
    if not text:
        return ""
    text = re.sub(r"\s+", " ", text).strip()
    text = re.sub(r"\s+([,.;:!?])", r"\1", text)
    text = text.rstrip(".,;:!?")
    text = lowercase_first(text)
    return text

def contains_whole_phrase(text: str, phrase: str) -> bool:
    text_n = normalize_token(text)
    phrase_n = normalize_token(phrase)
    if not text_n or not phrase_n:
        return False
    return re.search(rf"\b{re.escape(phrase_n)}\b", text_n) is not None

def content_overlap_ratio(a: str, b: str) -> float:
    wa = set(tokenize_words(a))
    wb = set(tokenize_words(b))
    if not wa or not wb:
        return 0.0
    inter = len(wa & wb)
    return inter / max(1, len(wa | wb))

def lightly_make_distinct(items: List[str]) -> List[str]:
    out = deduplicate_keep_order(items)
    if not out:
        return out
    while len(out) < 3:
        out.append(out[-1])
    return out[:3]

def topk_list(items: Any, k: int) -> List[Any]:
    if not isinstance(items, list):
        return []
    return items[:k]

def clip_list(items: List[Any], n: int) -> List[Any]:
    return items[:n] if isinstance(items, list) else []

# =========================
# BASIC FILTERS
# =========================
BAD_FRAGMENT_PATTERNS = [
    r"^there are in\b",
    r"^a between\b",
    r"^a wearing\b",
    r"^the someone\b",
    r"^there white\b",
    r"^a woman wearing a\.?$",
    r"^a man is\.?$",
    r"^(is|are|was|were|be|been|being)\b",
    r"^(on|in|at|by|with|from|to|between)\b",
    r"^(a|an|the)\s+(on|in|at|by|with|from|to|between)\b",
]

CONTENT_STOPWORDS = {
    "a", "an", "the", "is", "are", "was", "were", "be", "been", "being",
    "to", "of", "in", "on", "at", "by", "with", "from", "for", "into",
    "onto", "over", "under", "there", "here", "this", "that", "these",
    "those", "and", "or", "but", "as", "it", "its", "their", "his", "her",
    "has", "have", "had", "very", "just", "also", "still"
}

COPULA_WORDS = {"is", "are", "was", "were", "be", "been", "being"}

PREPOSITIONS = {
    "in", "on", "at", "by", "with", "from", "into", "onto",
    "over", "under", "near", "along", "between", "outside", "inside",
    "behind", "beside", "across", "through", "around", "above", "below",
    "of"
}

ARTICLE_WORDS = {"a", "an", "the"}

def sanitize_candidate_surface(text: str) -> str:
    text = clean_text(text)
    if not text:
        return ""

    toks = text.split()
    if toks:
        out = [toks[0]]
        for tok in toks[1:]:
            if normalize_token(tok) == normalize_token(out[-1]):
                continue
            out.append(tok)
        text = " ".join(out)

    text = re.sub(r"\s+", " ", text).strip()
    text = re.sub(r"\s+([,.;:!?])", r"\1", text)
    text = text.rstrip(".,;:!?")
    text = lowercase_first(text)
    return text

def extract_content_words(text: str) -> set:
    out = set()
    for w in tokenize_words(text):
        nw = normalize_token(w)
        if not nw or nw in CONTENT_STOPWORDS or len(nw) <= 1:
            continue
        out.add(nw)
    return out

def is_fragment_candidate(text: str) -> bool:
    text = clean_text(text)
    if not text:
        return True

    low = text.lower().strip()
    words = tokenize_words(text)

    if not words:
        return True

    if any(re.match(p, low) for p in BAD_FRAGMENT_PATTERNS):
        return True

    if low.endswith((" a", " an", " the", " of", " in", " on", " to", " with", " by", " from", " between")):
        return True

    if len(words) == 1:
        return True

    if len(words) == 2 and words[0] in {"a", "an", "the"}:
        return True

    if len(words) <= 3 and len(extract_content_words(text)) <= 1:
        return True

    return False

def has_bad_repetition(text: str) -> bool:
    t = normalize_token(text)
    bad_patterns = [
        "a a ", "the the ", "an an ", "of of ", "to to ",
        "is is ", "are are ", "in the in the", "on the on the"
    ]
    return any(p in t for p in bad_patterns)

def has_unsupported_new_content(
    candidate: str,
    initial_translation: str,
    local_evidence: Optional[Dict] = None
) -> bool:
    candidate = clean_text(candidate)
    initial_translation = clean_text(initial_translation)

    if not candidate:
        return False

    cand_words = extract_content_words(candidate)
    init_words = extract_content_words(initial_translation)

    evidence_words = set()
    if isinstance(local_evidence, dict):
        evidence_words |= extract_content_words(clean_text(local_evidence.get("visual_evidence", "")))
        evidence_words |= extract_content_words(clean_text(local_evidence.get("corrected_part", "")))
        evidence_words |= extract_content_words(clean_text(local_evidence.get("target_span", "")))
        evidence_words |= extract_content_words(clean_text(local_evidence.get("template_span", "")))

    new_words = cand_words - init_words - evidence_words
    dropped_words = init_words - cand_words

    if len(new_words) >= 2:
        return True

    if len(new_words) >= 1 and len(dropped_words) >= 1 and content_overlap_ratio(candidate, initial_translation) < 0.60:
        return True

    return False

# =========================
# COMPLETE-SENTENCE DETECTION
# =========================
def looks_like_complete_sentence_candidate(text: str) -> bool:
    text = clean_text(text)
    if not text:
        return False

    words = tokenize_words(text)
    if len(words) < 3:
        return False

    low = text.lower()

    if re.match(r"^(there|this|that|these|those|it|people|someone|somebody)\b", low):
        return True

    if re.match(r"^(a|an|the)\s+\w+", low) and len(words) >= 4:
        return True

    return False

# =========================
# LLM VALIDATOR
# =========================
def run_text_json(prompt: str, max_new_tokens: int = 180) -> str:
    messages = [{"role": "user", "content": [{"type": "text", "text": prompt}]}]
    text = processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)

    inputs = processor(
        text=[text],
        padding=True,
        return_tensors="pt"
    )
    prepared_inputs = {}
    for k, v in inputs.items():
        prepared_inputs[k] = v.to(model.device) if hasattr(v, "to") else v

    eos_token_id = getattr(processor.tokenizer, "eos_token_id", None)
    pad_token_id = getattr(processor.tokenizer, "pad_token_id", None)
    if pad_token_id is None:
        pad_token_id = eos_token_id

    with torch.no_grad():
        out = model.generate(
            **prepared_inputs,
            do_sample=False,
            max_new_tokens=max_new_tokens,
            use_cache=True,
            repetition_penalty=1.02,
            pad_token_id=pad_token_id,
            eos_token_id=eos_token_id,
        )

    prompt_len = prepared_inputs["input_ids"].shape[1]
    gen = out[:, prompt_len:]
    return processor.batch_decode(
        gen,
        skip_special_tokens=True,
        clean_up_tokenization_spaces=True
    )[0]

def extract_first_json(raw: str) -> Dict:
    raw = clean_text(raw)
    candidates = re.findall(r"\{.*\}", raw, flags=re.DOTALL)
    for c in candidates:
        try:
            return json.loads(c)
        except Exception:
            continue
    return {}

def llm_validate_fluency(candidate: str) -> Tuple[bool, str]:
    candidate = clean_text(candidate)
    if not candidate:
        return False, "empty"

    if is_fragment_candidate(candidate):
        return False, "rule_fragment"
    if has_bad_repetition(candidate):
        return False, "rule_repetition"

    prompt = f"""
You are an English sentence validator.

Task:
Judge whether the sentence is a complete, fluent, grammatical English sentence.

Rules:
- Reject fragments, broken phrases, duplicated starts, missing subject, missing predicate, or clearly malformed output.
- Accept short noun phrases only if they are natural image-caption style expressions.
- The input sentence may not end with punctuation. This is allowed.
- The first letter may be lowercase. This is allowed.
- Return JSON only.

Return JSON ONLY:
{{
  "valid": true,
  "reason": "..."
}}

Sentence:
{candidate}
""".strip()

    try:
        raw = run_text_json(prompt, max_new_tokens=80)
        obj = extract_first_json(raw)
        if isinstance(obj, dict) and "valid" in obj:
            return bool(obj.get("valid", False)), clean_text(obj.get("reason", ""))
    except Exception:
        pass

    return False, "validator_parse_failed"

# =========================
# GENERIC SUBJECT / RELATION HEURISTICS
# 不使用数据倾向词表
# =========================
def is_generic_content_token(tok: str) -> bool:
    nt = normalize_token(tok)
    if not nt:
        return False
    if nt in CONTENT_STOPWORDS or nt in PREPOSITIONS:
        return False
    if len(nt) <= 1:
        return False
    return True

def extract_leading_subject_phrase(text: str) -> str:
    text = clean_text(text)
    if not text:
        return ""

    raw_words = re.findall(r"[A-Za-z0-9\-']+", text)
    if not raw_words:
        return ""

    phrase = []
    idx = 0
    n = len(raw_words)

    if idx < n and normalize_token(raw_words[idx]) in ARTICLE_WORDS:
        phrase.append(raw_words[idx])
        idx += 1

    content_count = 0
    while idx < n:
        w = raw_words[idx]
        nw = normalize_token(w)

        if not nw:
            break

        if nw in PREPOSITIONS or nw in COPULA_WORDS:
            break

        if nw.endswith("ing") or nw.endswith("ed"):
            break

        if not is_generic_content_token(nw):
            if phrase:
                break
            idx += 1
            continue

        phrase.append(w)
        content_count += 1
        idx += 1

        if content_count >= 2:
            break

    phrase_text = clean_text(" ".join(phrase))
    if extract_content_words(phrase_text):
        return normalize_sentence(phrase_text)

    return ""

def infer_subject_from_visual_evidence(
    initial_translation: str,
    local_evidence: Optional[Dict]
) -> str:
    candidates = []

    if isinstance(local_evidence, dict):
        ve = clean_text(local_evidence.get("visual_evidence", ""))
        if ve:
            candidates.append(extract_leading_subject_phrase(ve))

    candidates.append(extract_leading_subject_phrase(initial_translation))

    for cand in candidates:
        cand = clean_text(cand)
        if cand and extract_content_words(cand):
            return cand

    return "it"

def relation_head_word(span_text: str) -> str:
    words = tokenize_words(span_text)

    for w in words:
        nw = normalize_token(w)
        if nw in PREPOSITIONS:
            return w

    for w in words:
        nw = normalize_token(w)
        if nw in COPULA_WORDS:
            return w

    for w in words:
        nw = normalize_token(w)
        if nw.endswith("ing") or nw.endswith("ed"):
            return w

    return words[0] if words else ""

# =========================
# REPAIR
# =========================
def replace_span_once(text: str, target_span: str, replacement: str) -> str:
    text = clean_text(text)
    target_span = clean_text(target_span)
    replacement = clean_text(replacement)

    if not text or not target_span:
        return text

    pattern = re.compile(re.escape(target_span), flags=re.IGNORECASE)
    new_text, n = pattern.subn(replacement, text, count=1)
    if n == 0:
        return text

    new_text = re.sub(r"\s+", " ", new_text).strip()
    new_text = re.sub(r"\s+([,.;:!?])", r"\1", new_text)
    new_text = new_text.rstrip(".,;:!?")
    return normalize_sentence(new_text)

def repair_by_direct_replacement_or_keep(
    initial_translation: str,
    target_span: str,
    corrected_part: str,
    local_evidence: Optional[Dict] = None
) -> str:
    initial_translation = normalize_sentence(initial_translation)
    target_span = clean_text(target_span)
    corrected_part = clean_text(corrected_part)

    if not initial_translation:
        return ""

    if not target_span:
        return initial_translation

    if not corrected_part:
        return initial_translation

    if looks_like_complete_sentence_candidate(corrected_part):
        return sanitize_candidate_surface(corrected_part)

    replaced = replace_span_once(initial_translation, target_span, corrected_part)
    replaced = sanitize_candidate_surface(replaced)

    if replaced and not is_fragment_candidate(replaced):
        return replaced

    subject = infer_subject_from_visual_evidence(initial_translation, local_evidence)
    low = clean_text(replaced).lower()

    if re.match(r"^(is|are|was|were|on|in|at|with|from|to|between)\b", low):
        return sanitize_candidate_surface(f"{subject} {replaced}")

    if re.match(r"^(a|an|the)\s+\w+(ing|ed)\b", low):
        return sanitize_candidate_surface(f"{subject} {replaced.split(None, 1)[1]}") if len(replaced.split()) > 1 else initial_translation

    return initial_translation

# =========================
# DEFERRED TEMPLATES
# =========================
def get_rewrite_mode(row: Dict) -> str:
    suspicious_analysis = row.get("suspicious_analysis", {})
    primary_span = clean_text(suspicious_analysis.get("primary_suspicious_span", ""))
    suspicious_spans = row.get("suspicious_spans", []) or suspicious_analysis.get("suspicious_spans", [])
    strong = row.get("deferred_relation_spans_strong", [])
    weak = row.get("deferred_relation_spans_weak", [])

    if primary_span or suspicious_spans:
        return "hard_and_relation" if (strong or weak) else "hard_only"

    if strong or weak:
        return "relation_only"

    return "no_suspicion"

def build_template_entry(span_item: Dict, kind: str) -> Dict:
    span_text = clean_text(span_item.get("span", ""))
    head = relation_head_word(span_text)

    if kind == "compact":
        instruction = (
            "make this relation expression more compact and minimal while preserving the source meaning; "
            "prefer a shorter, tighter phrasing"
        )
    elif kind == "preserve":
        instruction = (
            "keep this relation expression but rewrite it into a cleaner and more natural English form; "
            "stay close to the current meaning"
        )
    else:
        instruction = (
            "soften this relation expression; reduce over-commitment or overly specific relation wording "
            "while preserving supported content"
        )

    return {
        "template_type": kind,
        "target_span": span_text,
        "head_word": head,
        "instruction": instruction,
        "span_source_support_mean": span_item.get("span_source_support_mean", None),
        "span_visual_support_mean": span_item.get("span_visual_support_mean", None),
        "span_joint_support_mean": span_item.get("span_joint_support_mean", None),
        "mean_gain": span_item.get("mean_gain", None),
    }

def build_deferred_templates(row: Dict) -> List[Dict]:
    strong = clip_list(row.get("deferred_relation_spans_strong", []), 2)
    weak = clip_list(row.get("deferred_relation_spans_weak", []), 2)

    templates = []

    for sp in strong:
        templates.append(build_template_entry(sp, "compact"))
        templates.append(build_template_entry(sp, "preserve"))
        templates.append(build_template_entry(sp, "soften"))

    for sp in weak:
        templates.append(build_template_entry(sp, "preserve"))
        templates.append(build_template_entry(sp, "soften"))

    out = []
    seen = set()
    for t in templates:
        key = (clean_text(t["target_span"]).lower(), t["template_type"])
        if key in seen:
            continue
        seen.add(key)
        out.append(t)

    return out[:6]

def summarize_templates_for_prompt(templates: List[Dict], k: int = 6) -> str:
    if not templates:
        return "- none"

    lines = []
    for idx, t in enumerate(templates[:k], 1):
        span = clean_text(t.get("target_span", ""))
        template_type = clean_text(t.get("template_type", ""))
        instruction = clean_text(t.get("instruction", ""))
        lines.append(f"{idx}. type={template_type} | span={span} | instruction={instruction}")
    return "\n".join(lines)

# =========================
# SUSPICION SUMMARY
# =========================
def summarize_suspicious_spans(spans: Any, k: int = 3) -> str:
    if not isinstance(spans, list) or not spans:
        return ""

    parts = []
    for s in spans[:k]:
        if isinstance(s, dict):
            sp = clean_text(s.get("span", ""))
            mg = s.get("mean_gain", None)
            if sp:
                if isinstance(mg, (int, float)):
                    parts.append(f"- {sp} (mean_gain={mg:.4f})")
                else:
                    parts.append(f"- {sp}")
    return "\n".join(parts)

def summarize_suspicious_tokens(tokens: Any, k: int = 6) -> str:
    if not isinstance(tokens, list) or not tokens:
        return ""

    parts = []
    for t in tokens[:k]:
        if isinstance(t, dict):
            w = clean_text(t.get("word", ""))
            if w:
                parts.append(f"- {w}")
    return "\n".join(parts)

# =========================
# PROMPTS
# =========================
def build_candidate_prompt(
    source_text: str,
    initial_translation: str,
    suspicious_analysis: Dict,
    deferred_templates: List[Dict],
    rewrite_mode: str
) -> str:
    primary_span = clean_text(suspicious_analysis.get("primary_suspicious_span", ""))
    suspicious_spans = summarize_suspicious_spans(suspicious_analysis.get("suspicious_spans", []), k=3)
    suspicious_tokens = summarize_suspicious_tokens(suspicious_analysis.get("suspicious_tokens", []), k=6)
    template_block = summarize_templates_for_prompt(deferred_templates, k=6)

    return f"""
You are a multimodal translation correction system.

Task:
Revise the current English translation conservatively.
Some regions are marked as suspicious spans, and some relation spans are provided with rewrite templates.

Rules:
- Prefer minimal edits.
- Keep the translation close to the current translation unless a marked region clearly needs revision.
- Use the image only to resolve ambiguity.
- Do not add unrelated scene details.
- If relation templates are given, use them to produce three different candidate styles:
  candidate 1 = compact preference
  candidate 2 = preserve preference
  candidate 3 = soften preference
- If there are also suspicious spans, correct them conservatively while applying the relation template preference.
- You may output a complete corrected sentence.
- Do not add sentence-final punctuation.
- The first character of each candidate must be lowercase if it is an English letter.
- Output clean plain text.
- Return JSON ONLY.

Return JSON ONLY:
{{
  "candidate_1": "...",
  "candidate_2": "...",
  "candidate_3": "...",
  "local_evidence": {{
    "target_span": "...",
    "corrected_part": "...",
    "visual_evidence": "...",
    "template_span": "...",
    "template_type": "compact/preserve/soften"
  }}
}}

Source sentence:
{source_text}

Current translation:
{initial_translation}

Rewrite mode:
{rewrite_mode}

Primary suspicious span:
{primary_span if primary_span else "- none"}

Top suspicious spans:
{suspicious_spans if suspicious_spans else "- none"}

Top suspicious tokens:
{suspicious_tokens if suspicious_tokens else "- none"}

Deferred relation templates:
{template_block}
""".strip()

# =========================
# MODEL CALL
# =========================
def run_multimodal_json(prompt: str, image: Optional[Image.Image], max_new_tokens: int = 260) -> str:
    content = []
    if image is not None:
        content.append({"type": "image", "image": image})
    content.append({"type": "text", "text": prompt})

    messages = [{"role": "user", "content": content}]
    text = processor.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True
    )

    if image is not None:
        inputs = processor(
            text=[text],
            images=[image],
            padding=True,
            return_tensors="pt"
        )
    else:
        inputs = processor(
            text=[text],
            padding=True,
            return_tensors="pt"
        )

    prepared_inputs = {}
    for k, v in inputs.items():
        prepared_inputs[k] = v.to(model.device) if hasattr(v, "to") else v

    eos_token_id = getattr(processor.tokenizer, "eos_token_id", None)
    pad_token_id = getattr(processor.tokenizer, "pad_token_id", None)
    if pad_token_id is None:
        pad_token_id = eos_token_id

    with torch.no_grad():
        out = model.generate(
            **prepared_inputs,
            do_sample=False,
            max_new_tokens=max_new_tokens,
            use_cache=True,
            repetition_penalty=1.02,
            pad_token_id=pad_token_id,
            eos_token_id=eos_token_id,
        )

    prompt_len = prepared_inputs["input_ids"].shape[1]
    gen = out[:, prompt_len:]
    raw = processor.batch_decode(
        gen,
        skip_special_tokens=True,
        clean_up_tokenization_spaces=True
    )[0]
    return raw

def extract_json_block(raw: str) -> Dict:
    raw = str(raw).strip()
    candidates = re.findall(r"\{.*\}", raw, flags=re.DOTALL)
    for c in candidates:
        try:
            obj = json.loads(c)
            if all(k in obj for k in ["candidate_1", "candidate_2", "candidate_3"]):
                return obj
        except Exception:
            pass
    return {}

# =========================
# TEMPLATE FALLBACK
# =========================
def apply_relation_template_fallback(
    initial_translation: str,
    deferred_templates: List[Dict]
) -> List[str]:
    base = normalize_sentence(initial_translation)
    if not deferred_templates:
        return [base, base, base]

    compact = base
    preserve = base
    soften = base

    for t in deferred_templates:
        span = clean_text(t.get("target_span", ""))
        ttype = clean_text(t.get("template_type", ""))

        if not span or not contains_whole_phrase(base, span):
            continue

        if ttype == "compact":
            compact = replace_span_once(compact, span, span)
            compact = sanitize_candidate_surface(compact)

        elif ttype == "preserve":
            preserve = replace_span_once(preserve, span, span)
            preserve = sanitize_candidate_surface(preserve)

        elif ttype == "soften":
            words = tokenize_words(span)
            if len(words) >= 2:
                weakened = " ".join(words[1:])
                if weakened and not is_fragment_candidate(weakened):
                    soften = replace_span_once(soften, span, weakened)
                    soften = sanitize_candidate_surface(soften)

    cands = [compact, preserve, soften]
    cands = [normalize_sentence(x) if x else normalize_sentence(initial_translation) for x in cands]
    return lightly_make_distinct(cands)

# =========================
# CANDIDATE BUILD / VALIDATE
# =========================
def build_raw_candidates_from_model_output(
    initial_translation: str,
    parsed: Dict,
    deferred_templates: List[Dict]
) -> List[str]:
    parts = [
        simple_post_clean(parsed.get("candidate_1", "")),
        simple_post_clean(parsed.get("candidate_2", "")),
        simple_post_clean(parsed.get("candidate_3", "")),
    ]

    out = []
    for p in parts:
        if not p:
            continue
        out.append(sanitize_candidate_surface(p))

    if not out:
        out = apply_relation_template_fallback(initial_translation, deferred_templates)

    return deduplicate_keep_order(out)

def validate_and_finalize_candidates(
    candidates: List[str],
    initial_translation: str,
    target_span: str,
    corrected_part: str,
    local_evidence: Optional[Dict] = None,
    deferred_templates: Optional[List[Dict]] = None
) -> List[str]:
    out = []

    for cand in candidates:
        cand = sanitize_candidate_surface(cand)
        if not cand:
            cand = normalize_sentence(initial_translation)

        rule_ok = (
            not has_bad_repetition(cand)
            and not is_fragment_candidate(cand)
            and not has_unsupported_new_content(cand, initial_translation, local_evidence)
        )

        if not rule_ok:
            if deferred_templates:
                cand = apply_relation_template_fallback(initial_translation, deferred_templates)[0]
            else:
                cand = repair_by_direct_replacement_or_keep(
                    initial_translation=initial_translation,
                    target_span=target_span,
                    corrected_part=corrected_part,
                    local_evidence=local_evidence
                )
            cand = sanitize_candidate_surface(cand)

        valid, _ = llm_validate_fluency(cand)
        if not valid:
            if deferred_templates:
                fallback_list = apply_relation_template_fallback(initial_translation, deferred_templates)
                cand = sanitize_candidate_surface(fallback_list[0])
            else:
                cand = repair_by_direct_replacement_or_keep(
                    initial_translation=initial_translation,
                    target_span=target_span,
                    corrected_part=corrected_part,
                    local_evidence=local_evidence
                )
                cand = sanitize_candidate_surface(cand)

            valid2, _ = llm_validate_fluency(cand)
            if not valid2:
                cand = normalize_sentence(initial_translation)

        out.append(cand)

    out = deduplicate_keep_order(out)
    if not out:
        out = [normalize_sentence(initial_translation)]

    while len(out) < 3:
        out.append(out[-1])

    out = lightly_make_distinct(out)
    return out[:3]

def parse_or_fallback(
    raw: str,
    initial_translation: str,
    suspicious_analysis: Dict,
    deferred_templates: List[Dict]
) -> Dict:
    obj = extract_json_block(raw)
    if not obj:
        fallback = apply_relation_template_fallback(initial_translation, deferred_templates)
        return {
            "candidate_1": fallback[0],
            "candidate_2": fallback[1],
            "candidate_3": fallback[2],
            "local_evidence": {
                "target_span": clean_text(suspicious_analysis.get("primary_suspicious_span", "")),
                "corrected_part": "",
                "visual_evidence": "",
                "template_span": clean_text(deferred_templates[0]["target_span"]) if deferred_templates else "",
                "template_type": clean_text(deferred_templates[0]["template_type"]) if deferred_templates else "",
            }
        }

    local_evidence = obj.get("local_evidence", {})
    if not isinstance(local_evidence, dict):
        local_evidence = {}

    target_span = clean_text(local_evidence.get("target_span", "")) or clean_text(suspicious_analysis.get("primary_suspicious_span", ""))
    corrected_part = clean_text(local_evidence.get("corrected_part", ""))

    raw_candidates = build_raw_candidates_from_model_output(
        initial_translation=initial_translation,
        parsed=obj,
        deferred_templates=deferred_templates
    )

    if not raw_candidates:
        raw_candidates = apply_relation_template_fallback(initial_translation, deferred_templates)

    final_candidates = validate_and_finalize_candidates(
        candidates=raw_candidates,
        initial_translation=initial_translation,
        target_span=target_span,
        corrected_part=corrected_part,
        local_evidence=local_evidence,
        deferred_templates=deferred_templates
    )

    return {
        "candidate_1": final_candidates[0],
        "candidate_2": final_candidates[1],
        "candidate_3": final_candidates[2],
        "local_evidence": {
            "target_span": target_span,
            "corrected_part": corrected_part,
            "visual_evidence": clean_text(local_evidence.get("visual_evidence", "")),
            "template_span": clean_text(local_evidence.get("template_span", "")),
            "template_type": clean_text(local_evidence.get("template_type", "")),
        }
    }

# =========================
# JSONL
# =========================
def init_jsonl():
    os.makedirs(os.path.dirname(OUTPUT_JSONL), exist_ok=True)
    with open(OUTPUT_JSONL, "w", encoding="utf-8"):
        pass

def append_jsonl(record: Dict):
    with open(OUTPUT_JSONL, "a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")

# =========================
# MAIN
# =========================
def main():
    rows = []
    with open(INPUT_JSONL, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            rows.append(json.loads(line))

    total_all = len(rows)
    if MAX_ROWS is not None:
        rows = rows[:MAX_ROWS]

    init_jsonl()

    times = []
    total = len(rows)

    print(f"[INFO] Total loaded rows: {total_all}")
    print(f"[INFO] MAX_ROWS = {MAX_ROWS}")
    print(f"[INFO] Actual run rows: {total}")

    for i, row in enumerate(rows, 1):
        t0 = time.time()

        sid = clean_text(row.get("id", ""))
        image_path = clean_text(row.get("image_path", ""))
        source_text = clean_text(row.get("source_text", ""))
        initial_translation = clean_text(row.get("initial_translation", ""))

        suspicious_analysis = {
            "primary_suspicious_span": clean_text(row.get("primary_suspicious_span", "")),
            "suspicious_spans": row.get("suspicious_spans", []),
            "suspicious_tokens": row.get("suspicious_tokens", []),
            "word_metrics": row.get("word_metrics", []),
        }

        deferred_templates = build_deferred_templates(row)
        rewrite_mode = get_rewrite_mode({
            "suspicious_analysis": suspicious_analysis,
            "suspicious_spans": row.get("suspicious_spans", []),
            "deferred_relation_spans_strong": row.get("deferred_relation_spans_strong", []),
            "deferred_relation_spans_weak": row.get("deferred_relation_spans_weak", []),
        })

        try:
            if rewrite_mode == "no_suspicion":
                base = normalize_sentence(initial_translation)
                parsed = {
                    "candidate_1": base,
                    "candidate_2": base,
                    "candidate_3": base,
                    "local_evidence": {
                        "target_span": "",
                        "corrected_part": "",
                        "visual_evidence": "",
                        "template_span": "",
                        "template_type": ""
                    }
                }
                raw = ""
            else:
                image = load_image(image_path)
                prompt = build_candidate_prompt(
                    source_text=source_text,
                    initial_translation=initial_translation,
                    suspicious_analysis=suspicious_analysis,
                    deferred_templates=deferred_templates,
                    rewrite_mode=rewrite_mode
                )
                raw = run_multimodal_json(prompt, image, max_new_tokens=260)
                parsed = parse_or_fallback(
                    raw=raw,
                    initial_translation=initial_translation,
                    suspicious_analysis=suspicious_analysis,
                    deferred_templates=deferred_templates
                )

                if image is not None:
                    image.close()
                del image
                cleanup_cuda()

            append_jsonl({
                "id": sid,
                "image_path": image_path,
                "source_text": source_text,
                "initial_translation": initial_translation,
                "primary_suspicious_span": clean_text(suspicious_analysis.get("primary_suspicious_span", "")),
                "suspicious_spans": suspicious_analysis.get("suspicious_spans", []),
                "suspicious_tokens": suspicious_analysis.get("suspicious_tokens", []),
                "deferred_relation_spans_strong": row.get("deferred_relation_spans_strong", []),
                "deferred_relation_spans_weak": row.get("deferred_relation_spans_weak", []),
                "deferred_relation_templates": deferred_templates,
                "rewrite_mode": rewrite_mode,
                "candidate_1": parsed["candidate_1"],
                "candidate_2": parsed["candidate_2"],
                "candidate_3": parsed["candidate_3"],
                "local_evidence": parsed["local_evidence"],
                "raw_model_output": raw
            })

        except Exception as e:
            print(f"ERROR: {sid} | {e}")
            fallback_list = apply_relation_template_fallback(initial_translation, deferred_templates)
            append_jsonl({
                "id": sid,
                "image_path": image_path,
                "source_text": source_text,
                "initial_translation": initial_translation,
                "primary_suspicious_span": clean_text(suspicious_analysis.get("primary_suspicious_span", "")),
                "suspicious_spans": suspicious_analysis.get("suspicious_spans", []),
                "suspicious_tokens": suspicious_analysis.get("suspicious_tokens", []),
                "deferred_relation_spans_strong": row.get("deferred_relation_spans_strong", []),
                "deferred_relation_spans_weak": row.get("deferred_relation_spans_weak", []),
                "deferred_relation_templates": deferred_templates,
                "rewrite_mode": rewrite_mode,
                "candidate_1": fallback_list[0],
                "candidate_2": fallback_list[1],
                "candidate_3": fallback_list[2],
                "local_evidence": {
                    "target_span": clean_text(suspicious_analysis.get("primary_suspicious_span", "")),
                    "corrected_part": "",
                    "visual_evidence": "",
                    "template_span": clean_text(deferred_templates[0]["target_span"]) if deferred_templates else "",
                    "template_type": clean_text(deferred_templates[0]["template_type"]) if deferred_templates else "",
                },
                "raw_model_output": f"ERROR: {repr(e)}"
            })
            cleanup_cuda()

        dt = time.time() - t0
        times.append(dt)
        avg = sum(times) / len(times)
        eta = (total - i) * avg
        print(f"[{i}/{total}] {sid} | mode={rewrite_mode} | {dt:.2f}s | ETA {format_time(eta)}")

    print("DONE")
    print("OUTPUT_JSONL =", OUTPUT_JSONL)

if __name__ == "__main__":
    main()