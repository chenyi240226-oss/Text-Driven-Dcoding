#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import argparse

# =========================================================
# Arguments: parse before importing torch
# =========================================================
ALLOWED_LANGUAGES = {"hi", "lv", "tr"}

SONAR_SRC_LANG_MAP = {
    "hi": "hin_Deva",
    "lv": "lav_Latn",
    "tr": "tur_Latn",
}


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--lang",
        type=str,
        required=True,
        choices=sorted(ALLOWED_LANGUAGES),
        help="Language code: hi, lv, tr.",
    )
    parser.add_argument(
        "--gpu",
        type=str,
        required=True,
        help="Physical GPU id, for example: 0, 1, 5, 6, 7.",
    )
    return parser.parse_args()


ARGS = parse_args()
LANGUAGE = ARGS.lang
GPU = ARGS.gpu

# =========================================================
# Environment variables
# =========================================================
os.environ["CUDA_VISIBLE_DEVICES"] = str(GPU)
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"

os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"
os.environ["TOKENIZERS_PARALLELISM"] = "false"

os.environ["HF_HOME"] = "/home/chenyi/model_cache/huggingface"
os.environ["TRANSFORMERS_CACHE"] = "/home/chenyi/model_cache/huggingface/hub"

SYSLIBS_DIR = "/home/chenyi/offline_blaser_qe/syslibs"
os.environ["LD_LIBRARY_PATH"] = SYSLIBS_DIR + ":" + os.environ.get("LD_LIBRARY_PATH", "")

import json
import re
import time
from collections import defaultdict
from difflib import SequenceMatcher
from typing import Any, Dict, List, Optional, Tuple

import torch
import sentencepiece as spm

from sonar.models.sonar_text.model import SequenceBatch
from sonar.models.sonar_text import SonarTextEncoderConfig, create_sonar_text_encoder_model
from sonar.models.blaser.builder import create_blaser_model, _arch_blaser_basic_qe
from sonar.models.blaser.loader import convert_blaser_checkpoint

from comet import load_from_checkpoint

torch.set_grad_enabled(False)

try:
    torch.set_float32_matmul_precision("high")
except Exception:
    pass


# =========================================================
# Paths
# =========================================================
OUTPUT_ROOT = "/home/chenyi/offline_blaser_qe/out/Qwen_3_VL_8B/Multi30k"

INPUT_JSONL = os.path.join(
    OUTPUT_ROOT,
    LANGUAGE,
    f"{LANGUAGE}_3_candidates_from_span.jsonl",
)

OUTPUT_DIR = os.path.join(
    OUTPUT_ROOT,
    LANGUAGE,
)

OUTPUT_SOURCE_BEST_JSONL = os.path.join(
    OUTPUT_DIR,
    f"{LANGUAGE}_source_reference_best.jsonl",
)

CHECKPOINTS_DIR = "/home/chenyi/offline_blaser_qe/checkpoints"

SONAR_MODEL = os.path.join(CHECKPOINTS_DIR, "sonar_text_encoder.pt")
SPM_MODEL = os.path.join(CHECKPOINTS_DIR, "sentencepiece.source.256000.model")
BLASER_QE_CKPT = os.path.join(CHECKPOINTS_DIR, "blaser_2_0_qe_model.pt")

COMET_QE_CKPT = "/home/chenyi/offline_blaser_qe/comet_qe_models/wmt21-comet-qe-da/checkpoints/model_local_xlmr.ckpt"

DEVICE = "cuda"
MAX_LEN = 256

BATCH_ROWS = 64
COMET_BATCH_SIZE = 16

SRC_LANG = SONAR_SRC_LANG_MAP[LANGUAGE]
TGT_LANG = "eng_Latn"

SELECTION_FORMULA_VERSION = (
    "select_v11_qwen3_multi30k_cli_lang_gpu"
)


# =========================================================
# Lexical utilities
# =========================================================
FUNCTION_WORDS = {
    "a", "an", "the",
    "of", "in", "on", "at", "by", "with", "from", "to", "for",
    "into", "onto", "over", "under", "between", "around", "through",
    "during", "while", "near", "inside", "outside", "along", "across",
    "behind", "beside", "toward", "towards", "against", "about",
    "before", "after", "front", "back", "next", "side",
    "is", "are", "was", "were", "am", "be", "been", "being",
    "and", "or", "but", "who", "which", "that",
    "this", "these", "those",
    "his", "her", "their", "theirs", "its", "our", "ours", "your", "yours", "my", "mine",
    "he", "him", "she", "it", "they", "them", "we", "us", "you", "i", "me",
    "himself", "herself", "itself", "themselves", "ourselves", "yourself", "yourselves", "myself",
    "as", "if", "than", "then",
    "there", "here",
    "not", "no",
    "do", "does", "did", "done",
    "have", "has", "had",
    "will", "would", "can", "could", "should", "may", "might", "must",
    "still", "very", "just", "also",
}

RELATION_WORDS = {
    "in", "on", "at", "by", "with", "from", "to", "for",
    "into", "onto", "over", "under", "between", "around", "through",
    "during", "while", "near", "inside", "outside", "along", "across",
    "behind", "beside", "toward", "towards", "against", "before", "after",
    "front", "back", "next", "side",
}

GENERIC_NOUNS = {
    "thing", "things",
    "something", "anything", "everything",
    "object", "objects",
    "item", "items",
    "stuff",
    "piece", "pieces",
}

GENERIC_STRUCTURE_NOUNS = {
    "thing", "things",
    "something", "anything", "everything",
    "object", "objects",
    "item", "items",
    "piece", "pieces",
    "structure", "structures",
    "place", "places",
    "area", "areas",
    "scene", "scenes",
}

GENERIC_HUMAN_NOUNS = {
    "person", "persons",
    "people",
    "individual", "individuals",
    "man", "men",
    "woman", "women",
    "guy", "guys",
}

COLOR_WORDS = {
    "black", "white", "blue", "red", "green", "yellow", "orange",
    "brown", "gray", "grey", "purple", "pink", "violet", "beige",
    "tan", "dark", "light", "bright", "olive", "blond", "blonde",
}

ABSTRACT_OR_FORMAL_POLISH_WORDS = {
    "individual", "individuals",
    "prominent",
    "professional", "professionals",
    "personnel",
    "participant", "participants",
    "utilizing",
    "positioned",
    "situated",
    "emerged",
    "fluctuation", "fluctuations",
}

NON_VERBAL_ING_WORDS = {
    "clothing",
    "building",
    "ceiling",
    "morning",
    "evening",
    "wedding",
    "meeting",
    "setting",
    "painting",
    "drawing",
    "thing",
    "something",
    "anything",
    "everything",
    "ring",
    "earring",
    "spring",
}


# =========================================================
# Basic utils
# =========================================================
def clean_text(x: Any) -> str:
    if x is None:
        return ""
    return re.sub(r"\s+", " ", str(x).strip())


def norm(x: Any) -> str:
    x = clean_text(x).lower()
    x = x.replace("’", "'").replace("“", '"').replace("”", '"')
    x = re.sub(r"[^a-z0-9_\-\s]", " ", x)
    return re.sub(r"\s+", " ", x).strip()


def same(a: Any, b: Any) -> bool:
    return norm(a) == norm(b)


def safe_bool(x: Any, default: bool = False) -> bool:
    if isinstance(x, bool):
        return x

    s = norm(x)

    if s in {"true", "yes", "1"}:
        return True

    if s in {"false", "no", "0"}:
        return False

    return default


def safe_float(x: Any, default: float = 0.0) -> float:
    try:
        return float(x)
    except Exception:
        return default


def format_time(sec: float) -> str:
    sec = int(sec)
    return f"{sec // 3600:02d}:{(sec % 3600) // 60:02d}:{sec % 60:02d}"


def read_jsonl_records(path: str) -> List[Dict]:
    if not os.path.isfile(path):
        raise FileNotFoundError(f"JSONL not found: {path}")

    rows = []

    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))

    return rows


def write_jsonl_record(fp, obj: Dict):
    fp.write(json.dumps(obj, ensure_ascii=False) + "\n")


def softmax_scores(scores: List[float]) -> List[float]:
    if not scores:
        return []

    t = torch.tensor(scores, dtype=torch.float32)
    probs = torch.softmax(t, dim=0)

    return probs.detach().cpu().tolist()


def parse_json_value(v: Any) -> Any:
    if isinstance(v, (dict, list)):
        return v

    if isinstance(v, str):
        s = clean_text(v)
        if not s:
            return None
        try:
            return json.loads(s)
        except Exception:
            return None

    return None


def get_nested_dict(row: Dict, key: str) -> Dict:
    v = parse_json_value(row.get(key, {}))
    return v if isinstance(v, dict) else {}


def get_nested_list(row: Dict, key: str) -> List:
    v = parse_json_value(row.get(key, []))
    return v if isinstance(v, list) else []


def first_nonempty(row: Dict, keys: List[str]) -> str:
    for k in keys:
        v = clean_text(row.get(k, ""))
        if v:
            return v
    return ""


def get_reference_translation(row: Dict) -> str:
    return first_nonempty(
        row,
        [
            "reference_translation",
            "src_en",
            "source_text_en",
            "reference",
            "source",
        ],
    )


def get_initial_translation(row: Dict) -> str:
    return first_nonempty(
        row,
        [
            "initial_translation",
            "initial_translation_en",
        ],
    )


def get_source_for_score(row: Dict) -> Tuple[str, str]:
    source_text = clean_text(row.get("source_text", ""))

    if source_text:
        return source_text, SRC_LANG

    return "", SRC_LANG


def tokenize_words(x: Any) -> List[str]:
    return re.findall(r"[A-Za-z0-9_\-]+", norm(x))


def content_tokens_for_check(x: Any) -> List[str]:
    return [
        t for t in tokenize_words(x)
        if t and t not in FUNCTION_WORDS and t not in RELATION_WORDS
    ]


def relation_tokens_for_check(x: Any) -> List[str]:
    return [
        t for t in tokenize_words(x)
        if t in RELATION_WORDS
    ]


def canonical_content_token(t: str) -> str:
    t = norm(t)

    if t == "player":
        return "play"

    if t in {"plays", "played", "playing"}:
        return "play"

    if len(t) > 4 and t.endswith("ies"):
        return t[:-3] + "y"

    if len(t) > 4 and t.endswith("ing") and t not in NON_VERBAL_ING_WORDS:
        stem = t[:-3]

        if len(stem) >= 2 and stem[-1] == stem[-2]:
            stem = stem[:-1]

        return stem

    if len(t) > 3 and t.endswith("ed"):
        return t[:-2]

    if len(t) > 3 and t.endswith("es"):
        return t[:-2]

    if len(t) > 3 and t.endswith("s") and not t.endswith("ss"):
        return t[:-1]

    return t


def content_signature(x: Any) -> List[str]:
    return sorted(canonical_content_token(t) for t in content_tokens_for_check(x))


def has_verbal_morphology(x: Any) -> bool:
    toks = tokenize_words(x)

    for t in toks:
        if t in NON_VERBAL_ING_WORDS:
            continue

        if len(t) >= 4 and (t.endswith("ing") or t.endswith("ed")):
            return True

    return False


def has_conjoined_phrase(x: Any) -> bool:
    toks = tokenize_words(x)
    return "and" in toks or "or" in toks


def looks_like_removed_plural_object(tok: str) -> bool:
    tok = norm(tok)

    if not tok:
        return False

    if len(tok) <= 3:
        return False

    if not tok.endswith("s"):
        return False

    if tok.endswith("ss"):
        return False

    return True


def is_uninformative_action_equivalent_compression(frm: str, to: str) -> bool:
    from_content = content_tokens_for_check(frm)
    to_content = content_tokens_for_check(to)

    if len(from_content) != 2:
        return False

    if len(to_content) != 1:
        return False

    first, second = from_content[0], from_content[1]
    only_to = to_content[0]

    if not first.endswith("ing"):
        return False

    if not only_to.endswith("ing"):
        return False

    if looks_like_removed_plural_object(second):
        return True

    return False


# =========================================================
# N-gram structure filter
# =========================================================
def meaningful_ngram(gram: Tuple[str, ...]) -> bool:
    if not gram:
        return False

    if all((t in FUNCTION_WORDS or t in RELATION_WORDS) for t in gram):
        return False

    return any((t not in FUNCTION_WORDS and t not in RELATION_WORDS) for t in gram)


def repeated_meaningful_ngram_info(
    text: str,
    min_n: int = 2,
    max_n: int = 3,
) -> Tuple[bool, Tuple[str, ...]]:
    toks = tokenize_words(text)

    if len(toks) < min_n * 2:
        return False, tuple()

    for n in range(max_n, min_n - 1, -1):
        seen = {}

        for i in range(0, len(toks) - n + 1):
            gram = tuple(toks[i:i + n])

            if not meaningful_ngram(gram):
                continue

            if gram in seen:
                prev_i = seen[gram]

                if i - prev_i >= n:
                    return True, gram
            else:
                seen[gram] = i

    return False, tuple()


def candidate_bad_local_repeated_ngram(row: Dict, cand_idx: int, candidate: str) -> Tuple[bool, str]:
    has_rep, gram = repeated_meaningful_ngram_info(candidate, min_n=2, max_n=3)

    if not has_rep:
        return False, ""

    gram_set = set(gram)
    edits = get_candidate_edits(row, cand_idx)

    if not edits:
        return False, ""

    for ed in edits:
        to_tokens = set(tokenize_words(ed.get("to", "")))

        if gram_set & to_tokens:
            return True, "bad_local_repeated_ngram:" + "_".join(gram)

    return False, ""


# =========================================================
# Sentence diff utilities
# =========================================================
def get_sentence_diff_edits(initial: str, candidate: str) -> List[Dict]:
    a = tokenize_words(initial)
    b = tokenize_words(candidate)

    edits = []
    sm = SequenceMatcher(a=a, b=b)

    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal":
            continue

        left_a = max(0, i1 - 1)
        right_a = min(len(a), i2 + 1)
        left_b = max(0, j1 - 1)
        right_b = min(len(b), j2 + 1)

        raw_from = " ".join(a[i1:i2])
        raw_to = " ".join(b[j1:j2])

        frm = " ".join(a[left_a:right_a])
        to = " ".join(b[left_b:right_b])

        if raw_from or raw_to:
            edits.append({
                "from": frm,
                "to": to,
                "raw_from": raw_from,
                "raw_to": raw_to,
            })

    return edits


def get_main_sentence_diff_pair(initial: str, candidate: str) -> Dict:
    a = tokenize_words(initial)
    b = tokenize_words(candidate)

    if not a and not b:
        return {
            "from": "",
            "to": "",
            "raw_from": "",
            "raw_to": "",
        }

    left = 0

    while left < len(a) and left < len(b) and a[left] == b[left]:
        left += 1

    right_a = len(a) - 1
    right_b = len(b) - 1

    while right_a >= left and right_b >= left and a[right_a] == b[right_b]:
        right_a -= 1
        right_b -= 1

    raw_from = " ".join(a[left:right_a + 1])
    raw_to = " ".join(b[left:right_b + 1])

    return {
        "from": raw_from,
        "to": raw_to,
        "raw_from": raw_from,
        "raw_to": raw_to,
    }


def iter_diff_pairs(initial: str, candidate: str) -> List[Tuple[str, str]]:
    pairs = []

    main = get_main_sentence_diff_pair(initial, candidate)

    if clean_text(main.get("raw_from", "")) or clean_text(main.get("raw_to", "")):
        pairs.append((clean_text(main.get("raw_from", "")), clean_text(main.get("raw_to", ""))))
        pairs.append((clean_text(main.get("from", "")), clean_text(main.get("to", ""))))

    for ed in get_sentence_diff_edits(initial, candidate):
        pairs.append((clean_text(ed.get("raw_from", "")), clean_text(ed.get("raw_to", ""))))
        pairs.append((clean_text(ed.get("from", "")), clean_text(ed.get("to", ""))))

    out = []
    seen = set()

    for a, b in pairs:
        key = (norm(a), norm(b))
        if key not in seen:
            seen.add(key)
            out.append((a, b))

    return out


def is_phrase_level_nominal_edit_pair(frm: str, to: str) -> bool:
    f_content = content_tokens_for_check(frm)
    t_content = content_tokens_for_check(to)

    if not f_content or not t_content:
        return False

    phrase_like = len(f_content) >= 2 or len(t_content) >= 2
    no_action = not has_verbal_morphology(frm) and not has_verbal_morphology(to)
    changed = set(f_content) != set(t_content)
    not_deletion = len(t_content) >= 1

    return bool(phrase_like and no_action and changed and not_deletion)


def is_no_real_gain_rephrase_pair(frm: str, to: str) -> bool:
    f_content = content_tokens_for_check(frm)
    t_content = content_tokens_for_check(to)

    if not f_content or not t_content:
        return False

    f_sig = content_signature(frm)
    t_sig = content_signature(to)

    if f_sig and f_sig == t_sig:
        return True

    if t_sig == sorted(f_sig + ["wear"]):
        return True

    if f_sig == sorted(t_sig + ["wear"]):
        return True

    return False


def is_shared_modifier_head_swap_pair(frm: str, to: str) -> bool:
    f_content = content_tokens_for_check(frm)
    t_content = content_tokens_for_check(to)

    if not f_content or not t_content:
        return False

    if has_verbal_morphology(frm) or has_verbal_morphology(to):
        return False

    f_set = set(f_content)
    t_set = set(t_content)

    shared = f_set & t_set
    f_unique = f_set - t_set
    t_unique = t_set - f_set

    return bool(shared and f_unique and t_unique)


def is_unsafe_prior_fluency_nominal_pair(frm: str, to: str) -> bool:
    if is_no_real_gain_rephrase_pair(frm, to):
        return True

    if is_shared_modifier_head_swap_pair(frm, to):
        return True

    f_content = set(content_tokens_for_check(frm))
    t_content = set(content_tokens_for_check(to))

    if (f_content | t_content) & COLOR_WORDS:
        if f_content != t_content:
            return True

    if f_content & GENERIC_STRUCTURE_NOUNS:
        if not t_content.issubset(GENERIC_STRUCTURE_NOUNS):
            return True

    if t_content & ABSTRACT_OR_FORMAL_POLISH_WORDS:
        if not f_content & ABSTRACT_OR_FORMAL_POLISH_WORDS:
            return True

    return False


def is_sentence_diff_phrase_level_nominal_repair(initial: str, candidate: str) -> bool:
    for frm, to in iter_diff_pairs(initial, candidate):
        if not frm or not to:
            continue

        if is_unsafe_prior_fluency_nominal_pair(frm, to):
            continue

        if is_phrase_level_nominal_edit_pair(frm, to):
            return True

    return False


def is_no_real_gain_sentence_rewrite(initial: str, candidate: str) -> bool:
    if content_signature(initial) == content_signature(candidate):
        return True

    for frm, to in iter_diff_pairs(initial, candidate):
        if frm and to and is_no_real_gain_rephrase_pair(frm, to):
            return True

    return False


def is_shared_modifier_head_swap(initial: str, candidate: str) -> bool:
    for frm, to in iter_diff_pairs(initial, candidate):
        if frm and to and is_shared_modifier_head_swap_pair(frm, to):
            return True
    return False


def is_color_or_attribute_nominal_shift(initial: str, candidate: str) -> bool:
    for frm, to in iter_diff_pairs(initial, candidate):
        if not frm or not to:
            continue

        if has_verbal_morphology(frm) or has_verbal_morphology(to):
            continue

        f_content = set(content_tokens_for_check(frm))
        t_content = set(content_tokens_for_check(to))

        if not f_content or not t_content:
            continue

        f_colors = f_content & COLOR_WORDS
        t_colors = t_content & COLOR_WORDS

        if f_colors or t_colors:
            if f_colors != t_colors:
                return True

            if f_colors and (f_content - t_content) and (t_content - f_content):
                return True

    return False


def is_generic_to_specific_nominal_guess(initial: str, candidate: str) -> bool:
    for frm, to in iter_diff_pairs(initial, candidate):
        if not frm or not to:
            continue

        if has_verbal_morphology(frm) or has_verbal_morphology(to):
            continue

        f_content = set(content_tokens_for_check(frm))
        t_content = set(content_tokens_for_check(to))

        if not f_content or not t_content:
            continue

        if f_content & GENERIC_STRUCTURE_NOUNS:
            if not t_content.issubset(GENERIC_STRUCTURE_NOUNS):
                if len(t_content) >= len(f_content):
                    return True

    return False


def is_abstract_or_formal_polish_rewrite(initial: str, candidate: str) -> bool:
    for frm, to in iter_diff_pairs(initial, candidate):
        if not frm or not to:
            continue

        if has_verbal_morphology(frm) or has_verbal_morphology(to):
            continue

        f_content = set(content_tokens_for_check(frm))
        t_content = set(content_tokens_for_check(to))

        if not f_content or not t_content:
            continue

        if t_content & ABSTRACT_OR_FORMAL_POLISH_WORDS:
            if not f_content & ABSTRACT_OR_FORMAL_POLISH_WORDS:
                return True

        if (f_content & GENERIC_HUMAN_NOUNS) and (t_content & GENERIC_HUMAN_NOUNS):
            if f_content != t_content:
                return True

    return False


def is_unsafe_prior_fluency_nominal_rewrite(
    initial: str,
    candidate: str,
) -> Tuple[bool, str]:
    if is_no_real_gain_sentence_rewrite(initial, candidate):
        return True, "no_real_gain_rephrase"

    if is_color_or_attribute_nominal_shift(initial, candidate):
        return True, "color_or_attribute_nominal_shift"

    if is_shared_modifier_head_swap(initial, candidate):
        return True, "shared_modifier_head_swap"

    if is_generic_to_specific_nominal_guess(initial, candidate):
        return True, "generic_to_specific_nominal_guess"

    if is_abstract_or_formal_polish_rewrite(initial, candidate):
        return True, "abstract_or_formal_polish"

    return False, ""


def sentence_diff_has_non_head_preserving_specific_object_guess(initial: str, candidate: str) -> bool:
    for frm, to in iter_diff_pairs(initial, candidate):
        if not frm or not to:
            continue

        f_content = content_tokens_for_check(frm)
        t_content = content_tokens_for_check(to)

        if not f_content or not t_content:
            continue

        f_set = set(f_content)
        t_set = set(t_content)

        if f_set == t_set:
            continue

        if f_set.issubset(t_set):
            continue

        shared = f_set & t_set

        if shared and (f_set - t_set) and (t_set - f_set):
            if not has_verbal_morphology(frm) and not has_verbal_morphology(to):
                return True

        if len(f_content) == 1 and 1 <= len(t_content) <= 2 and not shared:
            if not has_verbal_morphology(frm) and not has_verbal_morphology(to):
                return True

    return False


# =========================================================
# Candidate-stage fields
# =========================================================
def get_candidate_verifier(row: Dict, cand_idx: int) -> Dict:
    if cand_idx == 0:
        return {}
    return get_nested_dict(row, f"candidate_{cand_idx}_verifier")


def candidate_stage_fields_present(row: Dict, cand_idx: int) -> bool:
    if cand_idx == 0:
        return True

    direct_keys = [
        f"candidate_{cand_idx}_eligible_for_selection",
        f"candidate_{cand_idx}_local_probability_gate_type",
        f"candidate_{cand_idx}_source_supported_candidate",
        f"candidate_{cand_idx}_prior_fluency_candidate",
        f"candidate_{cand_idx}_source_probability_quality_gate_pass",
    ]

    if any(k in row for k in direct_keys):
        return True

    verifier = get_candidate_verifier(row, cand_idx)

    if not verifier:
        return False

    nested_keys = [
        "eligible_for_selection",
        "local_probability_gate_type",
        "source_supported_candidate",
        "prior_fluency_candidate",
        "source_probability_quality_gate_pass",
    ]

    return any(k in verifier for k in nested_keys)


def get_candidate_probability_gate_type(row: Dict, cand_idx: int) -> str:
    if cand_idx == 0:
        return "initial"

    direct = clean_text(row.get(f"candidate_{cand_idx}_local_probability_gate_type", ""))

    if direct:
        return direct

    verifier = get_candidate_verifier(row, cand_idx)
    nested = clean_text(verifier.get("local_probability_gate_type", ""))

    return nested


def candidate_source_supported(row: Dict, cand_idx: int) -> bool:
    if cand_idx == 0:
        return False

    direct = row.get(f"candidate_{cand_idx}_source_supported_candidate", None)

    if direct is not None:
        return safe_bool(direct, False)

    gate_type = get_candidate_probability_gate_type(row, cand_idx)

    if gate_type == "source_supported_pass":
        return True

    verifier = get_candidate_verifier(row, cand_idx)

    if safe_bool(verifier.get("source_supported_candidate", False), False):
        return True

    if clean_text(verifier.get("local_probability_gate_type", "")) == "source_supported_pass":
        return True

    return False


def candidate_prior_fluency(row: Dict, cand_idx: int) -> bool:
    if cand_idx == 0:
        return False

    direct = row.get(f"candidate_{cand_idx}_prior_fluency_candidate", None)

    if direct is not None:
        return safe_bool(direct, False)

    gate_type = get_candidate_probability_gate_type(row, cand_idx)

    if gate_type == "prior_fluency_pass":
        return True

    verifier = get_candidate_verifier(row, cand_idx)

    if safe_bool(verifier.get("prior_fluency_candidate", False), False):
        return True

    if clean_text(verifier.get("local_probability_gate_type", "")) == "prior_fluency_pass":
        return True

    return False


def candidate_stage_eligible(row: Dict, cand_idx: int) -> bool:
    if cand_idx == 0:
        return True

    if not candidate_stage_fields_present(row, cand_idx):
        return True

    direct = row.get(f"candidate_{cand_idx}_eligible_for_selection", None)

    if direct is not None:
        return safe_bool(direct, False)

    direct_gate_pass = row.get(f"candidate_{cand_idx}_source_probability_quality_gate_pass", None)

    if direct_gate_pass is not None:
        return safe_bool(direct_gate_pass, False)

    if candidate_source_supported(row, cand_idx):
        return True

    if candidate_prior_fluency(row, cand_idx):
        return True

    verifier = get_candidate_verifier(row, cand_idx)

    if "eligible_for_selection" in verifier:
        return safe_bool(verifier.get("eligible_for_selection", False), False)

    if "source_probability_quality_gate_pass" in verifier:
        return safe_bool(verifier.get("source_probability_quality_gate_pass", False), False)

    return False


def candidate_gate_tier(row: Dict, cand_idx: int) -> str:
    if cand_idx == 0:
        return "initial"

    if candidate_source_supported(row, cand_idx):
        return "source_supported"

    if candidate_prior_fluency(row, cand_idx):
        return "prior_fluency"

    if candidate_stage_fields_present(row, cand_idx):
        return "candidate_gate_rejected"

    return "no_candidate_gate"


# =========================================================
# Candidate adapter
# =========================================================
def get_candidate_texts(row: Dict) -> List[str]:
    initial = get_initial_translation(row)

    cands = [
        initial,
        clean_text(row.get("candidate_1", "")),
        clean_text(row.get("candidate_2", "")),
        clean_text(row.get("candidate_3", "")),
    ]

    out = []

    for x in cands:
        x = clean_text(x)
        out.append(x if x else initial)

    return out


def get_candidate_edits(row: Dict, cand_idx: int) -> List[Dict]:
    if cand_idx == 0:
        return []

    edits = get_nested_list(row, f"edited_spans_{cand_idx}")

    clean_edits = []

    for ed in edits:
        if isinstance(ed, dict):
            clean_edits.append({
                "from": clean_text(ed.get("from", "")),
                "to": clean_text(ed.get("to", "")),
            })

    return clean_edits


def get_candidate_deterministic_allow(row: Dict, cand_idx: int) -> bool:
    if cand_idx == 0:
        return True

    direct = row.get(f"candidate_{cand_idx}_deterministic_allow_candidate", None)

    if direct is not None:
        return safe_bool(direct, False)

    verifier = get_candidate_verifier(row, cand_idx)

    return safe_bool(verifier.get("deterministic_allow_candidate", False), False)


def get_candidate_deterministic_score(row: Dict, cand_idx: int) -> float:
    if cand_idx == 0:
        return 0.0

    direct = row.get(f"candidate_{cand_idx}_deterministic_score", None)

    if direct is not None:
        return safe_float(direct, 0.0)

    verifier = get_candidate_verifier(row, cand_idx)

    return safe_float(verifier.get("deterministic_score", 0.0), 0.0)


def verifier_flag(row: Dict, cand_idx: int, key: str, default: bool = False) -> bool:
    verifier = get_candidate_verifier(row, cand_idx)
    return safe_bool(verifier.get(key, default), default)


def verifier_triggered(row: Dict, cand_idx: int, risk_name: str) -> bool:
    verifier = get_candidate_verifier(row, cand_idx)
    items = verifier.get("deterministic_risk_items", [])

    if not isinstance(items, list):
        return False

    for item in items:
        if not isinstance(item, dict):
            continue

        if clean_text(item.get("name", "")) == risk_name and safe_bool(item.get("triggered", False), False):
            return True

    return False


def candidate_is_changed(initial: str, candidate: str) -> bool:
    return not same(initial, candidate)


def candidate_is_phrase_compression_repair(row: Dict, cand_idx: int) -> bool:
    return (
        verifier_flag(row, cand_idx, "phrase_compression_repair", False)
        or verifier_triggered(row, cand_idx, "phrase_compression_repair")
        or verifier_triggered(row, cand_idx, "phrase_compression_repair_needs_pairwise_check")
    )


def candidate_is_relation_repair(row: Dict, cand_idx: int) -> bool:
    return (
        verifier_flag(row, cand_idx, "relation_repair", False)
        or verifier_triggered(row, cand_idx, "relation_repair")
        or verifier_triggered(row, cand_idx, "relation_repair_needs_pairwise_check")
    )


def candidate_is_high_risk(row: Dict, cand_idx: int) -> bool:
    if cand_idx == 0:
        return False

    return (
        verifier_flag(row, cand_idx, "single_word_replacement", False)
        or verifier_flag(row, cand_idx, "surface_rewrite", False)
        or verifier_triggered(row, cand_idx, "single_word_replacement_high_risk")
        or verifier_triggered(row, cand_idx, "surface_rewrite_high_risk")
        or verifier_triggered(row, cand_idx, "single_word_replacement_needs_pairwise_check")
        or verifier_triggered(row, cand_idx, "surface_rewrite_needs_pairwise_check")
    )


def candidate_core_content_repair(row: Dict, cand_idx: int) -> bool:
    if cand_idx == 0:
        return False

    return (
        verifier_flag(row, cand_idx, "core_content_replacement", False)
        or verifier_triggered(row, cand_idx, "core_content_replacement_high_risk")
        or verifier_triggered(row, cand_idx, "core_content_replacement_needs_pairwise_check")
        or verifier_flag(row, cand_idx, "local_content_substitution", False)
        or verifier_triggered(row, cand_idx, "local_content_substitution_high_risk")
        or verifier_triggered(row, cand_idx, "local_content_substitution_needs_pairwise_check")
    )


# =========================================================
# Edit-type filters
# =========================================================
def is_head_preserving_specificity_repair(row: Dict, cand_idx: int) -> bool:
    edits = get_candidate_edits(row, cand_idx)

    for ed in edits:
        frm = clean_text(ed.get("from", ""))
        to = clean_text(ed.get("to", ""))

        f_content = content_tokens_for_check(frm)
        t_content = content_tokens_for_check(to)

        if not f_content or not t_content:
            continue

        if set(f_content).issubset(set(t_content)) and len(t_content) > len(f_content):
            return True

    return False


def is_phrase_level_nominal_repair(row: Dict, cand_idx: int) -> bool:
    edits = get_candidate_edits(row, cand_idx)

    for ed in edits:
        frm = clean_text(ed.get("from", ""))
        to = clean_text(ed.get("to", ""))

        if is_unsafe_prior_fluency_nominal_pair(frm, to):
            continue

        if is_phrase_level_nominal_edit_pair(frm, to):
            return True

    return False


def is_safe_single_word_semantic_repair(row: Dict, cand_idx: int) -> bool:
    edits = get_candidate_edits(row, cand_idx)

    if len(edits) != 1:
        return False

    ed = edits[0]
    frm = clean_text(ed.get("from", ""))
    to = clean_text(ed.get("to", ""))

    f_content = content_tokens_for_check(frm)
    t_content = content_tokens_for_check(to)

    if len(f_content) != 1 or len(t_content) != 1:
        return False

    if relation_tokens_for_check(frm) or relation_tokens_for_check(to):
        return False

    if has_verbal_morphology(frm) or has_verbal_morphology(to):
        return False

    if candidate_is_relation_repair(row, cand_idx):
        return False

    return True


def is_one_word_verb_style_rewrite(row: Dict, cand_idx: int) -> bool:
    edits = get_candidate_edits(row, cand_idx)

    if len(edits) != 1:
        return False

    ed = edits[0]
    frm = clean_text(ed.get("from", ""))
    to = clean_text(ed.get("to", ""))

    f_content = content_tokens_for_check(frm)
    t_content = content_tokens_for_check(to)

    if len(f_content) == 1 and len(t_content) == 1 and f_content[0] != t_content[0]:
        if has_verbal_morphology(frm) or has_verbal_morphology(to):
            return True

        if f_content[0].endswith("ing") or t_content[0].endswith("ing"):
            return True

    return False


def is_generalization_rewrite(row: Dict, cand_idx: int) -> bool:
    edits = get_candidate_edits(row, cand_idx)

    for ed in edits:
        frm = clean_text(ed.get("from", ""))
        to = clean_text(ed.get("to", ""))

        f_content = content_tokens_for_check(frm)
        t_content = content_tokens_for_check(to)

        if not f_content or not t_content:
            continue

        f_set = set(f_content)
        t_set = set(t_content)

        if t_set & GENERIC_NOUNS and not f_set.issubset(t_set):
            return True

        if f_set & GENERIC_NOUNS and t_set & GENERIC_NOUNS and f_set != t_set:
            return True

    return False


def is_style_or_synonym_like_edit(
    row: Dict,
    cand_idx: int,
    initial: str = "",
    candidate: str = "",
) -> bool:
    if candidate_source_supported(row, cand_idx):
        return False

    if is_head_preserving_specificity_repair(row, cand_idx):
        return False

    if is_phrase_level_nominal_repair(row, cand_idx):
        return False

    if initial and candidate and is_sentence_diff_phrase_level_nominal_repair(initial, candidate):
        return False

    edits = get_candidate_edits(row, cand_idx)

    if not edits:
        return False

    for ed in edits:
        frm = clean_text(ed.get("from", ""))
        to = clean_text(ed.get("to", ""))

        f_content = content_tokens_for_check(frm)
        t_content = content_tokens_for_check(to)

        if not f_content or not t_content:
            continue

        if len(f_content) == 1 and len(t_content) == 1 and f_content[0] != t_content[0]:
            return True

        if len(f_content) == len(t_content) and set(f_content) != set(t_content):
            if not relation_tokens_for_check(frm) and not relation_tokens_for_check(to):
                return True

    return False


def is_unsupported_core_replacement(
    row: Dict,
    cand_idx: int,
    initial: str = "",
    candidate: str = "",
) -> bool:
    if candidate_source_supported(row, cand_idx):
        return False

    if is_head_preserving_specificity_repair(row, cand_idx):
        return False

    if initial and candidate:
        if sentence_diff_has_non_head_preserving_specific_object_guess(initial, candidate):
            return True

    if is_phrase_level_nominal_repair(row, cand_idx):
        return False

    if initial and candidate and is_sentence_diff_phrase_level_nominal_repair(initial, candidate):
        return False

    edits = get_candidate_edits(row, cand_idx)

    for ed in edits:
        frm = clean_text(ed.get("from", ""))
        to = clean_text(ed.get("to", ""))

        f_content = content_tokens_for_check(frm)
        t_content = content_tokens_for_check(to)

        if not f_content or not t_content:
            continue

        if len(f_content) == 1 and len(t_content) == 1:
            if f_content[0] != t_content[0]:
                return True

        if len(f_content) == 1 and 1 <= len(t_content) <= 2:
            if not set(f_content).intersection(set(t_content)):
                return True

    return False


def is_action_or_state_replacement(row: Dict, cand_idx: int) -> bool:
    edits = get_candidate_edits(row, cand_idx)

    for ed in edits:
        frm = clean_text(ed.get("from", ""))
        to = clean_text(ed.get("to", ""))

        f_content = content_tokens_for_check(frm)
        t_content = content_tokens_for_check(to)

        if not f_content or not t_content:
            continue

        if has_verbal_morphology(frm) or has_verbal_morphology(to):
            if set(f_content) != set(t_content):
                return True

    return False


# =========================================================
# Relation / phrase checks
# =========================================================
def has_relation_direction_flip(frm: str, to: str) -> bool:
    f_toks = set(tokenize_words(frm))
    t_toks = set(tokenize_words(to))

    if "behind" in f_toks and "front" in t_toks:
        return True

    if "front" in f_toks and "behind" in t_toks:
        return True

    if ({"under", "below"} & f_toks) and ({"over", "above"} & t_toks):
        return True

    if ({"over", "above"} & f_toks) and ({"under", "below"} & t_toks):
        return True

    if ({"inside", "into"} & f_toks) and ({"outside", "out"} & t_toks):
        return True

    if ({"outside", "out"} & f_toks) and ({"inside", "into", "in"} & t_toks):
        return True

    return False


def has_relation_weakening_or_bad_collocation(frm: str, to: str) -> bool:
    f_toks = set(tokenize_words(frm))
    t_toks = set(tokenize_words(to))

    if "front" in f_toks and ({"near", "side"} & t_toks):
        return True

    if "against" in f_toks and "on" in t_toks:
        return True

    if "across" in f_toks and "on" in t_toks:
        return True

    if "toward" in f_toks and "near" in t_toks:
        return True

    if "towards" in f_toks and "near" in t_toks:
        return True

    return False


def phrase_compression_strict_check(row: Dict, cand_idx: int) -> Tuple[bool, str]:
    if not candidate_is_phrase_compression_repair(row, cand_idx):
        return True, "not_phrase_compression"

    edits = get_candidate_edits(row, cand_idx)

    if not edits:
        return False, "phrase_compression_missing_edits"

    saw_valid_compression = False

    for ed in edits:
        frm = clean_text(ed.get("from", ""))
        to = clean_text(ed.get("to", ""))

        if not frm or not to:
            return False, "phrase_compression_empty_side"

        from_content = content_tokens_for_check(frm)
        to_content = content_tokens_for_check(to)

        if not from_content or not to_content:
            continue

        from_set = set(from_content)
        to_set = set(to_content)

        if from_set == to_set:
            continue

        relation_from = relation_tokens_for_check(frm)
        relation_to = relation_tokens_for_check(to)

        if relation_from or relation_to:
            return False, "phrase_compression_contains_relation"

        if is_uninformative_action_equivalent_compression(frm, to):
            return False, "phrase_compression_uninformative_action_equivalent"

        verbal_like = has_verbal_morphology(frm) or has_verbal_morphology(to)
        conjoined_like = has_conjoined_phrase(frm) and len(to_content) == 1

        if verbal_like or conjoined_like:
            saw_valid_compression = True
            continue

        if candidate_source_supported(row, cand_idx):
            saw_valid_compression = True
            continue

        return False, "phrase_compression_noun_or_attribute_drift"

    if not saw_valid_compression:
        return False, "phrase_compression_not_action_state"

    return True, "strict_phrase_compression_ok"


def relation_repair_strict_check(row: Dict, cand_idx: int) -> Tuple[bool, str]:
    if not candidate_is_relation_repair(row, cand_idx):
        return True, "not_relation_repair"

    edits = get_candidate_edits(row, cand_idx)

    if not edits:
        return False, "relation_repair_missing_edits"

    saw_relation_edit = False

    for ed in edits:
        frm = clean_text(ed.get("from", ""))
        to = clean_text(ed.get("to", ""))

        if not frm or not to:
            return False, "relation_repair_empty_side"

        if has_relation_direction_flip(frm, to):
            return False, "relation_direction_flip"

        if has_relation_weakening_or_bad_collocation(frm, to):
            return False, "relation_weakening_or_bad_collocation"

        from_rel = relation_tokens_for_check(frm)
        to_rel = relation_tokens_for_check(to)

        if from_rel or to_rel:
            saw_relation_edit = True

        from_content = content_tokens_for_check(frm)
        to_content = content_tokens_for_check(to)

        if set(from_content) != set(to_content):
            if candidate_source_supported(row, cand_idx):
                continue
            return False, "relation_content_drift"

    if not saw_relation_edit:
        return False, "relation_repair_without_relation_token"

    return True, "strict_relation_repair_ok"


def has_content_drift_without_safe_repair(row: Dict, cand_idx: int) -> Tuple[bool, str]:
    edits = get_candidate_edits(row, cand_idx)

    if not edits:
        return False, "no_edits"

    is_phrase = candidate_is_phrase_compression_repair(row, cand_idx)
    is_relation = candidate_is_relation_repair(row, cand_idx)

    if is_phrase:
        ok, reason = phrase_compression_strict_check(row, cand_idx)
        if ok:
            return False, "strict_phrase_compression"
        return True, reason

    if is_relation:
        ok, reason = relation_repair_strict_check(row, cand_idx)
        if ok:
            return False, "strict_relation_repair"
        return True, reason

    if candidate_source_supported(row, cand_idx) or candidate_prior_fluency(row, cand_idx):
        return False, "candidate_probability_gate_allows_content_drift"

    for ed in edits:
        frm = clean_text(ed.get("from", ""))
        to = clean_text(ed.get("to", ""))

        from_content = content_tokens_for_check(frm)
        to_content = content_tokens_for_check(to)

        if from_content and to_content and set(from_content) != set(to_content):
            return True, "content_drift_without_safe_repair"

    return False, "no_content_drift"


def candidate_has_hard_risk(row: Dict, cand_idx: int) -> Tuple[bool, str]:
    if cand_idx == 0:
        return False, "initial"

    verifier = get_candidate_verifier(row, cand_idx)

    source_supported = candidate_source_supported(row, cand_idx)
    prior_fluency = candidate_prior_fluency(row, cand_idx)

    if not verifier:
        return True, "missing_deterministic_verifier"

    if not safe_bool(verifier.get("verifier_parse_ok", True), True):
        return True, "deterministic_verifier_not_ok"

    if not safe_bool(verifier.get("target_span_touched", False), False):
        return True, "target_span_not_touched"

    if safe_bool(verifier.get("content_deletion", False), False):
        return True, "content_deletion"

    if safe_bool(verifier.get("empty_to_content_deletion", False), False):
        return True, "empty_to_content_deletion"

    if safe_bool(verifier.get("non_empty_content_deletion", False), False):
        return True, "non_empty_content_deletion"

    if safe_bool(verifier.get("pronoun_or_identity_shift", False), False):
        return True, "pronoun_or_identity_shift"

    if safe_bool(verifier.get("non_local_edit", False), False):
        return True, "non_local_edit"

    if safe_bool(verifier.get("length_delta_risk", False), False):
        return True, "length_delta_risk"

    if safe_bool(verifier.get("unsafe_relation_rewrite", False), False):
        return True, "unsafe_relation_rewrite"

    if verifier_triggered(row, cand_idx, "unsafe_relation_rewrite"):
        return True, "unsafe_relation_rewrite"

    if safe_bool(verifier.get("local_content_substitution", False), False):
        if not (source_supported or prior_fluency):
            return True, "local_content_substitution"

    if verifier_triggered(row, cand_idx, "local_content_substitution_high_risk"):
        if not (source_supported or prior_fluency):
            return True, "local_content_substitution"

    if verifier_triggered(row, cand_idx, "local_content_substitution_needs_pairwise_check"):
        if not (source_supported or prior_fluency):
            return True, "local_content_substitution"

    if safe_bool(verifier.get("core_content_replacement", False), False):
        if not (source_supported or prior_fluency):
            return True, "core_content_replacement"

    if verifier_triggered(row, cand_idx, "core_content_replacement_high_risk"):
        if not (source_supported or prior_fluency):
            return True, "core_content_replacement"

    if verifier_triggered(row, cand_idx, "core_content_replacement_needs_pairwise_check"):
        if not (source_supported or prior_fluency):
            return True, "core_content_replacement"

    phrase_ok, phrase_reason = phrase_compression_strict_check(row, cand_idx)

    if not phrase_ok:
        if not source_supported:
            return True, phrase_reason

    relation_ok, relation_reason = relation_repair_strict_check(row, cand_idx)

    if not relation_ok:
        if not source_supported:
            return True, relation_reason

    drift_risk, drift_reason = has_content_drift_without_safe_repair(row, cand_idx)

    if drift_risk:
        return True, drift_reason

    return False, "safe"


# =========================================================
# Selection priority
# =========================================================
def candidate_select_priority(row: Dict, cand_idx: int, initial: str, candidate: str) -> int:
    if cand_idx == 0:
        return 0

    source_supported = candidate_source_supported(row, cand_idx)
    prior_fluency = candidate_prior_fluency(row, cand_idx)

    head_specific = is_head_preserving_specificity_repair(row, cand_idx)
    phrase_nominal = (
        is_phrase_level_nominal_repair(row, cand_idx)
        or is_sentence_diff_phrase_level_nominal_repair(initial, candidate)
    )
    core_content = candidate_core_content_repair(row, cand_idx)
    relation_repair = candidate_is_relation_repair(row, cand_idx)

    if source_supported and core_content:
        return 70

    if source_supported and phrase_nominal:
        return 65

    if source_supported and head_specific:
        return 64

    if source_supported:
        return 60

    if prior_fluency and head_specific:
        return 45

    if prior_fluency and phrase_nominal:
        return 40

    if relation_repair:
        return 25

    if prior_fluency:
        return 10

    return 1


def has_source_supported_core_repair(row: Dict, selectable: List[bool]) -> bool:
    for j in [1, 2, 3]:
        if not selectable[j]:
            continue

        if not candidate_source_supported(row, j):
            continue

        if candidate_core_content_repair(row, j):
            return True

    return False


# =========================================================
# Selection
# =========================================================
def compute_selectable_candidates(
    row: Dict,
    candidates: List[str],
    blaser_scores: List[float],
    blaser_probs: List[float],
    comet_scores: List[float],
    comet_probs: List[float],
) -> Tuple[List[bool], List[str], List[float]]:
    initial = candidates[0]

    initial_blaser = blaser_scores[0]
    initial_comet = comet_scores[0]

    selectable = [False] * 4
    block_reasons = [""] * 4
    ranking_scores = [0.0] * 4

    selectable[0] = True
    block_reasons[0] = "initial_baseline"
    ranking_scores[0] = blaser_probs[0] + comet_probs[0]

    for idx in [1, 2, 3]:
        cand = candidates[idx]

        if not candidate_is_changed(initial, cand):
            selectable[idx] = False
            block_reasons[idx] = "same_as_initial"
            continue

        if not get_candidate_deterministic_allow(row, idx):
            selectable[idx] = False
            block_reasons[idx] = "deterministic_not_allowed"
            continue

        if candidate_stage_fields_present(row, idx) and not candidate_stage_eligible(row, idx):
            selectable[idx] = False
            block_reasons[idx] = "candidate_stage_not_eligible"
            continue

        gate_tier = candidate_gate_tier(row, idx)
        source_supported = gate_tier == "source_supported"
        prior_fluency = gate_tier == "prior_fluency"

        hard_risk, hard_reason = candidate_has_hard_risk(row, idx)

        if hard_risk:
            selectable[idx] = False
            block_reasons[idx] = hard_reason
            continue

        repeated_bad, _ = candidate_bad_local_repeated_ngram(row, idx, cand)

        if repeated_bad:
            selectable[idx] = False
            block_reasons[idx] = "bad_local_repeated_ngram"
            continue

        high_risk = candidate_is_high_risk(row, idx)

        if high_risk and not (source_supported or prior_fluency):
            selectable[idx] = False
            block_reasons[idx] = "high_risk_candidate"
            continue

        phrase_compression = candidate_is_phrase_compression_repair(row, idx)
        relation_repair = candidate_is_relation_repair(row, idx)

        blaser_win = blaser_scores[idx] > initial_blaser
        comet_win = comet_scores[idx] > initial_comet
        dual_qe_win = blaser_win and comet_win

        det_score = get_candidate_deterministic_score(row, idx)

        head_specific = is_head_preserving_specificity_repair(row, idx)
        phrase_nominal_by_edit = is_phrase_level_nominal_repair(row, idx)
        phrase_nominal_by_diff = is_sentence_diff_phrase_level_nominal_repair(initial, cand)
        phrase_nominal = phrase_nominal_by_edit or phrase_nominal_by_diff
        safe_single = is_safe_single_word_semantic_repair(row, idx)

        if source_supported:
            if is_generalization_rewrite(row, idx):
                selectable[idx] = False
                block_reasons[idx] = "source_supported_generalization_rewrite"
                continue

            if is_one_word_verb_style_rewrite(row, idx):
                selectable[idx] = False
                block_reasons[idx] = "source_supported_one_word_verb_style_rewrite"
                continue

            if high_risk and is_action_or_state_replacement(row, idx) and not dual_qe_win:
                selectable[idx] = False
                block_reasons[idx] = "source_supported_high_risk_requires_dual_qe"
                continue

            if dual_qe_win:
                selectable[idx] = True
                block_reasons[idx] = "source_supported_dual_qe_pass"
                ranking_scores[idx] = (
                    blaser_probs[idx]
                    + comet_probs[idx]
                    + 0.05
                    + 1e-6 * det_score
                )
                continue

            if blaser_win or comet_win:
                selectable[idx] = True
                block_reasons[idx] = "source_supported_single_qe_pass"
                qe_support_count = int(blaser_win) + int(comet_win)
                ranking_scores[idx] = (
                    blaser_probs[idx]
                    + comet_probs[idx]
                    + 0.02 * qe_support_count
                    + 1e-6 * det_score
                )
                continue

            selectable[idx] = False
            block_reasons[idx] = "source_supported_no_qe_higher_than_initial"
            continue

        if prior_fluency:
            unsafe_prior, unsafe_reason = is_unsafe_prior_fluency_nominal_rewrite(initial, cand)

            if unsafe_prior:
                selectable[idx] = False
                block_reasons[idx] = f"prior_fluency_{unsafe_reason}"
                continue

            if is_style_or_synonym_like_edit(row, idx, initial=initial, candidate=cand):
                selectable[idx] = False
                block_reasons[idx] = "prior_fluency_style_or_synonym_only"
                continue

            if is_unsupported_core_replacement(row, idx, initial=initial, candidate=cand):
                selectable[idx] = False
                block_reasons[idx] = "prior_fluency_unsupported_core_replacement"
                continue

            if head_specific:
                if blaser_win or comet_win:
                    selectable[idx] = True
                    block_reasons[idx] = "prior_fluency_head_preserving_specificity_pass"
                    qe_support_count = int(blaser_win) + int(comet_win)
                    ranking_scores[idx] = (
                        blaser_probs[idx]
                        + comet_probs[idx]
                        + 0.012 * qe_support_count
                        + 1e-6 * det_score
                    )
                    continue

                selectable[idx] = False
                block_reasons[idx] = "prior_fluency_head_preserving_no_qe_support"
                continue

            if phrase_nominal:
                if dual_qe_win:
                    selectable[idx] = True

                    if phrase_nominal_by_diff and not phrase_nominal_by_edit:
                        block_reasons[idx] = "prior_fluency_sentence_diff_phrase_nominal_dual_qe_pass"
                    else:
                        block_reasons[idx] = "prior_fluency_phrase_nominal_dual_qe_pass"

                    ranking_scores[idx] = (
                        blaser_probs[idx]
                        + comet_probs[idx]
                        + 0.01
                        + 1e-6 * det_score
                    )
                    continue

                selectable[idx] = False

                if phrase_nominal_by_diff and not phrase_nominal_by_edit:
                    block_reasons[idx] = "prior_fluency_sentence_diff_phrase_nominal_no_dual_qe_support"
                else:
                    block_reasons[idx] = "prior_fluency_phrase_nominal_no_dual_qe_support"
                continue

            if safe_single:
                selectable[idx] = False
                block_reasons[idx] = "prior_fluency_single_word_replacement_blocked"
                continue

            selectable[idx] = False
            block_reasons[idx] = "prior_fluency_ordinary_blocked"
            continue

        unsafe_prior, unsafe_reason = is_unsafe_prior_fluency_nominal_rewrite(initial, cand)

        if unsafe_prior:
            selectable[idx] = False
            block_reasons[idx] = f"unsafe_nominal_{unsafe_reason}"
            continue

        if dual_qe_win:
            selectable[idx] = True

            if relation_repair:
                block_reasons[idx] = "dual_qe_strict_relation_repair_pass"
            elif phrase_compression:
                block_reasons[idx] = "dual_qe_strict_phrase_compression_pass"
            else:
                block_reasons[idx] = "dual_qe_pairwise_pass"

            ranking_scores[idx] = blaser_probs[idx] + comet_probs[idx] + 1e-6 * det_score
            continue

        if phrase_compression and (blaser_win or comet_win):
            selectable[idx] = True
            block_reasons[idx] = "relaxed_strict_phrase_compression_single_qe_pass"

            qe_support_count = int(blaser_win) + int(comet_win)

            ranking_scores[idx] = (
                blaser_probs[idx]
                + comet_probs[idx]
                + 0.01 * qe_support_count
                + 1e-6 * det_score
            )
            continue

        if relation_repair:
            selectable[idx] = False

            if blaser_win and not comet_win:
                block_reasons[idx] = "relation_repair_comet_not_higher_than_initial"
            elif comet_win and not blaser_win:
                block_reasons[idx] = "relation_repair_blaser_not_higher_than_initial"
            else:
                block_reasons[idx] = "relation_repair_no_dual_qe_support"
            continue

        if not blaser_win and not comet_win:
            selectable[idx] = False
            block_reasons[idx] = "no_qe_higher_than_initial"
            continue

        if not blaser_win:
            selectable[idx] = False
            block_reasons[idx] = "blaser_not_higher_than_initial"
            continue

        if not comet_win:
            selectable[idx] = False
            block_reasons[idx] = "comet_not_higher_than_initial"
            continue

    if has_source_supported_core_repair(row, selectable):
        for j in [1, 2, 3]:
            if not selectable[j]:
                continue

            if candidate_prior_fluency(row, j) and not is_head_preserving_specificity_repair(row, j):
                selectable[j] = False
                block_reasons[j] = "prior_fluency_blocked_by_source_supported_core_repair"
                ranking_scores[j] = 0.0

    return selectable, block_reasons, ranking_scores


def select_best(
    row: Dict,
    blaser_scores: List[float],
    blaser_probs: List[float],
    comet_scores: List[float],
    comet_probs: List[float],
    candidates: List[str],
) -> Dict:
    selectable, block_reasons, ranking_scores = compute_selectable_candidates(
        row=row,
        candidates=candidates,
        blaser_scores=blaser_scores,
        blaser_probs=blaser_probs,
        comet_scores=comet_scores,
        comet_probs=comet_probs,
    )

    priorities = [
        candidate_select_priority(row, i, candidates[0], candidates[i])
        for i in range(4)
    ]

    ranking = sorted(
        range(4),
        key=lambda i: (
            selectable[i],
            priorities[i],
            ranking_scores[i],
            blaser_probs[i] + comet_probs[i],
            blaser_scores[i],
            comet_scores[i],
            -i,
        ),
        reverse=True,
    )

    best_idx = ranking[0]

    if best_idx == 0:
        best_from = "initial_translation"
    else:
        best_from = f"candidate_{best_idx}"

    return {
        "best_idx": best_idx,
        "best_from": best_from,
        "best_translation": candidates[best_idx],
        "selectable": selectable,
        "block_reasons": block_reasons,
        "ranking_scores": ranking_scores,
        "ranking_priorities": priorities,
    }


# =========================================================
# SentencePiece encode
# =========================================================
def sp_encode_batch(
    sp: spm.SentencePieceProcessor,
    texts: List[str],
    lang: str,
    max_len: int = 512,
    pad_id: int = 0,
):
    tagged = [f"__{lang}__ {str(t).strip()}" for t in texts]

    ids = [sp.encode(t, out_type=int)[:max_len] for t in tagged]
    lens = [len(x) for x in ids]
    maxl = max(lens) if lens else 0

    x = torch.full((len(ids), maxl), pad_id, dtype=torch.long)

    for i, row in enumerate(ids):
        if row:
            x[i, :len(row)] = torch.tensor(row, dtype=torch.long)

    attn = x != pad_id

    return x, attn


def build_vocab_info_from_spm(
    spm_path: str,
    vocab_size_override: Optional[int] = None,
):
    from fairseq2.data.vocabulary_info import VocabularyInfo

    sp = spm.SentencePieceProcessor(model_file=spm_path)

    unk = sp.unk_id()
    bos = sp.bos_id()
    eos = sp.eos_id()
    pad = sp.pad_id() if hasattr(sp, "pad_id") else -1

    if pad is None or pad < 0:
        pad = 0

    size = vocab_size_override if vocab_size_override is not None else sp.get_piece_size()

    return VocabularyInfo(
        size=int(size),
        unk_idx=int(unk),
        bos_idx=int(bos),
        eos_idx=int(eos),
        pad_idx=int(pad),
    )


# =========================================================
# SONAR text encoder offline load
# =========================================================
def load_sonar_text_encoder_offline(
    encoder_ckpt: str,
    spm_path: str,
    device: torch.device,
    max_seq_len: int = 512,
):
    if not os.path.isfile(encoder_ckpt):
        raise FileNotFoundError(f"SONAR text encoder checkpoint not found: {encoder_ckpt}")

    if not os.path.isfile(spm_path):
        raise FileNotFoundError(f"SentencePiece model not found: {spm_path}")

    ckpt = torch.load(encoder_ckpt, map_location="cpu")

    if not isinstance(ckpt, dict) or "model" not in ckpt:
        raise RuntimeError(
            f"Unexpected SONAR checkpoint format: type={type(ckpt)} "
            f"keys={list(ckpt.keys()) if isinstance(ckpt, dict) else None}"
        )

    state_dict = ckpt["model"]

    if not isinstance(state_dict, dict):
        raise RuntimeError(
            f"Expected ckpt['model'] to be a state_dict dict/OrderedDict, got {type(state_dict)}"
        )

    emb_w = state_dict["encoder_frontend.embed.weight"]
    vocab_size = emb_w.shape[0]
    model_dim = emb_w.shape[1]

    ffn_w = state_dict["encoder.layers.0.ffn.inner_proj.weight"]
    ffn_inner_dim = ffn_w.shape[0]

    max_layer = -1

    for k in state_dict.keys():
        if k.startswith("encoder.layers."):
            parts = k.split(".")
            if len(parts) > 2 and parts[2].isdigit():
                max_layer = max(max_layer, int(parts[2]))

    num_encoder_layers = max_layer + 1

    vocab_info = build_vocab_info_from_spm(
        spm_path,
        vocab_size_override=int(vocab_size),
    )

    cfg = SonarTextEncoderConfig(
        model_dim=int(model_dim),
        max_seq_len=int(max_seq_len),
        vocab_info=vocab_info,
        num_encoder_layers=int(num_encoder_layers),
        num_decoder_layers=0,
        num_encoder_attn_heads=16,
        num_decoder_attn_heads=0,
        ffn_inner_dim=int(ffn_inner_dim),
        pooling="mean",
    )

    encoder = create_sonar_text_encoder_model(cfg, device=device).eval()

    missing, unexpected = encoder.load_state_dict(state_dict, strict=False)

    if missing or unexpected:
        print(
            f"[warn] SONAR encoder load_state_dict(strict=False): "
            f"missing={len(missing)} unexpected={len(unexpected)}"
        )

    sp = spm.SentencePieceProcessor(model_file=spm_path)

    return encoder, sp


@torch.no_grad()
def sonar_encode(
    encoder,
    sp: spm.SentencePieceProcessor,
    texts: List[str],
    lang: str,
    device: torch.device,
    max_len: int = 512,
) -> torch.Tensor:
    toks, attn = sp_encode_batch(
        sp,
        texts,
        lang=lang,
        max_len=max_len,
        pad_id=0,
    )

    toks = toks.to(device)
    attn = attn.to(device)

    padding_mask = None

    try:
        from fairseq2.nn.padding import PaddingMask

        pad = ~attn

        if hasattr(PaddingMask, "from_bool_tensor"):
            padding_mask = PaddingMask.from_bool_tensor(pad)
        elif hasattr(PaddingMask, "from_bool"):
            padding_mask = PaddingMask.from_bool(pad)
        else:
            padding_mask = PaddingMask(pad)

    except Exception:
        padding_mask = None

    batch = SequenceBatch(seqs=toks, padding_mask=padding_mask)
    out = encoder(batch)

    if hasattr(out, "sentence_embeddings"):
        emb = out.sentence_embeddings
    elif isinstance(out, dict) and "sentence_embeddings" in out:
        emb = out["sentence_embeddings"]
    elif isinstance(out, (list, tuple)):
        emb = out[0]
    elif isinstance(out, torch.Tensor):
        emb = out
    else:
        raise RuntimeError(f"Unsupported SONAR encoder output type: {type(out)}")

    if emb.dim() != 2:
        raise RuntimeError(f"Unexpected embedding shape: {tuple(emb.shape)}")

    return emb


# =========================================================
# BLASER-QE offline load + scoring
# =========================================================
def load_blaser_qe_offline(
    blaser_ckpt: str,
    device: torch.device,
):
    if not os.path.isfile(blaser_ckpt):
        raise FileNotFoundError(f"BLASER-QE checkpoint not found: {blaser_ckpt}")

    cfg = _arch_blaser_basic_qe()
    model = create_blaser_model(cfg, device=device).eval()

    raw = torch.load(blaser_ckpt, map_location="cpu")
    candidate = raw

    if isinstance(candidate, dict) and "model" in candidate and isinstance(candidate["model"], dict):
        candidate = candidate["model"]
    elif isinstance(candidate, dict) and "state_dict" in candidate and isinstance(candidate["state_dict"], dict):
        candidate = candidate["state_dict"]

    try:
        state = convert_blaser_checkpoint(candidate, cfg)
    except Exception as e:
        print(f"[warn] convert_blaser_checkpoint failed, fallback to direct state_dict. err={repr(e)}")
        state = candidate

    if isinstance(state, dict) and "model" in state and isinstance(state["model"], dict):
        state = state["model"]

    missing, unexpected = model.load_state_dict(state, strict=False)

    if missing or unexpected:
        print(
            f"[warn] BLASER load_state_dict(strict=False): "
            f"missing={len(missing)} unexpected={len(unexpected)}"
        )

    return model


@torch.no_grad()
def blaser_qe_scores(
    blaser_model,
    src_emb: torch.Tensor,
    mt_emb: torch.Tensor,
) -> List[float]:
    try:
        s = blaser_model(src_emb, mt_emb)
    except TypeError:
        s = blaser_model(src=src_emb, mt=mt_emb)

    if isinstance(s, (tuple, list)):
        s = s[0]

    if s.dim() == 2 and s.size(-1) == 1:
        s = s.squeeze(-1)

    return s.detach().cpu().tolist()


# =========================================================
# COMET-QE offline load + scoring
# =========================================================
def load_comet_qe_offline(comet_ckpt: str):
    if not os.path.isfile(comet_ckpt):
        raise FileNotFoundError(f"COMET-QE checkpoint not found: {comet_ckpt}")

    print(f"[info] loading COMET-QE from: {comet_ckpt}")
    model = load_from_checkpoint(comet_ckpt)
    model.eval()
    return model


def extract_comet_scores(pred: Any) -> List[float]:
    if hasattr(pred, "scores"):
        return [float(x) for x in pred.scores]

    if isinstance(pred, dict) and "scores" in pred:
        return [float(x) for x in pred["scores"]]

    try:
        pred_dict = dict(pred)
        if "scores" in pred_dict:
            return [float(x) for x in pred_dict["scores"]]
    except Exception:
        pass

    if isinstance(pred, (list, tuple)):
        for item in pred:
            if isinstance(item, tuple) and len(item) == 2 and item[0] == "scores":
                return [float(x) for x in item[1]]

    raise RuntimeError(f"Cannot extract COMET scores from prediction object: {type(pred)} | {repr(pred)[:500]}")


def comet_qe_scores(
    comet_model,
    src_texts: List[str],
    mt_texts: List[str],
    device: torch.device,
    batch_size: int = 8,
) -> List[float]:
    if len(src_texts) != len(mt_texts):
        raise ValueError(f"src_texts and mt_texts length mismatch: {len(src_texts)} vs {len(mt_texts)}")

    data = [
        {
            "src": clean_text(src),
            "mt": clean_text(mt),
        }
        for src, mt in zip(src_texts, mt_texts)
    ]

    gpus = 1 if device.type == "cuda" else 0

    pred = comet_model.predict(
        data,
        batch_size=batch_size,
        gpus=gpus,
    )

    scores = extract_comet_scores(pred)

    if len(scores) != len(data):
        raise RuntimeError(f"COMET score count mismatch: got {len(scores)}, expected {len(data)}")

    return scores


# =========================================================
# Main
# =========================================================
def main():
    device = torch.device(DEVICE if torch.cuda.is_available() else "cpu")

    print("device:", device, "visible_cuda_count:", torch.cuda.device_count())
    print(f"[info] LANGUAGE={LANGUAGE}")
    print(f"[info] GPU={GPU}")
    print(f"[info] SRC_LANG={SRC_LANG}")
    print(f"[info] TGT_LANG={TGT_LANG}")
    print(f"[info] OUTPUT_ROOT={OUTPUT_ROOT}")
    print(f"[info] INPUT_JSONL={INPUT_JSONL}")
    print(f"[info] OUTPUT_SOURCE_BEST_JSONL={OUTPUT_SOURCE_BEST_JSONL}")
    print(f"[info] selection formula={SELECTION_FORMULA_VERSION}")
    print(f"[info] HF_HUB_OFFLINE={os.environ.get('HF_HUB_OFFLINE')}")
    print(f"[info] TRANSFORMERS_OFFLINE={os.environ.get('TRANSFORMERS_OFFLINE')}")
    print(f"[info] COMET_QE_CKPT={COMET_QE_CKPT}")

    rows = read_jsonl_records(INPUT_JSONL)
    total = len(rows)

    print(f"[info] loaded rows: {total}")

    if total == 0:
        print("[warn] no rows found.")
        return

    print("[info] loading SONAR encoder...")
    sonar_encoder, sp = load_sonar_text_encoder_offline(
        SONAR_MODEL,
        SPM_MODEL,
        device=device,
        max_seq_len=MAX_LEN,
    )

    print("[info] loading BLASER-QE...")
    blaser = load_blaser_qe_offline(
        BLASER_QE_CKPT,
        device=device,
    )

    print("[info] loading COMET-QE...")
    comet_model = load_comet_qe_offline(COMET_QE_CKPT)

    os.makedirs(OUTPUT_DIR, exist_ok=True)

    stats = defaultdict(int)
    stats["total"] = 0

    t_start = time.time()

    with open(OUTPUT_SOURCE_BEST_JSONL, "w", encoding="utf-8") as f_best:
        for b0 in range(0, total, BATCH_ROWS):
            b1 = min(b0 + BATCH_ROWS, total)
            batch = rows[b0:b1]

            src_texts: List[str] = []
            src_langs: List[str] = []
            mt_texts: List[str] = []
            row_meta: List[Tuple[int, int]] = []

            for row_idx, row in enumerate(batch):
                source_for_score, src_lang = get_source_for_score(row)
                candidates = get_candidate_texts(row)

                for cand_idx, cand in enumerate(candidates):
                    src_texts.append(source_for_score)
                    src_langs.append(src_lang)
                    mt_texts.append(cand)
                    row_meta.append((row_idx, cand_idx))

            src_emb_list: List[Optional[torch.Tensor]] = [None] * len(src_texts)
            lang_to_indices: Dict[str, List[int]] = {}

            for i, lg in enumerate(src_langs):
                lang_to_indices.setdefault(lg, []).append(i)

            for lg, idxs in lang_to_indices.items():
                sub_texts = [src_texts[i] for i in idxs]

                emb_sub = sonar_encode(
                    sonar_encoder,
                    sp,
                    sub_texts,
                    lang=lg,
                    device=device,
                    max_len=MAX_LEN,
                )

                for j, global_i in enumerate(idxs):
                    src_emb_list[global_i] = emb_sub[j]

            src_emb = torch.stack(src_emb_list, dim=0)

            mt_emb = sonar_encode(
                sonar_encoder,
                sp,
                mt_texts,
                lang=TGT_LANG,
                device=device,
                max_len=MAX_LEN,
            )

            blaser_scores_flat = blaser_qe_scores(
                blaser,
                src_emb,
                mt_emb,
            )

            comet_scores_flat = comet_qe_scores(
                comet_model=comet_model,
                src_texts=src_texts,
                mt_texts=mt_texts,
                device=device,
                batch_size=COMET_BATCH_SIZE,
            )

            blaser_score_map: Dict[Tuple[int, int], float] = {}
            comet_score_map: Dict[Tuple[int, int], float] = {}

            for k, (row_idx, cand_idx) in enumerate(row_meta):
                blaser_score_map[(row_idx, cand_idx)] = float(blaser_scores_flat[k])
                comet_score_map[(row_idx, cand_idx)] = float(comet_scores_flat[k])

            for row_idx, row in enumerate(batch):
                global_idx = b0 + row_idx + 1

                sid = clean_text(row.get("id", row.get("image_id", "")))
                source_text = clean_text(row.get("source_text", ""))
                reference_translation = get_reference_translation(row)

                if not reference_translation:
                    stats["missing_reference_translation"] += 1

                candidates = get_candidate_texts(row)

                blaser_scores = [
                    blaser_score_map[(row_idx, 0)],
                    blaser_score_map[(row_idx, 1)],
                    blaser_score_map[(row_idx, 2)],
                    blaser_score_map[(row_idx, 3)],
                ]

                comet_scores = [
                    comet_score_map[(row_idx, 0)],
                    comet_score_map[(row_idx, 1)],
                    comet_score_map[(row_idx, 2)],
                    comet_score_map[(row_idx, 3)],
                ]

                blaser_probs = softmax_scores(blaser_scores)
                comet_probs = softmax_scores(comet_scores)

                selected = select_best(
                    row=row,
                    blaser_scores=blaser_scores,
                    blaser_probs=blaser_probs,
                    comet_scores=comet_scores,
                    comet_probs=comet_probs,
                    candidates=candidates,
                )

                best_idx = selected["best_idx"]
                best_translation = selected["best_translation"]

                stats["total"] += 1

                selectable_candidates = [
                    i for i in [1, 2, 3]
                    if selected["selectable"][i]
                ]

                if selectable_candidates:
                    stats["selectable_candidate_rows"] += 1
                    stats["selectable_candidate_total"] += len(selectable_candidates)

                for i in [1, 2, 3]:
                    if candidate_is_changed(candidates[0], candidates[i]):
                        stats["changed_candidate_total"] += 1

                    if get_candidate_deterministic_allow(row, i):
                        stats["deterministic_allowed_candidate_total"] += 1

                    if candidate_stage_eligible(row, i) and candidate_stage_fields_present(row, i):
                        stats["candidate_stage_eligible_total"] += 1

                    if candidate_source_supported(row, i):
                        stats["source_supported_candidate_total"] += 1

                    if candidate_prior_fluency(row, i):
                        stats["prior_fluency_candidate_total"] += 1

                    if candidate_is_high_risk(row, i):
                        stats["high_risk_candidate_total"] += 1

                    if candidate_is_phrase_compression_repair(row, i):
                        stats["phrase_compression_repair_total"] += 1

                    if candidate_is_relation_repair(row, i):
                        stats["relation_repair_total"] += 1

                    reason = selected["block_reasons"][i]

                    if selected["selectable"][i]:
                        stats[f"admitted_{reason}"] += 1
                    else:
                        stats[f"blocked_{reason}"] += 1

                if best_idx == 0:
                    stats["keep_initial"] += 1
                else:
                    stats["replace_with_candidate"] += 1
                    stats[f"replace_candidate_{best_idx}"] += 1

                    if candidate_is_high_risk(row, best_idx):
                        stats["selected_high_risk_candidate"] += 1

                    if candidate_is_phrase_compression_repair(row, best_idx):
                        stats["selected_phrase_compression_repair"] += 1

                    if candidate_is_relation_repair(row, best_idx):
                        stats["selected_relation_repair"] += 1

                best_gate_type = get_candidate_probability_gate_type(row, best_idx) if best_idx > 0 else "initial"
                best_source_supported = candidate_source_supported(row, best_idx) if best_idx > 0 else False
                best_prior_fluency = candidate_prior_fluency(row, best_idx) if best_idx > 0 else False

                minimal_out = {
                    "id": sid,
                    "source_text": source_text,
                    "reference_translation": reference_translation,
                    "initial_translation": candidates[0],
                    "best_translation": best_translation,
                    "best_from": selected["best_from"],

                    "candidate_1": candidates[1],
                    "candidate_2": candidates[2],
                    "candidate_3": candidates[3],

                    "candidate_1_block_reason": selected["block_reasons"][1],
                    "candidate_2_block_reason": selected["block_reasons"][2],
                    "candidate_3_block_reason": selected["block_reasons"][3],

                    "candidate_1_ranking_priority": selected["ranking_priorities"][1],
                    "candidate_2_ranking_priority": selected["ranking_priorities"][2],
                    "candidate_3_ranking_priority": selected["ranking_priorities"][3],

                    "candidate_1_blaser_qe": blaser_scores[1],
                    "candidate_2_blaser_qe": blaser_scores[2],
                    "candidate_3_blaser_qe": blaser_scores[3],
                    "initial_blaser_qe": blaser_scores[0],

                    "candidate_1_comet_qe": comet_scores[1],
                    "candidate_2_comet_qe": comet_scores[2],
                    "candidate_3_comet_qe": comet_scores[3],
                    "initial_comet_qe": comet_scores[0],

                    "best_candidate_gate_type": best_gate_type,
                    "best_candidate_source_supported": best_source_supported,
                    "best_candidate_prior_fluency": best_prior_fluency,

                    "selection_formula_version": SELECTION_FORMULA_VERSION,
                    "language": LANGUAGE,
                    "src_lang": SRC_LANG,
                    "tgt_lang": TGT_LANG,
                }

                write_jsonl_record(f_best, minimal_out)

                if global_idx % 10 == 0 or global_idx == total:
                    elapsed = time.time() - t_start
                    avg = elapsed / global_idx
                    eta = avg * (total - global_idx)

                    print(
                        f"[{global_idx}/{total}] "
                        f"id={sid} | best={selected['best_from']} | "
                        f"elapsed={format_time(elapsed)} | ETA={format_time(eta)}"
                    )

            if torch.cuda.is_available():
                torch.cuda.empty_cache()

    print("[DONE]")
    print(f"[DONE] output: {OUTPUT_SOURCE_BEST_JSONL}")
    print("[stats]", dict(stats))

    if stats["missing_reference_translation"] > 0:
        print(
            f"[WARN] {stats['missing_reference_translation']} rows have empty reference_translation. "
            f"Please check whether candidate output already contains reference_translation."
        )


if __name__ == "__main__":
    main()