#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import argparse

# =====================================================
# 0. 命令行参数：必须在导入 bleurt / tensorflow 前设置 GPU
# =====================================================
ALLOWED_LANGUAGES = {"hi", "lv", "tr"}


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--lang",
        type=str,
        required=True,
        choices=sorted(ALLOWED_LANGUAGES),
        help="Language code: hi, lv, tr.",
    )
    parser.add_argument(
        "--gpu",
        type=str,
        required=True,
        help="Physical GPU id, for example: 0, 1, 5, 6, 7.",
    )
    return parser.parse_args()


ARGS = parse_args()
LANGUAGE = ARGS.lang
GPU = ARGS.gpu

os.environ["CUDA_VISIBLE_DEVICES"] = str(GPU)
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "2"

import json
from statistics import mean
from typing import List, Dict, Any

from bleurt import score as bleurt_score


# =====================================================
# 1. 路径配置
# =====================================================
OUTPUT_ROOT = "/home/chenyi/offline_blaser_qe/out/Qwen_3_VL_8B/Multi30k"

INPUT_JSONL = os.path.join(
    OUTPUT_ROOT,
    LANGUAGE,
    f"{LANGUAGE}_source_reference_best.jsonl",
)

OUTPUT_DIR = os.path.join(
    OUTPUT_ROOT,
    LANGUAGE,
)

OUTPUT_JSONL = os.path.join(
    OUTPUT_DIR,
    f"{LANGUAGE}_source_reference_best_bleurt.jsonl",
)

# BLEURT-20 模型目录
BLEURT_CHECKPOINT = "/mnt/raid/gzy/bleurt_model/BLEURT-20"

# 每批打分数量，显存不足时可以调小
BATCH_SIZE = 32


# =====================================================
# 2. 基础工具
# =====================================================
def clean_text(x: Any) -> str:
    if x is None:
        return ""
    return str(x).strip()


def first_nonempty(row: Dict[str, Any], keys: List[str]) -> str:
    for key in keys:
        value = clean_text(row.get(key, ""))
        if value:
            return value
    return ""


def read_jsonl(path: str) -> List[Dict[str, Any]]:
    if not os.path.exists(path):
        raise FileNotFoundError(f"找不到输入文件: {path}")

    rows = []

    with open(path, "r", encoding="utf-8") as f:
        for line_no, line in enumerate(f, 1):
            line = line.strip()

            if not line:
                continue

            try:
                row = json.loads(line)
            except Exception as e:
                raise ValueError(f"第 {line_no} 行不是合法 JSON: {e}")

            rows.append(row)

    return rows


def write_jsonl(path: str, rows: List[Dict[str, Any]]) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)

    with open(path, "w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


def get_row_id(row: Dict[str, Any]) -> Any:
    return row.get("id", row.get("image_id", ""))


def get_reference_translation(row: Dict[str, Any]) -> str:
    return first_nonempty(
        row,
        [
            "reference_translation",
            "src_en",
            "source_text_en",
            "reference",
            "source",
        ],
    )


def get_best_translation(row: Dict[str, Any]) -> str:
    return first_nonempty(
        row,
        [
            "best_translation",
            "best",
            "selected_translation",
        ],
    )


def get_initial_translation(row: Dict[str, Any]) -> str:
    return first_nonempty(
        row,
        [
            "initial_translation",
            "initial_translation_en",
            "translation",
            "mt",
        ],
    )


# =====================================================
# 3. BLEURT 打分
# =====================================================
def compute_bleurt_scores(
    scorer,
    references: List[str],
    candidates: List[str],
    batch_size: int = 32,
) -> List[float]:
    all_scores = []

    total = len(references)

    for start in range(0, total, batch_size):
        end = min(start + batch_size, total)

        refs_batch = references[start:end]
        cands_batch = candidates[start:end]

        scores = scorer.score(
            references=refs_batch,
            candidates=cands_batch,
        )

        all_scores.extend(scores)

        print(f"[INFO] BLEURT scored {end}/{total}")

    return all_scores


# =====================================================
# 4. 主流程
# =====================================================
def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    print(f"[INFO] LANGUAGE: {LANGUAGE}")
    print(f"[INFO] GPU: {GPU}")
    print(f"[INFO] CUDA_VISIBLE_DEVICES: {os.environ.get('CUDA_VISIBLE_DEVICES')}")
    print(f"[INFO] OUTPUT_ROOT: {OUTPUT_ROOT}")
    print(f"[INFO] 输入文件: {INPUT_JSONL}")
    print(f"[INFO] 输出 JSONL: {OUTPUT_JSONL}")
    print(f"[INFO] BLEURT_CHECKPOINT: {BLEURT_CHECKPOINT}")
    print(f"[INFO] BATCH_SIZE: {BATCH_SIZE}")

    rows = read_jsonl(INPUT_JSONL)
    print(f"[INFO] 读取样本数: {len(rows)}")

    if not rows:
        raise ValueError("输入文件为空，无法打分。")

    references = []
    candidates = []
    valid_rows = []
    skipped_rows = []

    for row in rows:
        ref = get_reference_translation(row)
        hyp = get_best_translation(row)

        if not ref or not hyp:
            skipped_rows.append({
                "id": row.get("id", ""),
                "image_id": row.get("image_id", ""),
                "language": LANGUAGE,
                "reason": "empty_reference_or_best_translation",
                "reference_translation": ref,
                "best_translation": hyp,
            })
            continue

        references.append(ref)
        candidates.append(hyp)
        valid_rows.append(row)

    print(f"[INFO] 有效打分样本数: {len(valid_rows)}")
    print(f"[INFO] 跳过样本数: {len(skipped_rows)}")

    if not valid_rows:
        raise ValueError("没有有效样本：reference_translation 或 best_translation 全为空。")

    print(f"[INFO] 正在加载 BLEURT 模型: {BLEURT_CHECKPOINT}")

    if not os.path.exists(BLEURT_CHECKPOINT):
        raise FileNotFoundError(f"找不到 BLEURT 模型路径: {BLEURT_CHECKPOINT}")

    scorer = bleurt_score.BleurtScorer(BLEURT_CHECKPOINT)
    print("[INFO] BLEURT 模型加载完成。")

    print("[INFO] 开始 BLEURT 打分...")

    scores_raw = compute_bleurt_scores(
        scorer=scorer,
        references=references,
        candidates=candidates,
        batch_size=BATCH_SIZE,
    )

    scored_rows = []

    for row, score in zip(valid_rows, scores_raw):
        reference_translation = get_reference_translation(row)
        best_translation = get_best_translation(row)
        initial_translation = get_initial_translation(row)

        out = {
            "id": clean_text(get_row_id(row)),
            "image_id": row.get("image_id", row.get("id", "")),
            "language": LANGUAGE,
            "source_text": clean_text(row.get("source_text", "")),
            "reference_translation": reference_translation,
            "initial_translation": initial_translation,
            "best_translation": best_translation,
            "best_from": clean_text(row.get("best_from", "")),
            "bleurt_raw": round(float(score), 6),
            "bleurt_100": round(float(score) * 100, 2),
        }

        scored_rows.append(out)

    avg_raw = mean([float(x) for x in scores_raw])
    avg_100 = avg_raw * 100

    write_jsonl(OUTPUT_JSONL, scored_rows)

    print("\n[DONE] BLEURT 打分完成。")
    print(f"[RESULT] language = {LANGUAGE}")
    print(f"[RESULT] total rows = {len(rows)}")
    print(f"[RESULT] valid scored rows = {len(valid_rows)}")
    print(f"[RESULT] skipped rows = {len(skipped_rows)}")
    print(f"[RESULT] average BLEURT raw = {avg_raw:.6f}")
    print(f"[RESULT] average BLEURT x100 = {avg_100:.2f}")
    print(f"[SAVE] JSONL: {OUTPUT_JSONL}")

    if skipped_rows:
        print("[WARN] 存在跳过样本。原因通常是 reference_translation 或 best_translation 为空。")


if __name__ == "__main__":
    main()