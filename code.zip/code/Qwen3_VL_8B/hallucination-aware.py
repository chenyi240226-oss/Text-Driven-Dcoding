import os
os.environ["CUDA_VISIBLE_DEVICES"] = "2"
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"

import re
import json
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from PIL import Image
import torch
import torch.nn as nn
import torch.nn.functional as F

from transformers import AutoProcessor, AutoModelForVision2Seq

torch.set_grad_enabled(False)

# =========================================================
# PATHS
# =========================================================
QWEN_PATH = "/mnt/raid/hss/model/Qwen3-VL-8B-Instruct"

INPUT_JSONL = "/home/chenyi/offline_blaser_qe/out/Qwen_3_VL_8B/Multi30k/hi/hi_test_translation.jsonl"
IMAGE_DIR = "/mnt/raid/wjx/vision-rag-mt/images_multi30k"

OUTPUT_JSON = "/home/chenyi/offline_blaser_qe/out/Qwen_3_VL_8B/Multi30k/hi/hi_hallucination_aware_layers.json"

# =========================================================
# RUN CONTROL
# =========================================================
MAX_ROWS = 200
TOP_K_LAYERS = 4
MAX_TARGET_TOKENS = 96
DTYPE = torch.bfloat16 if torch.cuda.is_available() else torch.float32

ALPHA = 1.0   # || z_xi - z_x ||
BETA = 1.0    # || z_xi - z_n ||
GAMMA = 1.0   # token 权重中的 logprob gap
EPS = 1e-8

# 是否打印模块扫描信息
PRINT_MODEL_SCAN = True

# =========================================================
# BASIC UTILS
# =========================================================
def clean_text(x) -> str:
    if x is None:
        return ""
    x = str(x).strip()
    x = re.sub(r"\s+", " ", x)
    return x

def ensure_dir(path: str):
    Path(path).parent.mkdir(parents=True, exist_ok=True)

def load_jsonl(path: str) -> List[Dict]:
    rows = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows

def load_image(path: str) -> Optional[Image.Image]:
    if not path or not os.path.isfile(path):
        return None
    try:
        return Image.open(path).convert("RGB")
    except Exception:
        return None

def resolve_image_path(row: Dict) -> str:
    for key in ["image_path", "image", "img_path"]:
        v = clean_text(row.get(key, ""))
        if v and os.path.isfile(v):
            return v

    image_id = row.get("image_id", row.get("id", ""))
    image_id = clean_text(image_id)
    if image_id:
        candidates = [
            os.path.join(IMAGE_DIR, f"{image_id}.jpg"),
            os.path.join(IMAGE_DIR, f"{image_id}.jpeg"),
            os.path.join(IMAGE_DIR, f"{image_id}.png"),
        ]
        for p in candidates:
            if os.path.isfile(p):
                return p
    return ""

def get_source_text(row: Dict) -> str:
    for key in ["source_text", "target", "src", "tgt"]:
        v = clean_text(row.get(key, ""))
        if v:
            return v
    return ""

def get_initial_translation(row: Dict) -> str:
    for key in ["initial_translation", "initial_translation_en", "translation", "mt"]:
        v = clean_text(row.get(key, ""))
        if v:
            return v
    return ""

# =========================================================
# MODEL LOADING
# =========================================================
print("Loading model...")
processor = AutoProcessor.from_pretrained(QWEN_PATH, trust_remote_code=True)
model = AutoModelForVision2Seq.from_pretrained(
    QWEN_PATH,
    torch_dtype=DTYPE,
    device_map="auto",
    trust_remote_code=True
).eval()
print("Model loaded.")

# =========================================================
# AUTO-FIND TEXT LAYERS / FFN MODULES
# =========================================================
def _is_transformer_block_list(x):
    if not isinstance(x, (nn.ModuleList, list, tuple)):
        return False
    if len(x) < 4:
        return False

    hit = 0
    for layer in x[: min(len(x), 8)]:
        if not hasattr(layer, "named_children"):
            continue
        names = set(dict(layer.named_children()).keys())
        if ("self_attn" in names or "attn" in names or "attention" in names) and \
           ("mlp" in names or "feed_forward" in names or "ffn" in names or "ff" in names):
            hit += 1
    return hit >= max(2, min(len(x), 4) // 2)

def _score_layer_container(name, container):
    score = 0
    lname = name.lower()

    if "language" in lname:
        score += 5
    if "model.layers" in lname or lname.endswith(".layers") or lname == "layers":
        score += 4
    if "decoder.layers" in lname:
        score += 3
    if "visual" in lname or "vision" in lname or "image" in lname:
        score -= 6
    if "encoder" in lname and "vision" in lname:
        score -= 6

    first = container[0]
    child_names = set(dict(first.named_children()).keys())
    if "mlp" in child_names:
        score += 3
    if "self_attn" in child_names or "attn" in child_names or "attention" in child_names:
        score += 3

    return score

def get_text_layers(model):
    candidates = []

    explicit_paths = [
        "language_model.model.layers",
        "language_model.layers",
        "model.layers",
        "model.decoder.layers",
        "decoder.layers",
        "layers",
    ]

    for path in explicit_paths:
        cur = model
        ok = True
        for p in path.split("."):
            if hasattr(cur, p):
                cur = getattr(cur, p)
            else:
                ok = False
                break
        if ok and _is_transformer_block_list(cur):
            candidates.append((path, cur, _score_layer_container(path, cur)))

    for name, module in model.named_modules():
        for child_name, child in module.named_children():
            full_name = f"{name}.{child_name}" if name else child_name
            if _is_transformer_block_list(child):
                candidates.append((full_name, child, _score_layer_container(full_name, child)))

    uniq = {}
    for name, container, score in candidates:
        uniq[id(container)] = (name, container, score)
    candidates = list(uniq.values())

    if not candidates:
        print("=== Top-level modules ===")
        for n, _ in model.named_children():
            print(n)
        raise RuntimeError("Cannot locate transformer layers automatically.")

    candidates = sorted(candidates, key=lambda x: x[2], reverse=True)
    best_name, best_layers, best_score = candidates[0]

    print(f"[info] selected text layers from: {best_name} | score={best_score} | num_layers={len(best_layers)}")
    if PRINT_MODEL_SCAN:
        print("[info] other candidates:")
        for name, container, score in candidates[:10]:
            print(f"  - {name} | score={score} | num_layers={len(container)}")

    return best_layers

def get_ffn_module(layer):
    if hasattr(layer, "mlp"):
        return layer.mlp
    for name in ["feed_forward", "ffn", "ff"]:
        if hasattr(layer, name):
            return getattr(layer, name)

    print("[debug] layer children:", list(dict(layer.named_children()).keys()))
    raise RuntimeError("Cannot locate FFN/MLP module inside a transformer layer.")

if PRINT_MODEL_SCAN:
    print("=== Top-level modules ===")
    for n, _ in model.named_children():
        print(n)

    print("\n=== Candidate module names containing 'layer' / 'model' / 'language' ===")
    shown = 0
    for n, _ in model.named_modules():
        if any(k in n.lower() for k in ["layer", "layers", "model", "language", "decoder"]):
            print(n)
            shown += 1
            if shown >= 200:
                print("... (truncated)")
                break

TEXT_LAYERS = get_text_layers(model)
NUM_LAYERS = len(TEXT_LAYERS)
print(f"Detected {NUM_LAYERS} transformer layers.")

FFN_MODULES = [get_ffn_module(layer) for layer in TEXT_LAYERS]

# =========================================================
# HOOKED FORWARD
# =========================================================
def run_forward_collect_ffn_outputs(
    *,
    prefix_text: str,
    target_text: str,
    image: Optional[Image.Image]
) -> Tuple[torch.Tensor, List[torch.Tensor], Tuple[int, int]]:
    """
    返回：
    - target token 的 logprobs: [target_len]
    - 每层 FFN 输出: list of [target_len, hidden]
    - (prefix_len, target_len)
    """
    if image is not None:
        prefix_inputs = processor(
            text=[prefix_text],
            images=[image],
            padding=True,
            return_tensors="pt"
        )
        full_inputs = processor(
            text=[prefix_text + target_text],
            images=[image],
            padding=True,
            return_tensors="pt"
        )
    else:
        prefix_inputs = processor(
            text=[prefix_text],
            padding=True,
            return_tensors="pt"
        )
        full_inputs = processor(
            text=[prefix_text + target_text],
            padding=True,
            return_tensors="pt"
        )

    prefix_len = int(prefix_inputs["input_ids"].shape[1])
    full_len = int(full_inputs["input_ids"].shape[1])
    target_len = full_len - prefix_len

    if target_len <= 0:
        raise RuntimeError("Target length <= 0. Cannot align target tokens.")

    if target_len > MAX_TARGET_TOKENS:
        target_len = MAX_TARGET_TOKENS
        trunc_len = prefix_len + target_len
        for k, v in full_inputs.items():
            if isinstance(v, torch.Tensor) and v.ndim >= 2 and v.shape[1] >= trunc_len:
                full_inputs[k] = v[:, :trunc_len]

    layer_outs = [None] * NUM_LAYERS
    handles = []

    def make_hook(i):
        def hook_fn(module, inp, out):
            o = out[0] if isinstance(out, tuple) else out
            layer_outs[i] = o.detach()
        return hook_fn

    for i, m in enumerate(FFN_MODULES):
        handles.append(m.register_forward_hook(make_hook(i)))

    model_inputs = {}
    for k, v in full_inputs.items():
        model_inputs[k] = v.to(model.device) if isinstance(v, torch.Tensor) else v

    with torch.no_grad():
        outputs = model(**model_inputs)

    for h in handles:
        h.remove()

    logits = outputs.logits.detach()   # [1, seq, vocab]
    input_ids = model_inputs["input_ids"]

    start = prefix_len
    end = prefix_len + target_len

    cond_logits = logits[:, start - 1:end - 1, :]
    target_ids = input_ids[:, start:end]

    log_probs = F.log_softmax(cond_logits, dim=-1)
    token_logprobs = log_probs.gather(-1, target_ids.unsqueeze(-1)).squeeze(-1).squeeze(0)

    target_layer_outs = []
    for i in range(NUM_LAYERS):
        o = layer_outs[i]
        if o is None:
            raise RuntimeError(f"Layer {i} hook did not capture output.")
        target_o = o[0, start:end, :].float().cpu()
        target_layer_outs.append(target_o)

    return token_logprobs.float().cpu(), target_layer_outs, (prefix_len, target_len)

# =========================================================
# PROMPTS
# =========================================================
def build_xi_prefix(source_text: str) -> str:
    return (
        "Translate the source sentence into English.\n"
        f"Source: {source_text}\n"
        "Translation:"
    )

def build_x_prefix(source_text: str) -> str:
    return (
        "Translate the source sentence into English.\n"
        f"Source: {source_text}\n"
        "Translation:"
    )

def build_n_prefix() -> str:
    return (
        "Continue the English text.\n"
        "Translation:"
    )

# =========================================================
# LAYER SCORE
# =========================================================
def compute_layer_scores_for_sample(
    source_text: str,
    target_text: str,
    image: Optional[Image.Image]
) -> Dict:
    """
    对单条样本：
    - xi: source + image
    - x : source only
    - n : language prior only
    计算每层 FFN 跨条件差分分数
    """
    logp_xi, ffn_xi, (_, tlen_xi) = run_forward_collect_ffn_outputs(
        prefix_text=build_xi_prefix(source_text),
        target_text=target_text,
        image=image
    )
    logp_x, ffn_x, (_, tlen_x) = run_forward_collect_ffn_outputs(
        prefix_text=build_x_prefix(source_text),
        target_text=target_text,
        image=None
    )
    logp_n, ffn_n, (_, tlen_n) = run_forward_collect_ffn_outputs(
        prefix_text=build_n_prefix(),
        target_text=target_text,
        image=None
    )

    tlen = min(tlen_xi, tlen_x, tlen_n)
    logp_xi = logp_xi[:tlen]
    logp_x = logp_x[:tlen]
    logp_n = logp_n[:tlen]

    gap = torch.clamp(logp_x - logp_xi, min=0.0)
    weights = 1.0 + GAMMA * gap

    layer_stats = []

    for l in range(NUM_LAYERS):
        z_xi = ffn_xi[l][:tlen]
        z_x = ffn_x[l][:tlen]
        z_n = ffn_n[l][:tlen]

        d_xi_x = torch.norm(z_xi - z_x, p=2, dim=-1)
        d_xi_n = torch.norm(z_xi - z_n, p=2, dim=-1)

        score_tokens = ALPHA * d_xi_x + BETA * d_xi_n
        score = (score_tokens * weights).mean().item()

        layer_stats.append({
            "layer": l,
            "score": float(score),
            "mean_d_xi_x": float(d_xi_x.mean().item()),
            "mean_d_xi_n": float(d_xi_n.mean().item()),
            "mean_weight": float(weights.mean().item()),
            "target_len": int(tlen),
        })

    return {
        "target_len": int(tlen),
        "layer_stats": layer_stats,
    }

# =========================================================
# MAIN
# =========================================================
def main():
    rows = load_jsonl(INPUT_JSONL)
    if MAX_ROWS is not None:
        rows = rows[:MAX_ROWS]

    print(f"Loaded {len(rows)} rows from {INPUT_JSONL}")

    valid_rows = []
    for row in rows:
        src = get_source_text(row)
        mt = get_initial_translation(row)
        img_path = resolve_image_path(row)
        if src and mt:
            valid_rows.append({
                "id": clean_text(row.get("id", row.get("image_id", ""))),
                "source_text": src,
                "initial_translation": mt,
                "image_path": img_path,
            })

    print(f"Valid rows: {len(valid_rows)}")

    layer_score_sum = torch.zeros(NUM_LAYERS, dtype=torch.float64)
    layer_count = torch.zeros(NUM_LAYERS, dtype=torch.float64)

    sample_logs = []

    for idx, row in enumerate(valid_rows, 1):
        sid = row["id"]
        src = row["source_text"]
        mt = row["initial_translation"]
        img_path = row["image_path"]

        image = load_image(img_path) if img_path else None

        try:
            out = compute_layer_scores_for_sample(
                source_text=src,
                target_text=mt,
                image=image
            )

            per_layer = out["layer_stats"]
            for item in per_layer:
                l = item["layer"]
                layer_score_sum[l] += item["score"]
                layer_count[l] += 1.0

            sample_logs.append({
                "id": sid,
                "target_len": out["target_len"],
                "top_layers_for_sample": sorted(
                    [{"layer": x["layer"], "score": round(x["score"], 6)} for x in per_layer],
                    key=lambda z: z["score"],
                    reverse=True
                )[:TOP_K_LAYERS]
            })

            top_show = sorted(per_layer, key=lambda z: z["score"], reverse=True)[:3]
            top_show_str = ", ".join([f"L{x['layer']}={x['score']:.4f}" for x in top_show])
            print(f"[{idx}/{len(valid_rows)}] {sid} | {top_show_str}")

        except Exception as e:
            print(f"[{idx}/{len(valid_rows)}] {sid} | ERROR: {repr(e)}")

        if image is not None:
            image.close()

        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            torch.cuda.ipc_collect()

    global_layer_stats = []
    for l in range(NUM_LAYERS):
        avg_score = (layer_score_sum[l] / max(layer_count[l], 1.0)).item()
        global_layer_stats.append({
            "layer": l,
            "avg_score": float(avg_score),
            "count": int(layer_count[l].item()),
        })

    global_layer_stats = sorted(global_layer_stats, key=lambda z: z["avg_score"], reverse=True)
    top_layers = [x["layer"] for x in global_layer_stats[:TOP_K_LAYERS]]

    result = {
        "config": {
            "model_path": QWEN_PATH,
            "input_jsonl": INPUT_JSONL,
            "image_dir": IMAGE_DIR,
            "max_rows": MAX_ROWS,
            "top_k_layers": TOP_K_LAYERS,
            "max_target_tokens": MAX_TARGET_TOKENS,
            "alpha": ALPHA,
            "beta": BETA,
            "gamma": GAMMA,
            "score_definition": "mean_t[(alpha*||z_xi-z_x||_2 + beta*||z_xi-z_n||_2) * (1 + gamma*ReLU(logp_x-logp_xi))]",
            "notes": "No training. Teacher-forcing on initial translation. FFN outputs only."
        },
        "num_layers": NUM_LAYERS,
        "num_valid_rows": len(valid_rows),
        "selected_top_layers": top_layers,
        "global_layer_ranking": [
            {
                "layer": x["layer"],
                "avg_score": round(x["avg_score"], 6),
                "count": x["count"],
            }
            for x in global_layer_stats
        ],
        "sample_logs_preview": sample_logs[:20],
    }

    ensure_dir(OUTPUT_JSON)
    with open(OUTPUT_JSON, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    print("\nDone.")
    print("Top hallucination-aware layers:", top_layers)
    print("Saved to:", OUTPUT_JSON)

if __name__ == "__main__":
    main()