#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import argparse

# =========================
# 命令行参数：必须在 import torch 前解析并设置 GPU
# =========================
ALLOWED_LANGUAGES = {"hi", "ha", "bn", "ma"}

SOURCE_LANGUAGE_NAME_MAP = {
    "hi": "Hindi",
    "ha": "Hausa",
    "bn": "Bengali",
    "ma": "Malayalam",
}


def parse_args():
    parser = argparse.ArgumentParser(
        description="Qwen3-VL VG image-assisted translation for hi/ha/bn/ma."
    )
    parser.add_argument(
        "--lang",
        type=str,
        required=True,
        choices=sorted(ALLOWED_LANGUAGES),
        help="Language code: hi, ha, bn, ma.",
    )
    parser.add_argument(
        "--gpu",
        type=str,
        required=True,
        help="Physical GPU id, for example: 0, 1, 5, 6, 7.",
    )
    return parser.parse_args()


ARGS = parse_args()
LANGUAGE = ARGS.lang.strip().lower()
GPU = str(ARGS.gpu).strip()
SOURCE_LANGUAGE_NAME = SOURCE_LANGUAGE_NAME_MAP[LANGUAGE]

os.environ["CUDA_VISIBLE_DEVICES"] = GPU
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"

import json
import time
import re
from typing import Any, Dict, List, Optional

import torch

# =========================
# Torch compatibility patch
# =========================
if not hasattr(torch, "compiler"):
    class _DummyCompiler:
        @staticmethod
        def is_compiling():
            return False
    torch.compiler = _DummyCompiler()
else:
    if not hasattr(torch.compiler, "is_compiling"):
        torch.compiler.is_compiling = lambda: False

from PIL import Image
from transformers import AutoProcessor, AutoModelForVision2Seq

# =========================
# 路径配置
# =========================
VG_DATA_ROOT = "/home/chenyi/offline_blaser_qe/dataSet/VG"
IMAGE_DIR = "/home/chenyi/offline_blaser_qe/dataSet/VG/images"

OUTPUT_ROOT = "/home/chenyi/offline_blaser_qe/out/Qwen_3_VL_8B/VG"

INPUT_JSONL = os.path.join(
    VG_DATA_ROOT,
    LANGUAGE,
    f"{LANGUAGE}_vg_test.jsonl",
)

OUTPUT_DIR = os.path.join(
    OUTPUT_ROOT,
    LANGUAGE,
)

OUTPUT_JSONL = os.path.join(
    OUTPUT_DIR,
    f"{LANGUAGE}_test_translation.jsonl",
)

QWEN_PATH = "/mnt/raid/hss/model/Qwen3-VL-8B-Instruct"

# =========================
# 参数
# =========================
DTYPE = torch.bfloat16 if torch.cuda.is_available() else torch.float32

# 设为 None 跑全部；设为整数只跑前 N 条
MAX_SAMPLES = None

FLUSH_EVERY = 20
MAX_NEW_TOKENS = 64

TARGET_LANG_NAME = "English"

torch.set_grad_enabled(False)

# =========================
# system prompt
# =========================
SYSTEM_PROMPT_TEMPLATE = (
    "/no_think\n"
    "You are a professional translator.\n"
    "Your job is to translate the given {source_lang_name} source sentence into {target_lang_name}.\n"
    "STRICT RULES:\n"
    "1) Faithful: Do NOT add, remove, or change objects, attributes, actions, or relations.\n"
    "2) Use the image only when it helps resolve ambiguity.\n"
    "3) Do not turn the task into image captioning.\n"
    "4) Output ONLY the translation in {target_lang_name}. No explanations.\n"
    "5) NEVER output any <think>...</think> content.\n"
)


# =========================
# 基础工具
# =========================
def clean_text(x: Any) -> str:
    if x is None:
        return ""
    return re.sub(r"\s+", " ", str(x).strip())


def format_time(seconds: float) -> str:
    seconds = max(0, int(seconds))
    h = seconds // 3600
    m = (seconds % 3600) // 60
    s = seconds % 60
    return f"{h:02d}:{m:02d}:{s:02d}"


def load_jsonl(path: str) -> List[Dict[str, Any]]:
    if not os.path.isfile(path):
        raise FileNotFoundError(f"Input JSONL not found: {path}")

    data = []

    with open(path, "r", encoding="utf-8") as f:
        for line_no, line in enumerate(f, 1):
            line = line.strip()

            if not line:
                continue

            try:
                data.append(json.loads(line))
            except Exception as e:
                print(f"[Warn] bad_json_line={line_no} | {repr(e)}")
                continue

            if MAX_SAMPLES is not None and len(data) >= MAX_SAMPLES:
                break

    return data


def cleanup_cuda():
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        torch.cuda.ipc_collect()


def get_row_id(item: Dict[str, Any]) -> Any:
    return item.get("id", item.get("image_id", ""))


def get_image_id(item: Dict[str, Any]) -> Any:
    return item.get("image_id", item.get("id", ""))


def first_nonempty(item: Dict[str, Any], keys: List[str]) -> str:
    for key in keys:
        value = clean_text(item.get(key, ""))
        if value:
            return value
    return ""


def get_source_text(item: Dict[str, Any]) -> str:
    """
    VG 原语言字段兼容：
    - source_text: 常见统一字段
    - target / tgt / src: 兼容不同预处理版本
    - source_lang_text / text: 兜底
    """
    return first_nonempty(
        item,
        [
            "source_text",
            "target",
            "tgt",
            "src",
            "source_lang_text",
            "text",
        ],
    )


def get_reference_translation(item: Dict[str, Any]) -> str:
    """
    英文参考译文字段兼容：
    - reference_translation
    - src_en / source_text_en
    - reference
    - source
    """
    return first_nonempty(
        item,
        [
            "reference_translation",
            "src_en",
            "source_text_en",
            "reference",
            "source",
        ],
    )


def resolve_image_path(item: Dict[str, Any]) -> Optional[str]:
    """
    优先使用样本中已有图片路径；
    若没有，则用 id / image_id 到 IMAGE_DIR 下查找。
    """
    for key in ["image_path", "image", "img_path"]:
        image_path = clean_text(item.get(key, ""))

        if image_path and os.path.isfile(image_path):
            return image_path

    image_id = clean_text(get_image_id(item))

    if not image_id:
        return None

    candidates = [
        os.path.join(IMAGE_DIR, f"{image_id}.jpg"),
        os.path.join(IMAGE_DIR, f"{image_id}.jpeg"),
        os.path.join(IMAGE_DIR, f"{image_id}.png"),
        os.path.join(IMAGE_DIR, f"{image_id}.JPG"),
        os.path.join(IMAGE_DIR, f"{image_id}.JPEG"),
        os.path.join(IMAGE_DIR, f"{image_id}.PNG"),
    ]

    for path in candidates:
        if os.path.isfile(path):
            return path

    return None


def is_effectively_empty_output(text: str) -> bool:
    if text is None:
        return True

    text = str(text).strip()

    if not text:
        return True

    if re.fullmatch(r"[\s\.\,\!\?\:\;\"\'\-\(\)\[\]\{\}]+", text):
        return True

    lower = text.lower()

    bad_patterns = [
        "i can't",
        "i cannot",
        "cannot determine",
        "cannot translate",
        "unable to",
        "no translation",
        "no output",
        "sorry",
        "as an ai",
    ]

    if any(p in lower for p in bad_patterns):
        return True

    return False


def clean_generation_text(text: str) -> str:
    text = str(text).strip()
    text = re.sub(r"^\s*(translation\s*[:：-]\s*)", "", text, flags=re.I)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def strip_think_blocks(text: str) -> str:
    if not text:
        return text

    text = re.sub(
        r"<think>.*?</think>",
        "",
        text,
        flags=re.DOTALL | re.IGNORECASE,
    )
    text = re.sub(r"</?think>", "", text, flags=re.IGNORECASE)

    return text.strip()


# =========================
# 模型加载
# =========================
def load_model():
    print("[Info] Loading model ...")
    print(f"[Info] LANGUAGE: {LANGUAGE}")
    print(f"[Info] SOURCE_LANGUAGE_NAME: {SOURCE_LANGUAGE_NAME}")
    print(f"[Info] GPU: {GPU}")
    print(f"[Info] CUDA_VISIBLE_DEVICES: {os.environ.get('CUDA_VISIBLE_DEVICES')}")
    print(f"[Info] QWEN_PATH: {QWEN_PATH}")
    print(f"[Info] VG_DATA_ROOT: {VG_DATA_ROOT}")
    print(f"[Info] IMAGE_DIR: {IMAGE_DIR}")
    print(f"[Info] INPUT_JSONL: {INPUT_JSONL}")
    print(f"[Info] OUTPUT_JSONL: {OUTPUT_JSONL}")

    processor = AutoProcessor.from_pretrained(
        QWEN_PATH,
        trust_remote_code=True,
    )

    model = AutoModelForVision2Seq.from_pretrained(
        QWEN_PATH,
        torch_dtype=DTYPE,
        device_map="auto",
        trust_remote_code=True,
    )

    model.eval()

    print("[Info] Model loaded.")
    return model, processor


# =========================
# 翻译生成
# =========================
def build_messages(image: Image.Image, src: str):
    system_prompt = SYSTEM_PROMPT_TEMPLATE.format(
        source_lang_name=SOURCE_LANGUAGE_NAME,
        target_lang_name=TARGET_LANG_NAME,
    )

    user_text = (
        f"{SOURCE_LANGUAGE_NAME} SOURCE:\n"
        f"{src}\n\n"
        f"Translate into {TARGET_LANG_NAME}."
    )

    messages = [
        {
            "role": "system",
            "content": [
                {
                    "type": "text",
                    "text": system_prompt,
                }
            ],
        },
        {
            "role": "user",
            "content": [
                {
                    "type": "image",
                    "image": image,
                },
                {
                    "type": "text",
                    "text": user_text,
                },
            ],
        },
    ]

    return messages


def translate(
    model,
    processor,
    image: Image.Image,
    src: str,
    image_id: Any = "",
) -> str:
    messages = build_messages(image, src)

    try:
        text = processor.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True,
        )

        inputs = processor(
            text=[text],
            images=[image],
            padding=True,
            return_tensors="pt",
        )

        prepared_inputs = {}

        for k, v in inputs.items():
            if hasattr(v, "to"):
                prepared_inputs[k] = v.to(model.device)
            else:
                prepared_inputs[k] = v

        eos_token_id = getattr(processor.tokenizer, "eos_token_id", None)
        pad_token_id = getattr(processor.tokenizer, "pad_token_id", None)

        if pad_token_id is None:
            pad_token_id = eos_token_id

        with torch.no_grad():
            out = model.generate(
                **prepared_inputs,
                max_new_tokens=MAX_NEW_TOKENS,
                do_sample=False,
                use_cache=True,
                pad_token_id=pad_token_id,
                eos_token_id=eos_token_id,
            )

        prompt_len = prepared_inputs["input_ids"].shape[1]
        out = out[:, prompt_len:]

        result = processor.batch_decode(
            out,
            skip_special_tokens=True,
            clean_up_tokenization_spaces=True,
        )[0]

        result = strip_think_blocks(result)
        result = clean_generation_text(result)

        if is_effectively_empty_output(result):
            print(
                f"[Warn] empty_generation | "
                f"image_id={image_id} | src={src} | raw={repr(result)}"
            )
            return ""

        return result

    except Exception as e:
        print(f"[TranslateError] image_id={image_id} | src={src} | {repr(e)}")
        return ""


# =========================
# 输出
# =========================
def write_jsonl_records(f, records: List[Dict[str, Any]]) -> None:
    for record in records:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")
    f.flush()


def build_output_record(
    *,
    image_id: Any,
    source_text: str,
    reference_translation: str,
    translation: str,
    image_path: str = "",
) -> Dict[str, Any]:
    return {
        "image_id": image_id,
        "id": image_id,
        "language": LANGUAGE,
        "source_language_name": SOURCE_LANGUAGE_NAME,
        "image_path": image_path,
        "source_text": source_text,
        "reference_translation": reference_translation,
        "initial_translation_en": translation,
    }


# =========================
# 主流程
# =========================
def main():
    data = load_jsonl(INPUT_JSONL)
    total = len(data)

    print(f"[Info] Total samples: {total}")
    print(f"[Info] LANGUAGE: {LANGUAGE}")
    print(f"[Info] SOURCE_LANGUAGE_NAME: {SOURCE_LANGUAGE_NAME}")
    print(f"[Info] GPU: {GPU}")
    print(f"[Info] CUDA available: {torch.cuda.is_available()}")

    if torch.cuda.is_available():
        print(f"[Info] Visible GPU count: {torch.cuda.device_count()}")
        print(f"[Info] Current device: {torch.cuda.current_device()}")

    model, processor = load_model()

    os.makedirs(OUTPUT_DIR, exist_ok=True)

    start_time = time.time()
    buffer = []
    saved = 0

    stats = {
        "total": total,
        "saved": 0,
        "empty_source_text": 0,
        "missing_reference_translation": 0,
        "image_not_found": 0,
        "empty_generation": 0,
        "error": 0,
    }

    with open(OUTPUT_JSONL, "w", encoding="utf-8") as f:
        for i, item in enumerate(data, 1):
            iter_start = time.time()

            image_id = get_image_id(item)
            source_text = get_source_text(item)
            reference_translation = get_reference_translation(item)

            if not reference_translation:
                stats["missing_reference_translation"] += 1

            translation = ""

            if not source_text:
                stats["empty_source_text"] += 1

                buffer.append(
                    build_output_record(
                        image_id=image_id,
                        source_text=source_text,
                        reference_translation=reference_translation,
                        translation="",
                        image_path="",
                    )
                )
                saved += 1
                stats["saved"] = saved

                if len(buffer) >= FLUSH_EVERY:
                    write_jsonl_records(f, buffer)
                    buffer = []

                elapsed = time.time() - start_time
                avg = elapsed / i
                eta = avg * (total - i)

                print(
                    f"[{i}/{total}] empty_src | "
                    f"elapsed={format_time(elapsed)} | "
                    f"ETA={format_time(eta)} | "
                    f"saved={saved}"
                )
                continue

            img_path = resolve_image_path(item)

            try:
                if img_path is not None:
                    image = Image.open(img_path).convert("RGB")
                    translation = translate(
                        model,
                        processor,
                        image,
                        source_text,
                        image_id=image_id,
                    )
                    image.close()

                    if not translation:
                        stats["empty_generation"] += 1

                else:
                    stats["image_not_found"] += 1
                    print(
                        f"[Warn] image_not_found | "
                        f"image_id={image_id} | "
                        f"image_field={item.get('image', item.get('image_path', ''))}"
                    )
                    translation = ""

                buffer.append(
                    build_output_record(
                        image_id=image_id,
                        source_text=source_text,
                        reference_translation=reference_translation,
                        translation=translation,
                        image_path=img_path or "",
                    )
                )
                saved += 1
                stats["saved"] = saved

            except Exception as e:
                stats["error"] += 1
                print(f"[Error] image_id={image_id} | {repr(e)}")

                buffer.append(
                    build_output_record(
                        image_id=image_id,
                        source_text=source_text,
                        reference_translation=reference_translation,
                        translation="",
                        image_path=img_path or "",
                    )
                )
                saved += 1
                stats["saved"] = saved

            finally:
                cleanup_cuda()

            if len(buffer) >= FLUSH_EVERY:
                write_jsonl_records(f, buffer)
                buffer = []

            iter_time = time.time() - iter_start
            elapsed = time.time() - start_time
            avg = elapsed / i
            eta = avg * (total - i)

            print(
                f"[{i}/{total}] "
                f"image_id={image_id} | "
                f"iter={iter_time:.2f}s | "
                f"avg={avg:.2f}s | "
                f"elapsed={format_time(elapsed)} | "
                f"ETA={format_time(eta)} | "
                f"saved={saved} | "
                f"ref_empty={not bool(reference_translation)} | "
                f"img_empty={img_path is None} | "
                f"translation_empty={not bool(translation)}"
            )

        if buffer:
            write_jsonl_records(f, buffer)

    total_time = time.time() - start_time

    print("\n==============================")
    print(f"LANGUAGE: {LANGUAGE}")
    print(f"SOURCE_LANGUAGE_NAME: {SOURCE_LANGUAGE_NAME}")
    print(f"GPU: {GPU}")
    print(f"INPUT_JSONL: {INPUT_JSONL}")
    print(f"IMAGE_DIR: {IMAGE_DIR}")
    print(f"OUTPUT_JSONL: {OUTPUT_JSONL}")
    print(f"TOTAL TIME: {format_time(total_time)}")
    print(f"[stats] {stats}")
    print("==============================")


if __name__ == "__main__":
    main()