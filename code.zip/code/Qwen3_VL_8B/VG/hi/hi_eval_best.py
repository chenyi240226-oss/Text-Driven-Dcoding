#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import json
import logging
import warnings
from typing import List, Tuple, Dict, Any

import torch
import sacrebleu

# ====== 环境 & 日志降噪 ======
os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"
os.environ["TOKENIZERS_PARALLELISM"] = "false"

warnings.filterwarnings("ignore", category=UserWarning)

logging.getLogger("pytorch_lightning").setLevel(logging.ERROR)
logging.getLogger("lightning.pytorch").setLevel(logging.ERROR)
logging.getLogger("lightning").setLevel(logging.ERROR)

# ====== COMET / XCOMET ======
try:
    from comet.models.regression.regression_metric import RegressionMetric
except Exception:
    RegressionMetric = None

try:
    from comet.models.multitask.xcomet_metric import XCOMETMetric
except Exception:
    XCOMETMetric = None


# =====================================================
# 1. 路径配置
# =====================================================
INPUT_JSONL = "/home/chenyi/offline_blaser_qe/out/Qwen_3_VL_8B/VG/hi/hi_source_reference_best.jsonl"
OUTPUT_DIR = "/home/chenyi/offline_blaser_qe/out/Qwen_3_VL_8B/VG/hi"

# ===== COMET / XCOMET 模型路径 =====
COMET_MODEL_DIR = "/mnt/raid/gzy/comet_model/wmt22-comet-da"
COMET_MODEL_CKPT = os.path.join(COMET_MODEL_DIR, "checkpoints", "model.ckpt")
COMET_ENCODER_DIR = os.path.join(COMET_MODEL_DIR, "xlm-roberta-large")

XCOMET_MODEL_DIR = "/mnt/raid/gzy/comet_model/XCOMET-XL"
XCOMET_MODEL_CKPT = os.path.join(XCOMET_MODEL_DIR, "checkpoints", "model.ckpt")
XCOMET_ENCODER_DIR = os.path.join(XCOMET_MODEL_DIR, "xlm-roberta-xl")

COMET_BATCH_SIZE = 16
USE_GPU = True

# 只输出 JSONL
OUTPUT_JSONL = os.path.join(OUTPUT_DIR, "hi_source_reference_best_scored.jsonl")


# =====================================================
# 2. 工具函数
# =====================================================
def get_gpus_flag() -> int:
    if USE_GPU and torch.cuda.is_available():
        return 1
    return 0


def read_jsonl(path: str) -> List[dict]:
    rows = []
    with open(path, "r", encoding="utf-8") as f:
        for line_idx, line in enumerate(f, start=1):
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except Exception as e:
                print(f"[WARN] 文件 {path} 第 {line_idx} 行 JSON 解析失败，已跳过: {e}")
    return rows


def write_jsonl(path: str, rows: List[dict]) -> None:
    with open(path, "w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


def normalize_text(x: Any) -> str:
    if x is None:
        return ""
    return str(x).strip()


def compute_bleu_chrf(
    hyps: List[str],
    refs: List[str]
) -> Tuple[List[float], List[float], float, float]:
    bleu = sacrebleu.corpus_bleu(hyps, [refs])
    chrf = sacrebleu.corpus_chrf(hyps, [refs])

    print(f"[RESULT] BLEU   = {bleu.score:.2f}")
    print(f"[RESULT] chrF++ = {chrf.score:.2f}")

    bleu_seg = [round(sacrebleu.sentence_bleu(h, [r]).score, 2) for h, r in zip(hyps, refs)]
    chrf_seg = [round(sacrebleu.sentence_chrf(h, [r]).score, 2) for h, r in zip(hyps, refs)]

    return bleu_seg, chrf_seg, round(bleu.score, 2), round(chrf.score, 2)


def compute_comet(
    comet_model,
    srcs: List[str],
    hyps: List[str],
    refs: List[str]
) -> Tuple[List[float], float]:
    samples = [{"src": s, "mt": h, "ref": r} for s, h, r in zip(srcs, hyps, refs)]

    gpus = get_gpus_flag()
    result = comet_model.predict(
        samples,
        batch_size=COMET_BATCH_SIZE,
        gpus=gpus,
        progress_bar=False
    )

    if isinstance(result, dict):
        sys_score = result.get("system_score", float("nan"))
        scores = result.get("scores", [float("nan")] * len(srcs))
    else:
        scores, sys_score = result

    scores_100 = [round(float(s) * 100, 2) if s == s else float("nan") for s in scores]

    if isinstance(sys_score, str):
        try:
            sys_score_float = round(float(sys_score) * 100, 2)
        except ValueError:
            print(f"[RESULT] COMET system score = {sys_score}")
            return scores_100, float("nan")
    else:
        sys_score_float = round(float(sys_score) * 100, 2)

    print(f"[RESULT] COMET (wmt22-comet-da) system score = {sys_score_float:.2f}")
    return scores_100, sys_score_float


def compute_xcomet(
    xcomet_model,
    srcs: List[str],
    hyps: List[str]
) -> Tuple[List[float], float]:
    samples = [{"src": s, "mt": h} for s, h in zip(srcs, hyps)]

    gpus = get_gpus_flag()
    result = xcomet_model.predict(
        samples,
        batch_size=COMET_BATCH_SIZE,
        gpus=gpus,
        progress_bar=False
    )

    if isinstance(result, dict):
        sys_score = result.get("system_score", float("nan"))
        scores = result.get("scores", [float("nan")] * len(srcs))
    else:
        scores, sys_score = result

    scores_100 = [round(float(s) * 100, 2) if s == s else float("nan") for s in scores]

    if isinstance(sys_score, str):
        try:
            sys_score_float = round(float(sys_score) * 100, 2)
        except ValueError:
            print(f"[RESULT] XCOMET-XL system score = {sys_score}")
            return scores_100, float("nan")
    else:
        sys_score_float = round(float(sys_score) * 100, 2)

    print(f"[RESULT] XCOMET-XL system score = {sys_score_float:.2f}")
    return scores_100, sys_score_float


# =====================================================
# 3. 数据读取与整理
# =====================================================
def prepare_rows(rows: List[dict]) -> List[dict]:
    prepared = []
    skipped = 0

    for row in rows:
        row_id = row.get("id", row.get("image_id", ""))
        source_text = normalize_text(row.get("source_text", ""))
        ref = normalize_text(row.get("reference_translation", ""))
        hyp = normalize_text(row.get("best_translation", ""))

        if not ref or not hyp:
            skipped += 1
            continue

        prepared.append({
            "id": str(row_id),
            "source_text": source_text,
            "reference_translation": ref,
            "best_translation": hyp
        })

    print(f"[INFO] 可评分条数: {len(prepared)}")
    print(f"[INFO] 因 reference_translation 或 best_translation 为空而跳过: {skipped}")
    return prepared


# =====================================================
# 4. 主函数
# =====================================================
def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    if not os.path.exists(INPUT_JSONL):
        raise FileNotFoundError(f"输入文件不存在: {INPUT_JSONL}")

    print(f"[INFO] 读取输入文件: {INPUT_JSONL}")
    rows = read_jsonl(INPUT_JSONL)
    print(f"[INFO] 读入条数: {len(rows)}")

    prepared_rows = prepare_rows(rows)

    if len(prepared_rows) == 0:
        raise RuntimeError("没有可评分的数据，无法继续。请检查 reference_translation 和 best_translation 字段。")

    src_list = [row["source_text"] for row in prepared_rows]
    hyp_list = [row["best_translation"] for row in prepared_rows]
    ref_list = [row["reference_translation"] for row in prepared_rows]

    # -----------------------------------------------------
    # 加载 COMET
    # -----------------------------------------------------
    print("[INFO] 正在加载 COMET 模型 (wmt22-comet-da)...")
    if RegressionMetric is None:
        raise RuntimeError("找不到 RegressionMetric，请检查 comet 安装版本。")

    comet_model = RegressionMetric.load_from_checkpoint(
        COMET_MODEL_CKPT,
        pretrained_model=COMET_ENCODER_DIR,
        load_pretrained_weights=False,
        strict=False
    )
    if get_gpus_flag() > 0:
        comet_model = comet_model.cuda()
    comet_model.eval()

    # -----------------------------------------------------
    # 加载 XCOMET
    # -----------------------------------------------------
    print("[INFO] 正在加载 XCOMET 模型 (XCOMET-XL)...")
    if XCOMETMetric is None:
        raise RuntimeError("找不到 XCOMETMetric，请确认 unbabel-comet 版本 >= 2.2.0。")

    xcomet_model = XCOMETMetric.load_from_checkpoint(
        XCOMET_MODEL_CKPT,
        pretrained_model=XCOMET_ENCODER_DIR,
        load_pretrained_weights=False,
        strict=False
    )
    if get_gpus_flag() > 0:
        xcomet_model = xcomet_model.cuda()
    xcomet_model.eval()

    print("[INFO] 模型加载完成，开始评估。")

    # -----------------------------------------------------
    # BLEU / chrF++
    # -----------------------------------------------------
    print("[INFO] 评估 BLEU / chrF++ ...")
    bleu_seg, chrf_seg, bleu_sys, chrf_sys = compute_bleu_chrf(hyp_list, ref_list)

    # -----------------------------------------------------
    # COMET
    # -----------------------------------------------------
    print("[INFO] 评估 COMET ...")
    comet_seg, comet_sys = compute_comet(comet_model, src_list, hyp_list, ref_list)

    # -----------------------------------------------------
    # XCOMET
    # -----------------------------------------------------
    print("[INFO] 评估 XCOMET-XL ...")
    xcomet_seg, xcomet_sys = compute_xcomet(xcomet_model, src_list, hyp_list)

    # -----------------------------------------------------
    # 整理输出
    # -----------------------------------------------------
    output_rows = []
    for i, row in enumerate(prepared_rows):
        out = {
            "id": row["id"],
            "source_text": row["source_text"],
            "reference_translation": row["reference_translation"],
            "best_translation": row["best_translation"],
            "BLEU": bleu_seg[i],
            "Chrf++": chrf_seg[i],
            "COMET": comet_seg[i],
            "XCOMET-XL": xcomet_seg[i]
        }
        output_rows.append(out)

    # 末尾追加系统平均分
    avg_row = {
        "id": "AVERAGE_SCORE",
        "source_text": "---",
        "reference_translation": "---",
        "best_translation": "---",
        "BLEU": bleu_sys,
        "Chrf++": chrf_sys,
        "COMET": comet_sys,
        "XCOMET-XL": xcomet_sys
    }
    output_rows.append(avg_row)

    write_jsonl(OUTPUT_JSONL, output_rows)
    print(f"[INFO] JSONL 结果已保存到: {OUTPUT_JSONL}")
    print("[DONE] 全部评估完成。")


if __name__ == "__main__":
    main()