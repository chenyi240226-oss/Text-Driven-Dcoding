import os
os.environ["CUDA_VISIBLE_DEVICES"] = "5"
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"

import re
import json
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from PIL import Image
import torch
import torch.nn as nn
import torch.nn.functional as F

from transformers import AutoProcessor, AutoModelForVision2Seq

# =========================
# Torch compatibility patch
# =========================
if not hasattr(torch, "compiler"):
    class _DummyCompiler:
        @staticmethod
        def is_compiling():
            return False
    torch.compiler = _DummyCompiler()
else:
    if not hasattr(torch.compiler, "is_compiling"):
        torch.compiler.is_compiling = lambda: False

torch.set_grad_enabled(False)

# =========================================================
# PATHS
# =========================================================
QWEN_PATH = "/mnt/raid/hss/model/Qwen3-VL-8B-Instruct"

INPUT_JSONL = "/home/chenyi/offline_blaser_qe/out/Qwen_3_VL_8B/VG/hi/hi_test_translation.jsonl"
IMAGE_DIR = "/home/chenyi/offline_blaser_qe/dataSet/VG/images"

OUTPUT_JSONL = "/home/chenyi/offline_blaser_qe/out/Qwen_3_VL_8B/VG/hi/hi_detect_span.jsonl"

# =========================================================
# RUN CONTROL
# =========================================================
MAX_ROWS = None
DTYPE = torch.bfloat16 if torch.cuda.is_available() else torch.float32

SELECTED_LAYERS = [0, 1, 2, 3]
MAX_TARGET_TOKENS = 96
MAX_CLASSIFY_NEW_TOKENS = 96

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

# =========================================================
# BASIC UTILS
# =========================================================
def clean_text(x) -> str:
    if x is None:
        return ""
    x = str(x).strip()
    x = re.sub(r"\s+", " ", x)
    return x

def ensure_dir(path: str):
    Path(path).parent.mkdir(parents=True, exist_ok=True)

def load_jsonl(path: str) -> List[Dict]:
    rows = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows

def write_jsonl(path: str, rows: List[Dict]):
    ensure_dir(path)
    with open(path, "w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")

def load_image(path: str) -> Optional[Image.Image]:
    if not path or not os.path.isfile(path):
        return None
    try:
        return Image.open(path).convert("RGB")
    except Exception:
        return None

def resolve_image_path(row: Dict) -> str:
    for key in ["image_path", "image", "img_path"]:
        v = clean_text(row.get(key, ""))
        if v and os.path.isfile(v):
            return v

    image_id = row.get("image_id", row.get("id", ""))
    image_id = clean_text(image_id)
    if image_id:
        candidates = [
            os.path.join(IMAGE_DIR, f"{image_id}.jpg"),
            os.path.join(IMAGE_DIR, f"{image_id}.jpeg"),
            os.path.join(IMAGE_DIR, f"{image_id}.png"),
        ]
        for p in candidates:
            if os.path.isfile(p):
                return p
    return ""

def get_source_text(row: Dict) -> str:
    for key in ["source_text", "target", "src", "tgt"]:
        v = clean_text(row.get(key, ""))
        if v:
            return v
    return ""

def get_initial_translation(row: Dict) -> str:
    for key in ["initial_translation", "initial_translation_en", "translation", "mt"]:
        v = clean_text(row.get(key, ""))
        if v:
            return v
    return ""

def normalize_token(text: str) -> str:
    text = clean_text(text).lower()
    text = text.replace("’", "'").replace("“", '"').replace("”", '"')
    text = re.sub(r"[^a-z0-9\-\s]", "", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text

# =========================================================
# FUNCTION / CONTENT WORDS
# =========================================================
FUNCTION_WORDS = {
    "a", "an", "the", "of", "in", "on", "at", "by", "with", "from", "to",
    "for", "into", "onto", "over", "under", "between", "around", "through",
    "is", "are", "was", "were", "be", "been", "being",
    "and", "or", "but", "as", "if", "that", "this", "these", "those",
    "who", "whom", "whose", "which", "while", "then", "than",
    "his", "her", "their", "its", "our", "your", "my",
    "there", "here", "still", "very", "just", "also"
}

def is_special_piece(piece: str) -> bool:
    p = str(piece)
    return ("<|im_end|>" in p) or ("<|im_start|>" in p)

def is_punctuation_only(text: str) -> bool:
    return re.fullmatch(r"[\W_]+", text or "") is not None

def is_function_word(text: str) -> bool:
    t = clean_text(text).lower().strip(".,;:!?")
    return t in FUNCTION_WORDS

def is_content_like(text: str) -> bool:
    t = clean_text(text)
    if not t:
        return False
    if is_punctuation_only(t):
        return False
    if is_function_word(t):
        return False
    if re.search(r"[A-Za-z0-9]", t):
        return True
    return False

# =========================================================
# MODEL LOADING
# =========================================================
print("Loading Qwen...")
processor = AutoProcessor.from_pretrained(QWEN_PATH, trust_remote_code=True)
model = AutoModelForVision2Seq.from_pretrained(
    QWEN_PATH,
    torch_dtype=DTYPE,
    device_map="auto",
    trust_remote_code=True
).eval()
tokenizer = processor.tokenizer
print("Qwen loaded.")

# =========================================================
# FIND TEXT LAYERS / FFN
# =========================================================
def _is_transformer_block_list(x):
    if not isinstance(x, (nn.ModuleList, list, tuple)):
        return False
    if len(x) < 4:
        return False

    hit = 0
    for layer in x[: min(len(x), 8)]:
        if not hasattr(layer, "named_children"):
            continue
        names = set(dict(layer.named_children()).keys())
        if ("self_attn" in names or "attn" in names or "attention" in names) and \
           ("mlp" in names or "feed_forward" in names or "ffn" in names or "ff" in names):
            hit += 1
    return hit >= max(2, min(len(x), 4) // 2)

def _score_layer_container(name, container):
    score = 0
    lname = name.lower()
    if "language" in lname:
        score += 5
    if "model.layers" in lname or lname.endswith(".layers") or lname == "layers":
        score += 4
    if "decoder.layers" in lname:
        score += 3
    if "visual" in lname or "vision" in lname or "image" in lname:
        score -= 6
    if "encoder" in lname and "vision" in lname:
        score -= 6

    first = container[0]
    child_names = set(dict(first.named_children()).keys())
    if "mlp" in child_names:
        score += 3
    if "self_attn" in child_names or "attn" in child_names or "attention" in child_names:
        score += 3
    return score

def get_text_layers(model):
    candidates = []
    explicit_paths = [
        "language_model.model.layers",
        "language_model.layers",
        "model.layers",
        "model.decoder.layers",
        "decoder.layers",
        "layers",
    ]

    for path in explicit_paths:
        cur = model
        ok = True
        for p in path.split("."):
            if hasattr(cur, p):
                cur = getattr(cur, p)
            else:
                ok = False
                break
        if ok and _is_transformer_block_list(cur):
            candidates.append((path, cur, _score_layer_container(path, cur)))

    for name, module in model.named_modules():
        for child_name, child in module.named_children():
            full_name = f"{name}.{child_name}" if name else child_name
            if _is_transformer_block_list(child):
                candidates.append((full_name, child, _score_layer_container(full_name, child)))

    uniq = {}
    for name, container, score in candidates:
        uniq[id(container)] = (name, container, score)
    candidates = list(uniq.values())

    if not candidates:
        raise RuntimeError("Cannot locate transformer layers automatically.")

    candidates = sorted(candidates, key=lambda x: x[2], reverse=True)
    best_name, best_layers, best_score = candidates[0]
    print(f"[info] selected text layers from: {best_name} | score={best_score} | num_layers={len(best_layers)}")
    return best_layers

def get_ffn_module(layer):
    if hasattr(layer, "mlp"):
        return layer.mlp
    for name in ["feed_forward", "ffn", "ff"]:
        if hasattr(layer, name):
            return getattr(layer, name)
    raise RuntimeError("Cannot locate FFN/MLP module inside a transformer layer.")

TEXT_LAYERS = get_text_layers(model)
NUM_LAYERS = len(TEXT_LAYERS)
FFN_MODULES = {l: get_ffn_module(TEXT_LAYERS[l]) for l in SELECTED_LAYERS}

# =========================================================
# CHAT TEMPLATE: SYSTEM + USER
# =========================================================
SYSTEM_PROMPT_TRANSLATE = (
    "You are a professional translator. "
    "Translate the given source sentence into English faithfully. "
    "Do not add, remove, or change objects, attributes, actions, or relations. "
    "Use the image only when it helps resolve ambiguity. "
    "Output only the English translation."
)

SYSTEM_PROMPT_CONTINUE = (
    "You are a language model that continues English text. "
    "Output only the continuation."
)

SYSTEM_PROMPT_EDIT_TYPE = (
    "You are a strict translation editor. "
    "Your job is to decide how a suspicious English span should be handled, "
    "using the source sentence, the current English translation, and the image if provided. "
    "Return exactly one JSON object with keys: edit_type, reason. "
    "Allowed edit_type values are: delete, visual_refill, paraphrase, keep.\n\n"
    "Definitions:\n"
    "- delete: the span is unsupported extra content and should be removed, not replaced.\n"
    "- visual_refill: the span is wrong or underspecified, and should be masked and refilled using source+image evidence.\n"
    "- paraphrase: the meaning is roughly supported, but the wording should be locally rewritten.\n"
    "- keep: the span should not drive editing even if it was flagged as suspicious.\n\n"
    "Rules:\n"
    "1. Prefer keep if the span is actually faithful.\n"
    "2. Use delete only for unsupported additions that do not need replacement.\n"
    "3. Use visual_refill when the local slot should be re-generated from grounded evidence.\n"
    "4. Use paraphrase when the content is basically right but phrasing is awkward, too strong, or overly specific.\n"
    "5. Output JSON only."
)

def build_multimodal_chat_text(system_text: str, user_text: str, image: Image.Image, add_generation_prompt: bool = False) -> str:
    messages = [
        {
            "role": "system",
            "content": [{"type": "text", "text": system_text}]
        },
        {
            "role": "user",
            "content": [
                {"type": "image", "image": image},
                {"type": "text", "text": user_text},
            ]
        }
    ]
    return processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=add_generation_prompt)

def build_text_chat_text(system_text: str, user_text: str, add_generation_prompt: bool = False) -> str:
    messages = [
        {
            "role": "system",
            "content": [{"type": "text", "text": system_text}]
        },
        {
            "role": "user",
            "content": [{"type": "text", "text": user_text}]
        }
    ]
    return processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=add_generation_prompt)

# =========================================================
# GENERATION UTILS
# =========================================================
def run_chat_generate(
    *,
    system_prompt: str,
    user_prompt: str,
    image: Optional[Image.Image] = None,
    max_new_tokens: int = 64
) -> str:
    if image is not None:
        chat_text = build_multimodal_chat_text(system_prompt, user_prompt, image, add_generation_prompt=True)
        inputs = processor(text=[chat_text], images=[image], padding=True, return_tensors="pt")
    else:
        chat_text = build_text_chat_text(system_prompt, user_prompt, add_generation_prompt=True)
        inputs = processor(text=[chat_text], padding=True, return_tensors="pt")

    model_inputs = {}
    for k, v in inputs.items():
        model_inputs[k] = v.to(model.device) if isinstance(v, torch.Tensor) else v

    with torch.no_grad():
        gen_ids = model.generate(
            **model_inputs,
            max_new_tokens=max_new_tokens,
            do_sample=False,
            use_cache=True
        )

    input_len = model_inputs["input_ids"].shape[1]
    out_ids = gen_ids[:, input_len:]
    text = tokenizer.batch_decode(out_ids, skip_special_tokens=True)[0]
    return clean_text(text)

def extract_first_json_object(text: str) -> Optional[Dict]:
    if not text:
        return None

    text = text.strip()

    try:
        obj = json.loads(text)
        if isinstance(obj, dict):
            return obj
    except Exception:
        pass

    m = re.search(r"\{.*\}", text, flags=re.DOTALL)
    if not m:
        return None

    frag = m.group(0)
    try:
        obj = json.loads(frag)
        if isinstance(obj, dict):
            return obj
    except Exception:
        return None
    return None

# =========================================================
# FORWARD / HOOK
# =========================================================
def run_forward_collect_selected_ffn_outputs(
    *,
    system_prompt: str,
    user_prompt: str,
    target_text: str,
    image: Optional[Image.Image]
) -> Tuple[torch.Tensor, Dict[int, torch.Tensor], Tuple[int, int], torch.Tensor]:
    if image is not None:
        prefix_chat = build_multimodal_chat_text(system_prompt, user_prompt, image)
        full_chat = build_multimodal_chat_text(system_prompt, user_prompt + target_text, image)

        prefix_inputs = processor(text=[prefix_chat], images=[image], padding=True, return_tensors="pt")
        full_inputs = processor(text=[full_chat], images=[image], padding=True, return_tensors="pt")
    else:
        prefix_chat = build_text_chat_text(system_prompt, user_prompt)
        full_chat = build_text_chat_text(system_prompt, user_prompt + target_text)

        prefix_inputs = processor(text=[prefix_chat], padding=True, return_tensors="pt")
        full_inputs = processor(text=[full_chat], padding=True, return_tensors="pt")

    prefix_len = int(prefix_inputs["input_ids"].shape[1])
    full_len = int(full_inputs["input_ids"].shape[1])
    target_len = full_len - prefix_len

    if target_len <= 0:
        raise RuntimeError("Target length <= 0.")

    if target_len > MAX_TARGET_TOKENS:
        target_len = MAX_TARGET_TOKENS
        trunc_len = prefix_len + target_len
        for k, v in full_inputs.items():
            if isinstance(v, torch.Tensor) and v.ndim >= 2 and v.shape[1] >= trunc_len:
                full_inputs[k] = v[:, :trunc_len]

    layer_outs = {l: None for l in SELECTED_LAYERS}
    handles = []

    def make_hook(layer_idx):
        def hook_fn(module, inp, out):
            o = out[0] if isinstance(out, tuple) else out
            layer_outs[layer_idx] = o.detach()
        return hook_fn

    for l in SELECTED_LAYERS:
        handles.append(FFN_MODULES[l].register_forward_hook(make_hook(l)))

    model_inputs = {}
    for k, v in full_inputs.items():
        model_inputs[k] = v.to(model.device) if isinstance(v, torch.Tensor) else v

    with torch.no_grad():
        outputs = model(**model_inputs)

    for h in handles:
        h.remove()

    logits = outputs.logits.detach()
    input_ids = model_inputs["input_ids"]

    start = prefix_len
    end = prefix_len + target_len

    cond_logits = logits[:, start - 1:end - 1, :]
    target_ids = input_ids[:, start:end]

    log_probs = F.log_softmax(cond_logits, dim=-1)
    token_logprobs = log_probs.gather(-1, target_ids.unsqueeze(-1)).squeeze(-1).squeeze(0)

    selected_layer_outs = {}
    for l in SELECTED_LAYERS:
        o = layer_outs[l]
        if o is None:
            raise RuntimeError(f"Layer {l} hook did not capture output.")
        target_o = o[0, start:end, :].float().cpu()
        selected_layer_outs[l] = target_o

    return token_logprobs.float().cpu(), selected_layer_outs, (prefix_len, target_len), target_ids.squeeze(0).detach().cpu()

# =========================================================
# PROMPTS: SYSTEM + USER
# =========================================================
def build_xi_prompts(source_text: str) -> Tuple[str, str]:
    system_prompt = SYSTEM_PROMPT_TRANSLATE
    user_prompt = (
        "Translate the following source sentence into English.\n"
        f"Source: {source_text}\n"
        "Translation:"
    )
    return system_prompt, user_prompt

def build_x_prompts(source_text: str) -> Tuple[str, str]:
    system_prompt = SYSTEM_PROMPT_TRANSLATE
    user_prompt = (
        "Translate the following source sentence into English.\n"
        f"Source: {source_text}\n"
        "Translation:"
    )
    return system_prompt, user_prompt

def build_n_prompts() -> Tuple[str, str]:
    system_prompt = SYSTEM_PROMPT_CONTINUE
    user_prompt = (
        "Continue the following English text.\n"
        "Translation:"
    )
    return system_prompt, user_prompt

# =========================================================
# TOKEN -> WORD GROUPS
# =========================================================
def decode_token_pieces(token_ids: torch.Tensor) -> List[str]:
    pieces = tokenizer.convert_ids_to_tokens(token_ids.tolist())
    return ["" if p is None else str(p) for p in pieces]

def piece_to_text(piece: str) -> str:
    if piece is None:
        return ""
    p = str(piece)
    p = p.replace("▁", " ")
    p = p.replace("Ġ", " ")
    p = p.replace("Ċ", "\n")
    p = p.replace("</w>", "")
    return p

def build_word_groups(token_ids: torch.Tensor) -> List[Dict]:
    pieces = decode_token_pieces(token_ids)
    groups = []

    cur_start = None
    cur_pieces = []
    cur_raw_pieces = []

    for i, raw_piece in enumerate(pieces):
        if is_special_piece(raw_piece):
            continue

        t = piece_to_text(raw_piece)
        if not clean_text(t) and "\n" in t:
            continue

        starts_new = False
        if len(cur_pieces) == 0:
            starts_new = True
        elif t.startswith(" "):
            starts_new = True

        if starts_new:
            if cur_pieces:
                text = "".join(cur_pieces).strip()
                text = re.sub(r"\s+", " ", text)
                text = re.sub(r"\s+([,.;:!?])", r"\1", text)
                if clean_text(text) and not is_punctuation_only(text):
                    groups.append({
                        "start": cur_start,
                        "end": i - 1,
                        "text": text,
                        "pieces": cur_raw_pieces[:]
                    })
            cur_start = i
            cur_pieces = [t]
            cur_raw_pieces = [raw_piece]
        else:
            cur_pieces.append(t)
            cur_raw_pieces.append(raw_piece)

    if cur_pieces:
        text = "".join(cur_pieces).strip()
        text = re.sub(r"\s+", " ", text)
        text = re.sub(r"\s+([,.;:!?])", r"\1", text)
        if clean_text(text) and not is_punctuation_only(text):
            groups.append({
                "start": cur_start,
                "end": len(pieces) - 1,
                "text": text,
                "pieces": cur_raw_pieces[:]
            })

    clean_groups = []
    for g in groups:
        text = clean_text(g["text"])
        text = re.sub(r"<\|.*?\|>", "", text).strip()
        text = re.sub(r"\s+", " ", text)
        text = text.strip(".,;:!?")
        if not text:
            continue
        if is_punctuation_only(text):
            continue
        clean_groups.append({
            "start": g["start"],
            "end": g["end"],
            "text": text,
            "pieces": g["pieces"]
        })
    return clean_groups

# =========================================================
# PARAMETER-FREE LOCAL EXTREMA DETECTION
# =========================================================
def group_equal_plateaus(values: List[float]) -> List[Tuple[int, int]]:
    if not values:
        return []

    spans = []
    s = 0
    for i in range(1, len(values)):
        if values[i] != values[i - 1]:
            spans.append((s, i - 1))
            s = i
    spans.append((s, len(values) - 1))
    return spans

def is_peak_plateau(values: List[float], s: int, e: int) -> bool:
    left_exists = s - 1 >= 0
    right_exists = e + 1 < len(values)

    left_ok = True
    right_ok = True

    if left_exists:
        left_ok = values[s - 1] < values[s]
    if right_exists:
        right_ok = values[e + 1] < values[e]

    if left_exists and right_exists:
        return left_ok and right_ok
    if left_exists:
        return left_ok
    if right_exists:
        return right_ok
    return True

def is_valley_plateau(values: List[float], s: int, e: int) -> bool:
    left_exists = s - 1 >= 0
    right_exists = e + 1 < len(values)

    left_ok = True
    right_ok = True

    if left_exists:
        left_ok = values[s - 1] > values[s]
    if right_exists:
        right_ok = values[e + 1] > values[e]

    if left_exists and right_exists:
        return left_ok and right_ok
    if left_exists:
        return left_ok
    if right_exists:
        return right_ok
    return True

def extract_parameter_free_suspicious_word_ids(word_metrics: List[Dict]) -> List[int]:
    content_positions = []
    content_scores = []

    for i, wm in enumerate(word_metrics):
        if wm["is_content_like"] and (not wm["is_function_word"]):
            content_positions.append(i)
            content_scores.append(float(wm["score"]))

    if not content_scores:
        return []

    plateau_spans = group_equal_plateaus(content_scores)
    suspicious_ids = []

    for s, e in plateau_spans:
        if is_peak_plateau(content_scores, s, e) or is_valley_plateau(content_scores, s, e):
            for k in range(s, e + 1):
                suspicious_ids.append(content_positions[k])

    return suspicious_ids

def merge_adjacent_word_ids(word_ids: List[int]) -> List[Tuple[int, int]]:
    if not word_ids:
        return []

    word_ids = sorted(set(word_ids))
    spans = []
    a = word_ids[0]
    b = word_ids[0]

    for idx in word_ids[1:]:
        if idx == b + 1:
            b = idx
        else:
            spans.append((a, b))
            a = idx
            b = idx
    spans.append((a, b))
    return spans

def choose_primary_peak_span_lexicographically(span_items: List[Dict]) -> str:
    if not span_items:
        return ""

    best = max(
        span_items,
        key=lambda x: (
            x["mean_score"],
            x["mean_logprob_gap"],
            (x["end_token"] - x["start_token"] + 1),
            -x["start_token"],
        )
    )
    return best["span"]

def choose_primary_valley_span(span_items: List[Dict]) -> str:
    if not span_items:
        return ""

    best = min(
        span_items,
        key=lambda x: (
            x["mean_score"],
            x["mean_logprob_gap"],
            -(x["end_token"] - x["start_token"] + 1),
            x["start_token"],
        )
    )
    return best["span"]

def build_primary_span_list(primary_peak: str, primary_valley: str) -> List[str]:
    out = []
    if clean_text(primary_peak):
        out.append(clean_text(primary_peak))
    if clean_text(primary_valley) and clean_text(primary_valley) not in out:
        out.append(clean_text(primary_valley))
    return out

# =========================================================
# SCORE COMPUTATION
# =========================================================
def concat_selected_layers(ffn_dict: Dict[int, torch.Tensor], tlen: int) -> torch.Tensor:
    mats = [ffn_dict[l][:tlen] for l in SELECTED_LAYERS]
    return torch.cat(mats, dim=-1)

def compute_token_suspicion(source_text: str, target_text: str, image: Optional[Image.Image]) -> Dict:
    sys_xi, usr_xi = build_xi_prompts(source_text)
    logp_xi, ffn_xi, (_, tlen_xi), target_ids_xi = run_forward_collect_selected_ffn_outputs(
        system_prompt=sys_xi,
        user_prompt=usr_xi,
        target_text=target_text,
        image=image
    )

    sys_x, usr_x = build_x_prompts(source_text)
    logp_x, ffn_x, (_, tlen_x), _ = run_forward_collect_selected_ffn_outputs(
        system_prompt=sys_x,
        user_prompt=usr_x,
        target_text=target_text,
        image=None
    )

    sys_n, usr_n = build_n_prompts()
    logp_n, ffn_n, (_, tlen_n), _ = run_forward_collect_selected_ffn_outputs(
        system_prompt=sys_n,
        user_prompt=usr_n,
        target_text=target_text,
        image=None
    )

    tlen = min(tlen_xi, tlen_x, tlen_n)
    logp_xi = logp_xi[:tlen]
    logp_x = logp_x[:tlen]
    target_ids = target_ids_xi[:tlen]

    z_xi = concat_selected_layers(ffn_xi, tlen)
    z_x = concat_selected_layers(ffn_x, tlen)
    z_n = concat_selected_layers(ffn_n, tlen)

    d_xi_x = torch.norm(z_xi - z_x, p=2, dim=-1)
    d_xi_n = torch.norm(z_xi - z_n, p=2, dim=-1)
    gap = torch.clamp(logp_x - logp_xi, min=0.0)

    scores = d_xi_x + d_xi_n + gap

    word_groups = build_word_groups(target_ids)
    if not word_groups:
        return {
            "target_len": int(tlen),
            "token_metrics": [],
            "word_metrics": [],
            "suspicious_tokens": [],
            "suspicious_spans": [],
            "score_primary_suspicious_span": "",
            "score_primary_low_suspicious_span": "",
            "score_primary_suspicious_spans": [],
        }

    word_metrics = []

    for g in word_groups:
        s = max(0, min(g["start"], tlen - 1))
        e = max(0, min(g["end"], tlen - 1))
        if e < s:
            continue

        text = clean_text(g["text"])
        word_score = float(scores[s:e + 1].mean().item())
        mean_dx = float(d_xi_x[s:e + 1].mean().item())
        mean_dn = float(d_xi_n[s:e + 1].mean().item())
        mean_gap = float(gap[s:e + 1].mean().item())

        word_metrics.append({
            "word": text,
            "start_token": int(s),
            "end_token": int(e),
            "score": round(word_score, 6),
            "ffn_diff_xi_x": round(mean_dx, 6),
            "ffn_diff_xi_n": round(mean_dn, 6),
            "logprob_gap_x_minus_xi": round(mean_gap, 6),
            "is_content_like": bool(is_content_like(text)),
            "is_function_word": bool(is_function_word(text)),
        })

    suspicious_word_ids = extract_parameter_free_suspicious_word_ids(word_metrics)
    merged_spans = merge_adjacent_word_ids(suspicious_word_ids)

    suspicious_tokens = []
    for i in suspicious_word_ids:
        wm = word_metrics[i]
        suspicious_tokens.append({
            "word": wm["word"],
            "start_token": wm["start_token"],
            "end_token": wm["end_token"],
            "score": wm["score"],
            "ffn_diff_xi_x": wm["ffn_diff_xi_x"],
            "ffn_diff_xi_n": wm["ffn_diff_xi_n"],
            "logprob_gap_x_minus_xi": wm["logprob_gap_x_minus_xi"],
        })

    span_items = []
    for a, b in merged_spans:
        span_words = [word_metrics[i]["word"] for i in range(a, b + 1)]
        span_text = " ".join(span_words).strip()
        if not span_text:
            continue

        num_words = b - a + 1
        num_function_words = sum(1 for i in range(a, b + 1) if word_metrics[i]["is_function_word"])

        mean_score = sum(word_metrics[i]["score"] for i in range(a, b + 1)) / max(1, num_words)
        mean_gap = sum(word_metrics[i]["logprob_gap_x_minus_xi"] for i in range(a, b + 1)) / max(1, num_words)

        span_items.append({
            "span": span_text,
            "start_token": int(word_metrics[a]["start_token"]),
            "end_token": int(word_metrics[b]["end_token"]),
            "mean_score": round(mean_score, 6),
            "mean_logprob_gap": round(mean_gap, 6),
            "num_words": int(num_words),
            "num_function_words": int(num_function_words),
        })

    token_metrics = []
    pieces = decode_token_pieces(target_ids)
    for i in range(tlen):
        p = piece_to_text(pieces[i])
        if is_special_piece(pieces[i]):
            continue
        if not clean_text(p) and "\n" in p:
            continue
        token_metrics.append({
            "token_idx": int(i),
            "piece": p,
            "score": round(float(scores[i].item()), 6),
            "ffn_diff_xi_x": round(float(d_xi_x[i].item()), 6),
            "ffn_diff_xi_n": round(float(d_xi_n[i].item()), 6),
            "logprob_gap_x_minus_xi": round(float(gap[i].item()), 6),
        })

    score_primary_peak = choose_primary_peak_span_lexicographically(span_items)
    score_primary_valley = choose_primary_valley_span(span_items)
    score_primary_both = build_primary_span_list(score_primary_peak, score_primary_valley)

    return {
        "target_len": int(tlen),
        "token_metrics": token_metrics,
        "word_metrics": word_metrics,
        "suspicious_tokens": suspicious_tokens,
        "suspicious_spans": span_items,

        # 这里保留原始 score-based primary，供调试
        "score_primary_suspicious_span": score_primary_peak,
        "score_primary_low_suspicious_span": score_primary_valley,
        "score_primary_suspicious_spans": score_primary_both,
    }

# =========================================================
# EDIT TYPE CLASSIFICATION
# =========================================================
ALLOWED_EDIT_TYPES = {"delete", "visual_refill", "paraphrase", "keep"}

def heuristic_fallback_edit_type(span_item: Dict) -> Tuple[str, str]:
    span = clean_text(span_item.get("span", ""))
    mean_gap = float(span_item.get("mean_logprob_gap", 0.0))
    num_words = int(span_item.get("num_words", 1))

    if not span:
        return "keep", "empty_span"

    if num_words >= 3 and mean_gap >= 0.35:
        return "paraphrase", "fallback_high_gap_multiword"

    if mean_gap >= 0.6:
        return "paraphrase", "fallback_high_gap"

    return "visual_refill", "fallback_default_refill"

def classify_span_edit_type(
    *,
    source_text: str,
    initial_translation: str,
    span_item: Dict,
    image: Optional[Image.Image]
) -> Dict:
    span_text = clean_text(span_item.get("span", ""))

    if not span_text:
        return {
            "edit_type": "keep",
            "edit_reason": "empty_span",
        }

    user_prompt = (
        f"Source sentence:\n{source_text}\n\n"
        f"Current English translation:\n{initial_translation}\n\n"
        f"Suspicious span:\n{span_text}\n\n"
        f"Span statistics:\n"
        f"- mean_score: {span_item.get('mean_score', 0.0)}\n"
        f"- mean_logprob_gap: {span_item.get('mean_logprob_gap', 0.0)}\n"
        f"- num_words: {span_item.get('num_words', 1)}\n\n"
        "Decide how this span should drive candidate generation.\n"
        "Return JSON only."
    )

    try:
        raw = run_chat_generate(
            system_prompt=SYSTEM_PROMPT_EDIT_TYPE,
            user_prompt=user_prompt,
            image=image,
            max_new_tokens=MAX_CLASSIFY_NEW_TOKENS
        )
        obj = extract_first_json_object(raw)

        if obj is None:
            et, rs = heuristic_fallback_edit_type(span_item)
            return {
                "edit_type": et,
                "edit_reason": rs,
            }

        edit_type = clean_text(obj.get("edit_type", "")).lower()
        reason = clean_text(obj.get("reason", ""))

        if edit_type not in ALLOWED_EDIT_TYPES:
            et, rs = heuristic_fallback_edit_type(span_item)
            return {
                "edit_type": et,
                "edit_reason": rs if not reason else f"invalid_label->{rs}",
            }

        if not reason:
            reason = "model_decision"

        return {
            "edit_type": edit_type,
            "edit_reason": reason,
        }

    except Exception as e:
        et, rs = heuristic_fallback_edit_type(span_item)
        return {
            "edit_type": et,
            "edit_reason": f"{rs}|{repr(e)}",
        }

def classify_all_suspicious_spans(
    *,
    source_text: str,
    initial_translation: str,
    suspicious_spans: List[Dict],
    image: Optional[Image.Image]
) -> List[Dict]:
    out = []

    for span_item in suspicious_spans:
        cls = classify_span_edit_type(
            source_text=source_text,
            initial_translation=initial_translation,
            span_item=span_item,
            image=image
        )
        new_item = dict(span_item)
        new_item["edit_type"] = cls["edit_type"]
        new_item["edit_reason"] = cls["edit_reason"]
        out.append(new_item)

    return out

# =========================================================
# ACTIONABILITY-FIRST PRIMARY
# =========================================================
def get_actionability_rank(span_item: Dict) -> int:
    """
    无参数优先级：
    0: delete / paraphrase
    1: explicit visual_refill
    2: fallback visual_refill
    3: keep / unknown
    """
    et = clean_text(span_item.get("edit_type", "")).lower()
    rs = clean_text(span_item.get("edit_reason", "")).lower()

    if et in {"delete", "paraphrase"}:
        return 0

    if et == "visual_refill":
        if rs.startswith("fallback_") or "fallback_" in rs:
            return 2
        return 1

    return 3

def choose_actionability_first_pool(span_items: List[Dict]) -> Tuple[List[Dict], int]:
    if not span_items:
        return [], 3
    best_rank = min(get_actionability_rank(x) for x in span_items)
    pool = [x for x in span_items if get_actionability_rank(x) == best_rank]
    return pool, best_rank

def choose_primary_edit_type(primary_span: str, span_items: List[Dict]) -> str:
    if not primary_span:
        return ""
    for x in span_items:
        if clean_text(x.get("span", "")) == clean_text(primary_span):
            return clean_text(x.get("edit_type", ""))
    return ""

def choose_primary_edit_types(primary_spans: List[str], span_items: List[Dict]) -> List[Dict]:
    out = []
    for sp in primary_spans:
        et = choose_primary_edit_type(sp, span_items)
        out.append({
            "span": sp,
            "edit_type": et
        })
    return out

def choose_actionability_first_primaries(span_items: List[Dict]) -> Dict:
    """
    actionability-first:
    - 若存在 non-keep / actionable span，则只从最高优先级池里选 primary
    - 若全是 keep，则自然回退到原来的 score-based 逻辑（因为池=全体 span）
    """
    pool, best_rank = choose_actionability_first_pool(span_items)

    primary_peak = choose_primary_peak_span_lexicographically(pool)
    primary_valley = choose_primary_valley_span(pool)
    primary_both = build_primary_span_list(primary_peak, primary_valley)

    return {
        "primary_suspicious_span": primary_peak,
        "primary_low_suspicious_span": primary_valley,
        "primary_suspicious_spans": primary_both,
        "primary_rank": best_rank,
        "primary_pool": pool,
    }

# =========================================================
# MAIN
# =========================================================
def main():
    rows = load_jsonl(INPUT_JSONL)
    if MAX_ROWS is not None:
        rows = rows[:MAX_ROWS]

    print(f"Loaded {len(rows)} rows from {INPUT_JSONL}")

    results = []

    for idx, row in enumerate(rows, 1):
        sid = clean_text(row.get("id", row.get("image_id", "")))
        source_text = get_source_text(row)
        initial_translation = get_initial_translation(row)
        image_path = resolve_image_path(row)

        if not source_text or not initial_translation:
            print(f"[{idx}/{len(rows)}] {sid} | skip: missing source_text or initial_translation")
            continue

        image = load_image(image_path) if image_path else None

        try:
            det = compute_token_suspicion(
                source_text=source_text,
                target_text=initial_translation,
                image=image
            )

            typed_spans = classify_all_suspicious_spans(
                source_text=source_text,
                initial_translation=initial_translation,
                suspicious_spans=det["suspicious_spans"],
                image=image
            )

            # =========================
            # NEW: actionability-first primary
            # =========================
            act = choose_actionability_first_primaries(typed_spans)

            primary_edit_type = choose_primary_edit_type(
                act["primary_suspicious_span"],
                typed_spans
            )
            primary_low_edit_type = choose_primary_edit_type(
                act["primary_low_suspicious_span"],
                typed_spans
            )
            primary_edit_types = choose_primary_edit_types(
                act["primary_suspicious_spans"],
                typed_spans
            )

            out = {
                "id": sid,
                "image_path": image_path,
                "source_text": source_text,
                "initial_translation": initial_translation,
                "selected_layers": SELECTED_LAYERS,
                "score_formula": "s_t = ||z_xi-z_x||_2 + ||z_xi-z_n||_2 + ReLU(logp_x-logp_xi)",
                "selection_rule": "parameter_free_local_extrema_over_content_words_with_actionability_first_primary",
                "edit_type_rule": "multimodal_span_edit_type_classification_after_peak_detection",
                "actionability_priority_rule": "delete/paraphrase > explicit_visual_refill > fallback_visual_refill > keep",
                "target_len": det["target_len"],
                "token_metrics": det["token_metrics"],
                "word_metrics": det["word_metrics"],
                "suspicious_tokens": det["suspicious_tokens"],
                "suspicious_spans": typed_spans,

                # =========================
                # DEBUG: 原始 score-based primary
                # =========================
                "score_primary_suspicious_span": det["score_primary_suspicious_span"],
                "score_primary_low_suspicious_span": det["score_primary_low_suspicious_span"],
                "score_primary_suspicious_spans": det["score_primary_suspicious_spans"],
                "score_primary_edit_type": choose_primary_edit_type(det["score_primary_suspicious_span"], typed_spans),
                "score_primary_low_edit_type": choose_primary_edit_type(det["score_primary_low_suspicious_span"], typed_spans),

                # =========================
                # NEW: actionability-first primary
                # =========================
                "primary_suspicious_span": act["primary_suspicious_span"],
                "primary_edit_type": primary_edit_type,

                "primary_low_suspicious_span": act["primary_low_suspicious_span"],
                "primary_low_edit_type": primary_low_edit_type,

                "primary_suspicious_spans": act["primary_suspicious_spans"],
                "primary_edit_types": primary_edit_types,

                "primary_selection_mode": "actionability_first",
                "primary_actionability_rank": act["primary_rank"],
                "primary_pool_spans": [x["span"] for x in act["primary_pool"]],
            }
            results.append(out)

            print(
                f"[{idx}/{len(rows)}] {sid} | "
                f"score_peak={det['score_primary_suspicious_span']} | "
                f"score_valley={det['score_primary_low_suspicious_span']} | "
                f"action_peak={act['primary_suspicious_span']}({primary_edit_type}) | "
                f"action_valley={act['primary_low_suspicious_span']}({primary_low_edit_type}) | "
                f"rank={act['primary_rank']}"
            )

        except Exception as e:
            print(f"[{idx}/{len(rows)}] {sid} | ERROR: {repr(e)}")
            results.append({
                "id": sid,
                "image_path": image_path,
                "source_text": source_text,
                "initial_translation": initial_translation,
                "selected_layers": SELECTED_LAYERS,
                "error": repr(e),
                "token_metrics": [],
                "word_metrics": [],
                "suspicious_tokens": [],
                "suspicious_spans": [],

                "score_primary_suspicious_span": "",
                "score_primary_low_suspicious_span": "",
                "score_primary_suspicious_spans": [],
                "score_primary_edit_type": "",
                "score_primary_low_edit_type": "",

                "primary_suspicious_span": "",
                "primary_edit_type": "",
                "primary_low_suspicious_span": "",
                "primary_low_edit_type": "",
                "primary_suspicious_spans": [],
                "primary_edit_types": [],
                "primary_selection_mode": "actionability_first",
                "primary_actionability_rank": 3,
                "primary_pool_spans": [],
            })

        if image is not None:
            image.close()

        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            torch.cuda.ipc_collect()

    write_jsonl(OUTPUT_JSONL, results)
    print("\nDone.")
    print("Saved to:", OUTPUT_JSONL)

if __name__ == "__main__":
    main()