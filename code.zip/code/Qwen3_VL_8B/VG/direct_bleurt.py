#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import argparse

# =====================================================
# 0. 命令行参数：必须在导入 bleurt / tensorflow 前设置 GPU
# =====================================================
ALLOWED_LANGUAGES = {"hi", "ha", "bn", "ma"}


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--lang",
        type=str,
        required=True,
        choices=sorted(ALLOWED_LANGUAGES),
        help="Language code: hi, ha, bn, ma.",
    )
    parser.add_argument(
        "--gpu",
        type=str,
        required=True,
        help="Physical GPU id, for example: 0, 1, 5, 6, 7.",
    )
    return parser.parse_args()


ARGS = parse_args()
LANGUAGE = ARGS.lang
GPU = ARGS.gpu

os.environ["CUDA_VISIBLE_DEVICES"] = str(GPU)
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "2"

import json
import re
from statistics import mean
from typing import List, Dict, Any

from bleurt import score as bleurt_score


# =====================================================
# 1. 路径配置
# =====================================================
VG_DATA_ROOT = "/home/chenyi/offline_blaser_qe/dataSet/VG"
IMAGE_DIR = "/home/chenyi/offline_blaser_qe/dataSet/VG/images"

OUTPUT_ROOT = "/home/chenyi/offline_blaser_qe/out/Qwen_3_VL_8B/VG"

# 翻译程序输出文件：包含 initial_translation_en / initial_translation
INPUT_JSONL = os.path.join(
    OUTPUT_ROOT,
    LANGUAGE,
    f"{LANGUAGE}_test_translation.jsonl",
)

# VG 原始测试集：用于补充 reference_translation / source_text / image_path
REFERENCE_JSONL = os.path.join(
    VG_DATA_ROOT,
    LANGUAGE,
    f"{LANGUAGE}_vg_test.jsonl",
)

OUTPUT_DIR = os.path.join(
    OUTPUT_ROOT,
    LANGUAGE,
)

OUTPUT_JSONL = os.path.join(
    OUTPUT_DIR,
    f"{LANGUAGE}_test_translation_initial_bleurt.jsonl",
)

# BLEURT-20 模型目录
BLEURT_CHECKPOINT = "/mnt/raid/gzy/bleurt_model/BLEURT-20"

# 每批打分数量，显存不足时可以调小
BATCH_SIZE = 32


# =====================================================
# 2. 基础工具
# =====================================================
def clean_text(x: Any) -> str:
    if x is None:
        return ""
    return re.sub(r"\s+", " ", str(x).strip())


def norm_text(x: Any) -> str:
    x = clean_text(x).lower()
    x = x.replace("’", "'").replace("“", '"').replace("”", '"')
    x = re.sub(r"[^a-z0-9_\-\s]", " ", x)
    x = re.sub(r"\s+", " ", x).strip()
    return x


def first_nonempty(row: Dict[str, Any], keys: List[str]) -> str:
    for key in keys:
        value = clean_text(row.get(key, ""))
        if value:
            return value
    return ""


def read_jsonl(path: str, required: bool = True) -> List[Dict[str, Any]]:
    if not os.path.exists(path):
        if required:
            raise FileNotFoundError(f"找不到输入文件: {path}")
        print(f"[WARN] 文件不存在，跳过读取: {path}")
        return []

    rows = []

    with open(path, "r", encoding="utf-8") as f:
        for line_no, line in enumerate(f, 1):
            line = line.strip()

            if not line:
                continue

            try:
                row = json.loads(line)
            except Exception as e:
                raise ValueError(f"第 {line_no} 行不是合法 JSON: {e}")

            rows.append(row)

    return rows


def write_jsonl(path: str, rows: List[Dict[str, Any]]) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)

    with open(path, "w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


def get_row_id(row: Dict[str, Any]) -> str:
    return clean_text(row.get("id", row.get("image_id", "")))


def get_image_id(row: Dict[str, Any]) -> str:
    return clean_text(row.get("image_id", row.get("id", "")))


def get_source_text(row: Dict[str, Any]) -> str:
    return first_nonempty(
        row,
        [
            "source_text",
            "src",
            "tgt",
            "target",
        ],
    )


def get_reference_translation_direct(row: Dict[str, Any]) -> str:
    return first_nonempty(
        row,
        [
            "reference_translation",
            "src_en",
            "source_text_en",
            "reference",
            "source",
        ],
    )


def get_initial_translation(row: Dict[str, Any]) -> str:
    return first_nonempty(
        row,
        [
            "initial_translation_en",
            "initial_translation",
            "translation",
            "mt",
        ],
    )


def resolve_image_path(row: Dict[str, Any]) -> str:
    for key in ["image_path", "image", "img_path"]:
        path = clean_text(row.get(key, ""))
        if path and os.path.isfile(path):
            return path

    image_id = get_image_id(row)
    if not image_id:
        return ""

    candidates = [
        os.path.join(IMAGE_DIR, f"{image_id}.jpg"),
        os.path.join(IMAGE_DIR, f"{image_id}.jpeg"),
        os.path.join(IMAGE_DIR, f"{image_id}.png"),
        os.path.join(IMAGE_DIR, f"{image_id}.JPG"),
        os.path.join(IMAGE_DIR, f"{image_id}.JPEG"),
        os.path.join(IMAGE_DIR, f"{image_id}.PNG"),
    ]

    for path in candidates:
        if os.path.isfile(path):
            return path

    return ""


def row_match_keys(row: Dict[str, Any]) -> List[str]:
    keys = []

    row_id = get_row_id(row)
    image_id = get_image_id(row)

    if row_id:
        keys.append(f"id::{row_id}")

    if image_id:
        keys.append(f"id::{image_id}")

    image_path = clean_text(row.get("image_path", row.get("image", "")))
    if image_path:
        stem = os.path.splitext(os.path.basename(image_path))[0]
        if stem:
            keys.append(f"id::{stem}")

    source_text = get_source_text(row)
    if source_text:
        keys.append(f"src::{norm_text(source_text)}")

    return list(dict.fromkeys(keys))


def build_reference_map(reference_rows: List[Dict[str, Any]]) -> Dict[str, Dict[str, str]]:
    """
    从 VG 原始测试集建立回退映射。
    常见字段兼容：
      id / image_id
      source_text / target / src / tgt
      reference_translation / src_en / source / reference
      image_path / image
    """
    ref_map: Dict[str, Dict[str, str]] = {}

    for row in reference_rows:
        ref = get_reference_translation_direct(row)
        source_text = get_source_text(row)
        image_path = resolve_image_path(row)

        if not ref:
            continue

        value = {
            "reference_translation": ref,
            "source_text": source_text,
            "image_path": image_path,
        }

        for key in row_match_keys(row):
            if key not in ref_map:
                ref_map[key] = value

    return ref_map


def lookup_reference_info(
    row: Dict[str, Any],
    ref_map: Dict[str, Dict[str, str]],
) -> Dict[str, str]:
    direct_ref = get_reference_translation_direct(row)
    direct_source = get_source_text(row)
    direct_image_path = resolve_image_path(row)

    info = {
        "reference_translation": direct_ref,
        "source_text": direct_source,
        "image_path": direct_image_path,
    }

    if direct_ref and direct_source and direct_image_path:
        return info

    for key in row_match_keys(row):
        if key not in ref_map:
            continue

        ref_info = ref_map[key]

        if not info["reference_translation"]:
            info["reference_translation"] = clean_text(ref_info.get("reference_translation", ""))

        if not info["source_text"]:
            info["source_text"] = clean_text(ref_info.get("source_text", ""))

        if not info["image_path"]:
            info["image_path"] = clean_text(ref_info.get("image_path", ""))

    return info


# =====================================================
# 3. BLEURT 打分
# =====================================================
def compute_bleurt_scores(
    scorer,
    references: List[str],
    candidates: List[str],
    batch_size: int = 32,
) -> List[float]:
    all_scores = []
    total = len(references)

    for start in range(0, total, batch_size):
        end = min(start + batch_size, total)

        refs_batch = references[start:end]
        cands_batch = candidates[start:end]

        scores = scorer.score(
            references=refs_batch,
            candidates=cands_batch,
        )

        all_scores.extend(scores)

        print(f"[INFO] BLEURT scored {end}/{total}")

    return all_scores


# =====================================================
# 4. 主流程
# =====================================================
def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    print(f"[INFO] LANGUAGE: {LANGUAGE}")
    print(f"[INFO] GPU: {GPU}")
    print(f"[INFO] CUDA_VISIBLE_DEVICES: {os.environ.get('CUDA_VISIBLE_DEVICES')}")
    print(f"[INFO] VG_DATA_ROOT: {VG_DATA_ROOT}")
    print(f"[INFO] IMAGE_DIR: {IMAGE_DIR}")
    print(f"[INFO] OUTPUT_ROOT: {OUTPUT_ROOT}")
    print(f"[INFO] INPUT_JSONL: {INPUT_JSONL}")
    print(f"[INFO] REFERENCE_JSONL: {REFERENCE_JSONL}")
    print(f"[INFO] OUTPUT_JSONL: {OUTPUT_JSONL}")
    print(f"[INFO] BLEURT_CHECKPOINT: {BLEURT_CHECKPOINT}")
    print(f"[INFO] BATCH_SIZE: {BATCH_SIZE}")

    rows = read_jsonl(INPUT_JSONL, required=True)
    print(f"[INFO] 读取翻译结果样本数: {len(rows)}")

    if not rows:
        raise ValueError("输入文件为空，无法打分。")

    reference_rows = read_jsonl(REFERENCE_JSONL, required=False)
    ref_map = build_reference_map(reference_rows) if reference_rows else {}

    print(f"[INFO] 读取 VG reference 样本数: {len(reference_rows)}")
    print(f"[INFO] reference map keys: {len(ref_map)}")

    references = []
    candidates = []
    valid_rows = []
    skipped_rows = []

    for row in rows:
        info = lookup_reference_info(row, ref_map)

        ref = clean_text(info.get("reference_translation", ""))
        hyp = get_initial_translation(row)

        if not ref or not hyp:
            skipped_rows.append({
                "id": row.get("id", ""),
                "image_id": row.get("image_id", ""),
                "language": LANGUAGE,
                "reason": "empty_reference_or_initial_translation",
                "reference_translation": ref,
                "initial_translation": hyp,
            })
            continue

        references.append(ref)
        candidates.append(hyp)

        row_copy = dict(row)
        row_copy["_resolved_reference_translation"] = ref
        row_copy["_resolved_source_text"] = clean_text(info.get("source_text", ""))
        row_copy["_resolved_image_path"] = clean_text(info.get("image_path", ""))

        valid_rows.append(row_copy)

    print(f"[INFO] 有效打分样本数: {len(valid_rows)}")
    print(f"[INFO] 跳过样本数: {len(skipped_rows)}")

    if not valid_rows:
        raise ValueError("没有有效样本：reference_translation 或 initial_translation 全为空。")

    print(f"[INFO] 正在加载 BLEURT 模型: {BLEURT_CHECKPOINT}")

    if not os.path.exists(BLEURT_CHECKPOINT):
        raise FileNotFoundError(f"找不到 BLEURT 模型路径: {BLEURT_CHECKPOINT}")

    scorer = bleurt_score.BleurtScorer(BLEURT_CHECKPOINT)
    print("[INFO] BLEURT 模型加载完成。")

    print("[INFO] 开始 BLEURT 打分...")

    scores_raw = compute_bleurt_scores(
        scorer=scorer,
        references=references,
        candidates=candidates,
        batch_size=BATCH_SIZE,
    )

    scored_rows = []

    for row, score in zip(valid_rows, scores_raw):
        reference_translation = clean_text(row.get("_resolved_reference_translation", ""))
        source_text = clean_text(row.get("_resolved_source_text", "")) or get_source_text(row)
        image_path = clean_text(row.get("_resolved_image_path", "")) or resolve_image_path(row)
        initial_translation = get_initial_translation(row)

        out = {
            "id": get_row_id(row),
            "image_id": get_image_id(row),
            "language": LANGUAGE,
            "image_path": image_path,
            "source_text": source_text,
            "reference_translation": reference_translation,
            "initial_translation": initial_translation,
            "bleurt_raw": round(float(score), 6),
            "bleurt_100": round(float(score) * 100, 2),
        }

        scored_rows.append(out)

    avg_raw = mean([float(x) for x in scores_raw])
    avg_100 = avg_raw * 100

    avg_row = {
        "id": "AVERAGE_SCORE",
        "image_id": "---",
        "language": LANGUAGE,
        "image_path": "---",
        "source_text": "---",
        "reference_translation": "---",
        "initial_translation": "---",
        "bleurt_raw": round(float(avg_raw), 6),
        "bleurt_100": round(float(avg_100), 2),
    }

    scored_rows.append(avg_row)

    write_jsonl(OUTPUT_JSONL, scored_rows)

    print("\n[DONE] BLEURT 打分完成。")
    print(f"[RESULT] language = {LANGUAGE}")
    print(f"[RESULT] total rows = {len(rows)}")
    print(f"[RESULT] valid scored rows = {len(valid_rows)}")
    print(f"[RESULT] skipped rows = {len(skipped_rows)}")
    print(f"[RESULT] average BLEURT raw = {avg_raw:.6f}")
    print(f"[RESULT] average BLEURT x100 = {avg_100:.2f}")
    print(f"[SAVE] JSONL: {OUTPUT_JSONL}")

    if skipped_rows:
        print("[WARN] 存在跳过样本。原因通常是 reference_translation 或 initial_translation 为空。")


if __name__ == "__main__":
    main()