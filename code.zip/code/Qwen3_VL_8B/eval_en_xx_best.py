#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import argparse

# =====================================================
# 0. 命令行参数：必须在 import torch 前解析并设置 GPU
# =====================================================

VG_LANGUAGES = {"hi", "ha", "bn", "ma"}
MULTI30K_LANGUAGES = {"hi", "lv", "tr"}
ALL_LANGUAGES = VG_LANGUAGES | MULTI30K_LANGUAGES

DATA_DIR_NAME = {
    "vg": "VG",
    "multi30k": "Multi30k",
}


def parse_args():
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--data",
        type=str,
        required=True,
        choices=["vg", "multi30k"],
        help="Dataset name: vg or multi30k.",
    )

    parser.add_argument(
        "--lang",
        type=str,
        required=True,
        choices=sorted(ALL_LANGUAGES),
        help="Language code. VG: bn, ha, hi, ma. Multi30K: hi, lv, tr.",
    )

    parser.add_argument(
        "--gpu",
        type=str,
        required=True,
        help="Physical GPU id, for example: 0, 1, 2, 5, 6, 7.",
    )

    parser.add_argument(
        "--alpha",
        type=float,
        required=True,
        help="CONTRAST_ALPHA used by translation file. Example: 0, 0.05, 0.09, 0.1.",
    )

    return parser.parse_args()


ARGS = parse_args()

DATASET = ARGS.data.strip().lower()
LANGUAGE = ARGS.lang.strip().lower()
GPU = str(ARGS.gpu).strip()
CONTRAST_ALPHA = float(ARGS.alpha)

if DATASET == "vg" and LANGUAGE not in VG_LANGUAGES:
    raise ValueError(
        f"--data vg only supports languages: {sorted(VG_LANGUAGES)}, "
        f"but got --lang {LANGUAGE}"
    )

if DATASET == "multi30k" and LANGUAGE not in MULTI30K_LANGUAGES:
    raise ValueError(
        f"--data multi30k only supports languages: {sorted(MULTI30K_LANGUAGES)}, "
        f"but got --lang {LANGUAGE}"
    )

DATA_OUTPUT_NAME = DATA_DIR_NAME[DATASET]


def alpha_to_filename_tag(alpha: float) -> str:
    """
    与翻译程序输出文件命名保持一致。

    例：
        0       -> "0"
        0.05    -> "0.05"
        0.09    -> "0.09"
        0.1     -> "0.1"
    """
    return f"{float(alpha):g}"


ALPHA_TAG = alpha_to_filename_tag(CONTRAST_ALPHA)

# ====== 环境变量必须在 import torch 前设置 ======
os.environ["CUDA_VISIBLE_DEVICES"] = GPU
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"

os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"
os.environ["TOKENIZERS_PARALLELISM"] = "false"

os.environ["HF_HOME"] = "/home/chenyi/model_cache/huggingface"
os.environ["TRANSFORMERS_CACHE"] = "/home/chenyi/model_cache/huggingface/hub"

SYSLIBS_DIR = "/home/chenyi/offline_blaser_qe/syslibs"
os.environ["LD_LIBRARY_PATH"] = SYSLIBS_DIR + ":" + os.environ.get("LD_LIBRARY_PATH", "")

import json
import logging
import warnings
from typing import List, Tuple, Dict, Any

import torch
import sacrebleu

# ====== 日志降噪 ======
warnings.filterwarnings("ignore", category=UserWarning)

logging.getLogger("pytorch_lightning").setLevel(logging.ERROR)
logging.getLogger("lightning.pytorch").setLevel(logging.ERROR)
logging.getLogger("lightning").setLevel(logging.ERROR)

# ====== COMET / XCOMET ======
try:
    from comet.models.regression.regression_metric import RegressionMetric
except Exception:
    RegressionMetric = None

try:
    from comet.models.multitask.xcomet_metric import XCOMETMetric
except Exception:
    XCOMETMetric = None


# =====================================================
# 1. 路径配置
# =====================================================

OUTPUT_ROOT_BASE = "/home/chenyi/offline_blaser_qe/out/Qwen3_VL_8B"

OUTPUT_ROOT = os.path.join(
    OUTPUT_ROOT_BASE,
    DATA_OUTPUT_NAME,
)

# =====================================================
# English -> target language full-main contrastive 输出
#
# 示例：
# /home/chenyi/offline_blaser_qe/out/Qwen3_VL_8B/VG/ma/en_ma_0.09_full_main_contrast_translation.jsonl
# =====================================================

INPUT_JSONL = os.path.join(
    OUTPUT_ROOT,
    LANGUAGE,
    f"en_{LANGUAGE}_{ALPHA_TAG}_full_main_contrast_translation.jsonl",
)

OUTPUT_DIR = os.path.join(
    OUTPUT_ROOT,
    LANGUAGE,
)

OUTPUT_JSONL = os.path.join(
    OUTPUT_DIR,
    f"en_{LANGUAGE}_{ALPHA_TAG}_full_main_contrast_translation_scored.jsonl",
)

# =====================================================
# 2. 输入字段配置：适配 English -> target language
# =====================================================
#
# VG 原始方向调换后：
#   src_en -> English source
#   tgt    -> target-language reference
#
# Multi30K 原始方向调换后：
#   source -> English source
#   target -> target-language reference
#
# 如果翻译程序已经统一输出：
#   source_text / reference_translation
# 则优先读取统一字段。
# =====================================================

SOURCE_FIELD_CANDIDATES = [
    "source_text",
    "src_en",
    "source",
    "english_source",
    "en_source",
    "src",
    "text",
]

REFERENCE_FIELD_CANDIDATES = [
    "reference_translation",
    "tgt",
    "target",
    "target_text",
    "reference",
    "ref",
]

HYP_FIELD_PRIMARY = "full_main_contrast_translation_en"
HYP_FIELD_FALLBACK = "text_main_contrast_translation_en"
OUTPUT_HYP_FIELD = "full_main_contrast_translation_en"

# ===== COMET / XCOMET 模型路径 =====
COMET_MODEL_DIR = "/mnt/raid/gzy/comet_model/wmt22-comet-da"
COMET_MODEL_CKPT = os.path.join(COMET_MODEL_DIR, "checkpoints", "model.ckpt")
COMET_ENCODER_DIR = os.path.join(COMET_MODEL_DIR, "xlm-roberta-large")

XCOMET_MODEL_DIR = "/mnt/raid/gzy/comet_model/XCOMET-XL"
XCOMET_MODEL_CKPT = os.path.join(XCOMET_MODEL_DIR, "checkpoints", "model.ckpt")
XCOMET_ENCODER_DIR = os.path.join(XCOMET_MODEL_DIR, "xlm-roberta-xl")

COMET_BATCH_SIZE = 16
USE_GPU = True


# =====================================================
# 3. 工具函数
# =====================================================

def get_gpus_flag() -> int:
    if USE_GPU and torch.cuda.is_available():
        return 1
    return 0


def read_jsonl(path: str) -> List[dict]:
    rows = []

    with open(path, "r", encoding="utf-8") as f:
        for line_idx, line in enumerate(f, start=1):
            line = line.strip()

            if not line:
                continue

            try:
                row = json.loads(line)
            except Exception as e:
                print(f"[WARN] 文件 {path} 第 {line_idx} 行 JSON 解析失败，已跳过: {e}")
                continue

            if row.get("record_type") == "summary":
                continue

            if str(row.get("id", "")).strip() in {"AVERAGE_SCORE", "__average__"}:
                continue

            rows.append(row)

    return rows


def write_jsonl(path: str, rows: List[dict]) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)

    with open(path, "w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


def normalize_text(x: Any) -> str:
    if x is None:
        return ""
    return str(x).strip()


def first_non_empty(row: Dict[str, Any], fields: List[str]) -> str:
    for field in fields:
        value = normalize_text(row.get(field, ""))
        if value:
            return value
    return ""


def first_non_empty_with_field(row: Dict[str, Any], fields: List[str]) -> Tuple[str, str]:
    for field in fields:
        value = normalize_text(row.get(field, ""))
        if value:
            return value, field
    return "", ""


def get_row_id(row: Dict[str, Any], fallback_idx: int) -> str:
    for k in ["id", "image_id", "qid", "question_id"]:
        if k in row and row[k] is not None:
            return str(row[k])
    return str(fallback_idx)


def compute_bleu_chrf(
    hyps: List[str],
    refs: List[str],
) -> Tuple[List[float], List[float], float, float]:
    """
    BLEU:
        - 每条样本使用 sacrebleu.sentence_bleu
        - 最终平均 BLEU 使用 sentence BLEU 的算术平均

    chrF++:
        - 每条样本使用 sacrebleu.sentence_chrf
        - 最终系统分使用 sacrebleu.corpus_chrf
    """

    bleu_seg = [
        round(sacrebleu.sentence_bleu(h, [r]).score, 2)
        for h, r in zip(hyps, refs)
    ]

    chrf = sacrebleu.corpus_chrf(hyps, [refs])

    chrf_seg = [
        round(sacrebleu.sentence_chrf(h, [r]).score, 2)
        for h, r in zip(hyps, refs)
    ]

    if len(bleu_seg) > 0:
        bleu_sys = round(sum(bleu_seg) / len(bleu_seg), 2)
    else:
        bleu_sys = float("nan")

    chrf_sys = round(chrf.score, 2)

    print(f"[RESULT] BLEU sentence average = {bleu_sys:.2f}")
    print(f"[RESULT] chrF++ corpus score    = {chrf_sys:.2f}")

    return bleu_seg, chrf_seg, bleu_sys, chrf_sys


def compute_comet(
    comet_model,
    srcs: List[str],
    hyps: List[str],
    refs: List[str],
) -> Tuple[List[float], float]:
    samples = [
        {
            "src": s,
            "mt": h,
            "ref": r,
        }
        for s, h, r in zip(srcs, hyps, refs)
    ]

    gpus = get_gpus_flag()

    result = comet_model.predict(
        samples,
        batch_size=COMET_BATCH_SIZE,
        gpus=gpus,
        progress_bar=False,
    )

    if isinstance(result, dict):
        sys_score = result.get("system_score", float("nan"))
        scores = result.get("scores", [float("nan")] * len(srcs))
    else:
        scores, sys_score = result

    scores_100 = [
        round(float(s) * 100, 2) if s == s else float("nan")
        for s in scores
    ]

    if isinstance(sys_score, str):
        try:
            sys_score_float = round(float(sys_score) * 100, 2)
        except ValueError:
            print(f"[RESULT] COMET system score = {sys_score}")
            return scores_100, float("nan")
    else:
        sys_score_float = round(float(sys_score) * 100, 2)

    print(f"[RESULT] COMET (wmt22-comet-da) system score = {sys_score_float:.2f}")

    return scores_100, sys_score_float


def compute_xcomet(
    xcomet_model,
    srcs: List[str],
    hyps: List[str],
) -> Tuple[List[float], float]:
    samples = [
        {
            "src": s,
            "mt": h,
        }
        for s, h in zip(srcs, hyps)
    ]

    gpus = get_gpus_flag()

    result = xcomet_model.predict(
        samples,
        batch_size=COMET_BATCH_SIZE,
        gpus=gpus,
        progress_bar=False,
    )

    if isinstance(result, dict):
        sys_score = result.get("system_score", float("nan"))
        scores = result.get("scores", [float("nan")] * len(srcs))
    else:
        scores, sys_score = result

    scores_100 = [
        round(float(s) * 100, 2) if s == s else float("nan")
        for s in scores
    ]

    if isinstance(sys_score, str):
        try:
            sys_score_float = round(float(sys_score) * 100, 2)
        except ValueError:
            print(f"[RESULT] XCOMET-XL system score = {sys_score}")
            return scores_100, float("nan")
    else:
        sys_score_float = round(float(sys_score) * 100, 2)

    print(f"[RESULT] XCOMET-XL system score = {sys_score_float:.2f}")

    return scores_100, sys_score_float


# =====================================================
# 4. 数据读取与整理
# =====================================================

def prepare_rows(rows: List[dict]) -> List[dict]:
    prepared = []
    skipped_empty_source = 0
    skipped_empty_ref = 0
    skipped_empty_hyp = 0

    hyp_field_used_counts = {}

    for idx, row in enumerate(rows, start=1):
        row_id = get_row_id(row, fallback_idx=idx)

        source_text, source_field_used = first_non_empty_with_field(
            row,
            SOURCE_FIELD_CANDIDATES,
        )

        ref, reference_field_used = first_non_empty_with_field(
            row,
            REFERENCE_FIELD_CANDIDATES,
        )

        hyp, hyp_field_used = first_non_empty_with_field(
            row,
            [
                HYP_FIELD_PRIMARY,
                HYP_FIELD_FALLBACK,
            ],
        )

        if not source_text:
            skipped_empty_source += 1
            continue

        if not ref:
            skipped_empty_ref += 1
            continue

        if not hyp:
            skipped_empty_hyp += 1
            continue

        hyp_field_used_counts[hyp_field_used] = hyp_field_used_counts.get(hyp_field_used, 0) + 1

        prepared.append({
            "id": str(row_id),
            "source_text": source_text,
            "reference_translation": ref,
            OUTPUT_HYP_FIELD: hyp,
            "source_field_used": source_field_used,
            "reference_field_used": reference_field_used,
            "hypothesis_field_used": hyp_field_used,
        })

    print(f"[INFO] 可评分条数: {len(prepared)}")
    print(f"[INFO] 因 source_text 为空而跳过: {skipped_empty_source}")
    print(f"[INFO] 因 reference_translation 为空而跳过: {skipped_empty_ref}")
    print(f"[INFO] 因 hypothesis 为空而跳过: {skipped_empty_hyp}")
    print(f"[INFO] hypothesis field used counts: {hyp_field_used_counts}")

    return prepared


# =====================================================
# 5. 主函数
# =====================================================

def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    print("========== Runtime Config ==========")
    print(f"[INFO] DATASET: {DATASET}")
    print(f"[INFO] DATA_OUTPUT_NAME: {DATA_OUTPUT_NAME}")
    print(f"[INFO] LANGUAGE: {LANGUAGE}")
    print(f"[INFO] GPU: {GPU}")
    print(f"[INFO] CONTRAST_ALPHA: {CONTRAST_ALPHA}")
    print(f"[INFO] ALPHA_TAG: {ALPHA_TAG}")
    print(f"[INFO] CUDA_VISIBLE_DEVICES: {os.environ.get('CUDA_VISIBLE_DEVICES')}")
    print(f"[INFO] torch.cuda.is_available: {torch.cuda.is_available()}")
    print(f"[INFO] torch.cuda.device_count: {torch.cuda.device_count()}")
    print(f"[INFO] OUTPUT_ROOT_BASE: {OUTPUT_ROOT_BASE}")
    print(f"[INFO] OUTPUT_ROOT: {OUTPUT_ROOT}")
    print(f"[INFO] INPUT_JSONL: {INPUT_JSONL}")
    print(f"[INFO] OUTPUT_JSONL: {OUTPUT_JSONL}")
    print(f"[INFO] SOURCE_FIELD_CANDIDATES: {SOURCE_FIELD_CANDIDATES}")
    print(f"[INFO] REFERENCE_FIELD_CANDIDATES: {REFERENCE_FIELD_CANDIDATES}")
    print(f"[INFO] HYP_FIELD_PRIMARY: {HYP_FIELD_PRIMARY}")
    print(f"[INFO] HYP_FIELD_FALLBACK: {HYP_FIELD_FALLBACK}")
    print(f"[INFO] OUTPUT_HYP_FIELD: {OUTPUT_HYP_FIELD}")
    print(f"[INFO] COMET_MODEL_CKPT: {COMET_MODEL_CKPT}")
    print(f"[INFO] COMET_ENCODER_DIR: {COMET_ENCODER_DIR}")
    print(f"[INFO] XCOMET_MODEL_CKPT: {XCOMET_MODEL_CKPT}")
    print(f"[INFO] XCOMET_ENCODER_DIR: {XCOMET_ENCODER_DIR}")
    print("====================================")

    if not os.path.exists(INPUT_JSONL):
        raise FileNotFoundError(f"输入文件不存在: {INPUT_JSONL}")

    print(f"[INFO] 读取输入文件: {INPUT_JSONL}")
    rows = read_jsonl(INPUT_JSONL)
    print(f"[INFO] 读入条数: {len(rows)}")

    prepared_rows = prepare_rows(rows)

    if len(prepared_rows) == 0:
        raise RuntimeError(
            f"没有可评分的数据，无法继续。请检查字段: "
            f"{SOURCE_FIELD_CANDIDATES}, "
            f"{REFERENCE_FIELD_CANDIDATES}, "
            f"{HYP_FIELD_PRIMARY}/{HYP_FIELD_FALLBACK}"
        )

    src_list = [row["source_text"] for row in prepared_rows]
    hyp_list = [row[OUTPUT_HYP_FIELD] for row in prepared_rows]
    ref_list = [row["reference_translation"] for row in prepared_rows]

    # -----------------------------------------------------
    # 加载 COMET
    # -----------------------------------------------------
    print("[INFO] 正在加载 COMET 模型 (wmt22-comet-da)...")

    if RegressionMetric is None:
        raise RuntimeError("找不到 RegressionMetric，请检查 comet 安装版本。")

    if not os.path.exists(COMET_MODEL_CKPT):
        raise FileNotFoundError(f"COMET checkpoint 不存在: {COMET_MODEL_CKPT}")

    if not os.path.isdir(COMET_ENCODER_DIR):
        raise FileNotFoundError(f"COMET encoder 目录不存在: {COMET_ENCODER_DIR}")

    comet_model = RegressionMetric.load_from_checkpoint(
        COMET_MODEL_CKPT,
        pretrained_model=COMET_ENCODER_DIR,
        load_pretrained_weights=False,
        strict=False,
    )

    if get_gpus_flag() > 0:
        comet_model = comet_model.cuda()

    comet_model.eval()

    # -----------------------------------------------------
    # 加载 XCOMET
    # -----------------------------------------------------
    print("[INFO] 正在加载 XCOMET 模型 (XCOMET-XL)...")

    if XCOMETMetric is None:
        raise RuntimeError("找不到 XCOMETMetric，请确认 unbabel-comet 版本 >= 2.2.0。")

    if not os.path.exists(XCOMET_MODEL_CKPT):
        raise FileNotFoundError(f"XCOMET checkpoint 不存在: {XCOMET_MODEL_CKPT}")

    if not os.path.isdir(XCOMET_ENCODER_DIR):
        raise FileNotFoundError(f"XCOMET encoder 目录不存在: {XCOMET_ENCODER_DIR}")

    xcomet_model = XCOMETMetric.load_from_checkpoint(
        XCOMET_MODEL_CKPT,
        pretrained_model=XCOMET_ENCODER_DIR,
        load_pretrained_weights=False,
        strict=False,
    )

    if get_gpus_flag() > 0:
        xcomet_model = xcomet_model.cuda()

    xcomet_model.eval()

    print("[INFO] 模型加载完成，开始评估。")

    # -----------------------------------------------------
    # BLEU / chrF++
    # -----------------------------------------------------
    print("[INFO] 评估 BLEU / chrF++ ...")
    bleu_seg, chrf_seg, bleu_sys, chrf_sys = compute_bleu_chrf(
        hyp_list,
        ref_list,
    )

    # -----------------------------------------------------
    # COMET
    # -----------------------------------------------------
    print("[INFO] 评估 COMET ...")
    comet_seg, comet_sys = compute_comet(
        comet_model,
        src_list,
        hyp_list,
        ref_list,
    )

    # -----------------------------------------------------
    # XCOMET
    # -----------------------------------------------------
    print("[INFO] 评估 XCOMET-XL ...")
    xcomet_seg, xcomet_sys = compute_xcomet(
        xcomet_model,
        src_list,
        hyp_list,
    )

    # -----------------------------------------------------
    # 整理输出
    # -----------------------------------------------------
    output_rows = []

    for i, row in enumerate(prepared_rows):
        out = {
            "id": row["id"],
            "data": DATASET,
            "data_output_name": DATA_OUTPUT_NAME,
            "translation_direction": f"English_to_{LANGUAGE}",
            "language": LANGUAGE,
            "contrast_alpha": CONTRAST_ALPHA,
            "alpha_tag": ALPHA_TAG,

            "source_text": row["source_text"],
            "reference_translation": row["reference_translation"],
            OUTPUT_HYP_FIELD: row[OUTPUT_HYP_FIELD],

            "source_field_used": row.get("source_field_used", ""),
            "reference_field_used": row.get("reference_field_used", ""),
            "hypothesis_field_used": row.get("hypothesis_field_used", ""),

            "BLEU": bleu_seg[i],
            "Chrf++": chrf_seg[i],
            "COMET": comet_seg[i],
            "XCOMET-XL": xcomet_seg[i],
        }

        output_rows.append(out)

    avg_row = {
        "record_type": "summary",
        "id": "AVERAGE_SCORE",
        "data": DATASET,
        "data_output_name": DATA_OUTPUT_NAME,
        "translation_direction": f"English_to_{LANGUAGE}",
        "language": LANGUAGE,
        "contrast_alpha": CONTRAST_ALPHA,
        "alpha_tag": ALPHA_TAG,

        "source_text": "---",
        "reference_translation": "---",
        OUTPUT_HYP_FIELD: "---",

        "input_jsonl": INPUT_JSONL,
        "output_jsonl": OUTPUT_JSONL,
        "total_rows_read": len(rows),
        "valid_scored_rows": len(prepared_rows),

        "BLEU": bleu_sys,
        "Chrf++": chrf_sys,
        "COMET": comet_sys,
        "XCOMET-XL": xcomet_sys,
    }

    output_rows.append(avg_row)

    write_jsonl(OUTPUT_JSONL, output_rows)

    print(f"[INFO] JSONL 结果已保存到: {OUTPUT_JSONL}")
    print("[DONE] 全部评估完成。")


if __name__ == "__main__":
    main()