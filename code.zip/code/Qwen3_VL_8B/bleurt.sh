#!/bin/bash
set -e
source /home/guozhengyi/anaconda3/envs/bleurt/bin/activate
cd /home/chenyi/offline_blaser_qe/code/Qwen3_VL_8B

python en_xx_bleurt_direct.py --data vg --lang ha --gpu 2 
python en_xx_bleurt_direct.py --data vg --lang hi --gpu 2 
python en_xx_bleurt_direct.py --data vg --lang ma --gpu 2 
python en_xx_bleurt_direct.py --data vg --lang bn --gpu 2 

python en_xx_bleurt_direct.py --data multi30k --lang lv --gpu 2 
python en_xx_bleurt_direct.py --data multi30k --lang tr --gpu 2 
python en_xx_bleurt_direct.py --data multi30k --lang hi --gpu 2 


# for alpha in 0.1 0.3 0.5 0.7 0.9
# do
#     echo "Running alpha: $lalpha"
    
#     python en_xx_bleurt.py --data vg --lang ha --gpu 2 --alpha $alpha
#     python en_xx_bleurt.py --data vg --lang hi --gpu 2 --alpha $alpha
#     python en_xx_bleurt.py --data vg --lang ma --gpu 2 --alpha $alpha
#     python en_xx_bleurt.py --data vg --lang bn --gpu 2 --alpha $alpha
#     echo "Finished language: $alpha"
# done

# for alpha in 0.1 0.3 0.5 0.7 0.9
# do
#     echo "Running alpha: $lalpha"
#     python en_xx_bleurt.py --data multi30k --lang lv --gpu 2 --alpha $alpha
#     python en_xx_bleurt.py --data multi30k --lang tr --gpu 2 --alpha $alpha
#     python en_xx_bleurt.py --data multi30k --lang hi --gpu 2 --alpha $alpha
   
#     echo "Finished language: $alpha"
# done

echo "All  finished."