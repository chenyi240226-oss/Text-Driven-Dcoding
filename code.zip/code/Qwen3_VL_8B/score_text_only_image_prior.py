#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
score_text_only_image_prior.py

用途：
1. 评估 text_only_and_image_prior 程序生成的两个输出文件：
   - text-only
   - image-prior only

2. 默认适配 English -> XX 的输出文件：
   /home/chenyi/offline_blaser_qe/out/Qwen3_VL_8B/{DATA}/{lang}/en_{lang}_text_only_translation.jsonl
   /home/chenyi/offline_blaser_qe/out/Qwen3_VL_8B/{DATA}/{lang}/en_{lang}_image_prior_only_translation.jsonl

3. 每个输入文件字段为：
   id
   source_text
   reference_translation
   initial_translation

4. 评估指标：
   BLEU
   chrF++
   COMET
   XCOMET-XL

5. 输出：
   每个条件一个 scored 文件：
   en_{lang}_text_only_translation_scored.jsonl
   en_{lang}_image_prior_only_translation_scored.jsonl

   一个汇总文件：
   en_{lang}_text_only_image_prior_summary.jsonl
"""

import os
import argparse

# =====================================================
# 0. 命令行参数：必须在 import torch 前解析并设置 GPU
# =====================================================

VG_LANGUAGES = {"hi", "ha", "bn", "ma"}
MULTI30K_LANGUAGES = {"hi", "lv", "tr"}
ALL_LANGUAGES = VG_LANGUAGES | MULTI30K_LANGUAGES

DATA_DIR_NAME = {
    "vg": "VG",
    "multi30k": "Multi30k",
}

MODEL_ROOT_MAP = {
    "qwen2_vl_7b": "/home/chenyi/offline_blaser_qe/out/Qwen2_VL_7B",
    "qwen3_vl_8b": "/home/chenyi/offline_blaser_qe/out/Qwen3_VL_8B",
    "qwen3_vl_32b": "/home/chenyi/offline_blaser_qe/out/Qwen3_VL_32B",
}


def parse_args():
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--model",
        type=str,
        default="qwen3_vl_8b",
        choices=sorted(MODEL_ROOT_MAP.keys()),
        help="Which output root to score.",
    )

    parser.add_argument(
        "--data",
        type=str,
        required=True,
        choices=["vg", "multi30k"],
        help="Dataset name: vg or multi30k.",
    )

    parser.add_argument(
        "--lang",
        type=str,
        required=True,
        choices=sorted(ALL_LANGUAGES),
        help="Language code. VG: bn, ha, hi, ma. Multi30K: hi, lv, tr.",
    )

    parser.add_argument(
        "--gpu",
        type=str,
        required=True,
        help="Physical GPU id, for example: 0, 1, 2, 5, 6, 7.",
    )

    parser.add_argument(
        "--direction",
        type=str,
        default="en2xx",
        choices=["en2xx", "xx2en"],
        help="en2xx uses en_{lang}_*.jsonl; xx2en uses {lang}_*.jsonl.",
    )

    parser.add_argument(
        "--condition",
        type=str,
        default="all",
        choices=["all", "text_only", "image_prior_only"],
        help="Which condition to score.",
    )

    parser.add_argument(
        "--batch_size",
        type=int,
        default=16,
        help="COMET / XCOMET batch size.",
    )

    parser.add_argument(
        "--output_root_base",
        type=str,
        default="",
        help="Optional override for output root base.",
    )

    return parser.parse_args()


ARGS = parse_args()

MODEL_NAME = ARGS.model.strip().lower()
DATASET = ARGS.data.strip().lower()
LANGUAGE = ARGS.lang.strip().lower()
GPU = str(ARGS.gpu).strip()
DIRECTION = ARGS.direction.strip().lower()
CONDITION_ARG = ARGS.condition.strip().lower()
COMET_BATCH_SIZE = int(ARGS.batch_size)

if DATASET == "vg" and LANGUAGE not in VG_LANGUAGES:
    raise ValueError(
        f"--data vg only supports languages: {sorted(VG_LANGUAGES)}, "
        f"but got --lang {LANGUAGE}"
    )

if DATASET == "multi30k" and LANGUAGE not in MULTI30K_LANGUAGES:
    raise ValueError(
        f"--data multi30k only supports languages: {sorted(MULTI30K_LANGUAGES)}, "
        f"but got --lang {LANGUAGE}"
    )

DATA_OUTPUT_NAME = DATA_DIR_NAME[DATASET]

if ARGS.output_root_base.strip():
    OUTPUT_ROOT_BASE = ARGS.output_root_base.strip()
else:
    OUTPUT_ROOT_BASE = MODEL_ROOT_MAP[MODEL_NAME]

OUTPUT_DIR = os.path.join(
    OUTPUT_ROOT_BASE,
    DATA_OUTPUT_NAME,
    LANGUAGE,
)

# ====== 环境变量必须在 import torch 前设置 ======
os.environ["CUDA_VISIBLE_DEVICES"] = GPU
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"

os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"
os.environ["TOKENIZERS_PARALLELISM"] = "false"

os.environ["HF_HOME"] = "/home/chenyi/model_cache/huggingface"
os.environ["TRANSFORMERS_CACHE"] = "/home/chenyi/model_cache/huggingface/hub"

SYSLIBS_DIR = "/home/chenyi/offline_blaser_qe/syslibs"
os.environ["LD_LIBRARY_PATH"] = SYSLIBS_DIR + ":" + os.environ.get("LD_LIBRARY_PATH", "")

import json
import logging
import warnings
from typing import List, Tuple, Dict, Any

import torch
import sacrebleu

# ====== 日志降噪 ======
warnings.filterwarnings("ignore", category=UserWarning)

logging.getLogger("pytorch_lightning").setLevel(logging.ERROR)
logging.getLogger("lightning.pytorch").setLevel(logging.ERROR)
logging.getLogger("lightning").setLevel(logging.ERROR)

# ====== COMET / XCOMET ======
try:
    from comet.models.regression.regression_metric import RegressionMetric
except Exception:
    RegressionMetric = None

try:
    from comet.models.multitask.xcomet_metric import XCOMETMetric
except Exception:
    XCOMETMetric = None


# =====================================================
# 1. 模型路径配置
# =====================================================

COMET_MODEL_DIR = "/mnt/raid/gzy/comet_model/wmt22-comet-da"
COMET_MODEL_CKPT = os.path.join(COMET_MODEL_DIR, "checkpoints", "model.ckpt")
COMET_ENCODER_DIR = os.path.join(COMET_MODEL_DIR, "xlm-roberta-large")

XCOMET_MODEL_DIR = "/mnt/raid/gzy/comet_model/XCOMET-XL"
XCOMET_MODEL_CKPT = os.path.join(XCOMET_MODEL_DIR, "checkpoints", "model.ckpt")
XCOMET_ENCODER_DIR = os.path.join(XCOMET_MODEL_DIR, "xlm-roberta-xl")

USE_GPU = True


# =====================================================
# 2. 字段配置：匹配 text_only/image_prior 输出
# =====================================================

SOURCE_FIELD_CANDIDATES = [
    "source_text",
    "src",
    "source",
    "src_en",
    "target",
    "tgt",
    "text",
]

REFERENCE_FIELD_CANDIDATES = [
    "reference_translation",
    "reference",
    "target_text",
    "target",
    "tgt",
    "src_en",
    "source",
]

HYP_FIELD_CANDIDATES = [
    "initial_translation",
    "initial_translation_en",
    "direct_translation_en",
    "full_main_contrast_translation_en",
    "text_main_contrast_translation_en",
]

OUTPUT_HYP_FIELD = "initial_translation"


# =====================================================
# 3. 路径函数
# =====================================================

def get_condition_list() -> List[str]:
    if CONDITION_ARG == "all":
        return ["text_only", "image_prior_only"]
    return [CONDITION_ARG]


def get_file_prefix() -> str:
    if DIRECTION == "en2xx":
        return f"en_{LANGUAGE}"
    return LANGUAGE


def get_input_jsonl(condition: str) -> str:
    prefix = get_file_prefix()
    return os.path.join(
        OUTPUT_DIR,
        f"{prefix}_{condition}_translation.jsonl",
    )


def get_scored_jsonl(condition: str) -> str:
    prefix = get_file_prefix()
    return os.path.join(
        OUTPUT_DIR,
        f"{prefix}_{condition}_translation_scored.jsonl",
    )


def get_summary_jsonl() -> str:
    prefix = get_file_prefix()

    if CONDITION_ARG == "all":
        name = f"{prefix}_text_only_image_prior_summary.jsonl"
    else:
        name = f"{prefix}_{CONDITION_ARG}_summary.jsonl"

    return os.path.join(OUTPUT_DIR, name)


# =====================================================
# 4. 工具函数
# =====================================================

def get_gpus_flag() -> int:
    if USE_GPU and torch.cuda.is_available():
        return 1
    return 0


def cleanup_cuda():
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        try:
            torch.cuda.ipc_collect()
        except Exception:
            pass


def read_jsonl(path: str) -> List[dict]:
    rows = []

    with open(path, "r", encoding="utf-8") as f:
        for line_idx, line in enumerate(f, start=1):
            line = line.strip()

            if not line:
                continue

            try:
                row = json.loads(line)
            except Exception as e:
                print(f"[WARN] 文件 {path} 第 {line_idx} 行 JSON 解析失败，已跳过: {e}", flush=True)
                continue

            if row.get("record_type") == "summary":
                continue

            if str(row.get("id", "")).strip() in {"AVERAGE_SCORE", "__average__"}:
                continue

            rows.append(row)

    return rows


def write_jsonl(path: str, rows: List[dict]) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)

    with open(path, "w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


def normalize_text(x: Any) -> str:
    if x is None:
        return ""
    return str(x).strip()


def first_non_empty_with_field(row: Dict[str, Any], fields: List[str]) -> Tuple[str, str]:
    for field in fields:
        value = normalize_text(row.get(field, ""))
        if value:
            return value, field
    return "", ""


def get_row_id(row: Dict[str, Any], fallback_idx: int) -> str:
    for k in ["id", "image_id", "qid", "question_id"]:
        if k in row and row[k] is not None:
            return str(row[k])
    return str(fallback_idx)


def safe_float_score(x: Any) -> float:
    try:
        y = float(x)
        if y == y:
            return y
        return float("nan")
    except Exception:
        return float("nan")


# =====================================================
# 5. 数据读取与整理
# =====================================================

def prepare_rows(rows: List[dict], condition: str) -> List[dict]:
    prepared = []

    skipped_empty_source = 0
    skipped_empty_ref = 0
    skipped_empty_hyp = 0

    hyp_field_used_counts = {}
    source_field_used_counts = {}
    reference_field_used_counts = {}

    for idx, row in enumerate(rows, start=1):
        row_id = get_row_id(row, fallback_idx=idx)

        source_text, source_field_used = first_non_empty_with_field(
            row,
            SOURCE_FIELD_CANDIDATES,
        )

        ref, reference_field_used = first_non_empty_with_field(
            row,
            REFERENCE_FIELD_CANDIDATES,
        )

        hyp, hyp_field_used = first_non_empty_with_field(
            row,
            HYP_FIELD_CANDIDATES,
        )

        if not source_text:
            skipped_empty_source += 1
            continue

        if not ref:
            skipped_empty_ref += 1
            continue

        if not hyp:
            skipped_empty_hyp += 1
            continue

        hyp_field_used_counts[hyp_field_used] = hyp_field_used_counts.get(hyp_field_used, 0) + 1
        source_field_used_counts[source_field_used] = source_field_used_counts.get(source_field_used, 0) + 1
        reference_field_used_counts[reference_field_used] = reference_field_used_counts.get(reference_field_used, 0) + 1

        prepared.append({
            "id": str(row_id),
            "condition": condition,
            "source_text": source_text,
            "reference_translation": ref,
            OUTPUT_HYP_FIELD: hyp,
            "source_field_used": source_field_used,
            "reference_field_used": reference_field_used,
            "hypothesis_field_used": hyp_field_used,
        })

    print(f"[INFO] condition={condition} 可评分条数: {len(prepared)}", flush=True)
    print(f"[INFO] condition={condition} 因 source_text 为空而跳过: {skipped_empty_source}", flush=True)
    print(f"[INFO] condition={condition} 因 reference_translation 为空而跳过: {skipped_empty_ref}", flush=True)
    print(f"[INFO] condition={condition} 因 hypothesis 为空而跳过: {skipped_empty_hyp}", flush=True)
    print(f"[INFO] condition={condition} source field used counts: {source_field_used_counts}", flush=True)
    print(f"[INFO] condition={condition} reference field used counts: {reference_field_used_counts}", flush=True)
    print(f"[INFO] condition={condition} hypothesis field used counts: {hyp_field_used_counts}", flush=True)

    return prepared


# =====================================================
# 6. 指标计算
# =====================================================

def compute_bleu_chrf(
    hyps: List[str],
    refs: List[str],
) -> Tuple[List[float], List[float], float, float]:
    """
    BLEU:
        每条样本使用 sacrebleu.sentence_bleu。
        最终平均 BLEU 使用 sentence BLEU 的算术平均。

    chrF++:
        使用 word_order=2。
        每条样本使用 sacrebleu.sentence_chrf。
        最终系统分使用 sacrebleu.corpus_chrf。
    """

    bleu_seg = [
        round(sacrebleu.sentence_bleu(h, [r]).score, 2)
        for h, r in zip(hyps, refs)
    ]

    chrf_seg = [
        round(sacrebleu.sentence_chrf(h, [r], word_order=2).score, 2)
        for h, r in zip(hyps, refs)
    ]

    if len(bleu_seg) > 0:
        bleu_sys = round(sum(bleu_seg) / len(bleu_seg), 2)
    else:
        bleu_sys = float("nan")

    if len(hyps) > 0:
        chrf = sacrebleu.corpus_chrf(hyps, [refs], word_order=2)
        chrf_sys = round(chrf.score, 2)
    else:
        chrf_sys = float("nan")

    return bleu_seg, chrf_seg, bleu_sys, chrf_sys


def compute_comet(
    comet_model,
    srcs: List[str],
    hyps: List[str],
    refs: List[str],
) -> Tuple[List[float], float]:
    samples = [
        {
            "src": s,
            "mt": h,
            "ref": r,
        }
        for s, h, r in zip(srcs, hyps, refs)
    ]

    if not samples:
        return [], float("nan")

    gpus = get_gpus_flag()

    result = comet_model.predict(
        samples,
        batch_size=COMET_BATCH_SIZE,
        gpus=gpus,
        progress_bar=False,
    )

    if isinstance(result, dict):
        sys_score = result.get("system_score", float("nan"))
        scores = result.get("scores", [float("nan")] * len(srcs))
    else:
        scores, sys_score = result

    scores_100 = [
        round(float(s) * 100, 2) if s == s else float("nan")
        for s in scores
    ]

    sys_score_float = safe_float_score(sys_score)

    if sys_score_float == sys_score_float:
        sys_score_float = round(sys_score_float * 100, 2)

    return scores_100, sys_score_float


def compute_xcomet(
    xcomet_model,
    srcs: List[str],
    hyps: List[str],
) -> Tuple[List[float], float]:
    samples = [
        {
            "src": s,
            "mt": h,
        }
        for s, h in zip(srcs, hyps)
    ]

    if not samples:
        return [], float("nan")

    gpus = get_gpus_flag()

    result = xcomet_model.predict(
        samples,
        batch_size=COMET_BATCH_SIZE,
        gpus=gpus,
        progress_bar=False,
    )

    if isinstance(result, dict):
        sys_score = result.get("system_score", float("nan"))
        scores = result.get("scores", [float("nan")] * len(srcs))
    else:
        scores, sys_score = result

    scores_100 = [
        round(float(s) * 100, 2) if s == s else float("nan")
        for s in scores
    ]

    sys_score_float = safe_float_score(sys_score)

    if sys_score_float == sys_score_float:
        sys_score_float = round(sys_score_float * 100, 2)

    return scores_100, sys_score_float


# =====================================================
# 7. 模型加载
# =====================================================

def load_comet_model():
    print("[INFO] 正在加载 COMET 模型 (wmt22-comet-da)...", flush=True)

    if RegressionMetric is None:
        raise RuntimeError("找不到 RegressionMetric，请检查 comet 安装版本。")

    if not os.path.exists(COMET_MODEL_CKPT):
        raise FileNotFoundError(f"COMET checkpoint 不存在: {COMET_MODEL_CKPT}")

    if not os.path.isdir(COMET_ENCODER_DIR):
        raise FileNotFoundError(f"COMET encoder 目录不存在: {COMET_ENCODER_DIR}")

    comet_model = RegressionMetric.load_from_checkpoint(
        COMET_MODEL_CKPT,
        pretrained_model=COMET_ENCODER_DIR,
        load_pretrained_weights=False,
        strict=False,
    )

    if get_gpus_flag() > 0:
        comet_model = comet_model.cuda()

    comet_model.eval()

    return comet_model


def load_xcomet_model():
    print("[INFO] 正在加载 XCOMET 模型 (XCOMET-XL)...", flush=True)

    if XCOMETMetric is None:
        raise RuntimeError("找不到 XCOMETMetric，请确认 unbabel-comet 版本 >= 2.2.0。")

    if not os.path.exists(XCOMET_MODEL_CKPT):
        raise FileNotFoundError(f"XCOMET checkpoint 不存在: {XCOMET_MODEL_CKPT}")

    if not os.path.isdir(XCOMET_ENCODER_DIR):
        raise FileNotFoundError(f"XCOMET encoder 目录不存在: {XCOMET_ENCODER_DIR}")

    xcomet_model = XCOMETMetric.load_from_checkpoint(
        XCOMET_MODEL_CKPT,
        pretrained_model=XCOMET_ENCODER_DIR,
        load_pretrained_weights=False,
        strict=False,
    )

    if get_gpus_flag() > 0:
        xcomet_model = xcomet_model.cuda()

    xcomet_model.eval()

    return xcomet_model


# =====================================================
# 8. 输出整理
# =====================================================

def build_scored_rows(
    condition: str,
    prepared_rows: List[dict],
    input_jsonl: str,
    output_jsonl: str,
    metric_pack: Dict[str, Any],
) -> Tuple[List[dict], Dict[str, Any]]:

    bleu_seg = metric_pack["bleu_seg"]
    chrf_seg = metric_pack["chrf_seg"]
    comet_seg = metric_pack["comet_seg"]
    xcomet_seg = metric_pack["xcomet_seg"]

    output_rows = []

    for i, row in enumerate(prepared_rows):
        out = {
            "id": row["id"],
            "model": MODEL_NAME,
            "data": DATASET,
            "data_output_name": DATA_OUTPUT_NAME,
            "language": LANGUAGE,
            "direction": DIRECTION,
            "condition": condition,

            "source_text": row["source_text"],
            "reference_translation": row["reference_translation"],
            OUTPUT_HYP_FIELD: row[OUTPUT_HYP_FIELD],

            "source_field_used": row.get("source_field_used", ""),
            "reference_field_used": row.get("reference_field_used", ""),
            "hypothesis_field_used": row.get("hypothesis_field_used", ""),

            "BLEU": bleu_seg[i],
            "Chrf++": chrf_seg[i],
            "COMET": comet_seg[i],
            "XCOMET-XL": xcomet_seg[i],
        }

        output_rows.append(out)

    avg_row = {
        "record_type": "summary",
        "id": "AVERAGE_SCORE",
        "model": MODEL_NAME,
        "data": DATASET,
        "data_output_name": DATA_OUTPUT_NAME,
        "language": LANGUAGE,
        "direction": DIRECTION,
        "condition": condition,

        "source_text": "---",
        "reference_translation": "---",
        OUTPUT_HYP_FIELD: "---",

        "input_jsonl": input_jsonl,
        "output_jsonl": output_jsonl,
        "valid_scored_rows": len(prepared_rows),

        "BLEU": metric_pack["bleu_sys"],
        "Chrf++": metric_pack["chrf_sys"],
        "COMET": metric_pack["comet_sys"],
        "XCOMET-XL": metric_pack["xcomet_sys"],
    }

    output_rows.append(avg_row)

    return output_rows, avg_row


# =====================================================
# 9. 主函数
# =====================================================

def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    conditions = get_condition_list()

    print("========== Runtime Config ==========")
    print(f"[INFO] MODEL_NAME: {MODEL_NAME}")
    print(f"[INFO] DATASET: {DATASET}")
    print(f"[INFO] DATA_OUTPUT_NAME: {DATA_OUTPUT_NAME}")
    print(f"[INFO] LANGUAGE: {LANGUAGE}")
    print(f"[INFO] DIRECTION: {DIRECTION}")
    print(f"[INFO] CONDITIONS: {conditions}")
    print(f"[INFO] GPU: {GPU}")
    print(f"[INFO] CUDA_VISIBLE_DEVICES: {os.environ.get('CUDA_VISIBLE_DEVICES')}")
    print(f"[INFO] torch.cuda.is_available: {torch.cuda.is_available()}")
    print(f"[INFO] torch.cuda.device_count: {torch.cuda.device_count()}")
    print(f"[INFO] OUTPUT_ROOT_BASE: {OUTPUT_ROOT_BASE}")
    print(f"[INFO] OUTPUT_DIR: {OUTPUT_DIR}")
    print(f"[INFO] SOURCE_FIELD_CANDIDATES: {SOURCE_FIELD_CANDIDATES}")
    print(f"[INFO] REFERENCE_FIELD_CANDIDATES: {REFERENCE_FIELD_CANDIDATES}")
    print(f"[INFO] HYP_FIELD_CANDIDATES: {HYP_FIELD_CANDIDATES}")
    print(f"[INFO] OUTPUT_HYP_FIELD: {OUTPUT_HYP_FIELD}")
    print(f"[INFO] COMET_MODEL_CKPT: {COMET_MODEL_CKPT}")
    print(f"[INFO] COMET_ENCODER_DIR: {COMET_ENCODER_DIR}")
    print(f"[INFO] XCOMET_MODEL_CKPT: {XCOMET_MODEL_CKPT}")
    print(f"[INFO] XCOMET_ENCODER_DIR: {XCOMET_ENCODER_DIR}")
    print(f"[INFO] COMET_BATCH_SIZE: {COMET_BATCH_SIZE}")
    print("====================================", flush=True)

    condition_data: Dict[str, Dict[str, Any]] = {}

    for condition in conditions:
        input_jsonl = get_input_jsonl(condition)
        output_jsonl = get_scored_jsonl(condition)

        print(f"[INFO] condition={condition} INPUT_JSONL: {input_jsonl}", flush=True)
        print(f"[INFO] condition={condition} OUTPUT_JSONL: {output_jsonl}", flush=True)

        if not os.path.exists(input_jsonl):
            raise FileNotFoundError(f"输入文件不存在: {input_jsonl}")

        rows = read_jsonl(input_jsonl)
        print(f"[INFO] condition={condition} 读入条数: {len(rows)}", flush=True)

        prepared_rows = prepare_rows(rows, condition=condition)

        if len(prepared_rows) == 0:
            raise RuntimeError(
                f"condition={condition} 没有可评分的数据，无法继续。请检查字段: "
                f"{SOURCE_FIELD_CANDIDATES}, "
                f"{REFERENCE_FIELD_CANDIDATES}, "
                f"{HYP_FIELD_CANDIDATES}"
            )

        src_list = [row["source_text"] for row in prepared_rows]
        hyp_list = [row[OUTPUT_HYP_FIELD] for row in prepared_rows]
        ref_list = [row["reference_translation"] for row in prepared_rows]

        print(f"[INFO] condition={condition} 评估 BLEU / chrF++ ...", flush=True)

        bleu_seg, chrf_seg, bleu_sys, chrf_sys = compute_bleu_chrf(
            hyp_list,
            ref_list,
        )

        print(f"[RESULT] condition={condition} BLEU sentence average = {bleu_sys:.2f}", flush=True)
        print(f"[RESULT] condition={condition} chrF++ corpus score    = {chrf_sys:.2f}", flush=True)

        condition_data[condition] = {
            "input_jsonl": input_jsonl,
            "output_jsonl": output_jsonl,
            "rows_raw_count": len(rows),
            "prepared_rows": prepared_rows,
            "src_list": src_list,
            "hyp_list": hyp_list,
            "ref_list": ref_list,
            "metrics": {
                "bleu_seg": bleu_seg,
                "chrf_seg": chrf_seg,
                "bleu_sys": bleu_sys,
                "chrf_sys": chrf_sys,
            },
        }

    # -----------------------------------------------------
    # COMET：加载一次，依次评估所有 condition，然后释放
    # -----------------------------------------------------
    comet_model = load_comet_model()

    try:
        for condition in conditions:
            data = condition_data[condition]

            print(f"[INFO] condition={condition} 评估 COMET ...", flush=True)

            comet_seg, comet_sys = compute_comet(
                comet_model,
                data["src_list"],
                data["hyp_list"],
                data["ref_list"],
            )

            data["metrics"]["comet_seg"] = comet_seg
            data["metrics"]["comet_sys"] = comet_sys

            print(f"[RESULT] condition={condition} COMET = {comet_sys:.2f}", flush=True)

    finally:
        del comet_model
        cleanup_cuda()

    # -----------------------------------------------------
    # XCOMET：加载一次，依次评估所有 condition，然后释放
    # -----------------------------------------------------
    xcomet_model = load_xcomet_model()

    try:
        for condition in conditions:
            data = condition_data[condition]

            print(f"[INFO] condition={condition} 评估 XCOMET-XL ...", flush=True)

            xcomet_seg, xcomet_sys = compute_xcomet(
                xcomet_model,
                data["src_list"],
                data["hyp_list"],
            )

            data["metrics"]["xcomet_seg"] = xcomet_seg
            data["metrics"]["xcomet_sys"] = xcomet_sys

            print(f"[RESULT] condition={condition} XCOMET-XL = {xcomet_sys:.2f}", flush=True)

    finally:
        del xcomet_model
        cleanup_cuda()

    # -----------------------------------------------------
    # 写出每个 condition 的 scored 文件 + 汇总文件
    # -----------------------------------------------------
    summary_rows = []

    for condition in conditions:
        data = condition_data[condition]

        scored_rows, avg_row = build_scored_rows(
            condition=condition,
            prepared_rows=data["prepared_rows"],
            input_jsonl=data["input_jsonl"],
            output_jsonl=data["output_jsonl"],
            metric_pack=data["metrics"],
        )

        avg_row["total_rows_read"] = data["rows_raw_count"]
        avg_row["output_root_base"] = OUTPUT_ROOT_BASE
        avg_row["output_dir"] = OUTPUT_DIR

        write_jsonl(data["output_jsonl"], scored_rows)

        print(f"[INFO] condition={condition} JSONL 结果已保存到: {data['output_jsonl']}", flush=True)

        summary_rows.append(avg_row)

    summary_jsonl = get_summary_jsonl()
    write_jsonl(summary_jsonl, summary_rows)

    print("========== Summary ==========")

    for row in summary_rows:
        print(
            f"[SUMMARY] condition={row['condition']} | "
            f"valid={row['valid_scored_rows']} | "
            f"BLEU={row['BLEU']} | "
            f"Chrf++={row['Chrf++']} | "
            f"COMET={row['COMET']} | "
            f"XCOMET-XL={row['XCOMET-XL']}",
            flush=True,
        )

    print(f"[INFO] summary saved to: {summary_jsonl}", flush=True)
    print("[DONE] 全部评估完成。", flush=True)


if __name__ == "__main__":
    main()