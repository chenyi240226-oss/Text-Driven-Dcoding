#!/bin/bash
set -e

source /home/guozhengyi/anaconda3/envs/evaluate/bin/activate
cd /home/chenyi/offline_blaser_qe/code/Qwen3_VL_8B

# python eval_en_xx_direct.py --data vg --lang ha --gpu 4 
# python eval_en_xx_direct.py --data vg --lang hi --gpu 4 
# python eval_en_xx_direct.py --data vg --lang ma --gpu 4 
# python eval_en_xx_direct.py --data vg --lang bn --gpu 4 

# python eval_en_xx_direct.py --data multi30k --lang lv --gpu 4 
# python eval_en_xx_direct.py --data multi30k --lang tr --gpu 4 
# python eval_en_xx_direct.py --data multi30k --lang hi --gpu 4 

for alpha in 0.2 0.25 0.3 0.35 0.4 
do
    echo "Running alpha: $lalpha"
    
    python eval_en_xx_best.py --data vg --lang ha --gpu 1 --alpha $alpha
    python eval_en_xx_best.py --data vg --lang hi --gpu 1 --alpha $alpha
    python eval_en_xx_best.py --data vg --lang ma --gpu 1 --alpha $alpha
    python eval_en_xx_best.py --data vg --lang bn --gpu 1 --alpha $alpha
    echo "Finished language: $alpha"
done

for alpha in 0.2 0.25 0.3 0.35 0.4
do
    echo "Running alpha: $lalpha"
    python eval_en_xx_best.py --data multi30k --lang lv --gpu 1 --alpha $alpha
    python eval_en_xx_best.py --data multi30k --lang tr --gpu 1 --alpha $alpha
    python eval_en_xx_best.py --data multi30k --lang hi --gpu 1 --alpha $alpha
   
    echo "Finished language: $alpha"
done

echo "All  finished."