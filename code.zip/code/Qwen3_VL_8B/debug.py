#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
debug_absolute_phrase_top3_three_conditions_qwen3vl_en2xx.py

目标：
1. 只处理一条样本，默认 target_id=707。
2. 不保存任何文件。
3. 不预设候选短语。
4. 在同一个生成前缀下，分别搜索并输出短语级 top3：

   A. Text+Image:
      logits_full

   B. Image-only:
      logits_image

   C. Contrast:
      new_logits = logits_full + alpha * (logits_full - logits_image)

5. 短语概率是绝对序列概率：
      phrase_prob = exp(sum token_logprob)

注意：
- 严格枚举全词表所有可变长短语不可行。
- 本程序使用 beam search 在全词表 top token 分支中近似搜索短语级 top3。
- 不再使用候选短语内部归一化概率。

推荐运行：
python debug_absolute_phrase_top3_three_conditions_qwen3vl_en2xx.py \
  --data multi30k \
  --lang hi \
  --gpu 0 \
  --alpha 0.1 \
  --target_id 707 \
  --print_after_contains "स्टेज पर" \
  --beam_size 80 \
  --expand_topk 128 \
  --phrase_max_tokens 8 \
  --phrase_max_words 3
"""

import os
import argparse

# =====================================================
# 0. 命令行参数：必须在 import torch 前解析并设置 GPU
# =====================================================

VG_LANGUAGES = {"hi", "ha", "bn", "ma"}
MULTI30K_LANGUAGES = {"hi", "lv", "tr"}
ALL_LANGUAGES = VG_LANGUAGES | MULTI30K_LANGUAGES

TARGET_LANGUAGE_NAME_MAP = {
    "hi": "Hindi",
    "ha": "Hausa",
    "bn": "Bengali",
    "ma": "Malayalam",
    "lv": "Latvian",
    "tr": "Turkish",
}

DATA_DIR_NAME = {
    "vg": "VG",
    "multi30k": "Multi30k",
}


def parse_args():
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--data",
        type=str,
        required=True,
        choices=["vg", "multi30k"],
        help="Dataset name: vg or multi30k.",
    )

    parser.add_argument(
        "--lang",
        type=str,
        required=True,
        choices=sorted(ALL_LANGUAGES),
        help="Target language code.",
    )

    parser.add_argument(
        "--gpu",
        type=str,
        required=True,
        help="Physical GPU id.",
    )

    parser.add_argument(
        "--alpha",
        type=float,
        required=True,
        help="Contrast alpha. Example: 0.1.",
    )

    parser.add_argument(
        "--target_id",
        type=str,
        default="707",
        help="Only process this sample id/image_id.",
    )

    parser.add_argument(
        "--max_new_tokens",
        type=int,
        default=64,
        help="Maximum generated tokens before reaching print prefix.",
    )

    parser.add_argument(
        "--print_after_contains",
        type=str,
        default="",
        help=(
            "Only print phrase top3 after generated prefix contains this string. "
            "Example: 'स्टेज पर'. Empty means print at the beginning."
        ),
    )

    parser.add_argument(
        "--beam_size",
        type=int,
        default=80,
        help="Beam size for phrase-level search.",
    )

    parser.add_argument(
        "--expand_topk",
        type=int,
        default=128,
        help="At each phrase-search step, expand top-k tokens from the full vocabulary logits.",
    )

    parser.add_argument(
        "--phrase_topk",
        type=int,
        default=3,
        help="Only output top-k phrase candidates.",
    )

    parser.add_argument(
        "--phrase_max_tokens",
        type=int,
        default=8,
        help="Maximum tokens in one searched phrase.",
    )

    parser.add_argument(
        "--phrase_min_tokens",
        type=int,
        default=1,
        help="Minimum tokens for a valid phrase.",
    )

    parser.add_argument(
        "--phrase_max_words",
        type=int,
        default=3,
        help="Maximum whitespace-separated words in one searched phrase.",
    )

    parser.add_argument(
        "--phrase_min_chars",
        type=int,
        default=2,
        help="Minimum visible characters for a valid phrase.",
    )

    return parser.parse_args()


ARGS = parse_args()

DATASET = ARGS.data.strip().lower()
LANGUAGE = ARGS.lang.strip().lower()
GPU = str(ARGS.gpu).strip()
CONTRAST_ALPHA = float(ARGS.alpha)
TARGET_ID = str(ARGS.target_id).strip()
MAX_NEW_TOKENS = int(ARGS.max_new_tokens)

PRINT_AFTER_CONTAINS = ARGS.print_after_contains.strip()
BEAM_SIZE = int(ARGS.beam_size)
EXPAND_TOPK = int(ARGS.expand_topk)
PHRASE_TOPK = int(ARGS.phrase_topk)
PHRASE_MAX_TOKENS = int(ARGS.phrase_max_tokens)
PHRASE_MIN_TOKENS = int(ARGS.phrase_min_tokens)
PHRASE_MAX_WORDS = int(ARGS.phrase_max_words)
PHRASE_MIN_CHARS = int(ARGS.phrase_min_chars)

if DATASET == "vg" and LANGUAGE not in VG_LANGUAGES:
    raise ValueError(
        f"--data vg only supports languages: {sorted(VG_LANGUAGES)}, "
        f"but got --lang {LANGUAGE}"
    )

if DATASET == "multi30k" and LANGUAGE not in MULTI30K_LANGUAGES:
    raise ValueError(
        f"--data multi30k only supports languages: {sorted(MULTI30K_LANGUAGES)}, "
        f"but got --lang {LANGUAGE}"
    )

DATA_OUTPUT_NAME = DATA_DIR_NAME[DATASET]
SOURCE_LANG_NAME = "English"
TARGET_LANG_NAME = TARGET_LANGUAGE_NAME_MAP[LANGUAGE]

# ====== 环境变量必须在 import torch 前设置 ======
os.environ["CUDA_VISIBLE_DEVICES"] = GPU
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"

os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"
os.environ["TOKENIZERS_PARALLELISM"] = "false"

os.environ["HF_HOME"] = "/home/chenyi/model_cache/huggingface"
os.environ["TRANSFORMERS_CACHE"] = "/home/chenyi/model_cache/huggingface/hub"

SYSLIBS_DIR = "/home/chenyi/offline_blaser_qe/syslibs"
os.environ["LD_LIBRARY_PATH"] = SYSLIBS_DIR + ":" + os.environ.get("LD_LIBRARY_PATH", "")

import re
import json
import math
import warnings
from typing import Dict, Any, List, Optional, Tuple

from PIL import Image

import torch
import torch.nn.functional as F
from transformers import AutoProcessor, AutoModelForVision2Seq


# =====================================================
# Torch compatibility patch
# =====================================================

if not hasattr(torch, "compiler"):
    class _DummyCompiler:
        @staticmethod
        def is_compiling():
            return False

    torch.compiler = _DummyCompiler()
else:
    if not hasattr(torch.compiler, "is_compiling"):
        torch.compiler.is_compiling = lambda: False

warnings.filterwarnings("ignore", category=UserWarning)
torch.set_grad_enabled(False)


# =====================================================
# 1. 固定配置
# =====================================================

MODEL_PATH = "/mnt/raid/hss/model/Qwen3-VL-8B-Instruct"

VG_INPUT_ROOT = "/home/chenyi/offline_blaser_qe/dataSet/VG"
VG_IMAGE_DIR = "/home/chenyi/offline_blaser_qe/dataSet/VG/images"

MULTI30K_INPUT_ROOT = "/mnt/raid/cycy/data/txt_multi30k"
MULTI30K_IMAGE_DIR = "/mnt/raid/wjx/vision-rag-mt/images_multi30k"

DTYPE_NAME = "bfloat16"

IMAGE_ID_FIELD = "image_id"

# English -> XX
VG_SOURCE_FIELD = "src_en"
VG_REFERENCE_FIELD = "tgt"

MULTI30K_SOURCE_FIELDS = ["source", "reference_translation"]
MULTI30K_REFERENCE_FIELDS = ["target", "source_text"]

MIN_NEW_TOKENS = 0


# =====================================================
# 2. Prompt
# =====================================================

SYSTEM_PROMPT_TEMPLATE = (
    "/no_think\n"
    "You are a professional translator.\n"
    "Your job is to translate the given {source_lang_name} source sentence into {target_lang_name}.\n"
    "STRICT RULES:\n"
    "1) Faithful: Do NOT add, remove, or change objects, attributes, actions, or relations.\n"
    "2) Use the image only when it helps resolve ambiguity.\n"
    "3) Do not turn the task into image captioning.\n"
    "4) Output ONLY the translation in {target_lang_name}. No explanations.\n"
    "5) NEVER output any <think>...</think> content.\n"
)


def build_system_prompt() -> str:
    return SYSTEM_PROMPT_TEMPLATE.format(
        source_lang_name=SOURCE_LANG_NAME,
        target_lang_name=TARGET_LANG_NAME,
    )


def build_user_text(src: str) -> str:
    return (
        f"{SOURCE_LANG_NAME} SOURCE:\n"
        f"{src}\n\n"
        f"Translate into {TARGET_LANG_NAME}."
    )


def build_messages_full(image: Image.Image, source_text: str):
    return [
        {
            "role": "system",
            "content": [{"type": "text", "text": build_system_prompt()}],
        },
        {
            "role": "user",
            "content": [
                {"type": "image", "image": image},
                {"type": "text", "text": build_user_text(source_text)},
            ],
        },
    ]


def build_messages_text_only(source_text: str):
    return [
        {
            "role": "system",
            "content": [{"type": "text", "text": build_system_prompt()}],
        },
        {
            "role": "user",
            "content": [
                {"type": "text", "text": build_user_text(source_text)},
            ],
        },
    ]


def build_messages_image_only(image: Image.Image):
    return [
        {
            "role": "system",
            "content": [{"type": "text", "text": build_system_prompt()}],
        },
        {
            "role": "user",
            "content": [
                {"type": "image", "image": image},
                {"type": "text", "text": build_user_text("[SOURCE SENTENCE HIDDEN]")},
            ],
        },
    ]


# =====================================================
# 3. 数据工具
# =====================================================

def normalize_text(x: Any) -> str:
    if x is None:
        return ""
    return str(x).strip()


def first_non_empty_with_field(row: Dict[str, Any], fields: List[str]) -> Tuple[str, str]:
    for field in fields:
        value = normalize_text(row.get(field, ""))
        if value:
            return value, field
    return "", ""


def get_input_jsonl() -> str:
    if DATASET == "vg":
        return os.path.join(
            VG_INPUT_ROOT,
            LANGUAGE,
            f"{LANGUAGE}_vg_test.jsonl",
        )

    if DATASET == "multi30k":
        return os.path.join(
            MULTI30K_INPUT_ROOT,
            f"en_{LANGUAGE}_test.jsonl",
        )

    raise ValueError(f"Unsupported DATASET: {DATASET}")


def read_jsonl(path: str) -> List[Dict[str, Any]]:
    rows = []

    with open(path, "r", encoding="utf-8") as f:
        for line_idx, line in enumerate(f, start=1):
            line = line.strip()

            if not line:
                continue

            try:
                rows.append(json.loads(line))
            except Exception as e:
                print(f"[WARN] JSON parse failed at line {line_idx}: {e}", flush=True)

    return rows


def get_row_id(row: Dict[str, Any], fallback_idx: int) -> str:
    if DATASET == "vg":
        for key in ["id", "image_id", "qid", "question_id", "sample_index"]:
            value = normalize_text(row.get(key, ""))
            if value:
                return value
        return str(fallback_idx)

    if DATASET == "multi30k":
        for key in ["id", "image_id", "qid", "question_id"]:
            value = normalize_text(row.get(key, ""))
            if value:
                return value

        image_path = normalize_text(row.get("image", row.get("image_path", "")))
        if image_path:
            stem = os.path.splitext(os.path.basename(image_path))[0]
            if stem:
                return stem

        return str(fallback_idx)

    return str(fallback_idx)


def find_target_row(rows: List[Dict[str, Any]]) -> Tuple[Dict[str, Any], int]:
    for idx, row in enumerate(rows, start=1):
        row_id = get_row_id(row, fallback_idx=idx)
        image_id = normalize_text(row.get("image_id", ""))

        if row_id == TARGET_ID or image_id == TARGET_ID:
            return row, idx

    raise ValueError(f"没有找到 target_id={TARGET_ID} 的样本。")


def get_source_and_reference(row: Dict[str, Any]) -> Tuple[str, str, str, str]:
    if DATASET == "vg":
        source_text = normalize_text(row.get(VG_SOURCE_FIELD, ""))
        reference_translation = normalize_text(row.get(VG_REFERENCE_FIELD, ""))
        return source_text, reference_translation, VG_SOURCE_FIELD, VG_REFERENCE_FIELD

    if DATASET == "multi30k":
        source_text, source_field = first_non_empty_with_field(
            row,
            MULTI30K_SOURCE_FIELDS,
        )
        reference_translation, reference_field = first_non_empty_with_field(
            row,
            MULTI30K_REFERENCE_FIELDS,
        )
        return source_text, reference_translation, source_field, reference_field

    raise ValueError(f"Unsupported DATASET: {DATASET}")


def resolve_image_path(row: Dict[str, Any]) -> Optional[str]:
    if DATASET == "vg":
        image_id = normalize_text(row.get(IMAGE_ID_FIELD, ""))

        if not image_id:
            return None

        for ext in [".jpg", ".jpeg", ".png", ".webp", ".JPG", ".JPEG", ".PNG"]:
            path = os.path.join(VG_IMAGE_DIR, image_id + ext)
            if os.path.isfile(path):
                return path

        return None

    if DATASET == "multi30k":
        image_path = normalize_text(row.get("image", ""))

        if image_path and os.path.isfile(image_path):
            return image_path

        for key in ["image_path", "img_path"]:
            path = normalize_text(row.get(key, ""))
            if path and os.path.isfile(path):
                return path

        image_id = normalize_text(row.get("image_id", row.get("id", "")))

        if not image_id:
            return None

        for ext in [".jpg", ".jpeg", ".png", ".webp", ".JPG", ".JPEG", ".PNG"]:
            path = os.path.join(MULTI30K_IMAGE_DIR, image_id + ext)
            if os.path.isfile(path):
                return path

        return None

    raise ValueError(f"Unsupported DATASET: {DATASET}")


def load_rgb_image(path: str) -> Image.Image:
    return Image.open(path).convert("RGB")


# =====================================================
# 4. 模型输入工具
# =====================================================

def get_torch_dtype(name: str):
    if not torch.cuda.is_available():
        return torch.float32

    if name == "float16":
        return torch.float16

    if name == "bfloat16":
        return torch.bfloat16

    return torch.float32


def get_tokenizer(processor):
    tokenizer = getattr(processor, "tokenizer", None)
    if tokenizer is None:
        raise RuntimeError("processor.tokenizer is None")
    return tokenizer


def get_model_device(model) -> torch.device:
    try:
        return model.device
    except Exception:
        return next(model.parameters()).device


def move_inputs_to_model_device_no_dtype_cast(
    inputs: Dict[str, Any],
    model,
) -> Dict[str, Any]:
    device = get_model_device(model)

    moved = {}

    for key, value in inputs.items():
        if hasattr(value, "to"):
            moved[key] = value.to(device)
        else:
            moved[key] = value

    return moved


def prepare_inputs(
    processor,
    model,
    messages,
    image: Optional[Image.Image],
) -> Dict[str, Any]:
    text = processor.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True,
    )

    if image is not None:
        inputs = processor(
            text=[text],
            images=[image],
            padding=True,
            return_tensors="pt",
        )
    else:
        inputs = processor(
            text=[text],
            padding=True,
            return_tensors="pt",
        )

    return move_inputs_to_model_device_no_dtype_cast(
        inputs=inputs,
        model=model,
    )


def prepare_three_condition_inputs(
    processor,
    model,
    image: Image.Image,
    source_text: str,
) -> Dict[str, Dict[str, Any]]:
    return {
        "text": prepare_inputs(
            processor=processor,
            model=model,
            messages=build_messages_text_only(source_text),
            image=None,
        ),
        "full": prepare_inputs(
            processor=processor,
            model=model,
            messages=build_messages_full(image, source_text),
            image=image,
        ),
        "image": prepare_inputs(
            processor=processor,
            model=model,
            messages=build_messages_image_only(image),
            image=image,
        ),
    }


def build_step_inputs(
    base_inputs: Dict[str, Any],
    generated_ids: List[int],
) -> Dict[str, Any]:
    base_input_ids = base_inputs["input_ids"]
    device = base_input_ids.device

    merged = {}

    for key, value in base_inputs.items():
        if key in ["input_ids", "attention_mask"]:
            continue
        merged[key] = value

    if generated_ids:
        gen_tensor = torch.tensor(
            [generated_ids],
            dtype=base_input_ids.dtype,
            device=device,
        )
        input_ids = torch.cat(
            [base_input_ids, gen_tensor],
            dim=1,
        )
    else:
        input_ids = base_input_ids

    if "attention_mask" in base_inputs:
        base_mask = base_inputs["attention_mask"]

        if generated_ids:
            gen_mask = torch.ones(
                (base_mask.shape[0], len(generated_ids)),
                dtype=base_mask.dtype,
                device=base_mask.device,
            )
            attention_mask = torch.cat(
                [base_mask, gen_mask],
                dim=1,
            )
        else:
            attention_mask = base_mask
    else:
        attention_mask = torch.ones_like(input_ids)

    merged["input_ids"] = input_ids
    merged["attention_mask"] = attention_mask

    return merged


def get_next_logits_no_cache(
    model,
    base_inputs: Dict[str, Any],
    generated_ids: List[int],
) -> torch.Tensor:
    step_inputs = build_step_inputs(
        base_inputs=base_inputs,
        generated_ids=generated_ids,
    )

    with torch.inference_mode():
        outputs = model(
            **step_inputs,
            use_cache=False,
        )

    logits = outputs.logits[:, -1, :].float()
    return logits


def sanitize_logits(logits: torch.Tensor) -> torch.Tensor:
    logits = logits.float()
    logits = torch.nan_to_num(
        logits,
        nan=-1e4,
        posinf=1e4,
        neginf=-1e4,
    )
    return logits


def get_condition_logits(
    model,
    condition_inputs: Dict[str, Dict[str, Any]],
    generated_ids: List[int],
    mode: str,
) -> torch.Tensor:
    """
    mode:
      full     -> Text+Image logits_full
      image    -> Image-only logits_image
      contrast -> logits_full + alpha * (logits_full - logits_image)
    """
    if mode == "full":
        logits_full = get_next_logits_no_cache(
            model=model,
            base_inputs=condition_inputs["full"],
            generated_ids=generated_ids,
        )
        return sanitize_logits(logits_full)

    if mode == "image":
        logits_image = get_next_logits_no_cache(
            model=model,
            base_inputs=condition_inputs["image"],
            generated_ids=generated_ids,
        )
        return sanitize_logits(logits_image)

    if mode == "contrast":
        logits_full = get_next_logits_no_cache(
            model=model,
            base_inputs=condition_inputs["full"],
            generated_ids=generated_ids,
        )
        logits_image = get_next_logits_no_cache(
            model=model,
            base_inputs=condition_inputs["image"],
            generated_ids=generated_ids,
        )

        logits_full = sanitize_logits(logits_full)
        logits_image = sanitize_logits(logits_image)

        new_logits = logits_full + CONTRAST_ALPHA * (logits_full - logits_image)
        return sanitize_logits(new_logits)

    raise ValueError(f"Unsupported mode: {mode}")


# =====================================================
# 5. 文本清洗
# =====================================================

def strip_think_blocks(text: str) -> str:
    if not text:
        return text

    text = re.sub(
        r"<think>.*?</think>",
        "",
        text,
        flags=re.DOTALL | re.IGNORECASE,
    )
    text = re.sub(r"</?think>", "", text, flags=re.IGNORECASE)

    return text.strip()


def clean_generation_text(text: str) -> str:
    text = str(text).strip()
    text = re.sub(r"^\s*(translation\s*[:：-]\s*)", "", text, flags=re.I)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def clean_translation_output(text: str) -> str:
    text = strip_think_blocks(text)
    text = clean_generation_text(text)

    bad_prefixes = [
        "Translation:",
        "The translation is:",
        "Output:",
        "Answer:",
        "Final translation:",
        "Final answer:",
    ]

    for prefix in bad_prefixes:
        if text.lower().startswith(prefix.lower()):
            text = text[len(prefix):].strip()

    text = text.strip().strip('"').strip("'").strip()
    text = re.sub(r"\s+", " ", text).strip()

    return text


def decode_ids(
    tokenizer,
    token_ids: List[int],
    skip_special_tokens: bool = True,
) -> str:
    return tokenizer.decode(
        token_ids,
        skip_special_tokens=skip_special_tokens,
        clean_up_tokenization_spaces=False,
    )


def phrase_clean(text: str) -> str:
    text = clean_translation_output(text)
    text = re.sub(r"^[\s,.;:!?，。！？、]+", "", text)
    text = re.sub(r"[\s,.;:!?，。！？、]+$", "", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def visible_word_count(text: str) -> int:
    text = phrase_clean(text)
    if not text:
        return 0
    return len(text.split())


def is_bad_phrase(text: str) -> bool:
    text = phrase_clean(text)

    if len(text) < PHRASE_MIN_CHARS:
        return True

    if re.fullmatch(r"[\s,.;:!?，。！？、\-—_]+", text):
        return True

    if "<|" in text or "|>" in text:
        return True

    if "\n" in text or "\r" in text:
        return True

    return False


def is_phrase_boundary(text: str) -> bool:
    """
    粗略短语边界：
    - 出现标点；
    - 或达到最大词数。
    """
    raw = text.strip()

    if re.search(r"[。！？.!?;；,，]$", raw):
        return True

    clean = phrase_clean(raw)

    if visible_word_count(clean) >= PHRASE_MAX_WORDS:
        return True

    return False


# =====================================================
# 6. 全词表 beam search：短语级绝对概率 top3
# =====================================================

def phrase_beam_search_absolute_topk(
    model,
    processor,
    condition_inputs: Dict[str, Dict[str, Any]],
    prefix_ids: List[int],
    mode: str,
    phrase_topk: int,
    beam_size: int,
    expand_topk: int,
    max_tokens: int,
    min_tokens: int,
) -> List[Dict[str, Any]]:
    tokenizer = get_tokenizer(processor)

    beams = [
        {
            "token_ids": [],
            "sum_logprob": 0.0,
            "token_logprobs": [],
            "finished": False,
        }
    ]

    completed = []

    eos_token_id = getattr(tokenizer, "eos_token_id", None)

    for depth in range(max_tokens):
        new_beams = []

        for beam in beams:
            if beam["finished"]:
                new_beams.append(beam)
                continue

            running_ids = list(prefix_ids) + beam["token_ids"]

            logits = get_condition_logits(
                model=model,
                condition_inputs=condition_inputs,
                generated_ids=running_ids,
                mode=mode,
            )

            log_probs = F.log_softmax(
                logits.float(),
                dim=-1,
            )

            top_logprobs, top_ids = torch.topk(
                log_probs,
                k=expand_topk,
                dim=-1,
            )

            top_logprobs_list = top_logprobs[0].detach().cpu().tolist()
            top_ids_list = top_ids[0].detach().cpu().tolist()

            for next_logprob, next_id in zip(top_logprobs_list, top_ids_list):
                next_id = int(next_id)
                next_logprob = float(next_logprob)

                candidate_ids = beam["token_ids"] + [next_id]
                candidate_logprobs = beam["token_logprobs"] + [next_logprob]
                candidate_sum_logprob = beam["sum_logprob"] + next_logprob

                decoded_raw = decode_ids(
                    tokenizer,
                    candidate_ids,
                    skip_special_tokens=True,
                )
                decoded_clean = phrase_clean(decoded_raw)

                is_eos = (
                    eos_token_id is not None
                    and next_id == int(eos_token_id)
                )

                enough_tokens = len(candidate_ids) >= min_tokens
                bad_phrase = is_bad_phrase(decoded_clean)

                finished = False

                if is_eos:
                    finished = True

                if enough_tokens and is_phrase_boundary(decoded_raw):
                    finished = True

                if len(candidate_ids) >= max_tokens:
                    finished = True

                new_beam = {
                    "token_ids": candidate_ids,
                    "sum_logprob": candidate_sum_logprob,
                    "token_logprobs": candidate_logprobs,
                    "finished": finished,
                }

                if enough_tokens and finished and not bad_phrase:
                    completed.append({
                        "phrase": decoded_clean,
                        "token_ids": candidate_ids,
                        "sum_logprob": candidate_sum_logprob,
                        "token_logprobs": candidate_logprobs,
                    })

                if not finished:
                    new_beams.append(new_beam)

        # 保留当前未结束分支中 sum_logprob 最高的 beam
        new_beams.sort(
            key=lambda x: x["sum_logprob"],
            reverse=True,
        )

        beams = new_beams[:beam_size]

        # 没有可继续扩展的分支，则停止
        if not beams:
            break

    # 如果 completed 太少，则把当前 beam 也作为候选短语纳入
    for beam in beams:
        if len(beam["token_ids"]) < min_tokens:
            continue

        decoded_clean = phrase_clean(
            decode_ids(
                tokenizer,
                beam["token_ids"],
                skip_special_tokens=True,
            )
        )

        if is_bad_phrase(decoded_clean):
            continue

        completed.append({
            "phrase": decoded_clean,
            "token_ids": beam["token_ids"],
            "sum_logprob": beam["sum_logprob"],
            "token_logprobs": beam["token_logprobs"],
        })

    # 去重：同一个短语保留 sum_logprob 更高的路径
    dedup = {}

    for item in completed:
        key = item["phrase"]

        if key not in dedup or item["sum_logprob"] > dedup[key]["sum_logprob"]:
            dedup[key] = item

    results = list(dedup.values())

    results.sort(
        key=lambda x: x["sum_logprob"],
        reverse=True,
    )

    top_results = results[:phrase_topk]

    for item in top_results:
        sum_logprob = float(item["sum_logprob"])
        avg_logprob = sum_logprob / max(1, len(item["token_ids"]))

        # 绝对序列概率：不是候选集合内部归一化
        abs_prob = math.exp(sum_logprob) if sum_logprob > -745 else 0.0

        item["absolute_prob"] = abs_prob
        item["avg_logprob"] = avg_logprob

    return top_results


def make_printable_absolute_topk(
    items: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    out = []

    for item in items:
        out.append({
            "phrase": item["phrase"],
            "absolute_prob": float(f"{item['absolute_prob']:.10e}"),
            "sum_logprob": round(float(item["sum_logprob"]), 6),
            "avg_logprob": round(float(item["avg_logprob"]), 6),
            "token_ids": item["token_ids"],
            "token_logprobs": [
                round(float(x), 6)
                for x in item["token_logprobs"]
            ],
        })

    return out


# =====================================================
# 7. 三条件输出
# =====================================================

def should_print_phrase_step(prefix_text: str) -> bool:
    if not PRINT_AFTER_CONTAINS:
        return True

    return PRINT_AFTER_CONTAINS in prefix_text


def print_absolute_phrase_top3_three_conditions(
    model,
    processor,
    condition_inputs: Dict[str, Dict[str, Any]],
    generated_ids: List[int],
    step_idx: int,
    prefix_text: str,
) -> None:
    modes = [
        ("text_image_full", "Text+Image / logits_full", "full"),
        ("image_only", "Image-only / logits_image", "image"),
        ("contrast", "new_logits = logits_full + alpha * (logits_full - logits_image)", "contrast"),
    ]

    result = {
        "step": step_idx + 1,
        "generated_prefix": prefix_text,
        "alpha": CONTRAST_ALPHA,
        "search_type": "beam_search_over_full_vocabulary",
        "probability_type": "absolute_sequence_probability_product_of_token_probs",
        "beam_size": BEAM_SIZE,
        "expand_topk": EXPAND_TOPK,
        "phrase_max_tokens": PHRASE_MAX_TOKENS,
        "phrase_min_tokens": PHRASE_MIN_TOKENS,
        "phrase_max_words": PHRASE_MAX_WORDS,
        "conditions": {},
    }

    for condition_key, condition_name, mode in modes:
        top_items = phrase_beam_search_absolute_topk(
            model=model,
            processor=processor,
            condition_inputs=condition_inputs,
            prefix_ids=generated_ids,
            mode=mode,
            phrase_topk=PHRASE_TOPK,
            beam_size=BEAM_SIZE,
            expand_topk=EXPAND_TOPK,
            max_tokens=PHRASE_MAX_TOKENS,
            min_tokens=PHRASE_MIN_TOKENS,
        )

        result["conditions"][condition_key] = {
            "condition_name": condition_name,
            "phrase_top3": make_printable_absolute_topk(top_items),
        }

    print(
        json.dumps(
            result,
            ensure_ascii=False,
        ),
        flush=True,
    )


# =====================================================
# 8. 生成：用 contrast 分支走到目标前缀，只输出一次 top3
# =====================================================

def is_eos_token(token_id: int, eos_token_id) -> bool:
    if eos_token_id is None:
        return False

    if isinstance(eos_token_id, int):
        return token_id == eos_token_id

    if isinstance(eos_token_id, (list, tuple, set)):
        return token_id in eos_token_id

    return False


def generate_until_prefix_and_print_top3(
    model,
    processor,
    image: Image.Image,
    source_text: str,
) -> str:
    tokenizer = get_tokenizer(processor)
    eos_token_id = getattr(tokenizer, "eos_token_id", None)

    condition_inputs = prepare_three_condition_inputs(
        processor=processor,
        model=model,
        image=image,
        source_text=source_text,
    )

    generated_ids: List[int] = []

    for step_idx in range(MAX_NEW_TOKENS):
        prefix_text = clean_translation_output(
            decode_ids(
                tokenizer,
                generated_ids,
                skip_special_tokens=True,
            )
        )

        if should_print_phrase_step(prefix_text):
            print_absolute_phrase_top3_three_conditions(
                model=model,
                processor=processor,
                condition_inputs=condition_inputs,
                generated_ids=generated_ids,
                step_idx=step_idx,
                prefix_text=prefix_text,
            )
            return prefix_text

        contrast_logits = get_condition_logits(
            model=model,
            condition_inputs=condition_inputs,
            generated_ids=generated_ids,
            mode="contrast",
        )

        next_id = int(torch.argmax(contrast_logits, dim=-1).item())

        if is_eos_token(next_id, eos_token_id) and step_idx >= MIN_NEW_TOKENS:
            break

        generated_ids.append(next_id)

    final_prefix = clean_translation_output(
        decode_ids(
            tokenizer,
            generated_ids,
            skip_special_tokens=True,
        )
    )

    print(
        json.dumps(
            {
                "warning": "print_after_contains was not reached; printed top3 at final generated prefix instead.",
                "generated_prefix": final_prefix,
            },
            ensure_ascii=False,
        ),
        flush=True,
    )

    print_absolute_phrase_top3_three_conditions(
        model=model,
        processor=processor,
        condition_inputs=condition_inputs,
        generated_ids=generated_ids,
        step_idx=len(generated_ids),
        prefix_text=final_prefix,
    )

    return final_prefix


# =====================================================
# 9. 模型加载
# =====================================================

def load_model_and_processor(dtype: torch.dtype):
    processor = AutoProcessor.from_pretrained(
        MODEL_PATH,
        trust_remote_code=True,
        local_files_only=True,
    )

    model = AutoModelForVision2Seq.from_pretrained(
        MODEL_PATH,
        torch_dtype=dtype,
        device_map="auto",
        trust_remote_code=True,
        local_files_only=True,
    )

    model.eval()

    return model, processor


# =====================================================
# 10. 主程序：只处理一条数据，不保存文件
# =====================================================

def main():
    torch.manual_seed(42)

    input_jsonl = get_input_jsonl()

    if not os.path.exists(input_jsonl):
        raise FileNotFoundError(f"输入文件不存在: {input_jsonl}")

    rows = read_jsonl(input_jsonl)
    row, row_idx = find_target_row(rows)

    row_id = get_row_id(row, fallback_idx=row_idx)
    source_text, reference_translation, source_field, reference_field = get_source_and_reference(row)

    if not source_text:
        raise ValueError(f"target_id={TARGET_ID} 的 source_text 为空。")

    image_path = resolve_image_path(row)

    if not image_path:
        raise FileNotFoundError(f"target_id={TARGET_ID} 无法解析图像路径。")

    print(
        json.dumps(
            {
                "runtime": {
                    "data": DATASET,
                    "data_output_name": DATA_OUTPUT_NAME,
                    "language": LANGUAGE,
                    "target_id": TARGET_ID,
                    "alpha": CONTRAST_ALPHA,
                    "input_jsonl": input_jsonl,
                    "model_path": MODEL_PATH,
                    "no_file_saved": True,
                },
                "target_sample": {
                    "row_idx": row_idx,
                    "id": row_id,
                    "image_id": normalize_text(row.get("image_id", "")),
                    "source_field": source_field,
                    "reference_field": reference_field,
                    "source": source_text,
                    "reference": reference_translation,
                    "image": image_path,
                },
            },
            ensure_ascii=False,
        ),
        flush=True,
    )

    dtype = get_torch_dtype(DTYPE_NAME)
    model, processor = load_model_and_processor(dtype=dtype)

    image = load_rgb_image(image_path)

    try:
        generate_until_prefix_and_print_top3(
            model=model,
            processor=processor,
            image=image,
            source_text=source_text,
        )
    finally:
        try:
            image.close()
        except Exception:
            pass


if __name__ == "__main__":
    main()