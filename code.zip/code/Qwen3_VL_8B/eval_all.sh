#!/bin/bash
set -e

source /home/guozhengyi/anaconda3/envs/evaluate/bin/activate
cd /home/chenyi/offline_blaser_qe/code/Qwen3_VL_8B

python score_text_only_image_prior.py --model qwen3_vl_8b --data vg --lang ha --gpu 6
python score_text_only_image_prior.py --model qwen3_vl_8b --data vg --lang bn --gpu 6
python score_text_only_image_prior.py --model qwen3_vl_8b --data vg --lang hi --gpu 6
python score_text_only_image_prior.py --model qwen3_vl_8b --data vg --lang ma --gpu 6


python score_text_only_image_prior.py --model qwen3_vl_8b --data multi30k --lang hi --gpu 6
python score_text_only_image_prior.py --model qwen3_vl_8b --data multi30k --lang lv --gpu 6
python score_text_only_image_prior.py --model qwen3_vl_8b --data multi30k --lang tr --gpu 6


echo "All  finished."